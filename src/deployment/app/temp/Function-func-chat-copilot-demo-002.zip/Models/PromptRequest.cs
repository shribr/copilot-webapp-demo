﻿// Copyright (c) Microsoft. All rights reserved.

namespace Shared.Models;

public class PromptRequest
{
    public string Prompt { get; set; } = default!;
}
