﻿// Copyright (c) Microsoft. All rights reserved.

namespace Shared.Models;

public enum Approach
{
    RetrieveThenRead,
    ReadRetrieveRead,
    ReadDecomposeAsk,
};
