﻿// Copyright (c) Microsoft. All rights reserved.
public record ImageEmbeddingResponse(string modelVersion, float[] vector);
