public class ChatContext
{
    public string History { get; set; }
    public string UserMessage { get; set; }
}