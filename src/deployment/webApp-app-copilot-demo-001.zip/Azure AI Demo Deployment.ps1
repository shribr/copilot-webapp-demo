#**********************************************************************************************************************
# Script: Azure AI Demo Deployment.ps1
#
# Before executing this script, ensure that you have installed the Azure CLI and PowerShell Core. 
# make sure you have an active Azure subscription and have logged in using the 'az login' command.
# To execute this script, run the following command:
# .\Azure AI Demo Deployment.ps1
# TEST
#**********************************************************************************************************************
<#
.SYNOPSIS
    This script automates the deployment of various Azure resources.

.DESCRIPTION˚¡
    This script reads parameters from a JSON file and uses them to create and configure the following list of Azure resources:
    # 1. storage accounts
    # 2. app service plans
    # 3. search services
    # 4. log analytics workspaces
    # 5. cognitive services accounts
    # 6. key vaults
    # 7. application insights components
    # 8. portal dashboards
    # 9. managed environments
    # 10. user assigned identities
    # 11. web apps
    # 12. function apps
    # 13. Azure OpenAI accounts
    # 14. Document Intelligence accounts

.PARAMETER parametersFile
    The path to the JSON file containing the parameters for the deployment. Default is "parameters.json".
    The list of variables in the parameters file includes:
    # 1. location
    # 2. resourceGroupName
    # 3. resourceSuffix
    # 4. storageAccountName
    # 5. appServicePlanName
    # 6. searchServiceName
    # 7. logAnalyticsWorkspaceName
    # 8. cognitiveServiceName
    # 9. keyVaultName
    # 10. appInsightsName
    # 11. portalDashboardName
    # 12. managedEnvironmentName
    # 13. userAssignedIdentityName
    # 14. webAppName
    # 15. functionAppName
    # 16. openAIName
    # 17. documentIntelligenceName
    # 18. virtualNetworkName
    # 19. subnetName
    # 20. networkSecurityGroupName
    # 21. publicIpAddressName
    # 22. networkInterfaceName
    # 23. virtualMachineName
    # 24. virtualMachineSize
    # 25. adminUsername
    # 26. adminPassword
    # 27. osDiskName
    # 28. osDiskSize
    # 29. dataDiskName
    # 30. dataDiskSize
    # 31. availabilitySetName
    # 32. loadBalancerName
    # 33. backendPoolName
    # 34. healthProbeName
    # 35. loadBalancingRuleName
    # 36. inboundNatRuleName
    # 37. applicationGatewayName
    # 38. gatewayIpConfigName
    # 39. frontendIpConfigName
    # 40. frontendPortName
    # 41. backendAddressPoolName
    # 42. httpSettingsName
    # 43. requestRoutingRuleName
    # 44. sslCertificateName
    # 45. autoscaleSettingName
    # 46. scaleRuleName
    # 47. actionGroupName

.EXAMPLE
    .\Azure\ AI\ Demo\ Deployment.ps1 -parametersFile "myParameters.json"
    This example runs the script using the parameters specified in "myParameters.json".
    .NOTES
        Author: Amis Schreiber
        Date: 2024-09-28
        Version: 1.0
        Additional information: Example script for deploying Azure resources.
        Prerequisites: Azure CLI, PowerShell Core, Azure subscription.
#>

# Set the default parameters file
param (
    [string]$parametersFile = "parameters.json"
)

# Mapping of global resource types
$global:ResourceTypes = @(
    "Microsoft.Storage/storageAccounts",
    "Microsoft.KeyVault/vaults",
    "Microsoft.Sql/servers",
    "Microsoft.DocumentDB/databaseAccounts",
    "Microsoft.Web/serverFarms",
    "Microsoft.Web/sites",
    "Microsoft.DataFactory/factories",
    "Microsoft.ContainerRegistry/registries",
    "Microsoft.CognitiveServices/accounts",
    "Microsoft.Search/searchServices"
)

# List of all KeyVault secret keys
$global:KeyVaultSecrets = @(
    “AzureOpenAiChatGptDeployment”, 
    “AzureOpenAiEmbeddingDeployment”, 
    “AzureOpenAiServiceEndpoint”, 
    “AzureSearchIndex”, 
    “AzureSearchServiceEndpoint”, 
    “AzureStorageAccountEndpoint”, 
    “AzureStorageContainer”, 
    “UseAOAI”, 
    “UseVision”
)

# Initialize the deployment path
$global:deploymentPath = Get-Location

# Initialize the deployment path
$currentLocation = Get-Location
if ($currentLocation.Path -notlike "*src/deployment*") {
    $global:deploymentPath = Join-Path -Path $currentLocation -ChildPath "src/deployment"
} else {
    $global:deploymentPath = $currentLocation
}

Set-Location -Path $global:deploymentPath

# Initialize the existing resources array
$global:existingResources = @()

# Function to get Cognitive Services API key
function Get-CognitiveServicesApiKey {
    param (
        [string]$resourceGroupName,
        [string]$cognitiveServiceName
    )

    try {
        # Run the Azure CLI command and capture the output
        $apiKeysJson = az cognitiveservices account keys list --resource-group $resourceGroupName --name $cognitiveServiceName

        # Parse the JSON output into a PowerShell object
        $apiKeys = $apiKeysJson | ConvertFrom-Json

        # Access the keys
        $key1 = $apiKeys.key1
        $key2 = $apiKeys.key2

        # Output the keys to verify
        Write-Host "Key 1: $key1"
        Write-Host "Key 2: $key2"
        return $key1
    }
    catch {
        Write-Error "Failed to retrieve API key for Cognitive Services resource: (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        return $null
    }
}

# Function to get the latest API version for a resource type
function Get-LatestApiVersion {
    param (
        [string]$resourceProviderNamespace,
        [string]$resourceType
    )

    $apiVersions = az provider show --namespace $resourceProviderNamespace --query "resourceTypes[?resourceType=='$resourceType'].apiVersions[]" --output json | ConvertFrom-Json
    $latestApiVersion = ($apiVersions | Sort-Object -Descending)[0]
    return $latestApiVersion
}

# Function to get the latest .NET runtime version
function Get-LatestDotNetRuntime {
    param(
        [string]$resourceType,
        [string]$os,
        [string]$version
    )

    if ($resourceType -eq "functionapp") {
        $functionRuntimes = az functionapp list-runtimes --output json | ConvertFrom-Json

        if ($os -eq "linux") {
            #$runtimes = $functionRuntimes.linux | Where-Object { $_.runtime -eq 'dotnet' -and $_.version -eq $version } | Select-Object -ExpandProperty version
            $runtimes = $functionRuntimes.linux | Where-Object { $_.runtime -eq 'dotnet' } | Select-Object -ExpandProperty version
        }
        else {
            $runtimes = $functionRuntimes.windows | Where-Object { $_.runtime -eq 'dotnet' } | Select-Object -ExpandProperty version
        }
    }
    elseif ($resourceType -eq "webapp") {
        $webpAppRuntimes = az webapp list-runtimes --output json | ConvertFrom-Json

        if ($os -eq "linux") {
            $runtimes = $webpAppRuntimes.linux | Where-Object { $_.runtime -eq 'dotnet' } | Select-Object -ExpandProperty version
        }
        else {
            $runtimes = $webpAppRuntimes.windows | Where-Object { $_.runtime -eq 'dotnet' } | Select-Object -ExpandProperty version
        }
    }
    else {
        throw "Unsupported resource type: $resourceType"
    }

    $latestRuntime = ($runtimes | Sort-Object -Descending)[0]

    return $latestRuntime
}

# Helper function to get a random integer
function Get-RandomInt {
    param (
        [int]$max
    )

    $random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 4
    $random.GetBytes($bytes)
    [math]::Abs([BitConverter]::ToInt32($bytes, 0)) % $max

    return [math]::Abs([BitConverter]::ToInt32($bytes, 0)) % $max
}

# Function to find a unique suffix and create resources
function Get-UniqueSuffix {
    param (
        [int]$resourceSuffix,
        [string]$resourceGroupName
    )

    $appResourceExists = $true

    do {
        $storageAccountName = "$($parameters.storageAccountName)$resourceGuid$resourceSuffix"
        $appServicePlanName = "$($parameters.appServicePlanName)-$resourceGuid-$resourceSuffix"
        $searchServiceName = "$($parameters.searchServiceName)-$resourceGuid-$resourceSuffix"
        $logAnalyticsWorkspaceName = "$($parameters.logAnalyticsWorkspaceName)-$resourceGuid-$resourceSuffix"
        $cognitiveServiceName = "$($parameters.cognitiveServiceName)-$resourceGuid-$resourceSuffix"
        $keyVaultName = "$($parameters.keyVaultName)-$resourceGuid-$resourceSuffix"
        $appInsightsName = "$($parameters.appInsightsName)-$resourceGuid-$resourceSuffix"
        $portalDashboardName = "$($parameters.portalDashboardName)-$resourceGuid-$resourceSuffix"
        $managedEnvironmentName = "$($parameters.managedEnvironmentName)-$resourceGuid-$resourceSuffix"
        $userAssignedIdentityName = "$($parameters.userAssignedIdentityName)-$resourceGuid-$resourceSuffix"
        $openAIName = "$($parameters.openAIName)-$resourceGuid-$resourceSuffix"
        $documentIntelligenceName = "$($parameters.documentIntelligenceName)-$resourceGuid-$resourceSuffix"
        $aiHubName = "$($aiHubName)-$($resourceGuid)-$($resourceSuffix)"
        $aiModelName = "$($aiModelName)-$($resourceGuid)-$($resourceSuffix)"
        $aiServiceName = "$($aiServiceName)-$($resourceGuid)-$($resourceSuffix)"

        foreach ($appService in $appServices) {
            $appService.Name = "$($appService.Name)-$($resourceGuid)-$($resourceSuffix)"
        }
        
        $resourceExists = Test-ResourceExists $storageAccountName "Microsoft.Storage/storageAccounts" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $appServicePlanName "Microsoft.Web/serverFarms" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $searchServiceName "Microsoft.Search/searchServices" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $logAnalyticsWorkspaceName "Microsoft.OperationalInsights/workspaces" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $cognitiveServiceName "Microsoft.CognitiveServices/accounts" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $keyVaultName "Microsoft.KeyVault/vaults" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $appInsightsName "Microsoft.Insights/components" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $portalDashboardName "Microsoft.Portal/dashboards" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $managedEnvironmentName "Microsoft.App/managedEnvironments" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $userAssignedIdentityName "Microsoft.ManagedIdentity/userAssignedIdentities" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $openAIName "Microsoft.CognitiveServices/accounts" -resourceGroupName $resourceGroupName -or
        Test-ResourceExists $documentIntelligenceName "Microsoft.CognitiveServices/accounts" -resourceGroupName $resourceGroupName

        foreach ($appService in $appServices) {
            $appResourceExists = Test-ResourceExists $appServiceName $appService.Name -resourceGroupName $resourceGroupName -or $resourceExists
            if ($appResourceExists) {
                $resourceExists = $true
                break
            }
        }

        if ($resourceExists) {
            $resourceSuffix++
        }
    } while ($resourceExists)

    <#
    # {    $userPrincipalName = "$($parameters.userPrincipalName)"

        New-Resources -storageAccountName $storageAccountName `
            -appServicePlanName $appServicePlanName `
            -searchServiceName $searchServiceName `
            -logAnalyticsWorkspaceName $logAnalyticsWorkspaceName `
            -cognitiveServiceName $cognitiveServiceName `
            -keyVaultName $keyVaultName `
            -appInsightsName $appInsightsName `
            -portalDashboardName $portalDashboardName `
            -managedEnvironmentName $managedEnvironmentName `
            -userAssignedIdentityName $userAssignedIdentityName `
            -userPrincipalName $userPrincipalName `
            -openAIName $openAIName `
            -documentIntelligenceName $documentIntelligenceName

        foreach ($appService in $appServices) {
            New-AppService -appService $appService -resourceGroupName $resourceGroupName -storageAccountName $storageAccountName
        }

        New-AIHubAndModel -aiHubName $aiHubName -aiModelName $aiModelName -aiModelType $aiModelType -aiModelVersion $aiModelVersion -aiServiceName $aiServiceName -resourceGroupName $resourceGroupName -location $location
    :Enter a comment or description}
    #>
    return $resourceSuffix
}

# Ensure the service name is valid
function Get-ValidServiceName {
    param (
        [string]$serviceName
    )
    # Convert to lowercase
    $serviceName = $serviceName.ToLower()

    # Remove invalid characters
    $serviceName = $serviceName -replace '[^a-z0-9-]', ''

    # Remove leading and trailing dashes
    $serviceName = $serviceName.Trim('-')

    # Remove consecutive dashes
    $serviceName = $serviceName -replace '--+', '-'

    return $serviceName
}

# Function to invoke an Azure REST API method
function Invoke-AzureRestMethod {
    param (
        [string]$method,
        [string]$url,
        [string]$jsonBody = $null
    )

    # Get the access token
    $token = az account get-access-token --query accessToken --output tsv

    $body = $jsonBody | ConvertFrom-Json

    $token = az account get-access-token --query accessToken --output tsv
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type"  = "application/json"
    }

    try {
        $response = Invoke-RestMethod -Method $method -Uri $url -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
        return $response
    }
    catch {
        Write-Host "Error: $_"
        throw $_
    }
}

# Initialize the parameters
function Initialize-Parameters {
    param (
        [string]$parametersFile = "parameters.json"
    )

    # Navigate to the project directory
    Set-DirectoryPath -targetDirectory $global:deploymentPath
        
    # Load parameters from the JSON file
    $parametersObject = Get-Content -Raw -Path $parametersFile | ConvertFrom-Json

    # Initialize global variables for each item in the parameters.json file
    $global:aiHubName = $parametersObject.aiHubName
    $global:aiModelName = $parametersObject.aiModelName
    $global:aiModelType = $parametersObject.aiModelType
    $global:aiModelVersion = $parametersObject.aiModelVersion
    $global:aiServiceName = $parametersObject.aiServiceName
    $global:aiProjectName = $parametersObject.aiProjectName
    $global:apiManagementServiceName = $parametersObject.apiManagementServiceName
    $global:appendUniqueSuffix = $parametersObject.appendUniqueSuffix
    $global:appServicePlanName = $parametersObject.appServicePlanName
    $global:appServices = $parametersObject.appServices
    $global:appInsightsName = $parametersObject.appInsightsName
    $global:blobStorageAccountName = $parametersObject.blobStorageAccountName
    $global:blobStorageContainerName = $parametersObject.blobStorageContainerName
    $global:cognitiveServiceName = $parametersObject.cognitiveServiceName
    $global:containerAppName = $parametersObject.containerAppName
    $global:containerAppsEnvironmentName = $parametersObject.containerAppsEnvironmentName
    $global:containerRegistryName = $parametersObject.containerRegistryName
    $global:cosmosDbAccountName = $parametersObject.cosmosDbAccountName
    $global:documentIntelligenceName = $parametersObject.documentIntelligenceName
    $global:eventHubNamespaceName = $parametersObject.eventHubNamespaceName
    $global:keyVaultName = $parametersObject.keyVaultName
    $global:location = $parametersObject.location
    $global:logAnalyticsWorkspaceName = $parametersObject.logAnalyticsWorkspaceName
    $global:managedIdentityName = $parametersObject.managedIdentityName
    $global:openAIName = $parametersObject.openAIName
    $global:portalDashboardName = $parametersObject.portalDashboardName
    $global:redisCacheName = $parametersObject.redisCacheName
    $global:resourceGroupName = $parametersObject.resourceGroupName
    $global:resourceSuffix = $parametersObject.resourceSuffix
    $global:searchDataSourceName = $parametersObject.searchDataSourceName
    $global:searchServiceName = $parametersObject.searchServiceName
    $global:searchIndexName = $parametersObject.searchIndexName
    $global:searchIndexFieldNames = $parametersObject.searchIndexFieldNames
    $global:searchIndexerName = $parametersObject.searchIndexerName
    $global:serviceBusNamespaceName = $parametersObject.serviceBusNamespaceName
    $global:sharedDashboardName = $parametersObject.sharedDashboardName
    $global:sqlServerName = $parametersObject.sqlServerName
    $global:storageAccountName = $parametersObject.storageAccountName
    $global:userAssignedIdentityName = $parametersObject.userAssignedIdentityName
    $global:virtualNetworkName = $parametersObject.virtualNetworkName
    #$global:objectId = $parametersObject.objectId

    #**********************************************************************************************************************
    # Add the following code to the InitializeParameters function to set the subscription ID, tenant ID, object ID, and user principal name.

    # Retrieve the subscription ID
    $global:subscriptionId = az account show --query "id" --output tsv
    # Retrieve the tenant ID
    $global:tenantId = az account show --query "tenantId" --output tsv
    # Retrieve the object ID of the signed-in user
    $global:objectId = az ad signed-in-user show --query "objectId" --output tsv
    # Retrieve the user principal name
    $global:userPrincipalName = az ad signed-in-user show --query userPrincipalName --output tsv
    # Retrieve the resource GUID
    $global:resourceGuid = Split-Guid


    if ($parametersObject.PSObject.Properties.Name.Contains("objectId")) {
        $global:objectId = $parametersObject.objectId
    }
    else {
        $global:objectId = az ad signed-in-user show --query "objectId" --output tsv

        $parametersObject | Add-Member -MemberType NoteProperty -Name "objectId" -Value $global:objectId
    }
    
    $parametersObject | Add-Member -MemberType NoteProperty -Name "subscriptionId" -Value $global:subscriptionId
    $parametersObject | Add-Member -MemberType NoteProperty -Name "tenantId" -Value $global:tenantId
    $parametersObject | Add-Member -MemberType NoteProperty -Name "userPrincipalName" -Value $global:userPrincipalName
    $parametersObject | Add-Member -MemberType NoteProperty -Name "resourceGuid" -Value $global:resourceGuid

    return @{
        aiHubName                    = $aiHubName
        aiModelName                  = $aiModelName
        aiModelType                  = $aiModelType
        aiModelVersion               = $aiModelVersion
        aiServiceName                = $aiServiceName
        aiProjectName                = $aiProjectName
        apiManagementServiceName     = $apiManagementServiceName
        appendUniqueSuffix           = $appendUniqueSuffix
        appServices                  = $appServices
        appServicePlanName           = $appServicePlanName
        appInsightsName              = $appInsightsName
        blobStorageAccountName       = $blobStorageAccountName
        blobStorageContainerName     = $blobStorageContainerName
        cognitiveServiceName         = $cognitiveServiceName
        containerAppName             = $containerAppName
        containerAppsEnvironmentName = $containerAppsEnvironmentName
        containerRegistryName        = $containerRegistryName
        cosmosDbAccountName          = $cosmosDbAccountName
        documentIntelligenceName     = $documentIntelligenceName
        eventHubNamespaceName        = $eventHubNamespaceName
        keyVaultName                 = $keyVaultName
        location                     = $location
        logAnalyticsWorkspaceName    = $logAnalyticsWorkspaceName
        managedIdentityName          = $managedIdentityName
        openAIName                   = $openAIName
        objectId                     = $objectId
        portalDashboardName          = $portalDashboardName
        redisCacheName               = $redisCacheName
        resourceGroupName            = $resourceGroupName
        resourceGuid                 = $resourceGuid
        resourceSuffix               = $resourceSuffix
        result                       = $result
        searchServiceName            = $searchServiceName
        searchIndexName              = $searchIndexName
        searchIndexFieldNames        = $searchIndexFieldNames
        searchIndexerName            = $searchIndexerName
        serviceBusNamespaceName      = $serviceBusNamespaceName
        searchDataSourceName         = $searchDataSourceName
        sharedDashboardName          = $sharedDashboardName
        sqlServerName                = $sqlServerName
        storageAccountName           = $storageAccountName
        subscriptionId               = $subscriptionId
        tenantId                     = $tenantId
        userAssignedIdentityName     = $userAssignedIdentityName
        userPrincipalName            = $userPrincipalName
        virtualNetworkName           = $virtualNetworkName      
        parameters                   = $parametersObject
    }
}

# Function to create AI Hub and AI Model
function New-AIHubAndModel {
    param (
        [string]$aiHubName,
        [string]$aiModelName,
        [string]$aiModelType,
        [string]$aiModelVersion,
        [string]$aiServiceName,
        [string]$resourceGroupName,
        [string]$location,
        [array]$existingResources
    )
    
    #$aiHubWorkspaceName = "workspace-$aiHubName"

    # Create AI Hub
    if ($existingResources -notcontains $aiHubName) {
        try {
            $ErrorActionPreference = 'Stop'
            az ml workspace create --kind hub --resource-group $resourceGroupName --name $aiHubName
            #az ml connection create --file "ai.connection.yaml" --resource-group $resourceGroupName --workspace-name $aiHubName
            Write-Host "AI Hub: '$aiHubName' created."
            Write-Log -message "AI Hub: '$aiHubName' created." -logFilePath "$currentPath/deployment.log"
        }
        catch {
            # Check if the error is due to soft deletion
            if ($_ -match "has been soft-deleted") {
                try {
                    $ErrorActionPreference = 'Stop'
                    # Attempt to restore the soft-deleted Cognitive Services account
                    az cognitiveservices account recover --name $aiHubName --resource-group $resourceGroupName --location $($location.ToUpper() -replace '\s', '')   --kind AIHub --sku S0 --output none
                    Write-Host "AI Hub '$aiHubName' restored."
                    Write-Log -message "AI Hub '$aiHubName' restored." -logFilePath "$currentPath/deployment.log"
                }
                catch {
                    Write-Error "Failed to restore AI Hub '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                    Write-Log -message "Failed to restore AI Hub '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
                }
            }
            else {
                Write-Error "Failed to create AI Hub '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create AI Hub '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
            }    
        }
    }

    # Create AI Service
    if ($existingResources -notcontains $aiServiceName) {
        try {
            $ErrorActionPreference = 'Stop'
            az cognitiveservices account create --name $aiServiceName --resource-group $resourceGroupName --location $location --kind AIServices --sku S0 --output none
            Write-Host "AI Service: '$aiServiceName' created."
            Write-Log -message "AI Service: '$aiServiceName' created."
        }
        catch {
            Write-Error "Failed to create AI Service '$aiServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create AI Service '$aiServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    Read-AIConnectionFile -resourceGroupName $resourceGroupName -aiServiceName $aiServiceName

    # Try to create an Azure Machine Learning workspace (AI Hub)
    if ($existingResources -notcontains $aiHubName) {
        try {
            $ErrorActionPreference = 'Stop'
            az ml workspace create --kind hub --name $aiHubName --resource-group $resourceGroupName --location $location --output none
            Write-Host "Azure AI Machine Learning workspace '$aiHubName' created."
            Write-Log -message "Azure Machine Learning workspace '$aiHubName' created." -logFilePath "$currentPath/deployment.log"
        }
        catch {
            Write-Error "Failed to create Azure Machine Learning workspace '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Azure Machine Learning workspace '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
        }
    }

    # Create AI Hub connection
    if ($existingResources -notcontains $aiHubName) {
        try {
            az ml connection create --file "ai.connection.yaml" --resource-group $resourceGroupName --workspace-name $aiHubName
            Write-Host "Azure AI Machine Learning Hub connection '$aiHubName' created."
            Write-Log -message "Azure AI Machine Learning Hub connection '$aiHubName' created." -logFilePath "$currentPath/deployment.log"
        }
        catch {
            Write-Error "Failed to create Azure AI Machine Learning Hub connection '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Azure AI Machine Learning Hub connection '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
        }
    }

    # Create AI Model Deployment
    if ($existingResources -notcontains $aiModelName) {

        $modelList = az cognitiveservices model list `
            --location $location `
            --query "[].{Kind:kind, ModelName:model.name, Version:model.version, Format:model.format, LifecycleStatus:model.lifecycleStatus, MaxCapacity:model.maxCapacity, SKUName:model.skus[0].name, DefaultCapacity:model.skus[0].capacity.default}" `
            --output table | Out-String
        
        Write-Host $modelList

        try {
            $ErrorActionPreference = 'Stop'
            az cognitiveservices account deployment create --name $cognitiveServiceName --resource-group $resourceGroupName --deployment-name chat --model-name gpt-4o --model-version "2024-05-13" --model-format OpenAI --sku-capacity 1 --sku-name "S0"
            Write-Host "AI Model deployment: '$aiModelName' created."
            Write-Log -message "AI Model deployment: '$aiModelName' created." -logFilePath "$currentPath/deployment.log"
        }
        catch {
            Write-Error "Failed to create AI Model deployment '$aiModelName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create AI Model deployment '$aiModelName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
        }
    }
    else {
        Write-Host "AI Model '$aiModelName' already exists."
        Write-Log -message "AI Model '$aiModelName' already exists." -logFilePath "$currentPath/deployment.log"
    }

    # Create AI Project
    if ($existingResources -notcontains $aiProjectName) {
        try {
            $ErrorActionPreference = 'Stop'
            az ml workspace create --kind project --hub-id $aiHubName --resource-group $resourceGroupName --name $aiProjectName
            Write-Host "AI project '$aiProjectName' in '$aiHubName' created."
            Write-Log -message  "AI project '$aiProjectName' in '$aiHubName' created." -logFilePath "$currentPath/deployment.log"
        }
        catch {
            Write-Error "Failed to create AI project '$aiProjectName' in '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create AI project '$aiProjectName' in '$aiHubName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
        }
    }
    else {
        Write-Host "AI Project '$aiProjectName' already exists."
        Write-Log -message "AI Project '$aiProjectName' already exists." -logFilePath "$currentPath/deployment.log"
    }

}

# Function to create and deploy app service (either web app or function app)
function New-AppService {
    param (
        [array]$appService,
        [string]$resourceGroupName,
        [string]$storageAccountName
    )

    #Set-DirectoryPath -targetDirectory "src/deployment"
    
    # Navigate to the project directory
    #$currentPath = Get-Location
    #$currentFolderName = Split-Path -Path $currentPath -Leaf

    $appExists = @()

    $ErrorActionPreference = 'Stop'
    
    # Making sure we are in the correct folder depending on the app type
    Set-DirectoryPath -targetDirectory $appService.Path

    $appServiceType = $appService.Type
    $appServiceName = $appService.Name

    try {
        # Compress the function app code
        $zipFilePath = "$appServiceType-$appServiceName.zip"

        if (Test-Path $zipFilePath) {
            Remove-Item $zipFilePath
        }
        
        # compress the function app code
        zip -r $zipFilePath * .env
       
        try {

            if ($appServiceType -eq "webApp") {

                $appExists = az webapp show --name $appServiceName --resource-group $resourceGroupName --query "name" --output tsv

                if (-not $webAppExists) {
                    # Create a new web app
                    az webapp create --name $appServiceName --resource-group $resourceGroupName --plan $appService.AppServicePlan --runtime $appService.Runtime --deployment-source-url $appService.Url
                }
            }
            else {

                # Check if the Function App exists
                $appExists = az functionapp show --name $appService.Name --resource-group $resourceGroupName --query "name" --output tsv

                if (-not $appExists) {
                    # Create a new function app
                    az functionapp create --name $appServiceName --resource-group $resourceGroupName --storage-account $storageAccountName --runtime $appService.Runtime --os-type "Windows" --consumption-plan-location $appService.Location --output none
                }
            }

            if (-not $appExists) {

                Write-Host "$appServiceType app '$appServiceName' created."
                Write-Log -message "$appServiceType app '$appServiceName' created. Moving on to deployment." -logFilePath "$currentPath/deployment.log"
            }
            else {              
                Write-Host "$appServiceType app '$appServiceName' already exists. Moving on to deployment."
                Write-Log -message "$appServiceType app '$appServiceName' already exists. Moving on to deployment." -logFilePath "$currentPath/deployment.log"
            }

            try {
                if ($appService.Type -eq "webApp") {
                    # Deploy the web app
                    az webapp deployment source config-zip --name $appServiceName --resource-group $resourceGroupName --src $zipFilePath
                }
                else {
                    # Deploy the function app
                    az functionapp deployment source config-zip --name $appServiceName --resource-group $resourceGroupName --src $zipFilePath
                }

                Write-Host "$appServiceType app '$appServiceName' deployed successfully."
                Write-Log -message "$appServiceType app '$appServiceName' deployed successfully." -logFilePath "$currentPath/deployment.log"
            }
            catch {
                Write-Error "Failed to deploy $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to deploy $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
            }
        }
        catch {
            Write-Error "Failed to create $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
        }
    }
    catch {
        Write-Error "Failed to zip $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to zip $appServiceType app '$appServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_" -logFilePath "$currentPath/deployment.log"
    }

    Set-DirectoryPath -targetDirectory $global:deploymentPath
}

# Function to get the latest API version
function New-RandomPassword {
    param (
        [int]$length = 16,
        [int]$nonAlphanumericCount = 2
    )

    try {
        $alphanumericChars = [char[]]"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray()
        $nonAlphanumericChars = [char[]]"!@#$%^&*()-_=+[]{}|;:,.<>?/~".ToCharArray()
    
        $passwordChars = New-Object char[] $length
    
        for ($i = 0; $i -lt ($length - $nonAlphanumericCount); $i++) {
            $passwordChars[$i] = $alphanumericChars[(Get-Random -Maximum $alphanumericChars.Length)]
        }
    
        for ($i = ($length - $nonAlphanumericCount); $i -lt $length; $i++) {
            $passwordChars[$i] = $nonAlphanumericChars[(Get-Random -Maximum $nonAlphanumericChars.Length)]
        }
    
        #Shuffle the characters to ensure randomness
        for ($i = 0; $i -lt $length; $i++) {
            $j = $random.GetInt32($length)
            $temp = $passwordChars[$i]
            $passwordChars[$i] = $passwordChars[$j]
            $passwordChars[$j] = $temp
        }
    
        return -join $passwordChars
    }
    catch {
        Write-Error "Failed to generate random password: (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to generate random password: (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        return $null
    }
}

# Function to create resources
function New-Resources {
    param (
        [string]$storageAccountName,
        [string]$appServicePlanName,
        [string]$searchServiceName,
        [string]$searchIndexName,
        [string]$searchIndexerName,
        [string]$searchDatasourceName,
        [string]$logAnalyticsWorkspaceName,
        [string]$cognitiveServiceName,
        [string]$keyVaultName,
        [string]$appInsightsName,
        [string]$portalDashboardName,
        [string]$managedEnvironmentName,
        [string]$userAssignedIdentityName,
        [string]$userPrincipalName,
        [string]$openAIName,
        [string]$documentIntelligenceName,
        [array]$existingResources
    )

    # Get the latest API versions
    #$storageApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.Storage" -resourceType "storageAccounts"
    #$appServiceApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.Web" -resourceType "serverFarms"
    #$searchApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.Search" -resourceType "searchServices"
    #$logAnalyticsApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.OperationalInsights" -resourceType "workspaces"
    #$cognitiveServicesApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.CognitiveServices" -resourceType "accounts"
    #$keyVaultApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.KeyVault" -resourceType "vaults"
    #$appInsightsApiVersion = Get-LatestApiVersion -resourceProviderNamespace "Microsoft.Insights" -resourceType "components"
   
    # Debug statements to print variable values
    Write-Host "subscriptionId: $subscriptionId"
    Write-Host "resourceGroupName: $resourceGroupName"
    Write-Host "storageAccountName: $storageAccountName"
    Write-Host "appServicePlanName: $appServicePlanName"
    Write-Host "location: $location"
    Write-Host "userPrincipalName: $userPrincipalName"

    # **********************************************************************************************************************
    # Create a storage account

    if ($existingResources -notcontains $storageAccountName) {

        try {
            az storage account create --name $storageAccountName --resource-group $resourceGroupName --location $location --sku Standard_LRS --kind StorageV2 --output none
            Write-Host "Storage account '$storageAccountName' created."
            Write-Log -message "Storage account '$storageAccountName' created."
        }
        catch {
            Write-Error "Failed to create Storage Account '$storageAccountName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Storage Account '$storageAccountName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "Storage account '$storageAccountName' already exists."
        Write-Log -message "Storage account '$storageAccountName' already exists."
    }

    #$storageAccessKey = az storage account keys list --account-name $storageAccountName --resource-group $resourceGroupName --query "[0].value" --output tsv
    #$storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=$storageAccountName;AccountKey=$storageAccessKey;EndpointSuffix=core.windows.net"

    # **********************************************************************************************************************
    # Create an App Service Plan

    if ($existingResources -notcontains $appServicePlanName) {
        try {
            az appservice plan create --name $appServicePlanName --resource-group $resourceGroupName --location $location --sku B1 --output none
            Write-Host "App Service Plan '$appServicePlanName' created."
            Write-Log -message "App Service Plan '$appServicePlanName' created."
        }
        catch {
            Write-Error "Failed to create App Service Plan '$appServicePlanName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create App Service Plan '$appServicePlanName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "App Service Plan '$appServicePlanName' already exists."
        Write-Log -message "App Service Plan '$appServicePlanName' already exists."
    }

    # **********************************************************************************************************************
    # Create a Search Service

    if ($existingResources -notcontains $searchServiceName) {

        $searchServiceName = Get-ValidServiceName -serviceName $searchServiceName
        #$searchServiceSku = "basic"

        try {
            az search service create --name $searchServiceName --resource-group $resourceGroupName --location $location --sku basic --output none
            Write-Host "Search Service '$searchServiceName' created."
            Write-Log -message "Search Service '$searchServiceName' created."
        }
        catch {
            Write-Error "Failed to create Search Service '$searchServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Search Service '$searchServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "Search Service '$searchServiceName' already exists."
        Write-Log -message "Search Service '$searchServiceName' already exists."
    }

    # **********************************************************************************************************************
    # Create a Log Analytics Workspace

    $logAnalyticsWorkspaceName = Get-ValidServiceName -serviceName $logAnalyticsWorkspaceName

    if ($existingResources -notcontains $logAnalyticsWorkspaceName) {
        try {
            $ErrorActionPreference = 'Stop'
            az monitor log-analytics workspace create --workspace-name $logAnalyticsWorkspaceName --resource-group $resourceGroupName --location $location --output none
            Write-Host "Log Analytics Workspace '$logAnalyticsWorkspaceName' created."
            Write-Log -message "Log Analytics Workspace '$logAnalyticsWorkspaceName' created."
        }
        catch {
            Write-Error "Failed to create Log Analytics Workspace '$logAnalyticsWorkspaceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Log Analytics Workspace '$logAnalyticsWorkspaceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "Log Analytics workspace '$logAnalyticsWorkspaceName' already exists."
        Write-Log -message "Log Analytics workspace '$logAnalyticsWorkspaceName' already exists."
    }

    #**********************************************************************************************************************
    # Create an Application Insights component

    if ($existingResources -notcontains $appInsightsName) {


        $appInsightsName = Get-ValidServiceName -serviceName $appInsightsName

        # Try to create an Application Insights component
        try {
            $ErrorActionPreference = 'Stop'
            az monitor app-insights component create --app $appInsightsName --location $location --resource-group $resourceGroupName --application-type web --output none
            Write-Host "Application Insights component '$appInsightsName' created."
            Write-Log -message "Application Insights component '$appInsightsName' created."
        }
        catch {
            Write-Error "Failed to create Application Insights component '$appInsightsName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create Application Insights component '$appInsightsName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "Application Insights '$appInsightsName' already exists."
        Write-Log -message "Application Insights '$appInsightsName' already exists."
    }

    #**********************************************************************************************************************
    # Create a Cognitive Services account

    $cognitiveServiceName = Get-ValidServiceName -serviceName $cognitiveServiceName

    if ($existingResources -notcontains $cognitiveServiceName) {
        try {
            $ErrorActionPreference = 'Stop'
            az cognitiveservices account create --name $cognitiveServiceName --resource-group $resourceGroupName --location $location --sku S0 --kind CognitiveServices --output none
            Write-Host "Cognitive Services account '$cognitiveServiceName' created."
            Write-Log -message "Cognitive Services account '$cognitiveServiceName' created."
        }
        catch {
            # Check if the error is due to soft deletion
            if ($_ -match "has been soft-deleted") {
                try {
                    # Attempt to restore the soft-deleted Cognitive Services account
                    az cognitiveservices account recover --name $cognitiveServiceName --resource-group $resourceGroupName --location $location
                    Write-Host "Cognitive Services account '$cognitiveServiceName' restored."
                    Write-Log -message "Cognitive Services account '$cognitiveServiceName' restored."
                }
                catch {
                    Write-Error "Failed to restore Cognitive Services account '$cognitiveServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                    Write-Log -message "Failed to restore Cognitive Services account '$cognitiveServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                }
            }
            else {
                Write-Error "Failed to create Cognitive Services account '$cognitiveServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create Cognitive Services account '$cognitiveServiceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            } 
        }
    }
    else {
        Write-Host "Cognitive Service '$cognitiveServiceName' already exists."
        Write-Log -message "Cognitive Service '$cognitiveServiceName' already exists."
    }

    #**********************************************************************************************************************
    # Create User Assigned Identity

    if ($existingResources -notcontains $userAssignedIdentityName) {
        try {
            $ErrorActionPreference = 'Stop'
            az identity create --name $userAssignedIdentityName --resource-group $resourceGroupName --location $location --output none
            Write-Host "User Assigned Identity '$userAssignedIdentityName' created."
            Write-Log -message "User Assigned Identity '$userAssignedIdentityName' created."

            # Construct the fully qualified resource ID for the User Assigned Identity
            try {
                $ErrorActionPreference = 'Stop'
                #$userAssignedIdentityResourceId = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.ManagedIdentity/userAssignedIdentities/$userAssignedIdentityName"
                $scope = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName"
                $roles = @("Contributor", "Cognitive Services OpenAI User", "Search Index Data Reader", "Storage Blob Data Reader")  # List of roles to assign
                $assigneePrincipalId = az identity show --resource-group $resourceGroupName --name $userAssignedIdentityName --query 'principalId' --output tsv
            
                foreach ($role in $roles) {
                    az role assignment create --assignee $assigneePrincipalId --role $role --scope $scope

                    Write-Host "User '$userAssignedIdentityName' assigned to role: '$role'."
                    Write-Log -message "User '$userAssignedIdentityName' assigned to role: '$role'."
                }
            }
            catch {
                Write-Error "Failed to assign role for Identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to assign role for Identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            }
        }
        catch {
            Write-Error "Failed to create User Assigned Identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to create User Assigned Identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
    else {
        Write-Host "Identity '$userAssignedIdentityName' already exists."
        Write-Log -message "Identity '$userAssignedIdentityName' already exists."
    }

    $useRBAC = $false

    #**********************************************************************************************************************
    # Create Key Vault

    if ($existingResources -notcontains $keyVaultName) {

        try {
            $ErrorActionPreference = 'Stop'
            if ($useRBAC) {
                az keyvault create --name $keyVaultName --resource-group $resourceGroupName --location $location --enable-rbac-authorization $true --output none
                Write-Host "Key Vault: '$keyVaultName' created with RBAC enabled."
                Write-Log -message "Key Vault: '$keyVaultName' created with RBAC enabled."

                # Assign RBAC roles to the managed identity
                Set-RBACRoles -userAssignedIdentityName $userAssignedIdentityName
            }
            else {
                az keyvault create --name $keyVaultName --resource-group $resourceGroupName --location $location --enable-rbac-authorization $false --output none
                Write-Host "Key Vault: '$keyVaultName' created with Vault Access Policies."
                Write-Log -message "Key Vault: '$keyVaultName' created with Vault Access Policies."

                # Set vault access policies for user
                Set-KeyVaultAccessPolicies -keyVaultName $keyVaultName -resourceGroupName $resourceGroupName -userPrincipalName $userPrincipalName
            }
        }
        catch {
            # Check if the error is due to soft deletion
            if ($_ -match "has been soft-deleted") {
                Restore-SoftDeletedResource -resourceName $keyVaultName -resourceType $resourceType -"KeyVault" $resourceGroupName -useRBAC -userAssignedIdentityName $userAssignedIdentityName
            }
            else {
                Write-Error "Failed to create Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            }
        }

        Set-KeyVaultRoles -keyVaultName $keyVaultName `
            -resourceGroupName $resourceGroupName `
            -userAssignedIdentityName $userAssignedIdentityName `
            -userPrincipalName $userPrincipalName `
            -useRBAC $useRBAC

        Set-KeyVaultSecrets -keyVaultName $keyVaultName `
            -resourceGroupName $resourceGroupName
    }
    else {
        Write-Host "Key Vault '$keyVaultName' already exists."
        Write-Log -message "Key Vault '$keyVaultName' already exists."
    }

    #**********************************************************************************************************************
    # Create OpenAI account

    if ($existingResources -notcontains $openAIName) {

        try {
            $ErrorActionPreference = 'Stop'
            az cognitiveservices account create --name $openAIName --resource-group $resourceGroupName --location $location --kind OpenAI --sku S0 --output none
            Write-Host "Azure OpenAI account '$openAIName' created."
            Write-Log -message "Azure OpenAI account '$openAIName' created."
        }
        catch {
            # Check if the error is due to soft deletion
            if ($_ -match "has been soft-deleted") {
                try {
                    $ErrorActionPreference = 'Stop'
                    # Attempt to restore the soft-deleted Cognitive Services account
                    az cognitiveservices account recover --name $openAIName --resource-group $resourceGroupName --location $($location.ToUpper() -replace '\s', '')   --kind OpenAI --sku S0 --output none
                    Write-Host "OpenAI account '$openAIName' restored."
                    Write-Log -message "OpenAI account '$openAIName' restored."
                }
                catch {
                    Write-Error "Failed to restore OpenAI account '$openAIName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                    Write-Log -message "Failed to restore OpenAI account '$openAIName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                }
            }
            else {
                Write-Error "Failed to create Azure OpenAI account '$openAIName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create Azure OpenAI account '$openAIName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            }   
        }
    }
    else {
        Write-Host "OpenAI Service '$openAIName' already exists."
        Write-Log -message "OpenAI Service '$openAIName' already exists."
    }

    #**********************************************************************************************************************
    # Create Document Intelligence account

    if ($existingResources -notcontains $documentIntelligenceName) {

        $availableLocations = az cognitiveservices account list-skus --kind FormRecognizer --query "[].locations" --output tsv

        # Check if the desired location is available
        if ($availableLocations -contains $($location.ToUpper() -replace '\s', '')  ) {
            # Try to create a Document Intelligence account
            try {
                $ErrorActionPreference = 'Stop'
                az cognitiveservices account create --name $documentIntelligenceName --resource-group $resourceGroupName --location $($location.ToUpper() -replace '\s', '')   --kind FormRecognizer --sku S0 --output none
                Write-Host "Document Intelligence account '$documentIntelligenceName' created."
                Write-Log -message "Document Intelligence account '$documentIntelligenceName' created."
            }
            catch {     
                # Check if the error is due to soft deletion
                if ($_ -match "has been soft-deleted") {
                    try {
                        $ErrorActionPreference = 'Stop'
                        # Attempt to restore the soft-deleted Cognitive Services account
                        az cognitiveservices account recover --name $documentIntelligenceName --resource-group $resourceGroupName --location $($location.ToUpper() -replace '\s', '')   --kind FormRecognizer --sku S0 --output none
                        Write-Host "Document Intelligence account '$documentIntelligenceName' restored."
                        Write-Log -message "Document Intelligence account '$documentIntelligenceName' restored."
                    }
                    catch {
                        Write-Error "Failed to restore Document Intelligence account '$documentIntelligenceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                        Write-Log -message "Failed to restore Document Intelligence account '$documentIntelligenceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                    }
                }
                else {
                    Write-Error "Failed to create Document Intelligence account '$documentIntelligenceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                    Write-Log -message "Failed to create Document Intelligence account '$documentIntelligenceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                }        
            }
        }
        else {
            Write-Error "The desired location '$location' is not available for FormRecognizer."
            Write-Log -message "The desired location '$location' is not available for FormRecognizer."
        }
    }
    else {
        Write-Host "Document Intelligence Service '$documentIntelligenceName' already exists."
        Write-Log -message "Document Intelligence Service '$documentIntelligenceName' already exists."
    }
}

# Function to read AI connection file
function Read-AIConnectionFile {
    param (
        [string]$resourceGroupName,
        [string]$aiServiceName
    )

    $filePath = "ai.connection.yaml"

    $apiKey = Get-CognitiveServicesApiKey -resourceGroupName $resourceGroupName -cognitiveServiceName $cognitiveServiceName

    $content = @"
name: $aiServiceName
type: azure_ai_services
endpoint: https://eastus.api.cognitive.microsoft.com/
api_key: $apiKey
ai_services_resource_id: /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.CognitiveServices/accounts/$aiServiceName
"@

    try {
        $content | Out-File -FilePath $filePath -Encoding utf8 -Force
        Write-Host "File 'ai.connection.yaml' created and populated."
        Write-Log -message "File 'ai.connection.yaml' created and populated."
    }
    catch {
        Write-Error "Failed to create or write to 'ai.connection.yaml': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to create or write to 'ai.connection.yaml': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
    }
}

# Function to delete Azure resource groups
function Remove-AzureResourceGroups {
    $resourceGroups = az group list --query "[?starts_with(name, 'myResourceGroup')].name" --output tsv

    foreach ($rg in $resourceGroups) {
        try {
            az group delete --name $rg --yes --output none
            Write-Host "Resource group '$rg' deleted."
            Write-Log -message "Resource group '$rg' deleted."
        }
        catch {
            Write-Error "Failed to delete Resource Group: $_ (Line $_.InvocationInfo.ScriptLineNumber)"
            Write-Log -message "Failed to delete Resource Group: $_ (Line $_.InvocationInfo.ScriptLineNumber)"
        }
    }
}

# Function to restore soft-deleted resources
function Restore-SoftDeletedResource {
    param(
        [string]$resourceName,
        [string]$resourceType,
        [string]$resourceGroupName,
        [string]$location,
        [string]$useRBAC,
        [string]$userAssignedIdentityName
    )

    if ($resourceType -eq "KeyVault") {
        if ($useRBAC) {
            try {
                $ErrorActionPreference = 'Stop'
                # Attempt to restore the soft-deleted Key Vault
                az keyvault recover --name $resourceName --resource-group $resourceGroupName --location $location --enable-rbac-authorization $true --output none
                Write-Host "Key Vault: '$resourceName' created with Vault Access Policies."
                Write-Log -message "Key Vault: '$resourceName' created with Vault Access Policies."

                # Assign RBAC roles to the managed identity
                Set-RBACRoles -userAssignedIdentityName $userAssignedIdentityName
            }
            catch {
                Write-Error "Failed to create Key Vault '$resourceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create Key Vault '$resourceName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            }
        }
        else {
            try {
                $ErrorActionPreference = 'Stop'
                # Attempt to restore the soft-deleted Key Vault
                az keyvault recover --name $keyVaultName --resource-group $resourceGroupName --location $location --enable-rbac-authorization $false --output none
                Write-Host "Key Vault: '$keyVaultName' created with Vault Access Policies."
                Write-Log -message "Key Vault: '$keyVaultName' created with Vault Access Policies."

                Set-KeyVaultAccessPolicies -keyVaultName $keyVaultName -resourceGroupName $resourceGroupName -userPrincipalName $userPrincipalName
            }
            catch {
                Write-Error "Failed to create Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
                Write-Log -message "Failed to create Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            }
        }
    }
}

# Function to set the directory location
function Set-DirectoryPath {
    param (
        [string]$targetDirectory
    )

    # Debug output to check the input
    Write-Host "Target Directory: $targetDirectory"

    # Get the root directory from the global variable
    $rootDirectory = $global:deploymentPath

    # Debug output to check the root directory
    Write-Host "Root Directory: $rootDirectory"

    # Get the current directory
    $currentDirectory = Get-Location

    # Debug output to check the current directory
    Write-Host "Current Directory: $currentDirectory"

    # Check if the current path is already equal to the root directory
    if ($currentDirectory.Path -notlike $rootDirectory) {
        # Check if the root directory exists
        if (Test-Path -Path $rootDirectory) {
            # Set location to the root directory
            Set-Location -Path $rootDirectory
            Write-Host "Changed directory to root: $rootDirectory"
        } else {
            throw "Root directory '$rootDirectory' does not exist."
        }
    } else {
        Write-Host "Already in the root directory: $rootDirectory"
        return
    }

    # Split the target directory into array
    $targetPathArray = $targetDirectory -split '\\|/'

    # Traverse down to the target directory
    foreach ($level in $targetPathArray) {
        Set-Location $level
    }

    # Verify the final path
    if ((Get-Location).Path -ne (Resolve-Path -Path $targetDirectory).Path) {
        throw "Failed to set the directory to $targetDirectory"
    }
}

# Function to set Key Vault access policies
function Set-KeyVaultAccessPolicies {
    param([string]$keyVaultName, 
        [string]$resourceGroupName, 
        [string]$userPrincipalName)
    
    try {
        $ErrorActionPreference = 'Stop'
        # Set policy for the user
        az keyvault set-policy --name $keyVaultName --resource-group $resourceGroupName --upn $userPrincipalName --key-permissions get list update create import delete backup restore recover purge encrypt decrypt unwrapKey wrapKey --secret-permissions get list set delete backup restore recover purge --certificate-permissions get list delete create import update managecontacts getissuers listissuers setissuers deleteissuers manageissuers recover purge
        Write-Host "Key Vault '$keyVaultName' policy permissions set for user: '$userPrincipalName'."
        Write-Log -message "Key Vault '$keyVaultName' policy permissions set for user: '$userPrincipalName'."
    }
    catch {
        Write-Error "Failed to set Key Vault '$keyVaultName' policy permissions for user '$userPrincipalName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to set Key Vault '$keyVaultName' policy permissions for user '$userPrincipalName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
    }
}

#Create Key Vault Roles
function Set-KeyVaultRoles {
    param (
        [string]$keyVaultName,
        [string]$resourceGroupName,
        [string]$userAssignedIdentityName,
        [string]$userPrincipalName,
        [bool]$useRBAC,
        [string]$location
    )

    # Set policy for the application
    try {
        $ErrorActionPreference = 'Stop'
        az keyvault set-policy --name $keyVaultName --resource-group $resourceGroupName --spn $userAssignedIdentityName --key-permissions get list update create import delete backup restore recover purge encrypt decrypt unwrapKey wrapKey --secret-permissions get list set delete backup restore recover purge --certificate-permissions get list delete create import update managecontacts getissuers listissuers setissuers deleteissuers manageissuers recover purge
        Write-Host "Key Vault '$keyVaultName' policy permissions set for application: '$userAssignedIdentityName'."
        Write-Log -message "Key Vault '$keyVaultName' policy permissions set for application: '$userAssignedIdentityName'."
    }
    catch {
        Write-Error "Failed to set Key Vault '$keyVaultName' policy permissions for application: '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to set Key Vault '$keyVaultName' policy permissions for application: '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
    }
}

# Function to create secrets in Key Vault
function Set-KeyVaultSecrets {
    param (
        [string]$keyVaultName,
        [string]$resourceGroupName
    )
    # Loop through the array of secrets and store each one in the Key Vault
    foreach ($secretName in $global:KeyVaultSecrets) {
        # Generate a random value for the secret
        #$secretValue = New-RandomPassword
        $secretValue = "TESTSECRET"

        try {
            $ErrorActionPreference = 'Stop'
            az keyvault secret set --vault-name $keyVaultName --name $secretName --value $secretValue --output none
            Write-Host "Secret: '$secretName' stored in Key Vault: '$keyVaultName'."
            Write-Log -message "Secret: '$secretName' stored in Key Vault: '$keyVaultName'."
        }
        catch {
            Write-Error "Failed to store secret '$secretName' in Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
            Write-Log -message "Failed to store secret '$secretName' in Key Vault '$keyVaultName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        }
    }
}

# Function to assign RBAC roles to a managed identity
function Set-RBACRoles {
    params(
        [string]$userAssignedIdentityName
    )
    try {
        $ErrorActionPreference = 'Stop'
        $scope = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName"
                
        az role assignment create --role "Key Vault Administrator" --assignee $userAssignedIdentityName --scope $scope
        az role assignment create --role "Key Vault Secrets User" --assignee $userAssignedIdentityName --scope $scope
        az role assignment create --role "Key Vault Certificates User" --assignee $userAssignedIdentityName --scope $scope
        az role assignment create --role "Key Vault Crypto User" --assignee $userAssignedIdentityName --scope $scope

        Write-Host "RBAC roles assigned to managed identity: '$userAssignedIdentityName'."
        Write-Log -message "RBAC roles assigned to managed identity: '$userAssignedIdentityName'."
    }
    catch {
        Write-Error "Failed to assign RBAC roles to managed identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
        Write-Log -message "Failed to assign RBAC roles to managed identity '$userAssignedIdentityName': (Line $($_.InvocationInfo.ScriptLineNumber)) : $_"
    }
}

# Function to alphabetize the parameters object
function Get-Parameters-Sorted {
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$Parameters
    )

    # Convert properties to an array and sort them by name
    $sortedProperties = $Parameters.PSObject.Properties | Sort-Object Name

    # Create a new sorted parameters object
    $sortedParametersObject = New-Object PSObject
    foreach ($property in $sortedProperties) {
        $sortedParametersObject | Add-Member -MemberType NoteProperty -Name $property.Name -Value $property.Value
    }

    return $sortedParametersObject
}

# Function to split a GUID and return the first 8 characters
function Split-Guid {

    $newGuid = [guid]::NewGuid().ToString()
    $newGuid = $newGuid -replace "-", ""

    $newGuid = $newGuid.Substring(0, 8)

    return $newGuid
}

# Function to start the deployment
function Start-Deployment {

    $logFilePath = "deployment.log"

    # Initialize the sequence number
    $sequenceNumber = 1

    $deleteResourceGroup = $false

    # Check if the log file exists
    if (Test-Path $logFilePath) {
        # Read all lines from the log file
        $logLines = Get-Content $logFilePath
        # Initialize an array to hold all sequence numbers
        $sequenceNumbers = @()

        # Iterate through each line to find matching sequence numbers
        foreach ($line in $logLines) {
            if ($line -match "\*\*\* LOG SEQUENCE: (\d+) \*\*\*") {
                $sequenceNumbers += [int]$matches[1]
            }
        }

        # If we found any sequence numbers, get the highest one and increment it
        if ($sequenceNumbers.Count -gt 0) {
            $sequenceNumber = ($sequenceNumbers | Measure-Object -Maximum).Maximum + 1
        }
    }

    # Log the current sequence number
    $logMessage = "*** LOG SEQUENCE: $sequenceNumber ***"
    Write-Host $logMessage
    Add-Content -Path $logFilePath -Value $logMessage

    # Start the timer
    $startTime = Get-Date

    if ($deleteResourceGroup -eq $true) {
        # Delete existing resource groups with the same name
        Remove-AzureResourceGroups
    }
    
    # Check if the resource group exists
    $resourceGroupName = Test-ResourceGroupExists -resourceGroupName $resourceGroupName -resourceSuffix $resourceSuffix -deleteResourceGroup $deleteResourceGroup

    if ($appendUniqueSuffix -eq $true) {

        # Find a unique suffix
        $resourceSuffix = Get-UniqueSuffix -resourceSuffix $resourceSuffix -resourceGroupName $resourceGroupName

        $existingResources = az resource list --resource-group $resourceGroupName --query "[].name" --output tsv

        New-Resources -storageAccountName $storageAccountName `
            -appServicePlanName $appServicePlanName `
            -searchServiceName $searchServiceName `
            `searchIndexName $searchIndexName `
            `searchIndexerName $searchIndexerName `
            -searchDatasourceName $searchDatasourceName `
            -logAnalyticsWorkspaceName $logAnalyticsWorkspaceName `
            -cognitiveServiceName $cognitiveServiceName `
            -keyVaultName $keyVaultName `
            -appInsightsName $appInsightsName `
            -portalDashboardName $portalDashboardName `
            -managedEnvironmentName $managedEnvironmentName `
            -userAssignedIdentityName $userAssignedIdentityName `
            -userPrincipalName $userPrincipalName `
            -openAIName $openAIName `
            -documentIntelligenceName $documentIntelligenceName `
            -existingResources $existingResources

        foreach ($appService in $appServices) {
            if ($existingResources -notcontains $appService) {
                New-AppService -appService $appService -resourceGroupName $resourceGroupName -storageAccountName $storageAccountName
            }
        }

        New-AIHubAndModel -aiHubName $aiHubName -aiModelName $aiModelName -aiModelType $aiModelType -aiModelVersion $aiModelVersion -aiServiceName $aiServiceName -resourceGroupName $resourceGroupName -location $location -existingResources $existingResources
    }
    else {
        $userPrincipalName = "$($parameters.userPrincipalName)"

        $existingResources = az resource list --resource-group $resourceGroupName --query "[].name" --output tsv

        New-Resources -storageAccountName $storageAccountName `
            -appServicePlanName $appServicePlanName `
            -searchServiceName $searchServiceName `
            `searchIndexName $searchIndexName `
            `searchIndexerName $searchIndexerName `
            -searchDatasourceName $searchDatasourceName `
            -logAnalyticsWorkspaceName $logAnalyticsWorkspaceName `
            -cognitiveServiceName $cognitiveServiceName `
            -keyVaultName $keyVaultName `
            -appInsightsName $appInsightsName `
            -portalDashboardName $portalDashboardName `
            -managedEnvironmentName $managedEnvironmentName `
            -userAssignedIdentityName $userAssignedIdentityName `
            -userPrincipalName $userPrincipalName `
            -openAIName $openAIName `
            -documentIntelligenceName $documentIntelligenceName `
            -existingResources $existingResources

        foreach ($appService in $appServices) {
            if ($existingResources -notcontains $appService) {
                New-AppService -appService $appService -resourceGroupName $resourceGroupName -storageAccountName $storageAccountName
            }
        }

        # Create a new AI Hub and Model
        New-AIHubAndModel -aiHubName $aiHubName -aiModelName $aiModelName -aiModelType $aiModelType -aiModelVersion $aiModelVersion -aiServiceName $aiServiceName -resourceGroupName $resourceGroupName -location $location -existingResources $existingResources
    }

    # End the timer
    $endTime = Get-Date
    $executionTime = $endTime - $startTime

    # Format the execution time
    $executionTimeFormatted = "{0:D2} HRS : {1:D2} MIN : {2:D2} SEC : {3:D3} MS" -f $executionTime.Hours, $executionTime.Minutes, $executionTime.Seconds, $executionTime.Milliseconds

    # Log the total execution time
    $executionTimeMessage = "*** TOTAL SCRIPT EXECUTION TIME: $executionTimeFormatted ***"
    Add-Content -Path $logFilePath -Value $executionTimeMessage

    # Add a line break
    Add-Content -Path $logFilePath -Value ""
}

# Function to check if a resource group exists
function Test-ResourceGroupExists {
    param (
        [int]$resourceSuffix,
        [string]$resourceGroupName,
        [bool]$deleteResourceGroup
    )

    if ($deleteResourceGroup -eq $false) {
        $resourceGroupName = "$($resourceGroupName)-$resourceSuffix"

        $resourceGroupExists = az group exists --resource-group $resourceGroupName --output tsv
    }
    else {
        do {
            $resourceGroupName = "$($resourceGroupName)-$resourceSuffix"
            $resourceGroupExists = az group exists --resource-group $resourceGroupName --output tsv

            try {
                if ($resourceGroupExists -eq "true") {
                    Write-Host "Resource group '$resourceGroupName' exists."
                    $resourceSuffix++
                }
                else {
                    az group create --name $resourceGroupName --location $location --output none
                    Write-Host "Resource group '$resourceGroupName' created."
                    $resourceGroupExists = $false
                        
                }
            }
            catch {
                Write-Error "Failed to create Resource Group: $_ (Line $_.InvocationInfo.ScriptLineNumber)"
                Write-Log -message "Failed to create Resource Group: $_ (Line $_.InvocationInfo.ScriptLineNumber)"
            }

        } while ($resourceGroupExists)

    }

    return $resourceGroupName
}

# Function to check if a resource exists
function Test-ResourceExists {
    param (
        [string]$resourceName,
        [string]$resourceType,
        [string]$resourceGroupName
    )

    if ($global:ResourceTypes -contains $resourceType) {
        switch ($resourceType) {
            "Microsoft.Storage/storageAccounts" {
                $nameAvailable = az storage account check-name --name $resourceName --query "nameAvailable" --output tsv

                if ($nameAvailable -eq "true") {
                    $result = ""
                }
                else {
                    $result = $nameAvailable
                }
            }
            "Microsoft.KeyVault/vaults" {
                $result = az keyvault list --query "[?name=='$resourceName'].name" --output tsv
                $deletedVault = az keyvault list-deleted --query "[?name=='$resourceName'].name" --output tsv

                if (-not [string]::IsNullOrEmpty($deletedVault)) {
                    $result = $true
                }
            }
            "Microsoft.Sql/servers" {
                $result = az sql server list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.DocumentDB/databaseAccounts" {
                $result = az cosmosdb list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.Web/serverFarms" {
                $result = az appservice plan list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.Web/sites" {
                $result = az webapp list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.DataFactory/factories" {
                $result = az datafactory list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.ContainerRegistry/registries" {
                $result = az acr list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.CognitiveServices/accounts" {
                $result = az cognitiveservices account list --query "[?name=='$resourceName'].name" --output tsv
            }
            "Microsoft.Search/searchServices" {
                $result = az search service list --resource-group $resourceGroupName --query "[?name=='$resourceName'].name" --output tsv
            }
        }

        if (-not [string]::IsNullOrEmpty($result)) {
            Write-Host "$resourceName exists."
            return $true
        }
        else {
            Write-Host "$resourceName does not exist."
            return $false
        }
    } 
    else {
        # Check within the subscription
        $result = az resource list --name $resourceName --resource-type $resourceType --query "[].name" --output tsv
        if (-not [string]::IsNullOrEmpty($result)) {
            Write-Host "$resourceName exists."
            return $true
        }
        else {
            Write-Host "$resourceName does not exist."
            return $false
        }
    }
}

# Function to write messages to a log file
function Write-Log {
    param (
        [string]$message,
        [string]$logFilePath = "deployment.log"
    )

    $currentDirectory = (Get-Location).Path

    Set-DirectoryPath -targetDirectory $global:deploymentPath

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "$timestamp - $message"

    Add-Content -Path $logFilePath -Value $logMessage

    Set-DirectoryPath -targetDirectory $currentDirectory
}


#**********************************************************************************************************************
# Main script
#**********************************************************************************************************************

$ErrorActionPreference = 'Stop'

# Initialize parameters
$initParams = Initialize-Parameters -parametersFile $parametersFile
#Write-Host "Parameters initialized."
#Write-Log -message "Parameters initialized."

# Alphabetize the parameters object
$parameters = Get-Parameters-Sorted -Parameters $initParams.parameters

# Set the user-assigned identity name
$userPrincipalName = $parameters.userPrincipalName

Set-DirectoryPath -targetDirectory $global:deploymentPath

# Start the deployment
Start-Deployment

#**********************************************************************************************************************
# End of script
