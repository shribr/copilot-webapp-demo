# Kernel Memory

Source and Docs: <https://github.com/microsoft/kernel-memory>

The solution uses Kernel Memory to provide robust ingest and retrieval through configured Azure services. The [API](API.md) does this by direct reference of the KernelMemory.Core nuget package. The solution also uses a Kernel Memory Service deployment to run the ingest process handlers.

## Deploy App

This step is handled by build and deploy automation. See **file** in project solution in the development environment.

Staging/Production deployment Steps:

-
-

## Configure App Settings

### Authentication Settings

docs at <https://next-auth.js.org/configuration/options>

---

- AzureAd\_\_Instance : `https://login.microsoftonline.com/` (azure cloud login endpoint)
- Audience : api://chatbotapi (Must match the API App registration: Application ID)
- ClientId : _clientid_
- TenantId : _tenantid_
- Scopes\_\_Admin\_\_0 : Admin.All
- Scopes\_\_User\_\_0 : User.All

### Kernel Memory settings

- KernelMemory\_\_Service\_\_RunWebService : false (run the web api service)
- KernelMemory\_\_Service\_\_OpenApiEnabled : false (run the web api swagger service)
- KernelMemory\_\_ContentStorageType : AzureBlobs
- KernelMemory\_\_TextGeneratorType : AzureOpenAIText
- KernelMemory\_\_DataIngestion\_\_OrchestrationType : Distributed
- KernelMemory\_\_DataIngestion\_\_DistributedOrchestration\_\_QueueType : AzureQueues
- KernelMemory\_\_DataIngestion\_\_EmbeddingGenerationEnabled : true,
- KernelMemory\_\_DataIngestion\_\_EmbeddingGeneratorTypes\_\_0 : AzureOpenAIEmbedding
- KernelMemory\_\_DataIngestion\_\_MemoryDbTypes\_\_0 : AzureAISearch
- KernelMemory\_\_DataIngestion\_\_TextPartitioning\_\_MaxTokensPerLine : 300
- KernelMemory\_\_DataIngestion\_\_TextPartitioning\_\_MaxTokensPerParagraph : 1000
- KernelMemory\_\_DataIngestion\_\_TextPartitioning\_\_OverlappingTokens : 100
- KernelMemory\_\_Retrieval\_\_MemoryDbType: AzureAISearch
- KernelMemory\_\_Retrieval\_\_EmbeddingGeneratorType: AzureOpenAIEmbedding

### Kernel Memory Azure service settings - Match the service settings of the [API](API.md) service

---

- KernelMemory\_\_Services\_\_AzureQueues\_\_Auth : ConnectionString (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureQueues\__Account: \_queuesdeploymentname_,
- KernelMemory\_\_Services\_\_AzureQueues\__ConnectionString: \_queuesconnectionstring_,
- KernelMemory\_\_Services\_\_AzureQueues\_\_EndpointSuffix: core.windows.net (azure cloud endpoint)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_Auth: ConnectionString (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_Container: default (blob container to store source documents, chunks, embeddings, pipeline status)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_ConnectionString: _blobsconnectionstring_,
- KernelMemory\_\_Services\_\_AzureBlobs\_\_EndpointSuffix: core.windows.net (azure cloud endpoint)
- KernelMemory\_\_Services\_\_AzureAISearch\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureAISearch\__Endpoint: \_searchendpoint_
- KernelMemory\_\_Services\_\_AzureAISearch\__APIKey: \_searchapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_APIType: ChatCompletion
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureOpenAIText\__Endpoint: \_azureopenaitextendpoint_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_Deployment: gpt-35-turbo (ai chat completion model)
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_MaxTokenTotal: 4096 (max tokens supported by model)
- KernelMemory\_\_Services\_\_AzureOpenAIText\__APIKey: \_azureopenaiapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_MaxRetries: 10 (max ai api connection retries)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\__Endpoint: \_azureopenaitextendpoint_
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\__APIKey: \_azureopenaiapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_Deployment: text-embedding-ada-002 (ai embedding generation model)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_MaxTokenTotal: 8191 (The max number of tokens supported by model deployed)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_APIType: EmbeddingGeneration

## Local Development

The Service is run as a docker container by providing a service configuration appsettings.KMService.json

From a Command Prompt:

```command
> docker run --volume .\appsettings.KMService.json:/app/appsettings.Production.json -it --rm -p 9001:9001 kernelmemory/service
```

Example appsettings.KMService.json

```json
{
  "KernelMemory": {
    "Service": {
      "RunWebService": false,
      "OpenApiEnabled": false
    },
    "ContentStorageType": "AzureBlobs",
    "TextGeneratorType": "AzureOpenAIText",
    "DataIngestion": {
      "OrchestrationType": "Distributed",
      "DistributedOrchestration": {
        "QueueType": "AzureQueues"
      },
      "EmbeddingGenerationEnabled": true,
      "EmbeddingGeneratorTypes": ["AzureOpenAIEmbedding"],
      "MemoryDbTypes": ["AzureAISearch"],
      "TextPartitioning": {
        "MaxTokensPerLine": 300,
        "MaxTokensPerParagraph": 1000,
        "OverlappingTokens": 100
      }
    },
    "Retrieval": {
      "MemoryDbType": "AzureAISearch",
      "EmbeddingGeneratorType": "AzureOpenAIEmbedding"
    },
    "Services": {
      "AzureBlobs": {
        "Auth": "ConnectionString",
        "Account": "[SERVICE]",
        "Container": "smemory",
        "ConnectionString": "DefaultEndpointsProtocol=https;AccountName=[SERVICE];AccountKey=/[KEY];EndpointSuffix=core.windows.net",
        "EndpointSuffix": "core.windows.net"
      },
      "AzureQueues": {
        "Auth": "ConnectionString",
        "Account": "[SERVICE]",
        "ConnectionString": "DefaultEndpointsProtocol=https;AccountName=[SERVICE];AccountKey=/[KEY];EndpointSuffix=core.windows.net",
        "EndpointSuffix": "core.windows.net"
      },
      "AzureAISearch": {
        "Auth": "ApiKey",
        "Endpoint": "https://[SERVICE].search.windows.net",
        "APIKey": "[KEY]"
      },

      "AzureOpenAIText": {
        "APIType": "ChatCompletion",
        "Auth": "ApiKey",
        "Endpoint": "https://[SERVICE].openai.azure.com/",
        "Deployment": "gpt-35-turbo",
        "MaxTokenTotal": 4096,
        "APIKey": "[KEY]",
        "MaxRetries": 10
      },
      "AzureOpenAIEmbedding": {
        "Auth": "ApiKey",
        "Endpoint": "https://[SERVICE].openai.azure.com/",
        "APIKey": "[KEY]",
        "Deployment": "text-embedding-ada-002",
        "MaxTokenTotal": 8191,
        "APIType": "EmbeddingGeneration"
      }
    }
  }
}
```
