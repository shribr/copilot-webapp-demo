# DevOps Overview

## Environments
As of 12/2/2024 we support the following tenants and environments within each (unless otherwise noted, we have a CI/CD pipeline workflow to deploy each environment):

1. **FedAIRS** (This tenant is purely used by the internal team)
   -  'SBX' (Sandbox) -- IL2 infrastructure testing
   -  'Dev' -- IL2 UI/API testing

2. **DISA** (POC: jlunda)
   - 'SBX' -- IL2 adhoc testing, not regularly updated
   - 'Dev' -- IL2 production environment

3. **I3E** (POC: khoaquach)
   - 'SBX' -- IL2 adhoc testing, not regularly updated
   - 'Dev' -- IL2 production environment
   - 'DevGov' -- IL4 production environment --> Note: Currently we build the artifacts within the CI pipeline and deploy manually

4. **GFIM** (POC: jlunda) (used by sale team for demos)
   - 'SBX'  -- IL4 initial environment, needs regular updates

5. **CNATRA** (POC: khoaquach)
   - 'DevGov' -- IL4 production environment --> Note: Currently we build the artifacts within the CI pipeline and deploy manually

### Access and Permissions
All team members have the ability to run our CI/CD pipelines without extra permissions.

There are no standardized roles or permissions across customer tenants, as each have their own requirements/limits for access. In addition, not all team members have access (via portal) to all tenants, given different contracts supporting different people.

## CI/CD Process

### Continous Integration

Purpose: generates percept UI and API zip artifacts and runs unit tests

Parameters:

- Branch name
- Targeted Environment
  - dev, sbx
- Customer
  - I3E, DISA, Fedairs, etc.

Automatically kicked off when:

  1. Pull request is created
  2. Commit to main branch (Typically when a PR is approved and merged to main)

### Continous Deployment

Purpose: Deploy infrastructure (excluding App Registrations and KeyVaults), Update Database Schema, and Deploy web apps to Azure App Service

Parameters:

- Branch name
  - main, feature/*
- Targeted Environment
  - dev, sbx
- Customer
  - I3E, DISA, Fedairs, etc.
- skipInfra
  - True (won't deploy infra), False (will deploy infra)
- skipDbSchema
  - True (won't update db schema), False (will update db schema)

Automatically kicked off when:
  1. Commit to main branch (Typically when a PR is approved and merged to main)

Default parameters will deploy to Fedairs environment

### Pipeline Flowchart
::: mermaid 
graph TD;
    A["Percept API PR + 
       PR Completion Triggers 
       CI Pipeline"];
    B["Pipeline: Percept-CI
       (YAML defined in Percept AI repo)"];
    C["Artifacts:
       Percept_api.zip, Percept_ui.zip"];
    D["[ON HOLD] SQL: 
       (Bundle/Scripts)"];
    E["Percept API Main Branch Triggers CD Pipeline "];
    F["Pipeline: Percept-CD-CrossRepo
       (YAML defined in Percept Infra repo)"];
    G["Generate release tags for customer deployments"]
    H["Deploy App, Infra, Update Database Schema"];
    I["Publish artifacts to this pipeline for quick download, instead of manually finding artifacts with associated build number from CI pipeline"]

    A-->B;
    B-->C;
    B-->D;
    E-->F;
    C-->F;
    D-->F;
    F-->G;
    F-->H;
    F-->I;
:::

### Smoke Test
As of 12/10/2024 these are the steps we perform manually to test a completed deployment. Any specific names that are referenced below from the GFIM/SBX environment. 

1. Hit 'browse' on api web application in portal. By design, we should see a 401 error on the page (there is no swagger page deployed with prod envs). If we see the 401 in a timely manner we assume that it's working as expected
2. Hit 'browse' on ui web application in portal. You may need to be added to a group, Percept AI Global Admins, within the env to see the applications:
3. Create an application (if there's not already one available)
4. Create a new data connector (leave as Documents) (if there's not already one available)
5. Create a new agent (if there's not already one available)
6. Upload a document to your data connector (you may need to modify the network traffic settings for the KM storage account to enable from all networks until private DNS zones are implemented)
7. Ask a question within the app's chat, for your desired agent, that would reference the document that you uploaded.
8. Make sure that the answer contains the citation and that when you click on 'Referenced Documents' you see that the document comes up in the PDF reader
9. Provide feedback for the answer
10. Give yourself 'Feedback Viewer' permission
11. Go to the 'Feedback Review' tab to see your comment and click on it to see the full view
12. Make sure you can see the knowledge sources tab and create a new data connector
13. Swap out the data connector for your original agent

### Misc

If you get the following error,

```Tenant ID, application ID, principal ID, and scope are not allowed to be updated.```

Check for existing role assignments