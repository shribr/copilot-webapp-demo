# Project Overview

This solution enables individuals and organizations to have natural language interactions with their data through with AI memory stores. AI memory stores differ from traditional search index stores by adding vectors to improve query retrievals and provide those retrievals to AI models with prompts to provide focussed and succinct responses.

## Concepts

- Natural language interactions with responses directly from organization sources including citations.
- Sources Ingest to provide knowledge repositories and grounding information for all requests.
- User feedback and review for continuous improvement.
- Administration of all sources with role based security.

## Components

A web application front end provides all of the user and administrative interfaces. The application is integrated with Azure Entra ID to support enterprise single-sign-on and integrated application role based security.

A web API provides standard interfaces for interacting with all required back end services. The API incorporates JWT token based security integrated with Azure Entra ID to restrict access to the endpoints to authorized users and applications. The Microsoft Kernel-Memory (KM) library provides a standard approach to the data and document Ingest and Response processes. The library is used directly by the solution API for Ingest functions such as Index, Memory, and file management and pipeline queuing. It also provides for retrieval of memories directly through Searching, Downloading, and Asking questions for AI response. The Microsoft Semantic-Kernel (SK) library provides Chat History for ongoing contextual conversations.

A web service deployment of the Kernel-Memory service project provides a resilient pipeline that runs the Ingest handlers to extract text, partition text, generate embeddings, and store memories. It is extensible to support custom handlers for processing requirements as well.

The solution requires the following Azure services:

- Azure App Service - for hosting the web UI, API, and KM pipeline service
- Azure Storage Blobs - for persisting files and data in source format as well as extracted text and generated embeddings.
- Azure Storage Queue - for Ingest pipeline processing, resilience, and scale.
- Azure AI Search - for memory storage and retrieval.
- Azure Open AI - for generation of embeddings and natural language responses.
- Azure SQL - for user feedback, prompt management, administrative artifacts.

## Configuration and Deployment

[Web UI](WebUI.md)

[API](API.md)

[Kernel Memory](KernelMemory.md)

### Azure Storage

### Azure AI Search

### Azure Open AI

### Azure SQL
