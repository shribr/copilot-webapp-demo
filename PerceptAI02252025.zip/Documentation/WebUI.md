# Web UI

## Create Entra ID Application registration

Name: chatbot
**Overview** - copy

- [ ] Directory (_tenantid_) ID
- [ ] Application (_clientid_) ID

**Authentication** – Add a platform : Web

Set Redirect URIs

- [ ] Deployed WebApp: (_app url_)/api/auth/callback/azure-ad (\_example for local dev: http://localhost:3000/api/auth/callback/azure-ad)

**Certificates & secrets** – Client secrets

- [ ] New client secret
- [ ] Copy the secret as _clientSecret_

**App Roles** - RBAC

- [ ] Create app role

Allowed member types: Both (Users/Groups + Applications)

Value: admin

Do you want to enable this app role? : checked

**API permissions** - Roles Claims

>Note: If you do not see the exposed API Permissions, make sure you are an Owner on both the UI and API app registrations.

- [ ] Add a permission

- Microsoft APIs -> Microsoft Graph
- Delegated: User.Read, email, profile
- [ ] Grant Admin Consent (allows the application to find users and groups for permission assignments)

**Enterprise Application** - Assign Application Administrators

- Users and groups – Add user/group
- [ ] Select Users and Roles

## Deploy App

This step is handled by build and deploy automation. See **file** in project solution in the development environment.

Staging/Production deployment Steps:

-
-

## Configure Web UI for API scopes

Docs: <https://learn.microsoft.com/en-us/entra/identity-platform/quickstart-configure-app-access-web-apis>

After creation of the [API](API.md) App Registration the Web UI App registration needs to be updated to issue the API scopes.

### Entra App Registrations

- Select chatbot registration

**API permissions** – Add a permission

- Microsoft APIs -> Microsoft Graph
- Delegated: User.Read, email, profile
[ ] Grant Admin Consent (allows the application to find users and groups for permission assignments)

## Configure App Settings

Authentication Settings, docs at <https://next-auth.js.org/configuration/options>

---

i.e client id,  redirect uri, etc.
Reference ```.env.local.sample`` file

Application settings

---

i.e logo, theme, title, etc.

Reference ```.env.local.sample``

---


## Local Development

The web ui is build with React and NextJs

If the [API](API.md) and/or [Kernel Memory](KernelMemory.md) handlers are running locally then start them first.

```nodejs
release build

> npm install
> npm run build
> npm start

or development server

> npm run dev
```
