# Utilizing GitVersion for Semantic Versioning Guide

## GitVersion

GitVersion has been implemented into our `build-web.yml` file to version our application's assemblies and UI. GitVersion looks at all of the ADO check ins to generate a version number that both labels the build itself and makes the different version variables available to the rest of the build pipeline. See [GitVersion](https://gitversion.net/docs/learn/how-it-works) a detailed explanation on how GitVersion works.

## Install GitVersion Locally

To troubleshot GitVersion locally in your repository you should install it via the terminal.

.NET Global Tool

```
dotnet tool install --global GitVersion.Tool
```

OR With Chocolatey

```
choco install gitversion
```

## Branching Strategy and Custom Labeling

To get the most out of GitVerison we need to adhere to the following branching strategies.

1. All branches for active development work should be labeled as `feature/storyNumber-Description`.
2. Once we are ready to make a release we should create a new branch labeled `release/semanticVersionNumber`.
3. To update the major version number for a release due to breaking changes update the `next-verison` tag in the `GitVersion.yml` file.

> **NOTE:** GitVersion has strict branch naming conventions. For example, `bug` is not a suitable branch name for GitVersion. To see all of GitVersion's available branch names see the [default configuration](https://gitversion.net/docs/reference/configuration).

Here is an example of our current `GitVersion.yml` file that is in the root directory.

```
mode: ContinuousDeployment
next-version: 1.0.0
branches:
  hotfix:
    label: bugfix
  feature:
    label: alpha
  release:
    label: ''
```

This file is utilize to override the defaults from GitVersion - in our case, we are using it for custom labels. These labels are used when creating our artifacts from the build pipeline.

Example artifacts from a manually triggered pipeline on a `feature` branch.

![Azure DevOps Pipeline Artifacts with Semantic Versioning naming](./assets/pipeline-artifacts.png)

If you are interested in seeing all of the available properties for the `GitVersion.yml` file you can run the following the command locally.

```
gitversion -showconfig
```

> **NOTE:** Anything not directly specified in our `GitVersion.yml` file will inherit directly from GitVersion's [default configuration](https://gitversion.net/docs/reference/configuration).

> Overview of the GitVersion [Commands](https://github.com/GitTools/actions/blob/main/docs/examples/github/gitversion/index.md)

For more information on utilizing GitVersion for sensible versioning check out this [post](https://www.dennisdoomen.com/2022/02/gitversion.html).
