# Getting Started - Percept AI

## 1. Prerequisites

- Visual Studio Code
- Visual Studio
- Git
- Node JS manager for Windows (<https://github.com/coreybutler/nvm-windows>)
- FedAir account

  Request account <https://aka.ms/fedairsuser>

  More information: [FedAirGuide](https://microsoft.sharepoint.com/teams/TechWebFed/User%20Guides/Forms/AllItems.aspx?csf=1&web=1&e=MbcFNT&ovuser=72f988bf%2D86f1%2D41af%2D91ab%2D2d7cd011db47%2Ctopliner%40microsoft%2Ecom&OR=Teams%2DHL&CT=1638977619439&sourceId=&params=%7B%22AppName%22%3A%22Teams%2DDesktop%22%2C%22AppVersion%22%3A%2227%2F21110108714%22%7D&cid=566d805b%2D66ce%2D4940%2D8363%2D58b2f6d1b0cb&FolderCTID=0x0120005B6B5380CDA89C40809C7FF5392885BD&id=%2Fteams%2FTechWebFed%2FUser%20Guides%2FFedAIRS%20Guide)

- [PerceptAI_PublicPackages Feed Access for dotnet](https://dev.azure.com/thedeluge/Percept%20AI/_artifacts/feed/PerceptAI_PublicPackages/connect)
  - [Install the latest .NET Core SDK](https://go.microsoft.com/fwlink/?linkid=2103972)
  - [Download and install the credential provider](https://github.com/microsoft/artifacts-credprovider#azure-artifacts-credential-provider)

## 2. Front end / setting up environment

1. Clone PerceptAI project locally using git.

2. On command prompt, run

   ```powershell
   nvm install latest
   nvm use latest
   ```

3. Run PowerShell as administrator and run these commands

   ```powershell
    Get-ExecutionPolicy
    Set-ExecutionPolicy RemoteSigned
    # Select "Yes"
   ```

4. Open PerceptAI project on VSCode
5. Open a terminal and run

   ```powershell
   cd web_ui
   npm install
   ```

6. Create a copy of the "env.local.sample" file under the "web_ui" folder
   Rename the copy to ".env.local" and place it inside the web_ui folder
7. Run ```npm run dev``` to start the application at ***<http://localhost:3000>***
   Note: make sure to have backend Percept API running

## 3. Backend / API Setup

1. To enable Application Insights logging for local development, add your FedAIRS account in Visual Studio by navigating to Tools > Options > Azure Service Authentication > Account Selection.
1. Open the "PerceptApi.sln" file in Visual Studio.
1. Open the Solution Explorer and SQL Object Explorer views.
1. Live Share to get ClientSecret from team member.
1. In Solution Explorer, right-click on the PerceptApi project, select "Manage User Secrets," and paste the following settings to override the defaults from appsettings.json. Note that the following settings do not contain secrets, but you will need access to the respective FedAIRS environment for them to work. Customize the values as needed for your development environment.  Update Sql Connection Strings to match your local SQL.

```json
{
  "AzureAd": {
    "Instance": "https://login.microsoftonline.com/",
    "ClientId": "85e9641e-68e8-4bc7-b5c4-02d068506131",
    "ClientSecret": "[required value here]",
    /*
      You need specify the TenantId only if you want to accept access tokens from a single tenant (line of business app)
      Otherwise you can leave them set to common
      */
    "TenantId": "e362c86f-e64a-4e58-b26a-c8bf314b1093", // A guid (Tenant ID = Directory ID) or 'common' or 'organizations' or 'consumers',
    "Authority": "https://login.microsoftonline.com/e362c86f-e64a-4e58-b26a-c8bf314b1093",
    "ValidIssuer": "https://login.microsoftonline.com/e362c86f-e64a-4e58-b26a-c8bf314b1093"
  },
  "SqlConnectionString": "Data Source=(localdb)\\ProjectModels;Initial Catalog=ArgonDb;Integrated Security=True;Connect Timeout=60;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False",
  "DocumentIntelligence": {
    "Endpoint": "https://argondocintelligence.cognitiveservices.azure.com/"
  },
  "Percept": {
    "Kestrel:Certificates:Development:Password": "def380d0-3faa-47c0-8b8a-41f9ff117159",
    "SqlConnectionString": "Data Source=(localdb)\\ProjectModels;Initial Catalog=ArgonDb;Integrated Security=True;Connect Timeout=60;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False"
  },
  "KernelMemory": {
    "Services": {
      "AzureBlobs": {
        "Account": "disaqadocs2"
      },
      "AzureAISearch": {
        "Endpoint": "https://disaqasearch3.search.windows.net"
      },
      "AzureOpenAIText": {
        "Endpoint": "https://qabot1.openai.azure.com/"
      },
      "AzureOpenAIEmbedding": {
        "Endpoint": "https://qabot1.openai.azure.com/"
      }
    }
  }
}
```

1. Open a terminal and run (Note: make sure to update database migrations beforehand if there are changes)

   ```powershell
   dotnet tool install --global dotnet-ef
   dotnet ef database update --project PerceptApi
    ```

   Note: if the above command for database update fails, you may check that you have access to the dotnet feed or you may run 'update-database' under Package Manager Console in Visual Studio
1. Build the "PerceptApi" solution
1. Start with/without debugging. ***<https://localhost:7089/swagger/index.html>***

## 3. Authorizing to use PerceptAPI

1. While running the frontend, use the browser console to copy the token from the cookie named percept_accessToken.
2. On ***<https://localhost:7089/swagger/index.html>***, click on "Authorize" and type `Bearer` followed by pasting the token you copied from the console.

## Running kernel memory service

1. Follow steps at <https://github.com/microsoft/kernel-memory>,

   ```powershell
   cd kernel-memory/service/Service
   dotnet run setup
   ```

Values to be pasted will be located in appsettings and/or secrets.json

## 4. Helpful VSCode Extensions

- Azure Tools
- Azure Developer CLI
- ESLint
- Git Blame
- Git History
- Github Copilot / GitHub Copilot Chat
  - See [this link](https://repos.opensource.microsoft.com/orgs/MicrosoftCopilot) to sign in using your EMU msft account for free copilot license
- Git Lens
- Live Share
- Markdown All in One
- markdownlint
- React Native Tools
- ES7 React/Redux/GraphQL/React-Native snippets
- Auto Rename Tag
- Prettier
- Tailwind CSS IntelliSense
