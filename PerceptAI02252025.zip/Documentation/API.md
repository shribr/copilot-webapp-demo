# API

## Create Entra ID Application registration

Docs: <https://learn.microsoft.com/en-us/entra/identity-platform/quickstart-configure-app-expose-web-apis>

Name: chatbotapi
**Overview** - copy

- [ ] Directory (_tenantid_) ID
- [ ] Application (_clientid_) ID

**Certificates & secrets** – Client secrets

- [ ] New client secret
- [ ] Copy the secret as _clientSecret_

**App Roles** – RBAC

- [ ] Create app role

Allowed member types: User/Groups,Applications

Value: SystemAdmin

Do you want to enable this app role? : checked

- [ ] Repeat above steps to add a role with Value: AppCreator

**Expose an API** – Add a Scope

Note: Set the Application ID to a friendly value URI: api://chatbotapi

- [ ] copy the application id as the _api id_
- Scope name: User.All
- Who can consent: Admin and users only


**Expose an API** – Add a client application (optional)

> Note: If you follow this optional step, the client app is now a pre-authorized client app (PCA), and users won't be prompted for their consent when signing in to it.

- [ ] Client ID from the Web UI App registration
- [ ] Select the User.All scope

- **API permissions** - Microsoft Graph

> Note: If you do not see the exposed API Permissions, make sure you are an Owner on both the UI and API app registrations.

- [ ] Add permissions
- Microsoft APIs -> Microsoft Graph
- Application : User.Read.All, Group.Read.All
- Delegated: User.Read
- [ ] Grant Admin Consent (allows the application to find users and groups for permission assignments)

## Deploy App

This step is handled by build and deploy automation. See **file** in project solution in the development environment.

Staging/Production deployment Steps:

-
-

## Configure App Settings

#### Database Settings

- SqlConnectionString : _azuresqlconnectionstring_

---

#### Authentication Settings

docs at <https://next-auth.js.org/configuration/options>

---

- AzureAd\_\_Instance : `https://login.microsoftonline.com/` (azure cloud login endpoint)
- Audience : api://chatbotapi (Must match the API App registration: Application ID)
- ClientId : _clientid_
- ClientSecret : _clientSecret_
- TenantId : _tenantid_
- Scopes\_\_User\_\_0 : User.All

#### Kernel Memory Azure service settings - Match the service settings of the [Kernel Memory](KernelMemory.md) service

---

- KernelMemory\_\_Services\_\_AzureQueues\_\_Auth : ConnectionString (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureQueues\__Account: \_queuesdeploymentname_,
- KernelMemory\_\_Services\_\_AzureQueues\__ConnectionString: \_queuesconnectionstring_,
- KernelMemory\_\_Services\_\_AzureQueues\_\_EndpointSuffix: core.windows.net (azure cloud endpoint)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_Auth: ConnectionString (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_Container: default (blob container to store source documents, chunks, embeddings, pipeline status)
- KernelMemory\_\_Services\_\_AzureBlobs\_\_ConnectionString: _blobsconnectionstring_,
- KernelMemory\_\_Services\_\_AzureBlobs\_\_EndpointSuffix: core.windows.net (azure cloud endpoint)
- KernelMemory\_\_Services\_\_AzureAISearch\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureAISearch\__Endpoint: \_searchendpoint_
- KernelMemory\_\_Services\_\_AzureAISearch\__APIKey: \_searchapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_APIType: ChatCompletion
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureOpenAIText\__Endpoint: \_azureopenaitextendpoint_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_Deployment: gpt-35-turbo (ai chat completion model)
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_MaxTokenTotal: 4096 (max tokens supported by model)
- KernelMemory\_\_Services\_\_AzureOpenAIText\__APIKey: \_azureopenaiapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIText\_\_MaxRetries: 10 (max ai api connection retries)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_Auth: ApiKey (TODO: Change to AzureIdentity)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\__Endpoint: \_azureopenaitextendpoint_
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\__APIKey: \_azureopenaiapikey_
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_Deployment: text-embedding-ada-002 (ai embedding generation model)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_MaxTokenTotal: 8191 (The max number of tokens supported by model deployed)
- KernelMemory\_\_Services\_\_AzureOpenAIEmbedding\_\_APIType: EmbeddingGeneration

#### Feature Flags

---

-
-

## Local Development

Deploy a local database from Package Manager Console:

```dotnet
> dotnet ef database update --project PerceptApi
```

Run the API with .NET version 8

```dotnet
> dotnet run
```
