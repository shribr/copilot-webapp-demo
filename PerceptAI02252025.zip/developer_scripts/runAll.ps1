[CmdletBinding()]
param (
    [Parameter()]
    [switch]
    $RunWeb,

    [Parameter()]
    [switch]
    $RunArgonApi,

    [Parameter()]
    [switch]
    $RunKernelMemoryHandlers,

    [Parameter()]
    [switch]
    $OpenBrowser
)

# Define paths
$projectRoot = Split-Path -Path $PSScriptRoot
$argonApiPath = Join-Path -Path $projectRoot -ChildPath (Join-Path -Path 'Api' -ChildPath 'PerceptApi')
$webUiPath = Join-Path -Path $projectRoot -ChildPath 'web_ui'
$kernelMemoryApiPath = Join-Path -Path $projectRoot -ChildPath (Join-Path -Path 'kernelmemory_api' -ChildPath '')

# Conditionally run npm run dev in the web_ui directory
if ($RunWeb) {
    Start-Process -FilePath 'npm' -ArgumentList 'run dev' -WorkingDirectory $webUiPath
}

# Conditionally run dotnet for the ArgonApi
if ($RunArgonApi) {
    Start-Process -FilePath 'dotnet' -ArgumentList 'run' -WorkingDirectory $argonApiPath
}

# Conditionally run dotnet for the kernelmemory_service
if ($RunKernelMemoryHandlers) {
    Start-Process -FilePath 'docker' -ArgumentList 'run --volume .\appsettings.KMService.json:/app/appsettings.Production.json -it --rm -p 9001:9001 kernelmemory/service' -WorkingDirectory $kernelMemoryApiPath
}

# Conditionally open Microsoft Edge and navigate to http://localhost:3000
if ($OpenBrowser) {
    Start-Process -FilePath 'msedge' -ArgumentList 'http://localhost:3000'
}
