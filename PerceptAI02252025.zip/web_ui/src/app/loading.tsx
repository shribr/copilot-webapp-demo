import Loading from '@/components/Loading';

export default function Loader() {
  return <Loading />;
}
