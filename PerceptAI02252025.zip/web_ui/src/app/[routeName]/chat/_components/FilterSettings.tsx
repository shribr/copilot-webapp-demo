import { Stack, Typography } from '@mui/material';
import ChatFilter from '@/components/ChatFilter';
import { AgentResponseDto } from '@/types/agent';

type FilterSettingsProps = {
  appId: string;
  chatAgent: AgentResponseDto | null;
};
export default function FilterSettings({
  appId,
  chatAgent,
}: FilterSettingsProps) {
  return (
    <Stack
      direction='column'
      sx={{
        gap: 1,
        padding: '0 1rem',
      }}
    >
      <Typography variant='h6'>Filter Settings</Typography>
      <Stack
        direction='column'
        sx={{
          alignItems: 'center',
          justifyContent: 'center',
          gap: 2,
        }}
      >
        <ChatFilter appId={appId} chatAgent={chatAgent} />
      </Stack>
    </Stack>
  );
}
