'use client';
import ChatBot from '@/components/ChatBot';
import SourcesSidePanel from '@/components/SourcesSidePanel';
import themeConstants from '@/styles/constants';
import { AgentResponseDto } from '@/types/agent';
import { ChatConversation } from '@/types/chatConversation';
import { Box, Container, Slide, Stack } from '@mui/material';
import ChatDrawer from './ChatDrawer';
import ChatHeader from './ChatHeader';
import { useViewModel } from './viewModel';

type ChatPageProps = {
  routeName: string;
  appId: string;
  agents: AgentResponseDto[];
  conversation?: ChatConversation;
};

export default function ChatPage({
  routeName,
  appId,
  agents,
  conversation,
}: ChatPageProps) {
  const {
    handleFeedback,
    chatMessages,
    initialChatMessages,
    reaction,
    isFeedbackDialogOpen,
    isWaitingForAi,
    bypassAutoScrollRef,
    handleFeedbackDialogClose,
    handleFeedbackDialogSave,
    handleClearChat,
    handleSendChatMessage,
    handleChatComplete,
    showSourcesPanel,
    handleSourcesPanelClose,
    activeTab,
    handleTabChange,
    isLoading,
    handleIconButtonClick,
    isChatDrawerOpen,
    setIsChatDrawerOpen,
    conversations,
    handleArchiveConversation,
    handleRenameConversation,
    handleAgentChange,
    chatAgent,
    isResponseLimitReached,
    isSavingRename,
    agentOptions,
    selectedConversationId,
  } = useViewModel(routeName, appId, agents, conversation);

  return (
    <>
      <ChatDrawer
        open={isChatDrawerOpen}
        conversations={conversations}
        onDrawerClose={() => setIsChatDrawerOpen(!isChatDrawerOpen)}
        onArchiveConversation={handleArchiveConversation}
        onRenameConversation={handleRenameConversation}
        isSavingRename={isSavingRename}
        appId={appId}
        chatAgent={chatAgent}
      />
      <Container
        maxWidth={themeConstants.contentWidth}
        sx={{
          height: '100%',
        }}
      >
        <Stack
          className='chatPageContainer'
          direction='column'
          sx={{
            width: '100%',
            height: '100%',
            padding: '1rem',
          }}
        >
          <ChatHeader
            onClearChat={handleClearChat}
            appRouteName={routeName}
            agentOptions={agentOptions}
            onAgentChange={handleAgentChange}
            selectedAgent={chatAgent}
            isAgentChangeDisabled={selectedConversationId !== undefined}
          />
          <Stack
            direction='row'
            sx={{
              transition: 'width 0.5s ease-in-out',
              height: '100%',
              overflow: 'hidden',
            }}
          >
            <ChatBot
              chatMessages={chatMessages}
              initialChatMessages={initialChatMessages}
              reaction={reaction}
              isFeedbackDialogOpen={isFeedbackDialogOpen}
              isWaitingForAi={isWaitingForAi}
              bypassAutoScrollRef={bypassAutoScrollRef}
              onFeedbackDialogClose={handleFeedbackDialogClose}
              onFeedbackDialogSave={handleFeedbackDialogSave}
              onSendChatMessage={handleSendChatMessage}
              onChatComplete={handleChatComplete}
              onFeedback={handleFeedback}
              onSourcesClick={handleIconButtonClick}
              isResponseLimitReached={isResponseLimitReached}
            />
            <Slide direction='left' in={showSourcesPanel} unmountOnExit>
              <Box
                sx={{
                  width: '50%',
                  height: '100%',
                  transition: 'width 0.5s ease-in-out',
                  padding: ' 0 1rem',
                }}
              >
                <SourcesSidePanel
                  onClose={handleSourcesPanelClose}
                  activeTab={activeTab}
                  onTabChange={handleTabChange}
                  isLoading={isLoading}
                />
              </Box>
            </Slide>
          </Stack>
        </Stack>
      </Container>
    </>
  );
}
