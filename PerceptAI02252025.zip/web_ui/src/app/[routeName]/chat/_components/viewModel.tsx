'use client';
import { conversationService } from '@/app/services/conversationService';
import { dataSourceService } from '@/app/services/dataSourceService';
import { feedbackService } from '@/app/services/feedbackService';
import { chatLimits } from '@/constants/chatLimits';
import { searchParamNames } from '@/constants/searchParamNames';
import { useChatStore } from '@/store/ChatStore';
import { useToastHandler } from '@/store/Toast';
import useUserStore from '@/store/UserStore';
import { AgentOption, AgentResponseDto } from '@/types/agent';
import { AiMessage, Message, UserType } from '@/types/chat';
import { ChatConversation } from '@/types/chatConversation';
import { DataSourceType } from '@/types/dataSourceDto';
import { FeedbackRequest } from '@/types/feedback';
import { KernelMemoryAgentQuery } from '@/types/kernelMemoryAgentQueryContext';
import { Reaction } from '@/types/reaction';
import { SourceTabPanel } from '@/types/sourceTabPanel';
import { SelectChangeEvent } from '@mui/material/Select';
import { uniqueId } from 'lodash-es';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

const tabMapping: SourceTabPanel[] = ['citation', 'thought', 'document'];

export const useViewModel = (
  routeName: string,
  appId: string,
  agents: AgentResponseDto[],
  conversation?: ChatConversation
) => {
  const router = useRouter();
  const { addMessage } = useToastHandler();
  const [isSavingRename, setIsSavingRename] = useState(false);
  const [isFeedbackDialogOpen, setIsFeedbackDialogOpen] = useState(false);
  const [reaction, setReaction] = useState<Reaction | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<AiMessage | null>(
    null
  );
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [isWaitingForAi, setIsWaitingForAi] = useState(false);
  const initialChatMessages = useRef<{ [key: string]: boolean }>({});
  const [showSourcesPanel, setShowSourcesPanel] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const fetchChatMessage = useChatStore((state) => state.fetchChatMessage);
  const selectedChatMessage = useChatStore(
    (state) => state.selectedChatMessage
  );
  const setSelectedChatMessage = useChatStore(
    (state) => state.setSelectedChatMessage
  );

  const isLoading = useChatStore((state) => state.isLoading);
  const chatFilter = useChatStore((state) => state.chatFilter);

  const [chatAgent, setChatAgent] = useState<AgentResponseDto | null>(null);
  const [agentOptions, setAgentOptions] = useState<AgentOption[]>([]);

  const selectedConversationId = useChatStore(
    (state) => state.selectedConversationId
  );
  const setSelectedConversationId = useChatStore(
    (state) => state.setSelectedConversationId
  );
  const setQueryContext = useChatStore((state) => state.setQueryContext);

  const bypassAutoScrollRef = useRef(false);
  const isChatDrawerOpen = useChatStore((state) => state.isChatDrawerOpen);
  const setIsChatDrawerOpen = useChatStore(
    (state) => state.setIsChatDrawerOpen
  );
  const conversations = useChatStore((state) => state.conversations);
  const setConversations = useChatStore((state) => state.setConversations);

  const isResponseLimitReached = useMemo(
    () =>
      chatMessages.filter((msg) => msg.from === UserType.AI).length >=
      chatLimits.maxResponses,
    [chatMessages]
  );

  const handleSetAgentById = useCallback(
    (agentId: string) => {
      const agent = agents.find((agent) => agent.id === agentId);
      if (agent) {
        setChatAgent(agent);
      }
    },
    [agents, setChatAgent]
  );

  const fetchConversations = useCallback(() => {
    conversationService.getConversations(appId).then((conversations) => {
      setConversations(conversations);
    });
  }, [appId, setConversations]);

  const user = useUserStore((state) => state.user);

  const fetchManageableAgents = useCallback(async () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    if (user) {
      return dataSourceService
        .getManagedPagedDataSources(
          appId,
          {
            page: 0,
            pageSize: 100,
          },
          DataSourceType.Documents
        )
        .then((response) => {
          const dataSourceIds = response.items.map(
            (dataSource) => dataSource.id
          );
          const manageable = agents
            .filter((agent) =>
              agent.dataSources.some((ds) => dataSourceIds.includes(ds.id))
            )
            .map((agent) => agent.id);
          return manageable || [];
        });
    }
  }, [agents, appId, user]);

  // Trigger: component prop change: agents.
  // Action: Check URL for agent query param, set chatAgent.  Default to first agent.
  useEffect(() => {
    const initAgentOptions = getAgentOptions(agents, []); //initialize Agent options with agents from server side fetched agents
    setAgentOptions(initAgentOptions);
    const urlParams = new URLSearchParams(window.location.search);
    const agentName = urlParams.get(searchParamNames.agent);

    const firstAgent = agents[0] || null;

    const selectedAgent = agentName
      ? agents.find((agent) => agent.name === agentName) || firstAgent
      : firstAgent;

    if (selectedAgent) {
      setChatAgent(selectedAgent);
    }

    // Fetch manageable agents and update agent options
    fetchManageableAgents().then((response) => {
      const options = getAgentOptions(agents, response);
      setAgentOptions(options);
    });
  }, [agents, fetchManageableAgents]);

  // Trigger: component prop change: conversation.
  // Action: set chat messages, agent, query context. Fetch conversations.
  useEffect(() => {
    fetchConversations();
    if (conversation) {
      setSelectedConversationId(conversation.id);
      const initialRef = conversation.messages.reduce((acc, curr) => {
        return { ...acc, [curr.id]: true };
      }, {});
      initialChatMessages.current = initialRef;
      setChatMessages(conversation.messages);
      handleSetAgentById(conversation.agentId);
      setQueryContext(conversation.agentQueryContext);
    } else {
      setSelectedConversationId(undefined);
      setChatMessages([]);
    }
  }, [
    appId,
    conversation,
    fetchConversations,
    handleSetAgentById,
    setChatAgent,
    setConversations,
    setQueryContext,
    setSelectedConversationId,
  ]);

  const getAgentOptions = (
    agents: AgentResponseDto[],
    manageableAgentsIds: string[] = []
  ): AgentOption[] => {
    return agents.length === 0
      ? []
      : agents.map((agent) => ({
          agentName: agent.name,
          agentId: agent.id,
          manageable: manageableAgentsIds
            ? manageableAgentsIds.includes(agent.id)
            : false,
          description: agent.description || '',
        }));
  };

  const handleIconButtonClick = useCallback(
    (message: Message, path: SourceTabPanel) => {
      setActiveTab(tabMapping.indexOf(path));
      if (
        message.from === UserType.AI &&
        selectedChatMessage?.id !== message.id
      ) {
        fetchChatMessage(appId, message.id, message?.conversationId || '');
      }
      setShowSourcesPanel(true);
    },
    [appId, fetchChatMessage, selectedChatMessage?.id]
  );

  const handleSourcesPanelClose = () => {
    setShowSourcesPanel(false);
    setSelectedChatMessage(null);
  };

  const handleTabChange = (newValue: number) => {
    setActiveTab(newValue);
  };

  const handleClearChat = () => {
    setChatMessages([]);
    setSelectedConversationId(undefined);
    setSelectedChatMessage(null);
    initialChatMessages.current = {};
    router.push(`/${routeName}/chat?agent=${chatAgent?.name}`);
  };

  const handleChatComplete = useCallback(() => {
    setIsWaitingForAi(false);
  }, []);

  const handleSendChatMessage = useCallback(
    (message: string) => {
      setIsWaitingForAi(true);
      setChatMessages((prev) =>
        prev.concat([
          {
            id: uniqueId(),
            from: UserType.User,
            message: message,
          },
        ])
      );
      bypassAutoScrollRef.current = false;

      const query: KernelMemoryAgentQuery = {
        agentId: chatAgent?.id,
        question: message,
        conversationId: selectedConversationId,
        contextArguments: {
          $type: 'KernelMemoryQuery',
          filters: chatFilter,
          minRelevance: 0.8,
        },
      };

      conversationService
        .ask(appId, query)
        .then((response) => {
          setChatMessages((prev) => prev.concat([response]));
          setSelectedConversationId(response.conversationId);
          if (selectedConversationId !== response.conversationId) {
            fetchConversations(); // Add new conversation to list
            router.push(
              `/${routeName}/chat/${response.conversationId}?agent=${chatAgent?.name}`,
              { scroll: false }
            );
          }
        })
        .catch((error) => {
          setChatMessages((prev) =>
            prev.concat([
              {
                id: uniqueId(),
                from: UserType.System,
                message: error.message ?? 'An error has occurred',
                systemMessageType: 'error',
              },
            ])
          );
          addMessage('Unable to set chat messages', 'error', error.message);
          handleChatComplete();
        });
    },
    [
      chatAgent?.id,
      chatAgent?.name,
      selectedConversationId,
      chatFilter,
      appId,
      setSelectedConversationId,
      fetchConversations,
      router,
      routeName,
      addMessage,
      handleChatComplete,
    ]
  );

  const handleFeedback = (message: AiMessage, reaction: Reaction) => {
    setReaction(reaction);
    setIsFeedbackDialogOpen(true);
    setFeedbackMessage(message);
  };

  const handleFeedbackDialogSave = useCallback(
    async (comment?: string) => {
      if (!feedbackMessage || reaction == null) return;
      const index = chatMessages.findIndex(
        (msg) => msg.from === UserType.AI && msg.id === feedbackMessage.id
      );
      const question = chatMessages[index - 1];
      if (!question) return;

      const feedback = {
        applicationId: appId,
        reaction: reaction,
        response: feedbackMessage.message,
        question: question.message,
        comment: comment,
      } satisfies FeedbackRequest;

      feedbackService
        .sendFeedback(appId, feedback)
        .then(() => {
          handleFeedbackDialogClose();
        })
        .catch((error) => {
          addMessage('Failed to send feedback', 'error', error.message);
        });
    },
    [addMessage, appId, chatMessages, feedbackMessage, reaction]
  );

  const handleFeedbackDialogClose = () => {
    setIsFeedbackDialogOpen(false);
    setReaction(null);
    setFeedbackMessage(null);
  };

  const handleArchiveConversation = useCallback(
    (conversationId: string) => {
      conversationService
        .archiveConversation(appId, conversationId)
        .then(() => {
          const newConversations = conversations.filter(
            (conversation) => conversation.id !== conversationId
          );
          setConversations(newConversations);
          addMessage('Conversation archived', 'success');
        })
        .catch((error) => {
          addMessage('Failed to archive conversation', 'error', error.message);
        });
    },
    [addMessage, appId, conversations, setConversations]
  );

  const handleRenameConversation = useCallback(
    async (conversationId: string, name: string) => {
      setIsSavingRename(true);
      conversationService
        .renameConversation(appId, conversationId, name)
        .then(() => {
          const updatedConversations = conversations.map((conversation) =>
            conversation.id === conversationId
              ? { ...conversation, name }
              : conversation
          );
          setConversations(updatedConversations);
          addMessage('Conversation renamed', 'success');
        })
        .catch((error) => {
          addMessage('Failed to rename conversation', 'error', error.message);
        })
        .finally(() => {
          setIsSavingRename(false);
        });
    },
    [addMessage, appId, conversations, setConversations]
  );

  const handleAgentChange = (event: SelectChangeEvent) => {
    const agentId = event.target.value;
    handleSetAgentById(agentId);

    const agent = agents.find((agent) => agent.id === agentId);
    if (agent) {
      const url = new URL(window.location.href);
      url.searchParams.set(searchParamNames.agent, agent.name);
      window.history.replaceState({ agentId: agent.id }, '', url.toString());
    }
  };

  return {
    activeTab,
    agentOptions,
    bypassAutoScrollRef,
    chatAgent,
    chatMessages,
    conversations,
    handleAgentChange,
    handleArchiveConversation,
    handleChatComplete,
    handleClearChat,
    handleFeedback,
    handleFeedbackDialogClose,
    handleFeedbackDialogSave,
    handleIconButtonClick,
    handleRenameConversation,
    handleSendChatMessage,
    handleSourcesPanelClose,
    handleTabChange,
    initialChatMessages,
    isChatDrawerOpen,
    isFeedbackDialogOpen,
    isLoading,
    isResponseLimitReached,
    isSavingRename,
    isWaitingForAi,
    reaction,
    selectedChatMessage,
    setIsChatDrawerOpen,
    setShowSourcesPanel,
    showSourcesPanel,
    selectedConversationId,
  };
};
