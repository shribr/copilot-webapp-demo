'use client';
import FilterAltRoundedIcon from '@mui/icons-material/FilterAltRounded';
import ChatRoundedIcon from '@mui/icons-material/ChatRounded';
import {
  Box,
  Divider,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Fade,
  Stack,
} from '@mui/material';
import DrawerHeader from '@/components/DrawerHeader';
import SideDrawer from '@/components/SideDrawer';
import FilterSettings from './FilterSettings';
import { useMemo, useState } from 'react';
import { SwitchTransition } from 'react-transition-group';
import ConversationHistory from '@/components/ConversationHistory';
import { ChatConversationItem } from '@/types/chatConversationItem';
import { AgentResponseDto } from '@/types/agent';
import DrawerClose from '@/components/DrawerClose';

enum ChatDrawerMenu {
  StartNewChat,
  ConversationHistory,
  FilterSettings,
}
type ChatDrawerProps = {
  open: boolean;
  conversations: ChatConversationItem[];
  onDrawerClose: () => void;
  onArchiveConversation: (id: string) => void;
  onRenameConversation: (conversationId: string, name: string) => Promise<void>;
  isSavingRename: boolean;
  appId: string;
  chatAgent: AgentResponseDto | null;
};
export default function ChatDrawer({
  open,
  conversations,
  isSavingRename,
  onDrawerClose,
  onArchiveConversation,
  onRenameConversation,
  appId,
  chatAgent,
}: ChatDrawerProps) {
  const [activeMenuItem, setActiveMenuItem] = useState<ChatDrawerMenu>(
    ChatDrawerMenu.ConversationHistory
  );

  const handleConversationHistory = () => {
    setActiveMenuItem(ChatDrawerMenu.ConversationHistory);
  };

  const handleFilterSettings = () => {
    setActiveMenuItem(ChatDrawerMenu.FilterSettings);
  };

  const menus = useMemo(
    () => [
      {
        title: 'Conversation History',
        icon: <ChatRoundedIcon />,
        type: ChatDrawerMenu.ConversationHistory,
        props: { onClick: handleConversationHistory },
      },
      {
        title: 'Filter Settings',
        icon: <FilterAltRoundedIcon />,
        type: ChatDrawerMenu.FilterSettings,
        props: { onClick: handleFilterSettings },
      },
    ],
    []
  );

  return (
    <SideDrawer anchor='left' open={open}>
      <Stack
        className='contents'
        direction='column'
        sx={{
          height: '100%',
          overflowY: 'hidden',
        }}
      >
        <DrawerHeader>
          <DrawerClose onDrawerClose={onDrawerClose} />
        </DrawerHeader>
        <Divider />
        <Stack
          className='inner-contents'
          direction='column'
          sx={{
            height: '100%',
            gap: 1,
            padding: '.5rem 0',
            overflowY: 'hidden',
          }}
        >
          <List>
            {menus.map((item) => (
              <ListItem key={item.title} disablePadding>
                <ListItemButton
                  selected={activeMenuItem === item.type}
                  {...item.props}
                >
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.title} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
          <Divider />
          <Box sx={{ flexGrow: 1, overflowY: 'scroll', height: '100%' }}>
            <SwitchTransition>
              <Fade key={activeMenuItem}>
                <div>
                  {activeMenuItem === ChatDrawerMenu.ConversationHistory && (
                    <ConversationHistory
                      conversations={conversations}
                      onArchiveConversation={onArchiveConversation}
                      onRenameConversation={onRenameConversation}
                      isSavingRename={isSavingRename}
                    />
                  )}
                  {activeMenuItem === ChatDrawerMenu.FilterSettings && (
                    <FilterSettings appId={appId} chatAgent={chatAgent} />
                  )}
                </div>
              </Fade>
            </SwitchTransition>
          </Box>
        </Stack>
      </Stack>
    </SideDrawer>
  );
}
