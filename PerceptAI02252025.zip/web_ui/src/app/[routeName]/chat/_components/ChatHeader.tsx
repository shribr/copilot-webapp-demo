'use client';
import React, { useMemo } from 'react';
import {
  Stack,
  StackProps,
  Typography,
  SelectChangeEvent,
  Link as MUILink,
  Fade,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import ClearChatButton from '@/components/ClearChatButton';
import SelectMenu from '@/components/SelectMenu';
import { Option } from '@/types/option';
import { AgentOption, AgentResponseDto } from '@/types/agent';
import { useSearchParams } from 'next/navigation';
import { searchParamNames } from '@/constants/searchParamNames';
import Link from 'next/link';

type ChatHeaderProps = StackProps & {
  onClearChat: () => void;
  onAgentChange: (event: SelectChangeEvent) => void;
  appRouteName: string;
  isAgentChangeDisabled: boolean;
  agentOptions: AgentOption[];
  selectedAgent: AgentResponseDto | null;
};

export default function ChatHeader({
  onClearChat,
  onAgentChange,
  appRouteName,
  isAgentChangeDisabled,
  agentOptions,
  selectedAgent,
  ...props
}: ChatHeaderProps) {
  const theme = useTheme();
  const searchParams = useSearchParams();
  const agent = searchParams.get(searchParamNames.agent);
  const manageContentLink = `/registration/${selectedAgent?.applicationId}/documents/list?${searchParamNames.agent}=${agent}&${searchParamNames.chat}=${appRouteName}`;

  const agentSelectOptions: Option[] = useMemo(
    () =>
      agentOptions.map((agentOption) => ({
        label: agentOption.agentName,
        value: agentOption.agentId,
        tooltip: agentOption.description,
      })),
    [agentOptions]
  );

  const isManageable = !!agentOptions.find(
    (x) => x.agentId === selectedAgent?.id && x.manageable
  );

  return (
    <Stack direction='column' {...props}>
      <Stack direction='row' justifyContent='center'>
        <Typography
          variant='caption'
          color={theme.palette.getContrastText(
            theme.palette.background.default
          )}
        >
          AI-generated content may be incorrect
        </Typography>
      </Stack>
      <Stack
        direction='row'
        justifyContent='space-between'
        alignItems='center'
        padding='0 0 0.5rem 0'
      >
        <Stack
          direction='row'
          gap={1}
          width='50%'
          justifyContent='flex-start'
          alignItems='center'
        >
          <Stack width='50%'>
            <SelectMenu
              title='Conversation Agent'
              options={agentSelectOptions}
              selectedValue={selectedAgent?.id || ''}
              size='small'
              onChange={onAgentChange}
              disabled={isAgentChangeDisabled}
            />
          </Stack>
          <Fade in={isManageable}>
            <MUILink component={Link} href={manageContentLink}>
              Manage Content
            </MUILink>
          </Fade>
        </Stack>
        <ClearChatButton onClick={onClearChat} />
      </Stack>
    </Stack>
  );
}
