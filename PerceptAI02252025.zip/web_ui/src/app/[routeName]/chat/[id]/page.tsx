'use server';

import { agentService } from '@/app/services/agentService';
import { appRegistrationService } from '@/app/services/appRegistrationService';
import { conversationService } from '@/app/services/conversationService';
import { Metadata } from 'next';
import ChatPage from '../_components/ChatPage';


export async function generateMetadata({ params }: { params: { id: string; routeName: string } }): Promise<Metadata> {
  const app = await appRegistrationService.getByRouteName(params.routeName);
  const conversation = await conversationService.getConversation(app.id, params.id);

  return {
    title: `${app.name} - ${conversation.name}`,
  };
}

export default async function ConversationPage({
  params,
}: {
  params: { id: string; routeName: string };
}) {
  let conversation;
  let app;
  let agents;
  try {
    app = await appRegistrationService.getByRouteName(params.routeName);
    agents = await agentService.getPagedChatAgents(app.id, {
      page: 0,
      pageSize: 100,
    });
  } catch (error) {
    throw Error(`Failed to fetch app: ${error}`);
  }

  try {
    conversation = await conversationService.getConversation(app.id, params.id);
  } catch (error) {
    throw Error(`Failed to fetch conversation: ${error}`);
  }

  return (
    <ChatPage
      routeName={params.routeName}
      conversation={conversation}
      appId={app.id}
      agents={agents.items}
    />
  );
}
