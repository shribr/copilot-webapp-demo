'use server';
import { agentService } from '@/app/services/agentService';
import { appRegistrationService } from '@/app/services/appRegistrationService';
import { Metadata } from 'next';
import ChatPage from './_components/ChatPage';

export async function generateMetadata({
  params,
}: {
  params: { id: string; routeName: string };
}): Promise<Metadata> {
  const app = await appRegistrationService.getByRouteName(params.routeName);

  return {
    title: `${app.name} - New Chat Conversation`,
  };
}

export default async function Home({
  params,
}: {
  params: { routeName: string };
}) {
  let app;
  let agents;
  try {
    app = await appRegistrationService.getByRouteName(params.routeName);
    agents = await agentService.getPagedChatAgents(app.id, {
      page: 0,
      pageSize: 100,
    });
  } catch (error) {
    throw Error(`Failed to fetch app and agents: ${error}`);
  }

  return (
    <ChatPage
      routeName={params.routeName}
      appId={app.id}
      agents={agents.items}
    />
  );
}
