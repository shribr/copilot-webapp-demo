import { getTokenCookieAsync } from '@/utils/apiUtils';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  // Get the session from NextAuth
  const token = await getTokenCookieAsync();

  // Check if the session exists and has a token
  if (!token) {
    return NextResponse.json({ Message: 'Unauthorized' }, { status: 401 });
  }

  // Extract the URL from the query string
  const searchParams = req.nextUrl.searchParams;
  const url = searchParams.get('url');

  // Check if the URL is present and is a string
  if (!url || typeof url !== 'string') {
    return NextResponse.json(
      { Message: 'No URL provided or URL is not a string' },
      { status: 400 }
    );
  }

  try {
    // Set up the options for the fetch request
    const options: RequestInit = {
      headers: {
        // Set the Authorization header with the token from the session
        Authorization: `Bearer ${token}`,
      },
      mode: 'cors',
    };

    // Make the fetch request to the provided URL
    const response = await fetch(url, options);

    // Check if the request was successful
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    // Stream the response back to the client
    return response;
  } catch (error) {
    // Handle any errors
    return NextResponse.json(
      { Message: error?.toString() ?? 'error' },
      { status: 500 }
    );
  }
}
