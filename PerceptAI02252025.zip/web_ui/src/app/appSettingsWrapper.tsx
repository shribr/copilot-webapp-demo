'use client';

import {
  ClassificationSettings,
  useClassificationsStore,
} from '@/components/Classifications';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import { ClientAppSettings } from '@/types/clientAppSettings';
import { useEffect } from 'react';

type AppSettingsWrapperProps = {
  appSettings: ClientAppSettings;
  classificationSettings?: ClassificationSettings;
  children: React.ReactNode;
};

export default function AppSettingsWrapper({
  appSettings,
  classificationSettings,
  children,
}: AppSettingsWrapperProps) {
  const setAppSettings = useClientAppSettingsStore(
    (state) => state.setAppSettings
  );

  const setClassificationSettings = useClassificationsStore(
    (state) => state.setClassificationSettings
  );

  useEffect(() => {
    setAppSettings(appSettings);
    setClassificationSettings(classificationSettings);
  }, [
    appSettings,
    classificationSettings,
    setAppSettings,
    setClassificationSettings,
  ]);

  return <>{children}</>;
}
