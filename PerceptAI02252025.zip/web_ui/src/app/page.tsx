'use server';
import LandingPage from '@/app/_components/LandingPage';

export default async function Home() {
  return <LandingPage />;
}
