'use client';
import ErrorPage from './_components/ErrorPage';

const Error: React.FC<{ error: Error }> = ({
  error,
}) => { 

  return (
    <ErrorPage error={error} />
  );
};

export default Error;
