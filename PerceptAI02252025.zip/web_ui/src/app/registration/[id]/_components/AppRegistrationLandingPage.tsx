'use client';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';
import { Stack } from '@mui/material';
import { useViewModel } from '../../sharedViewModel/viewModel';
import useAppStore from '@/store/AppStore';
import { useEffect } from 'react';
import AppRegistrationForm from '@/components/AppRegistrationForm';

type AppRegistrationLandingPageProps = {
  appRegistration: AppRegistrationWithUserRoles;
};

export default function AppRegistrationLandingPage({
  appRegistration,
}: AppRegistrationLandingPageProps) {
  const { handleCancel, handleSubmit, isSaving } =
    useViewModel(appRegistration);

  const setAppSlug = useAppStore((state) => state.setAppSlug);

  useEffect(() => {
    setAppSlug(appRegistration);
  }, [setAppSlug, appRegistration]);

  return (
    <Stack direction='column' sx={{ height: '100%', overflowY: 'auto' }}>
      <AppRegistrationForm
        initialApp={appRegistration}
        isSaving={isSaving}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
      />
    </Stack>
  );
}
