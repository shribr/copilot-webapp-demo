import { Meta, StoryObj } from '@storybook/react';
import ConnectorAssignedAgent from './ConnectorAssignedAgent';

const meta: Meta<typeof ConnectorAssignedAgent> = {
  title: 'Connectors/Assigned Agent',
  component: ConnectorAssignedAgent,
  tags: ['autodocs'],
};

export default meta;

type Story = StoryObj<typeof meta>;

export const Index: Story = {
  args: {
    agents: [
      {
        id: '1',
        name: 'Agent 1',
      },
      {
        id: '2',
        name: 'Agent 2',
      },
      {
        id: '3',
        name: 'Agent 3',
      },
      {
        id: '4',
        name: 'Agent 4',
      },
      {
        id: '5',
        name: 'Agent 5',
      },
      {
        id: '6',
        name: 'Agent 6',
      },
      {
        id: '7',
        name: 'Agent 7',
      },
      {
        id: '8',
        name: 'Agent 8',
      },
      {
        id: '9',
        name: 'Agent 9',
      },
      {
        id: '10',
        name: 'Agent 10',
      },
    ],
  },
};
