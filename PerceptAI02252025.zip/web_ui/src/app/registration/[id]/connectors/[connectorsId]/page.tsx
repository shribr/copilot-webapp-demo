import { getDataConnectorById } from '@/app/actions/resources/dataConnectors';
import { appRegistrationService } from '@/app/services/appRegistrationService';
import DataConnectorLandingPage from './_components/DataConnectorLandingPage';

export default async function DataConnectorLanding({
  params,
}: {
  params: { id: string; connectorsId: string };
}) {
  let dataConnector;
  let app;
  try {
    [app, dataConnector] = await Promise.all([
      appRegistrationService.getAppWithUserRoles(params.id),
      getDataConnectorById(params.id, params.connectorsId),
    ]);
  } catch {
    throw Error(
      `Failed to fetch data source with id: ${params.connectorsId}`
    );
  }

  return <DataConnectorLandingPage dataConnector={dataConnector} app={app} />;
}
