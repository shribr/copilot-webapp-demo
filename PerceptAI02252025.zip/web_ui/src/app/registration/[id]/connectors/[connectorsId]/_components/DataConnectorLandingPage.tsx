'use client';
import DataConnectorForm from '@/components/DataConnectorForm';
import useAppStore from '@/store/AppStore';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';
import { DataSourceResponse } from '@/types/dataSourceDto';
import { useEffect } from 'react';
import { useViewModel } from '../../sharedViewModel/viewModel';

type EditDataConnectorPageProps = {
  dataConnector: DataSourceResponse;
  app: AppRegistrationWithUserRoles;
};

export default function DataConnectorLandingPage({
  dataConnector,
  app,
}: EditDataConnectorPageProps) {
  const {
    handleCancel,
    handleSubmit,
    handleIndexNameChange,
    handleConnectionStringChange,
    handleFetchSchema,
    setFormValues,
    formValues,
    isSaving,
    isConnectionStringValid,
    isSchemaValid,
    isSchemaValidating,
    dataSourceTypeOptions,
    indexField,
    connectionField,
    dialogOpen,
  } = useViewModel(dataConnector.applicationId ?? '', dataConnector);

  const setSlugs = useAppStore((state) => state.setSlugs);
  const setAppSlug = useAppStore((state) => state.setAppSlug);

  useEffect(() => {
    setSlugs({
      [dataConnector.id]: dataConnector.name,
    });
    setAppSlug(app);
  }, [app, dataConnector, setAppSlug, setSlugs]);

  return (
    <DataConnectorForm
      initialConnector={dataConnector}
      isSaving={isSaving}
      isSaveDisabled={false}
      isConnectionStringValid={isConnectionStringValid}
      isSchemaValid={isSchemaValid}
      isSchemaValidating={isSchemaValidating}
      onCancel={handleCancel}
      onSubmit={handleSubmit}
      formValues={formValues}
      setFormValues={setFormValues}
      onIndexNameChange={handleIndexNameChange}
      onConnectionStringChange={handleConnectionStringChange}
      onFetchSchema={handleFetchSchema}
      dataSourceTypeOptions={dataSourceTypeOptions}
      indexField={indexField}
      connectionField={connectionField}
      dialogOpen={dialogOpen}
    />
  );
}
