'use client';
import { AgentResponseDto } from '@/types/agent';
import { Stack } from '@mui/material';
import { useViewModel } from '../../sharedViewModel/viewModel';
import { DataSourceResponse } from '@/types/dataSourceDto';
import AgentForm from '@/components/AgentForm';
import useAppStore from '@/store/AppStore';
import { useEffect } from 'react';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';

type AgentPageProps = {
  app: AppRegistrationWithUserRoles;
  agent: AgentResponseDto;
  dataSources: DataSourceResponse[];
};

export default function EditAgent({ app, agent, dataSources }: AgentPageProps) {
  const {
    handleCancel,
    handleSubmit,
    handleDataConnectorChange,
    handleCloseDataConnectorDialog,
    handleOpenDataConnectorDialog,
    handleDataConnectorCreate,
    isDataConnectorDialogOpen,
    setFormValues,
    formValues,
    isSaving,
    dataSourceOptions,
  } = useViewModel(agent.applicationId, dataSources, agent);

  const setSlugs = useAppStore((state) => state.setSlugs);
  const setAppSlug = useAppStore((state) => state.setAppSlug);

  useEffect(() => {
    setSlugs({
      [agent.id]: agent.name,
    });
    setAppSlug(app);
  }, [setSlugs, agent.id, agent.name, setAppSlug, app]);

  return (
    <Stack
      direction='column'
      sx={{
        height: '100%',
      }}
    >
      <AgentForm
        dataSourceOptions={dataSourceOptions}
        formValues={formValues}
        onDataConnectorChange={handleDataConnectorChange}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        setFormValues={setFormValues}
        isSaving={isSaving}
        isDataConnectorDialogOpen={isDataConnectorDialogOpen}
        app={app}
        onCloseDataConnectorDialog={handleCloseDataConnectorDialog}
        onOpenDataConnectorDialog={handleOpenDataConnectorDialog}
        onDataConnectorCreate={handleDataConnectorCreate}
      />
    </Stack>
  );
}
