import { getAgentById } from '@/app/actions/resources/agents';
import EditAgent from './_components/AgentLandingPage';
import { dataSourceService } from '@/app/services/dataSourceService';
import { appRegistrationService } from '@/app/services/appRegistrationService';

export default async function AgentLanding({
  params,
}: {
  params: { id: string; agentId: string };
}) {
  let agent;
  let dataSources;
  let app;
  try {
    [app, agent, dataSources] = await Promise.all([
      appRegistrationService.getAppWithUserRoles(params.id),
      getAgentById(params.id, params.agentId),
      dataSourceService.getPagedDataSources(params.id, {
        page: 0,
        pageSize: 100,
      }),
    ]);
  } catch {
    throw Error(`Failed to fetch agent with id: ${params.agentId}`);
  }

  return <EditAgent app={app} agent={agent} dataSources={dataSources.items} />;
}
