import { appRegistrationService } from '@/app/services/appRegistrationService';
import AgentsPage from './_components/AgentsPage';

export default async function Agents({ params }: { params: { id: string } }) {
  let app;
  try {
    app = await appRegistrationService.getAppWithUserRoles(params.id);
  } catch {
    throw Error(`Failed to fetch app registration with id: ${params.id}`);
  }

  return <AgentsPage app={app} />;
}
