import { agentService } from '@/app/services/agentService';
import { useToastHandler } from '@/store/Toast';
import { AgentRequestDto, AgentResponseDto } from '@/types/agent';
import { DataSourceResponse } from '@/types/dataSourceDto';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Option } from '@/types/option';
import { SelectChangeEvent } from '@mui/material/Select';
import { onlyLLMDataSource } from '@/constants/onlyLLMDataSource';

export const useViewModel = (
  appId: string,
  dataSources: DataSourceResponse[],
  initialAgent?: AgentResponseDto
) => {
  const [isSaving, setIsSaving] = useState(false);
  const router = useRouter();
  const { addMessage } = useToastHandler();
  const pathName = usePathname();
  const [dataSourceOptions, setDataSourceOptions] = useState<Option[]>([]);
  const [isDataConnectorDialogOpen, setIsDataConnectorDialogOpen] =
    useState(false);

  useEffect(() => {
    setDataSourceOptions([
      ...dataSources.map((d) => ({
      label: d.name,
      value: d.id,
      })),
      { label: onlyLLMDataSource.name, value: onlyLLMDataSource.id },
    ]);
  }, [dataSources]);

  const [formValues, setFormValues] = useState<AgentRequestDto>({
    name: '',
    description: '',
    applicationId: appId,
    dataSourceIds: [],
    configuration: {
      instructions: 'You are an AI assistant to help answer user questions.',
    },
  });

  useEffect(() => {
    if (initialAgent) {
      setFormValues({
        ...initialAgent,
        dataSourceIds: initialAgent.dataSources.map((d) => d.id),
      });
    }
  }, [initialAgent]);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (initialAgent) {
      handleUpdate(formValues, initialAgent.id);
    } else {
      handleCreate(formValues);
    }
  };

  const handleCreate = async (agentRequest: AgentRequestDto) => {
    setIsSaving(true);

    agentService
      .createAgent(appId, agentRequest)
      .then(() => {
        const newRoute = pathName.replace('/new', '');
        router.push(newRoute);
      })
      .catch((error) => {
        addMessage('Error creating Agent', 'error', error.message);
      })
      .finally(() => {
        setIsSaving(false);
      });
  };

  const handleUpdate = async (agentRequest: AgentRequestDto, id: string) => {
    setIsSaving(true);

    agentService
      .updateAgent(appId, agentRequest, id)
      .then(() => {
        const newRoute = pathName.replace('/edit', '');
        router.push(newRoute);
        addMessage('Agent updated', 'success');
      })
      .catch((error) => {
        addMessage('Error saving Agent', 'error', error.message);
      })
      .finally(() => {
        setIsSaving(false);
      });
  };

  const handleCancel = () => {
    router.back();
  };

  const handleDataConnectorChange = (event: SelectChangeEvent) => {
    setFormValues((prev) => ({
      ...prev,
      dataSourceIds: [event.target.value],
    }));
  };

  const handleOpenDataConnectorDialog = () => {
    setIsDataConnectorDialogOpen(true);
  };

  const handleCloseDataConnectorDialog = () => {
    setIsDataConnectorDialogOpen(false);
  };

  const handleDataConnectorCreate = (
    dataConnectorName: string,
    dataConnectorId: string
  ) => {
    setDataSourceOptions((prev) => [
      ...prev,
      {
        label: dataConnectorName,
        value: dataConnectorId,
      },
    ]);
    setFormValues((prev) => ({
      ...prev,
      dataSourceIds: [dataConnectorId],
    }));

    setIsDataConnectorDialogOpen(false);
  };

  return {
    isSaving,
    isDataConnectorDialogOpen,
    dataSourceOptions,
    formValues,
    setFormValues,
    handleCloseDataConnectorDialog,
    handleOpenDataConnectorDialog,
    handleDataConnectorChange,
    handleDataConnectorCreate,
    handleSubmit,
    handleCancel,
  };
};