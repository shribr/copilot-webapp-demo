'use client';
import { authorizationService } from '@/app/services/authorizationService';
import ConfirmationDialog from '@/components/ConfirmationDialog';
import { LoadingList } from '@/components/LoadingList';
import SearchInput from '@/components/SearchInput';
import useComponentHeight from '@/hooks/useComponentHeight';
import useAppStore from '@/store/AppStore';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';
import { Box, Button, Stack } from '@mui/material';
import Link from 'next/link';
import { useEffect } from 'react';
import EditMenu from './EditMenu';
import { useViewModel } from './viewModel';

type AgentsPageProps = {
  app: AppRegistrationWithUserRoles;
};
export default function AgentsPage({ app }: AgentsPageProps) {
  const {
    columns,
    rows,
    rowCount,
    isLoading,
    paginationModel,
    pathname,
    anchorEl,
    menuSelectedItem,
    setPaginationModel,
    handleRowClick,
    handleMenuClose,
    handleArchiveMenuSelect,
    handleDisableMenuSelect,
    handleAgentStatusChange,
    handleFilterChange,    
    handleSortByField,
    isArchiveDialogOpen,
    isDisableDialogOpen,
    isSaving,
  } = useViewModel(app);

  const setAppSlug = useAppStore((state) => state.setAppSlug);

  useEffect(() => {
    setAppSlug(app);
  }, [setAppSlug, app]);

  const { ref, height } = useComponentHeight();

  const canEditAgent = authorizationService.agent.canEdit(app.userRoles);

  const disableMessage = `Disabling this agent will prevent users from chatting. This action will also make all ongoing conversations in this app inaccessible. Other agents will not be affected.`;

  const enableMessage = `Enabling this agent will allow users to resume conversations. Other agents will not be affected.`;

  const archiveMessage =
    'Archiving this agent will remove it from view and make it inaccessible to users. The agent will be stored for auditing purposes but can no longer be accessed or used.';

  return (
    <>
      <Stack
        direction='column'
        sx={{
          gap: 2,
          height: '100%',
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Stack
          direction='row'
          sx={{
            width: '100%',
            gap: 2,
            alignItems: 'center',
          }}
        >
          <Box>
            <Button
              variant='contained'
              color='primary'
              disabled={!canEditAgent}
              LinkComponent={Link}
              href={`${pathname}/new`}
            >
              Create New Agent
            </Button>
          </Box>

          <Box sx={{ width: '50%' }}>
            <SearchInput
              onChange={handleFilterChange}
              sx={{ flexGrow: 1, width: '100%' }}
              autoComplete='off'
            />
          </Box>
        </Stack>
        <Stack
          direction='row'
          ref={ref}
          sx={{
            height: '100%',
            width: '100%',
            gap: 2,
            flexGrow: 1,
            overflowY: 'scroll',
          }}
        >
          <Box sx={{ height, width: '100%' }}>
            <LoadingList
              columns={columns}
              rows={rows}
              pagination
              rowCount={rowCount}
              paginationModel={paginationModel}
              paginationMode='server'
              onPaginationModelChange={setPaginationModel}
              pageSizeOptions={[10, 25, 100]}
              loading={isLoading}
              disableRowSelectionOnClick
              onRowClick={handleRowClick}
              sx={{
                '.MuiDataGrid-row': {
                  cursor: 'pointer',
                },
              }}
              onSortModelChange={handleSortByField}
              sortingMode='server'
            />
          </Box>
        </Stack>
      </Stack>
      <EditMenu
        anchorEl={anchorEl}
        menuSelectedItem={menuSelectedItem}
        onMenuClose={handleMenuClose}
        onArchiveMenuSelect={handleArchiveMenuSelect}
        onDisableMenuSelect={handleDisableMenuSelect}
        pathName={pathname}
        appRoute={app.routeName}
      />
      <ConfirmationDialog
        title={`Archive ${menuSelectedItem?.name}?`}
        message={archiveMessage}
        isOpen={isArchiveDialogOpen}
        onClose={handleArchiveMenuSelect}
        onConfirm={() => handleAgentStatusChange('Archive')}
        isSaving={isSaving}
      />
      <ConfirmationDialog
        title={`${menuSelectedItem?.isDisabled ? 'Enable' : 'Disable'} ${
          menuSelectedItem?.name
        }?`}
        message={`${
          menuSelectedItem?.isDisabled ? enableMessage : disableMessage
        }`}
        isOpen={isDisableDialogOpen}
        onClose={handleDisableMenuSelect}
        onConfirm={() =>
          handleAgentStatusChange(
            `${menuSelectedItem?.isDisabled ? 'Enable' : 'Disable'}`
          )
        }
        isSaving={isSaving}
      />
    </>
  );
}
