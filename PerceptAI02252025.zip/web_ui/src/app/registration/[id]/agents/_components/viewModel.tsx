import { agentService } from '@/app/services/agentService';
import { useToastHandler } from '@/store/Toast';
import { AgentResponseDto, AgentStatusAction } from '@/types/agent';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';
import { Pagination } from '@/types/pagination';
import { SortingModel } from '@/types/sortingModel';
import MoreHorizRoundedIcon from '@mui/icons-material/MoreHorizRounded';
import { Chip, IconButton, Stack, Typography } from '@mui/material';
import { GridColDef, GridRowParams, GridSortModel } from '@mui/x-data-grid';
import { usePathname, useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';

export const useViewModel = (app: AppRegistrationWithUserRoles) => {
  const [isLoading, setIsLoading] = useState(false);
  const [rows, setRows] = useState<AgentResponseDto[]>([]);
  const [rowCount, setRowCount] = useState(0);
  const [paginationModel, setPaginationModel] = useState<Pagination>({
    pageSize: 25,
    page: 0,
  });
  const { addMessage } = useToastHandler();
  const router = useRouter();
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isArchiveDialogOpen, setIsArchiveDialogOpen] = useState(false);
  const [isDisableDialogOpen, setIsDisableDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [filter, setFilter] = useState<string>('');  
  const [sortingModel, setSortingModel] = useState<SortingModel>({
    sortBy: 'name',
    sortDirection: 'asc',
  });

  const fetchRows = useCallback(() => {
    setIsLoading(true);
    agentService
      .getPagedAgents(
        app.id,
        paginationModel,
        filter,
        sortingModel
      )
      .then((response) => {
        setRows(response.items);
        setRowCount(response.totalCount);
      })
      .catch((error) => {
        console.error('Error fetching agents', error);
        addMessage('Error fetching agents', 'error');
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [addMessage, app.id, filter, paginationModel, sortingModel]);

  useEffect(() => {
    fetchRows();
  }, [fetchRows]);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [menuSelectedItem, setMenuSelectedItem] =
    useState<AgentResponseDto | null>(null);

  const handleMenuClose = () => {
    setAnchorEl(null);
    setMenuOpen(false);
  };

  const handleMenuOpen = (
    event:
      | React.MouseEvent<HTMLButtonElement>
      | React.KeyboardEvent<HTMLButtonElement>,
    item: AgentResponseDto
  ) => {
    event.stopPropagation(); // Prevent row selection
    setAnchorEl(event.currentTarget);
    setMenuSelectedItem(item);
    setMenuOpen(true);
    event.preventDefault();
  };

  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLButtonElement>,
    item: AgentResponseDto
  ) => {
    if (event.key === 'Enter') {
      handleMenuOpen(event, item);
    }
  };

  const columns: GridColDef<AgentResponseDto>[] = [
    {
      field: 'name',
      headerName: 'Agent Name',
      flex: 1,
      renderCell: (params) => (
        <Stack
          direction='row'
          sx={{
            gap: 1,
            height: '100%',
            justifyContent: 'flex-start',
            alignItems: 'center',
          }}
        >
          <Typography
            sx={{
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {params.row.name}
          </Typography>
          {params.row.isDisabled && (
            <Chip label='Disabled' size='small' tabIndex={params.tabIndex} />
          )}
        </Stack>
      ),
    },
    {
      field: 'description',
      headerName: 'Description',
      flex: 1,
    },
    {
      field: 'edit',
      headerName: '',
      width: 75,
      renderCell: (params) => (
        <IconButton
          edge='end'
          onClick={(event) => handleMenuOpen(event, params.row)}
          onKeyDown={(event) => handleKeyDown(event, params.row)}
          aria-controls={menuOpen ? `menu-${params.id}` : undefined}
          aria-haspopup='true'
          aria-expanded={menuOpen ? 'true' : undefined}
          aria-label={`Open menu for ${params.row.name}`}
          tabIndex={params.tabIndex}
        >
          <MoreHorizRoundedIcon />
        </IconButton>
      ),
    },
  ];

  const handleRowClick = (params: GridRowParams) => {
    router.push(`${pathname}/${params.row.id}`);
  };

  const handleSortByField = (sorting: GridSortModel) => {
    if (!sorting.length) {
      return;
    }

    setSortingModel({
      sortBy: sorting[0].field,
      sortDirection: sorting[0].sort || 'asc',
    });
  };

  const handleArchiveMenuSelect = () => {
    setIsArchiveDialogOpen((prev) => !prev);
    handleMenuClose();
  };

  const handleDisableMenuSelect = () => {
    setIsDisableDialogOpen((prev) => !prev);
    handleMenuClose();
  };

  const handleFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setFilter(value);
  };

  const handleAgentStatusChange = async (action: AgentStatusAction) => {
    if (!menuSelectedItem) {
      return;
    }

    setIsSaving(true);
    agentService
      .updateAgentStatus(app.id, menuSelectedItem.id, action)
      .then(() => {
        addMessage('Agent status updated successfully', 'success');
      })
      .catch((error: Error) => {
        addMessage('Error changing Agent status', 'error', error.message);
      })
      .finally(() => {
        setIsSaving(false);
        setIsArchiveDialogOpen(false);
        setIsDisableDialogOpen(false);
      });
  };

  return {
    columns,
    rows,
    rowCount,
    isLoading,
    paginationModel,
    pathname,
    appRoute: app.routeName,
    anchorEl,
    menuSelectedItem,
    setPaginationModel,
    handleRowClick,
    handleMenuClose,
    handleArchiveMenuSelect,
    handleDisableMenuSelect,
    handleAgentStatusChange,
    handleFilterChange,    
    handleSortByField,
    isArchiveDialogOpen,
    isDisableDialogOpen,
    isSaving,    
    filter,
    sortingModel,
  };
};
