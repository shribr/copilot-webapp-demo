import { AgentResponseDto } from '@/types/agent';
import { Divider, Menu, MenuItem } from '@mui/material';
import { useRouter } from 'next/navigation';

type EditMenuProps = {
  anchorEl: null | HTMLElement;
  menuSelectedItem: AgentResponseDto | null;
  onMenuClose: () => void;
  onArchiveMenuSelect: () => void;
  onDisableMenuSelect: () => void;
  pathName: string;
  appRoute: string;
};

export default function EditMenu({
  anchorEl,
  menuSelectedItem,
  pathName,
  appRoute,
  onMenuClose,
  onArchiveMenuSelect,
  onDisableMenuSelect,
}: EditMenuProps) {
  const router = useRouter();
  const enableOrDisable = menuSelectedItem?.isDisabled ? 'Enable' : 'Disable';
  return (
    <Menu
      id={`menu-${menuSelectedItem?.id}`}
      anchorEl={anchorEl}
      open={Boolean(anchorEl)}
      onClose={onMenuClose}
      MenuListProps={{
        'aria-labelledby': `menu-button-${menuSelectedItem?.id}`,
      }}
    >
      <MenuItem
        onClick={() => {
          if (menuSelectedItem) {
            router.push(`/${appRoute}/chat?agent=${menuSelectedItem.name}`);
          }
        }}
        aria-label={`Chat with ${menuSelectedItem?.name}`}
      >
        Chat
      </MenuItem>
      <MenuItem
        onClick={() => {
          if (menuSelectedItem) {
            router.push(`${pathName}/${menuSelectedItem.id}`);
          }
        }}
        aria-label={`Edit Agent Settings ${menuSelectedItem?.id}`}
      >
        Edit Agent Settings
      </MenuItem>
      <Divider />
      <MenuItem
        onClick={onArchiveMenuSelect}
        aria-label={`Archive ${menuSelectedItem?.id}`}
      >
        Archive
      </MenuItem>
      <MenuItem
        onClick={onDisableMenuSelect}
        aria-label={`${enableOrDisable} ${menuSelectedItem?.id}`}
      >
        {enableOrDisable}
      </MenuItem>
    </Menu>
  );
}
