import { dataSourceService } from '@/app/services/dataSourceService';
import { appRegistrationService } from '@/app/services/appRegistrationService';
import CreateAgentPage from './_components/CreateAgentPage';

export default async function CreateAgent({
  params,
}: {
  params: { id: string };
}) {
  let app;
  let dataSources;
  try {
    [app, dataSources] = await Promise.all([
      appRegistrationService.getAppWithUserRoles(params.id),
      dataSourceService.getPagedDataSources(params.id, {
        page: 0,
        pageSize: 100,
      }),
    ]);
  } catch {
    throw Error(`Failed to fetch app registration with id: ${params.id}`);
  }

  return <CreateAgentPage app={app} dataSources={dataSources.items} />;
}
