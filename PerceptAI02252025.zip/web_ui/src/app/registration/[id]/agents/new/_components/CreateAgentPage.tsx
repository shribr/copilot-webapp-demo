'use client';
import AgentForm from '@/components/AgentForm';
import { Stack } from '@mui/material';
import { useViewModel } from '../../sharedViewModel/viewModel';
import { DataSourceResponse } from '@/types/dataSourceDto';
import useAppStore from '@/store/AppStore';
import { useEffect } from 'react';
import { AppRegistrationWithUserRoles } from '@/types/appRegistration';

type CreateAgentPageProps = {
  app: AppRegistrationWithUserRoles;
  dataSources: DataSourceResponse[];
};
export default function CreateAgentPage({
  app,
  dataSources,
}: CreateAgentPageProps) {
  const {
    handleCancel,
    handleSubmit,
    handleDataConnectorChange,
    handleCloseDataConnectorDialog,
    handleOpenDataConnectorDialog,
    handleDataConnectorCreate,
    setFormValues,
    formValues,
    isSaving,
    isDataConnectorDialogOpen,
    dataSourceOptions,
  } = useViewModel(app.id, dataSources);

  const setAppSlug = useAppStore((state) => state.setAppSlug);

  useEffect(() => {
    setAppSlug(app);
  }, [app, setAppSlug]);

  return (
    <Stack
      sx={{
        height: '100%',
      }}
    >
      <AgentForm
        newAgent
        app={app}
        dataSourceOptions={dataSourceOptions}
        formValues={formValues}
        onDataConnectorChange={handleDataConnectorChange}
        onCloseDataConnectorDialog={handleCloseDataConnectorDialog}
        onOpenDataConnectorDialog={handleOpenDataConnectorDialog}
        onDataConnectorCreate={handleDataConnectorCreate}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        setFormValues={setFormValues}
        isDataConnectorDialogOpen={isDataConnectorDialogOpen}
        isSaving={isSaving}
      />
    </Stack>
  );
}
