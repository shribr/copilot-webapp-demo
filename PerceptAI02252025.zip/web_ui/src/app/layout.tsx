'use server';

import AppLayout from '@/app/_components/AppLayout';
import ThemeWrapper from '@/app/_components/ThemeWrapper';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter';
import { ErrorBoundary } from 'next/dist/client/components/error-boundary';
import Error from './error';
import './globals.css';
import MsalWrapper from '@/msal/MsalWrapper';
import { joinUrl } from '@/utils/url';
import AppSettingsWrapper from './appSettingsWrapper';
import { GetClientAppSettings } from './actions/appSettings';
import { getTokenCookieAsync } from '@/utils/apiUtils';
import { Metadata } from 'next';
import {
  classificationService,
  ClassificationSettings,
} from '@/components/Classifications';
import { workspaceService } from './workspaces/_services/workspaceService';
import { WorkspaceConfiguration } from './workspaces/_types/workspaceConfiguration';

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: process.env.NEXT_TITLE ?? 'AI Assistant',
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // Arbitrary server call to trigger loading of env in Azure Environment
  await getTokenCookieAsync();
  let classificationSettings: ClassificationSettings;
  let workspaceConfiguration: WorkspaceConfiguration;

  const appSettings = await GetClientAppSettings();
  try {
    [classificationSettings, workspaceConfiguration] = await Promise.all([
      classificationService.getClassificationSettings(),
      workspaceService.getConfiguration(),
    ]);
  } catch (error) {
    console.error('Error fetching settings:', error);
    // handle default values for these settings if they fail to load
    classificationSettings = {
      classificationControls: [],
      classificationValueOptions: [],
    };
    workspaceConfiguration = {
      enabled: false,
      maxSources: 0,
      maxWorkspaces: 0,
      enableCollaboration: false,
    };
  }

  const msalConfig = {
    auth: {
      clientId: process.env.NEXT_AZURE_AD_CLIENT_ID ?? '',
      authority: joinUrl(
        process.env.NEXT_AZURE_AD_ENDPOINT ?? '',
        process.env.NEXT_AZURE_AD_TENANT_ID ?? ''
      ),
      redirectUri: process.env.NEXT_APP_REDIRECT_URI,
      // build an auth page to capture the authentication, set the cookie and then redirect to the app?
      postLogoutRedirectUri: process.env.NEXT_APP_REDIRECT_URI,
    },
    system: {
      allowNativeBroker: false,
    },
  };

  return (
    <html lang='en'>
      <body>
        <AppSettingsWrapper
          appSettings={{
            ...appSettings,
            WorkspaceConfiguration: workspaceConfiguration,
          }}
          classificationSettings={classificationSettings}
        >
          <ThemeWrapper>
            <AppRouterCacheProvider>
              <MsalWrapper config={msalConfig}>
                <ErrorBoundary errorComponent={Error}>
                  <AppLayout>{children}</AppLayout>
                </ErrorBoundary>
              </MsalWrapper>
            </AppRouterCacheProvider>
          </ThemeWrapper>
        </AppSettingsWrapper>
      </body>
    </html>
  );
}
