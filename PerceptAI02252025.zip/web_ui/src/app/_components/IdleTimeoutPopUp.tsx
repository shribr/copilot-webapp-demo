import React from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  Button,
} from '@mui/material';

interface IdleTimeoutPopupProps {
  onStayLoggedIn: () => void;
}

export default function IdleTimeoutPopup({ onStayLoggedIn }: IdleTimeoutPopupProps) {
  return (
    <Dialog open={true} sx={{ p: '2rem' }}>
      <DialogTitle>You will be logged out soon due to inactivity.</DialogTitle>
      <DialogContent>
        <Box display="flex" justifyContent="center" alignItems="center" sx={{ mt: 2 }}>
          <Button variant="contained" color="primary" onClick={onStayLoggedIn}>
            Stay Logged In
          </Button>
        </Box>
      </DialogContent>
      <DialogActions></DialogActions>
    </Dialog>
  );
}