'use client';
import LoadingMessage from '@/components/LoadingMessage';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import { Stack, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useViewModel } from './viewModel';
import AppsCard from './AppsCard';
import { AppRegistrationResponse } from '@/types/appRegistration';

const StatusContainer = ({ children }: { children: React.ReactNode }) => (
  <Stack
    sx={{ justifyContent: 'center', alignItems: 'center', padding: '1rem' }}
  >
    {children}
  </Stack>
);

export default function LandingPage() {
  const { isLoading, availableApps } = useViewModel();
  const NEXT_LOGO = useClientAppSettingsStore((state) => state.NEXT_LOGO);
  const NEXT_TITLE = useClientAppSettingsStore((state) => state.NEXT_TITLE);

  const router = useRouter();
  const navigateToApp = (appRoute: string) => {
    return () => router.push(`/${appRoute}/chat`);
  };

  const workspacesConfiguration = useClientAppSettingsStore(
    (state) => state.WorkspaceConfiguration
  );
  useEffect(() => {
    const generateMetadata = () => {
      document.title = NEXT_TITLE + ' - My Apps';
    };
    generateMetadata();
  }, [NEXT_TITLE]);

  const workspacesApp = {
    id: 'workspaces',
    name: 'Workspaces',
    description: 'Your AI workspaces',
    routeName: 'workspaces',
  } as AppRegistrationResponse;

  return (
    <Stack
      sx={{
        height: '100%',
        marginLeft: '2rem',
      }}
    >
      <Typography variant={'h4'} sx={{ padding: '2rem 0 1rem 0' }}>
        My Apps
      </Typography>
      <Stack
        direction='row'
        useFlexGap
        sx={{
          gap: 2,
          flexWrap: 'wrap',
          overflowY: 'auto',
          padding: '.5rem 0',
          justifyContent: 'flex-start',
          alignItems: 'center',
        }}
      >
        {workspacesConfiguration.enabled && (
          <AppsCard
            key={'workspaces'}
            app={workspacesApp}
            logo={'knapsack.svg'}
            onClick={() => router.push(`/${workspacesApp.routeName}`)}
          />
        )}
        {isLoading ? (
          <StatusContainer>
            <LoadingMessage message='Loading Apps...' />
          </StatusContainer>
        ) : (
          availableApps.map((app) => (
            <AppsCard
              key={app.id}
              app={app}
              logo={NEXT_LOGO}
              onClick={navigateToApp(app.routeName)}
            />
          ))
        )}
        {availableApps.length === 0 && !isLoading && (
          <StatusContainer>
            <Typography>No apps available</Typography>
          </StatusContainer>
        )}
      </Stack>
    </Stack>
  );
}
