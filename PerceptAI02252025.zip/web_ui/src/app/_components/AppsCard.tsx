import { AppRegistrationResponse } from '@/types/appRegistration';
import {
  Card,
  CardActionArea,
  CardMedia,
  CardContent,
  Tooltip,
  Stack,
  Typography,
} from '@mui/material';

export type AppsCardProps = {
  app: AppRegistrationResponse;
  logo: string;
  onClick?: () => void;
};
export default function AppsCard({ app, logo, onClick }: AppsCardProps) {
  return (
    <Card
      sx={{
        overflow: 'hidden',
        width: 300,
        height: 300,
        display: 'flex',
        flexDirection: 'column',
      }}
      key={app.id}
    >
      <CardActionArea
        onClick={onClick}
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <CardMedia
          component='img'
          sx={{ paddingTop: '0.5rem', objectFit: 'contain' }}
          height='150'
          image={`/${logo}`}
          alt={`${app.name} Logo`}
        />
        <CardContent
          sx={{
            flexGrow: 1,
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <Tooltip title={app.name}>
            <Stack
              direction='row'
              sx={{
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Typography
                gutterBottom
                variant='h6'
                component='div'
                sx={{
                  display: '-webkit-box',
                  WebkitLineClamp: 1,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {app.name}
              </Typography>
            </Stack>
          </Tooltip>
          <Tooltip title={app.description}>
            <Stack
              direction='row'
              sx={{
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Typography
                variant='body2'
                component='div'
                sx={{
                  color: 'text.secondary',
                  display: '-webkit-box',
                  WebkitLineClamp: 5,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {app.description}
              </Typography>
            </Stack>
          </Tooltip>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}
