'use client';
import { useToastHandler } from '@/store/Toast';
import themeConstants from '@/styles/constants';
import {
  Alert,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Fade,
  Link,
  Stack,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useState } from 'react';
import { TransitionGroup } from 'react-transition-group';

export default function Messages() {
  const { messages, removeMessage } = useToastHandler();
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');

  const handleOpen = (details: string) => {
    setModalContent(details);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setModalContent('');
  };

  return (
    <>
      <TransitionGroup
        component={Stack}
        gap={1}
        direction='column'
        position={'fixed'}
        sx={{
          zIndex: theme.zIndex.modal + 1,
          left: '50%',
          transform: 'translateX(-50%)',
        }}
        bottom={themeConstants.footerHeight}
        width='65%'
      >
        {messages.map((message) => (
          <Fade key={message.id}>
            <Stack
              direction='row'
              sx={{
                justifyContent: 'center',
              }}
            >
              <Alert
                onClose={() => removeMessage(message.id)}
                severity={message.type}
              >
                {message.message}
                <br />
                {message.errorDetails && (
                  <Link
                    href='#'
                    onClick={(e) => {
                      e.preventDefault();
                      handleOpen(
                        message.errorDetails ?? 'No details available'
                      );
                    }}
                    style={{ textDecoration: 'underline', cursor: 'pointer' }}
                    variant='caption'
                  >
                    See Details
                  </Link>
                )}
              </Alert>
            </Stack>
          </Fade>
        ))}
      </TransitionGroup>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby='dialog-title'
        aria-describedby='dialog-description'
        fullWidth={true}
      >
        <DialogTitle id='dialog-title'>Details</DialogTitle>
        <DialogContent>
          <DialogContentText id='dialog-description'>
            {modalContent}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={handleClose}
            color='primary'
            variant='contained'
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
