'use client';
import themeConstants from '@/styles/constants';
import { Card, CardContent, Container, Stack, Typography } from '@mui/material';
import { useEffect } from 'react';

export default function ErrorPage({
  error,
}: {
  error: Error & { digest?: string };
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <Container
      maxWidth={themeConstants.contentWidth}
      sx={{
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Card
        sx={{
          width: '100%',
          height: '50%',
          justifyItems: 'center',
          textAlign: 'center',
        }}
      >
        <CardContent sx={{ height: '100%' }}>
          <Stack
            direction='column'
            sx={{
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
            }}
          >
            <Typography variant='h2' component='div' gutterBottom>
              Oops, Something went wrong!
            </Typography>
            <Typography variant='h5' color='textSecondary'>
              {error.message}
            </Typography>
          </Stack>
        </CardContent>
        {/* <CardActions sx={{ justifyContent: 'center' }}>
          <Button
            variant='contained'
            color='primary'
            size='large'
            onClick={() => router.back()}
          >
            Go Back
          </Button>
        </CardActions> */}
      </Card>
    </Container>
  );
}
