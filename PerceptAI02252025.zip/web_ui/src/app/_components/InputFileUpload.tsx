/* eslint-disable security/detect-object-injection */
import * as React from 'react';
import { styled } from '@mui/material/styles';
import UploadIcon from '@mui/icons-material/Upload';
import ButtonGroup from '@mui/material/ButtonGroup';
import Button from '@mui/material/Button';
import { ButtonProps } from '@mui/material/Button';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Grow from '@mui/material/Grow';
import Paper from '@mui/material/Paper';
import Popper from '@mui/material/Popper';
import MenuItem from '@mui/material/MenuItem';
import Tooltip from '@mui/material/Tooltip';
import MenuList from '@mui/material/MenuList';
import { useEffect, useMemo } from 'react';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

type InputFileUploadProps = Omit<ButtonProps, 'onClick'> & {
  onClick: (file: File[], useMarkdown?: boolean) => void;
  isUploading?: boolean;
  enableMarkdown?: boolean;
  allowMarkdown?: boolean;
};

export default function InputFileUpload({
  onClick,
  isUploading = false,
  enableMarkdown = false,
  allowMarkdown = true,
  ...props
}: InputFileUploadProps) {
  const handleFileChange: React.ChangeEventHandler<HTMLInputElement> = (
    event
  ) => {
    if (event && event.target.files) {
      const files = Array.from(event.target.files);
      onClick(files, selectedIndex === 1);
    }
  };

  const options = useMemo(() => [
    {
      label: 'Upload',
      tooltip: 'Standard upload process.',
      enable: true,
    },
    {
      label: 'Markdown Upload',
      tooltip:
        'Uses Azure Document Intelligence for advanced processing. Incurs additional costs per upload.',
      enable: enableMarkdown,
    },
  ], [enableMarkdown]);

  const [localOptions, setLocalOptions] = React.useState(options);
  const [open, setOpen] = React.useState(false);
  const anchorRef = React.useRef<HTMLDivElement>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  useEffect(() => {
    setLocalOptions(allowMarkdown ? options : options.slice(0, 1));
  }, [allowMarkdown, options]);

  const handleMenuItemClick = (
    event: React.MouseEvent<HTMLLIElement, MouseEvent>,
    index: number
  ) => {
    setSelectedIndex(index);
    setOpen(false);
  };

  const handleClose = (event: Event) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }

    setOpen(false);
  };

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  return (
    <>
      <ButtonGroup ref={anchorRef}>
        <Tooltip title={localOptions[selectedIndex].tooltip}>
          <Button
            variant='contained'
            color='primary'
            component='label'
            role={undefined}
            disabled={isUploading}
            loading={isUploading}
            endIcon={<UploadIcon />}
            loadingPosition='end'
            {...props}
          >
            {localOptions[selectedIndex].label}
            <VisuallyHiddenInput
              ref={inputRef}
              type='file'
              onChange={handleFileChange}
              multiple
              onClick={() => {
                if (inputRef.current) {
                  inputRef.current.value = '';
                }
              }}
            />
          </Button>
        </Tooltip>
        {localOptions.length > 1 && (
          <Button
            size='small'
            variant='contained'
            aria-controls={open ? 'split-button-menu' : undefined}
            aria-expanded={open ? 'true' : undefined}
            aria-label='select merge strategy'
            aria-haspopup='menu'
            onClick={handleToggle}
          >
            <ArrowDropDownIcon />
          </Button>
        )}
      </ButtonGroup>
      <Popper
        sx={{ zIndex: 1 }}
        open={open}
        anchorEl={anchorRef.current}
        role={undefined}
        transition
        disablePortal
      >
        {({ TransitionProps, placement }) => (
          <Grow
            {...TransitionProps}
            style={{
              transformOrigin:
                placement === 'bottom' ? 'center top' : 'center bottom',
            }}
          >
            <Paper>
              <ClickAwayListener onClickAway={handleClose}>
                <MenuList id='split-button-menu' autoFocusItem>
                  {localOptions.map((option, index) => (
                    <Tooltip
                      key={option.label}
                      title={option.tooltip}
                      placement='right'
                    >
                      <MenuItem
                        selected={index === selectedIndex}
                        disabled={!option.enable}
                        onClick={(event) => handleMenuItemClick(event, index)}
                      >
                        {option.label}
                      </MenuItem>
                    </Tooltip>
                  ))}
                </MenuList>
              </ClickAwayListener>
            </Paper>
          </Grow>
        )}
      </Popper>
    </>
  );
}
