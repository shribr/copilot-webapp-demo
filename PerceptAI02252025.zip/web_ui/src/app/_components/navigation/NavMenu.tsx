'use client';
import { useTheme as useThemeProvider } from '@/app/_components/ThemeWrapper';
import Icon from '@/components/Icon';
import navigationRoutes, { routeSlugs } from '@/utils/navigationRoutes';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import LightModeIcon from '@mui/icons-material/LightMode';
import QuestionMarkIcon from '@mui/icons-material/HelpOutline';
import LogoutIcon from '@mui/icons-material/Logout';
import {
  Divider,
  Fade,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  MenuList,
  Stack,
  Typography,
} from '@mui/material';
import {
  useParams,
  usePathname,
  useSearchParams,
  useRouter,
} from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { SwitchTransition } from 'react-transition-group';
import Link from 'next/link';
import { searchParamNames } from '@/constants/searchParamNames';
import { appRoute } from '@/types/appRoute';
import { handleLogout } from '@/msal/msal';
import useUserStore from '@/store/UserStore';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import AppVersion from '@/components/AppVersion';

export default function NavMenu({
  open,
  anchorElement,
}: {
  open: boolean;
  anchorElement: HTMLElement | null;
}) {
  const { toggleTheme, isDarkTheme } = useThemeProvider();
  const [isOpen, setOpen] = useState(open);
  const user = useUserStore((state) => state.user);
  const activePathname = usePathname();
  const router = useRouter();

  const params = useParams();
  const searchParams = useSearchParams();

  const getRoutes = useCallback(() => {
    const appRouteParam = Array.isArray(params.routeName)
      ? params.routeName[0]
      : params.routeName;
    const appId = Array.isArray(params.id) ? params.id[0] : params.id;
    const agentId = Array.isArray(params.agentId)
      ? params.agentId[0]
      : params.agentId;
    const agentName = searchParams.get(searchParamNames.agent) ?? undefined;
    const slugs: routeSlugs = {
      appId,
      appRoute: appRouteParam,
      agentId,
      agentName,
    };

    return navigationRoutes.getChildren(user?.systemRoles, '/', slugs);
  }, [
    params.agentId,
    params.id,
    params.routeName,
    searchParams,
    user?.systemRoles,
  ]);

  const [rootRoutes, setRootRoutes] = useState<appRoute[]>(getRoutes());

  const helpUrl = useClientAppSettingsStore((state) => state.NEXT_HELP_URL);
  const helpUrlName = useClientAppSettingsStore(
    (state) => state.NEXT_HELP_URL_NAME
  );

  useEffect(() => {
    setRootRoutes(getRoutes());
  }, [getRoutes]);

  useEffect(() => {
    setOpen(open);
  }, [open]);

  return (
    <Menu
      sx={{ width: 300, maxWidth: '100%' }}
      id='nav-menu'
      anchorEl={anchorElement}
      open={isOpen}
      onClose={() => {
        setOpen(false);
      }}
      onKeyDown={(event) => {
        if (event.key === 'Escape') {
          setOpen(false);
        }
      }}
    >
      <Stack direction='column'>
        <Typography
          variant='body1'
          sx={{
            padding: '0 1rem',
            fontWeight: 'bold',
            display: 'inline-block',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            width: '100%',
          }}
        >
          {user?.name}
        </Typography>
        <Typography
          variant='caption'
          sx={{
            padding: '0 1rem',
            display: 'inline-block',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            width: '100%',
          }}
        >
          {user?.email}
        </Typography>
      </Stack>
      <MenuList sx={{ padding: '0', width: '100%', overflow: 'hidden' }}>
        {rootRoutes.map((tab) => (
          <MenuItem
            key={`${tab.href}`}
            selected={activePathname === tab.href}
            href={tab.href}
            onClick={() => {
              router.push(`${tab.href}`);
            }}
            LinkComponent={Link}
            disabled={tab.disabled}
          >
            <ListItemIcon>
              <Icon iconName={tab?.icon || ''} />
            </ListItemIcon>
            <ListItemText>{tab.title}</ListItemText>
          </MenuItem>
        ))}
        <Divider />
        {helpUrl && (
          <MenuItem
            component='a'
            href={helpUrl}
            target='_blank'
            rel='noreferrer'
          >
            <ListItemIcon>
              <QuestionMarkIcon fontSize='small' />
            </ListItemIcon>
            <ListItemText
              primary={helpUrlName || 'Help'}
              slotProps={{
                primary: {
                  noWrap: true,
                  sx: {
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: 'block',
                  },
                },
              }}
            />
          </MenuItem>
        )}
        <MenuItem onClick={toggleTheme}>
          <ListItemIcon>
            <SwitchTransition mode='out-in'>
              <Fade key={isDarkTheme ? 'dark' : 'light'}>
                {isDarkTheme ? <LightModeIcon /> : <DarkModeIcon />}
              </Fade>
            </SwitchTransition>
          </ListItemIcon>
          <ListItemText>Set {isDarkTheme ? 'Light' : 'Dark'} Mode</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleLogout()}>
          <ListItemIcon>
            <LogoutIcon fontSize='small' />
          </ListItemIcon>
          <ListItemText>Sign Out</ListItemText>
        </MenuItem>
      </MenuList>
      <Divider />
      <AppVersion />
    </Menu>
  );
}
