'use client';
import useUserStore from '@/store/UserStore';
import { Avatar, AvatarProps } from '@mui/material';

export default function UserAvatar({
  variant,
  sx,
}: Pick<AvatarProps, 'variant' | 'sx'>) {
  const user = useUserStore((state) => state.user);
  return (
    <Avatar
      sx={{
        ...{
          width: 32,
          height: 32,
        },
        ...sx,
      }}
      alt={user?.name}
      src={user?.image ?? ''}
      variant={variant}
    >
      {user?.name?.charAt(0)}
    </Avatar>
  );
}
