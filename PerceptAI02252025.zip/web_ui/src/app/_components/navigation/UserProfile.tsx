'use client';

import { IconButton } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useState } from 'react';
import NavMenu from './NavMenu';
import UserAvatar from './UserAvatar';
import useUserStore from '@/store/UserStore';

export default function UserProfile() {
  const user = useUserStore((state) => state.user);
  const theme = useTheme();
  const [navMenuOpen, setNavMenuOpen] = useState(false);

  const handleClick = () => {
    setNavMenuOpen(!navMenuOpen);
  };

  return (
    <IconButton id='basic-button' onClick={handleClick} aria-label={user?.name}>
      <UserAvatar
        sx={{
          bgcolor: theme.palette.getContrastText(theme.palette.primary.dark),
          color: theme.palette.primary.dark,
        }}
      />
      <NavMenu
        open={navMenuOpen}
        anchorElement={document.getElementById('basic-button')}
      />
    </IconButton>
  );
}
