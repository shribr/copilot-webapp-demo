import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import { Stack, StackProps, Typography } from '@mui/material';
import Image from 'next/image';

type LogoProps = StackProps & {
  textColor?: string;
};
export default function Logo({ textColor = 'inherit', ...props }: LogoProps) {
  const NEXT_LOGO = useClientAppSettingsStore((state) => state.NEXT_LOGO);
  const NEXT_TITLE = useClientAppSettingsStore((state) => state.NEXT_TITLE);

  return (
    <Stack
      direction='row'
      {...props}
      sx={[
        {
          gap: 2,
          alignItems: 'center',
          justifyContent: 'center',
        },
        ...(Array.isArray(props.sx) ? props.sx : [props.sx]),
      ]}
    >
      {NEXT_LOGO && (
        <Image
          src={`/${NEXT_LOGO}`}
          width='55'
          height='55'
          alt={`${NEXT_TITLE} Logo`}
          priority
        />
      )}
      <Typography variant='h5' sx={{ color: textColor }}>
        {NEXT_TITLE}
      </Typography>
    </Stack>
  );
}
