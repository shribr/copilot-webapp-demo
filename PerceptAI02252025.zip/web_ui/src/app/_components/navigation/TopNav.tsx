'use client';

import themeConstants from '@/styles/constants';
import MenuIcon from '@mui/icons-material/Menu';
import { Stack } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';
import Link from 'next/link';
import ClassificationBanner from '../ClassificationBanner';
import Logo from './Logo';
import UserProfile from './UserProfile';

interface Props {
  onDrawerToggle: () => void;
  isLeftDrawerOpen: boolean;
  isMenuVisible: boolean;
}

const NavLogo = ({ appBarTextColor }: { appBarTextColor: string }) => {
  return (
    <Link href='/' title='Home'>
      <Logo sx={{ p: '.5rem', color: appBarTextColor }} />
    </Link>
  );
};

export default function TopNav({
  onDrawerToggle,
  isLeftDrawerOpen,
  isMenuVisible,
}: Props) {
  const theme = useTheme();
  const appBarColor = theme.palette.appBar.main;
  const appBarTextColor = theme.palette.getContrastText(appBarColor);

  return (
    <>
      <AppBar
        position='fixed'
        component='nav'
        elevation={0}
        sx={{
          background: appBarColor,
          height: `calc(${themeConstants.appBarHeight} + ${themeConstants.headerHeight})`,
        }}
      >
        <ClassificationBanner type='header' />
        <Toolbar>
          <Stack
            direction='row'
            sx={{
              width: '100%',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <Stack
              direction='row'
              sx={{
                gap: 1,
              }}
            >
              <IconButton
                color='inherit'
                aria-label='open drawer'
                edge='start'
                onClick={() => onDrawerToggle()}
                sx={{ mr: 2, visibility: isMenuVisible ? 'visible' : 'hidden' }}
              >
                <MenuIcon
                  sx={{
                    color: theme.palette.getContrastText(
                      theme.palette.appBar.main
                    ),
                  }}
                />
              </IconButton>
              <Box
                sx={{
                  transition: theme.transitions.create('margin', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.enteringScreen,
                  }),
                  marginLeft: isLeftDrawerOpen
                    ? `${themeConstants.drawerWidth}px`
                    : 0,
                }}
              >
                <NavLogo appBarTextColor={appBarTextColor} />
              </Box>
            </Stack>
            <Stack
              direction='row'
              sx={{
                gap: 1,
              }}
            >
              <UserProfile />
            </Stack>
          </Stack>
        </Toolbar>
      </AppBar>
    </>
  );
}
