import { Box, Skeleton } from '@mui/material';
import Image from 'next/image';
export default function BackgroundImageLoader() {
  return (
    <>
      <Box
        sx={{
          height: '100%',
          width: '100%',

          img: {
            filter: 'blur(20rem)',
          },
        }}
      >
        <Image
          priority
          quality={2}
          src={'/background.png'}
          alt={'background'}
          fill
          objectFit='contain'
        />
      </Box>
      <Skeleton
        sx={{
          position: 'absolute',
          top: 0,
          height: '100%',
          width: '100%',
          transform: 'none',
        }}
      />
    </>
  );
}
