import { appRegistrationService } from '@/app/services/appRegistrationService';
import { useToastHandler } from '@/store/Toast';
import { AppRegistrationResponse } from '@/types/appRegistration';
import { useCallback, useEffect, useState } from 'react';

export const useViewModel = () => {
  const [isInitialLoad, setInitialLoad] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [availableApps, setAvailableApps] = useState<AppRegistrationResponse[]>(
    []
  );
  const { addMessage } = useToastHandler();

  const fetchApps = useCallback(async () => {
    setIsLoading(true);
    // fetch apps
    appRegistrationService
      .getAppsForChat({ page: 0, pageSize: 100 })
      .then((response) => {
        setAvailableApps(response.items);
      })
      .catch((error) => {
        addMessage('Failed to load apps', 'error', error.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [addMessage]);

  useEffect(() => {
    if (isInitialLoad) {
      fetchApps();
      setInitialLoad(false);
    }
  }, [fetchApps, isInitialLoad]);

  return {
    isLoading,
    availableApps,
  };
};
