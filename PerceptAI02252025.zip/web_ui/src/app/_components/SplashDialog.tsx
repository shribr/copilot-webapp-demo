import { handleLogin } from '@/msal/msal';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  Typography,
} from '@mui/material';
import { useCallback } from 'react';

function SignInButton(props: { disabled?: boolean }) {
  const { disabled } = props;
  const NEXT_API_SCOPES = useClientAppSettingsStore(
    (state) => state.NEXT_API_SCOPES
  );
  const _handleLogin = useCallback(() => {
    handleLogin(NEXT_API_SCOPES, 'redirect');
  }, [NEXT_API_SCOPES]);

  return (
    <Button
      variant='contained'
      type='submit'
      disabled={disabled}
      onClick={_handleLogin}
    >
      Confirm
    </Button>
  );
}

const SplashDialog = (props: { disabled?: boolean }): JSX.Element => {
  const { disabled } = props;
  return (
    <Dialog open={true} sx={{ p: '2rem' }}>
      <DialogTitle>Acceptable Use Policy</DialogTitle>
      <DialogContent>
        <Typography>
          You are accessing a U.S. Government (USG) Information System (IS) that
          is provided for USG-authorized use only.
        </Typography>
        <br />
        <Typography>
          By using this IS (which includes any device attached to this IS), you
          consent to the following conditions:
        </Typography>
        <List
          sx={{
            '&.MuiList-root': { listStyle: 'disc', pl: 2 },
            '& .MuiListItem-root': { display: 'list-item' },
          }}
        >
          <ListItem>
            The USG routinely intercepts and monitors communications on this IS
            for purposes including, but not limited to, penetration testing,
            COMSEC monitoring, network operations and defense, personnel
            misconduct (PM), law enforcement (LE), and counterintelligence (CI)
            investigations.
          </ListItem>
          <ListItem>
            At any time, the USG may inspect and seize data stored on this IS.
          </ListItem>
          <ListItem>
            Communications using, or data stored on, this IS are not private,
            are subject to routine monitoring, interception, and search, and may
            be disclosed or used for any USG-authorized purpose.
          </ListItem>
          <ListItem>
            This IS includes security measures (e.g., authentication and access
            controls) to protect USG interests--not for your personal benefit or
            privacy.
          </ListItem>
          <ListItem>
            Notwithstanding the above, using this IS does not constitute consent
            to PM, LE or CI investigative searching or monitoring of the content
            of privileged communications, or work product, related to personal
            representation or services by attorneys, psychotherapists, or
            clergy, and their assistants. Such communications and work product
            are private and confidential. See User Agreement for details.
          </ListItem>
        </List>
      </DialogContent>
      <DialogActions>
        <SignInButton disabled={disabled} />
      </DialogActions>
    </Dialog>
  );
};

export default SplashDialog;
