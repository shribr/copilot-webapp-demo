'use client';

import { useChatStore } from '@/store/ChatStore';
import { ToastHandlerProvider } from '@/store/Toast';
import themeConstants from '@/styles/constants';
import { Box, Fade, Stack, styled } from '@mui/material';
import { AnimatePresence } from 'motion/react';
import { usePathname } from 'next/navigation';
import React, { useEffect } from 'react';
import SwitchTransition from 'react-transition-group/SwitchTransition';
import ClassificationBanner from './ClassificationBanner';
import Messages from './Messages';
import SplashDialog from './SplashDialog';
import TopNav from './navigation/TopNav';
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
} from '@azure/msal-react';
import useUserStore from '@/store/UserStore';
import Loading from '@/components/Loading';
import { InteractionStatus } from '@azure/msal-browser';
import { initializeAppInsights } from '@/utils/logger/appInsights';

const Main = styled('main', {
  shouldForwardProp: (prop) =>
    prop !== 'leftDrawerOpen' && prop != 'rightDrawerOpen',
})<{
  leftDrawerOpen?: boolean;
  rightDrawerOpen?: boolean;
}>(({ theme, leftDrawerOpen, rightDrawerOpen }) => ({
  display: 'flex',
  height: '100%',
  flexDirection: 'column',
  flexGrow: 1,
  transition: theme.transitions.create('margin', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  justifyContent: 'center',
  overflow: 'hidden',
  marginLeft: 0,
  marginRight: 0,
  marginTop: `calc(${themeConstants.appBarHeight} + ${themeConstants.headerHeight})`,
  marginBottom: `${themeConstants.footerHeight}`,
  padding: '.75rem 2rem',
  background: theme.palette.background.default,
  ...(leftDrawerOpen && {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: `${themeConstants.drawerWidth}px`,
  }),
  ...(rightDrawerOpen && {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginRight: `${themeConstants.drawerWidth}px`,
  }),
}));

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const user = useUserStore((state) => state.user);
  const setIsChatDrawerOpen = useChatStore(
    (state) => state.setIsChatDrawerOpen
  );
  const isChatDrawerOpen = useChatStore((state) => state.isChatDrawerOpen);
  const activePathname = usePathname();
  const isChatRouteActive =
    activePathname.includes('/chat') || activePathname.includes('/workspaces');
  const { inProgress } = useMsal();

  useEffect(() => {
    initializeAppInsights();
  }, []);

  return (
    inProgress === InteractionStatus.None && (
      <SwitchTransition mode='out-in'>
        <Fade key='fade-x'>
          <Box sx={{ width: '100%', height: '100%' }}>
            <AuthenticatedTemplate>
              <>
                {!user ? (
                  <Loading />
                ) : (
                  <>
                    <TopNav
                      onDrawerToggle={() =>
                        setIsChatDrawerOpen(!isChatDrawerOpen)
                      }
                      isLeftDrawerOpen={isChatRouteActive && isChatDrawerOpen}
                      isMenuVisible={isChatRouteActive}
                    />
                    <Stack direction='column' sx={{ height: '100%' }}>
                      <ToastHandlerProvider>
                        <Main
                          leftDrawerOpen={isChatRouteActive && isChatDrawerOpen}
                        >
                          <AnimatePresence>{children}</AnimatePresence>
                          <Messages />
                        </Main>
                      </ToastHandlerProvider>
                    </Stack>
                    <ClassificationBanner type='footer' />
                  </>
                )}
              </>
            </AuthenticatedTemplate>
            <UnauthenticatedTemplate>
              <>
                <ClassificationBanner type='header' />
                <Stack direction='column' sx={{ height: '100%' }}>
                  <SplashDialog />
                </Stack>
                <ClassificationBanner type='footer' />
              </>
            </UnauthenticatedTemplate>
          </Box>
        </Fade>
      </SwitchTransition>
    )
  );
}
