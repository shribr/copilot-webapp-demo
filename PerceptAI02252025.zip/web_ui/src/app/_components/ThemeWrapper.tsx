'use client';

import { CssBaseline } from '@mui/material';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import React, { useCallback, useLayoutEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import Loading from '../../components/Loading';
import { paletteMap } from '@/styles/palettes';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import { createCustomTheme } from '@/styles/theme';

interface ContextProps {
  toggleTheme: () => void;
  isDarkTheme: boolean;
}
const ThemeContext = React.createContext<ContextProps>({
  toggleTheme: () => {},
  isDarkTheme: false,
});

export default function ThemeProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const themeSetting =
    useClientAppSettingsStore((state) => state.NEXT_THEME) || 'default';
  const selectedPalette = React.useMemo(
    /* eslint-disable security/detect-object-injection */
    () => paletteMap[themeSetting] || paletteMap.default,
    [themeSetting]
  );
  const [isDarkTheme, setDarkTheme] = useLocalStorage('darkmode', false);
  const [hasCheckedStorage, setHasCheckedStorage] = useState(false);
  const toggleTheme = useCallback(() => {
    setDarkTheme(!isDarkTheme);
  }, [setDarkTheme, isDarkTheme]);

  useLayoutEffect(() => {
    if (hasCheckedStorage) {
      return;
    }
    const darkmode = window.localStorage.getItem('darkmode');

    setDarkTheme(darkmode ? JSON.parse(darkmode) : isDarkTheme);
    setHasCheckedStorage(true);
  }, [hasCheckedStorage, isDarkTheme, setDarkTheme]);

  const theme = React.useMemo(
    () =>
      isDarkTheme
        ? createCustomTheme(selectedPalette.dark)
        : createCustomTheme(selectedPalette.light),
    [isDarkTheme, selectedPalette]
  );

  return (
    <MuiThemeProvider theme={theme}>
      <CssBaseline />
      <ThemeContext.Provider
        value={{
          toggleTheme,
          isDarkTheme,
        }}
      >
        {hasCheckedStorage ? children : <Loading />}
      </ThemeContext.Provider>
    </MuiThemeProvider>
  );
}

export function useTheme() {
  const context = React.useContext(ThemeContext);
  if (context === undefined) {
    throw new Error(`useTheme must be used within a ThemeProvider`);
  }
  return context;
}
