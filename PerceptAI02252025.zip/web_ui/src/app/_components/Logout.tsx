import { logoutCookieName } from '@/msal/msal';
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
} from '@mui/material';

import { useEffect } from 'react';

export default function LogoutMessage() {
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      document.cookie = `${logoutCookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; Path=/`;
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, []);

  return (
    <Dialog open={true} sx={{ p: '2rem' }}>
      <DialogTitle>Logout Successful</DialogTitle>
      <DialogContent>
        <Typography>You have successfully logged out</Typography>
      </DialogContent>
      <DialogActions></DialogActions>
    </Dialog>
  );
}
