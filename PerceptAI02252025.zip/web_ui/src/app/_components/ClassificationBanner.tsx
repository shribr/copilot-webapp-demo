'use client';
import themeConstants from '@/styles/constants';
import { Box, Typography } from '@mui/material';
import useClientAppSettingsStore from '@/store/ClientAppSettingsStore';
import { useTheme } from '@mui/material/styles';
import { classificationColorMap } from '@/components/Classifications';

interface ClassificationBannerProps {
  type?: 'header' | 'footer';
}

export default function ClassificationBanner({
  type = 'header',
}: ClassificationBannerProps): JSX.Element {
  const NEXT_CLASSIFICATION_BG_COLOR = useClientAppSettingsStore(
    (state) => state.NEXT_CLASSIFICATION_BG_COLOR
  );
  const NEXT_CLASSIFICATION_MESSAGE = useClientAppSettingsStore(
    (state) => state.NEXT_CLASSIFICATION_MESSAGE
  );
  const theme = useTheme();

  const mappedColor =
    classificationColorMap[
      NEXT_CLASSIFICATION_BG_COLOR.toLowerCase() as keyof typeof classificationColorMap
    ];

  const bannerColor = {
    backgroundColor: mappedColor || NEXT_CLASSIFICATION_BG_COLOR,
    textColor: mappedColor
      ? theme.palette.getContrastText(mappedColor)
      : theme.palette.common.white,
  };

  return (
    <Box
      sx={{
        width: '100%',
        height:
          type == 'header'
            ? themeConstants.headerHeight
            : themeConstants.footerHeight,
        backgroundColor: bannerColor.backgroundColor,
        textAlign: 'center',
        zIndex: 9999,
        position: 'sticky',
        left: 0,
        top: type == 'header' ? 0 : undefined,
        bottom: type == 'footer' ? 0 : undefined,
        textTransform: 'uppercase',
      }}
    >
      <Typography
        sx={{
          color: bannerColor.textColor,
          fontWeight: 'bold',
          padding: '0.25rem 0 0 0',
        }}
      >
        {NEXT_CLASSIFICATION_MESSAGE}
      </Typography>
    </Box>
  );
}
