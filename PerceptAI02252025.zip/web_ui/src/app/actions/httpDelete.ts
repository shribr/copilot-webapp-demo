'use server';
import {
  defaultHeadersAsync,
  getFormattedErrorMessage,
} from '@/utils/apiUtils';
import { joinUrl } from '@/utils/url';

export async function httpDelete<Tout = boolean>(url: string): Promise<Tout> {
  const defaultWithAuthHeaders = await defaultHeadersAsync();
  const serverUrl = joinUrl(process.env.NEXT_PERCEPT_API_URL || '', url);
  return fetch(serverUrl, {
    method: 'DELETE',
    headers: {
      ...defaultWithAuthHeaders,
    },
  })
    .then(async (response) => {
      if (!response.ok) {
        const errorResponse = await getFormattedErrorMessage(response);
        throw new Error(errorResponse);
      }
      if (typeof ({} as Tout) === 'boolean') {
        return response.ok;
      }
      return response.json();
    })
    .catch((error) => {
      throw new Error(error);
    });
}
