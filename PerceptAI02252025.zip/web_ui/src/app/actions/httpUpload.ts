'use client';

import { Dictionary } from '@/types/dictionary';
import {
  FileUpload,
  UploadsAccepted,
} from '@/app/workspaces/_types/fileUpload';
import { ProgressListItem } from '@/types/ProgressList';
import { defaultHeadersAsync } from '@/utils/apiUtils';
import { joinUrl } from '@/utils/url';

export function httpUpload(
  apiUrl: string,
  url: string,
  files: File[],
  data?: Dictionary<string>,
  onProgress?: (progressItem: ProgressListItem<string>) => void
) {
  const serverUrl = joinUrl(apiUrl, url);
  const uploadList: FileUpload[] = [];

  files.forEach((file) => {
    const fileId = `--${file.name}--${Date.now().toString()}`;
    const formData = new FormData();
    formData.append('file', file);
    if (data) {
      Object.entries(data).forEach(([key, value]) => {
        formData.append(key, value);
      });
    }

    let xhr: XMLHttpRequest;

    const promise = new Promise<UploadsAccepted>(async (resolve, reject) => {
      xhr = new XMLHttpRequest();
      xhr.open('POST', serverUrl, true);

      // Set headers
      const defaultWithAuthHeaders = await defaultHeadersAsync();
      for (const key in defaultWithAuthHeaders) {
        if (
          defaultWithAuthHeaders.hasOwnProperty(key) &&
          key !== 'Content-Type'
        ) {
          // eslint-disable-next-line security/detect-object-injection
          xhr.setRequestHeader(key, defaultWithAuthHeaders[key]);
        }
      }

      // Track progress
      xhr.upload.onprogress = (event: ProgressEvent) => {
        if (event.lengthComputable) {
          const percentComplete = (event.loaded / event.total) * 100;
          if (onProgress) {
            // eslint-disable-next-line security/detect-object-injection
            onProgress({ item: fileId, progress: percentComplete });
          }
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(xhr.response ? JSON.parse(xhr.response) : {});
        } else {
          reject(xhr.statusText);
        }
      };

      xhr.onerror = () => reject(xhr.statusText);

      xhr.send(formData);
    });

    uploadList.push({
      id: fileId,
      file,
      promise,
      cancel: () => {
        if (xhr) {
          xhr.abort();
        }
      },
    });
  });

  return uploadList;
}
