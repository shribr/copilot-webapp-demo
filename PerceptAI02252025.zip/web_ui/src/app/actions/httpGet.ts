'use server';
import { queryParams } from '@/types/queryParams';
import {
  defaultHeadersAsync,
  getFormattedErrorMessage,
} from '@/utils/apiUtils';
import { buildQuery, joinUrl } from '@/utils/url';

function hasValidAuthHeader(headers: HeadersInit): boolean {
  let authHeader: string | null = null;

  if (headers instanceof Headers) {
    authHeader = headers.get('Authorization');
  } else if (Array.isArray(headers)) {
    authHeader =
      headers.find(([key]) => key.toLowerCase() === 'authorization')?.[1] ||
      null;
  } else if (typeof headers === 'object') {
    authHeader = (headers as Record<string, string>)['Authorization'] || null;
  }

  return (
    authHeader !== null &&
    authHeader !== '' &&
    authHeader !== 'Bearer undefined' &&
    authHeader.length > 8
  );
}

export async function httpGet<Tout>(
  url: string,
  query?: queryParams,
  headers?: HeadersInit,
  mode?: 'cors' | 'no-cors' | 'same-origin'
): Promise<Tout> {
  const serverUrl = joinUrl(process.env.NEXT_PERCEPT_API_URL || '', url);
  const queryString = buildQuery(query);
  const destinationUrl = `${serverUrl}${queryString}`;
  const defaultWithAuthHeaders = headers ?? (await defaultHeadersAsync());

  if (!hasValidAuthHeader(defaultWithAuthHeaders)) {
    return Promise.reject(new Error('Invalid Authorization Header'));
  }

  return fetch(destinationUrl, {
    method: 'GET',
    headers: {
      ...defaultWithAuthHeaders,
    },
    mode,
  })
    .then(async (response) => {
      if (!response.ok) {
        const errorResponse = await getFormattedErrorMessage(response);
        throw new Error(errorResponse);
      }
      if (response.status === 204) {
        return null;
      }
      return response.json();
    })
    .catch((error) => {
      throw new Error(error);
    });
}
