import { apiEndpoints } from '@/constants/endpoints';
import { SchemaDefinition } from '@/types/schemaDefinition';
import { SqlSchemaRequestDto } from '@/types/sqlSchemaRequestDto';
import { api } from '../api';

export async function getSchema(sqlRequestDto: SqlSchemaRequestDto) {
    return await api.post<SqlSchemaRequestDto, SchemaDefinition>(
        apiEndpoints.sql,
        sqlRequestDto
      );
}
