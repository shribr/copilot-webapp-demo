import { apiEndpoints } from "@/constants/endpoints";
import { DataSourceResponse } from "@/types/dataSourceDto";
import { api } from "../api";

export async function getDataConnectorById(appId: string, dataConnectorId: string) {
  return api.get<DataSourceResponse>(
    `${apiEndpoints.appRegistrations}/${appId}/${apiEndpoints.dataSources}/${dataConnectorId}`
  );
}