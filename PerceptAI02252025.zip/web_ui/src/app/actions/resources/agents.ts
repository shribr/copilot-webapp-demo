import { apiEndpoints } from '@/constants/endpoints';
import { api } from '../api';
import { AgentResponseDto } from '@/types/agent';

export async function getAgentById(appId: string, agentId: string) {
  return api.get<AgentResponseDto>(
    `${apiEndpoints.appRegistrations}/${appId}/${apiEndpoints.agents}/${agentId}`
  );
}
