'use client';
import { queryParams } from '@/types/queryParams';
import { defaultHeadersAsync, getTokenCookieAsync } from '@/utils/apiUtils';
import { buildQuery, joinUrl } from '@/utils/url';
import { GetAppSettings } from './appSettings';

export async function httpDownload(url: string, query?: queryParams) {
  const NEXT_PERCEPT_API_URL = await GetAppSettings('NEXT_PERCEPT_API_URL');
  const queryString = buildQuery(query);
  const serverUrl = joinUrl(NEXT_PERCEPT_API_URL, url);
  const destinationUrl = `${serverUrl}${queryString}`;
  const token = getTokenCookieAsync();
  const authorization = `Bearer ${token ?? ''}`;

  return fetch(destinationUrl, {
    headers: {
      Authorization: authorization,
    },
    mode: 'cors',
  })
    .then(async (response) => {
      const blob = await response.blob();
      const filename =
        response.headers
          ?.get('Content-Disposition')
          ?.split('filename=')[1]
          .split(';')[0] ?? 'file.unknown';

      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch((error) => {
      throw new Error(error);
    });
}

export async function httpPostDownload<TIn>(
  url: string,
  data: TIn,
  query?: queryParams
) {
  const NEXT_PERCEPT_API_URL = await GetAppSettings('NEXT_PERCEPT_API_URL');

  const queryString = buildQuery(query);
  const serverUrl = joinUrl(NEXT_PERCEPT_API_URL, url);
  const destinationUrl = `${serverUrl}${queryString}`;
  const defaultWithAuthHeaders = await defaultHeadersAsync();

  let body;

  if (data instanceof FormData) {
    if ('Content-Type' in defaultWithAuthHeaders) {
      delete defaultWithAuthHeaders['Content-Type'];
    }
    body = data;
  } else {
    body = JSON.stringify(data);
  }

  return fetch(destinationUrl, {
    method: 'POST',
    headers: {
      ...defaultWithAuthHeaders,
    },
    body: body,
    mode: 'cors',
  })
    .then(async (response) => {
      const blob = await response.blob();

      const filename =
        response.headers
          ?.get('Content-Disposition')
          ?.split('filename=')[1]
          .split(';')[0] ?? 'file.unknown';

      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch((error) => {
      throw new Error(error);
    });
}
