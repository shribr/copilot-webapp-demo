'use server';
import {
  defaultHeadersAsync,
  getFormattedErrorMessage,
} from '@/utils/apiUtils';
import { joinUrl } from '@/utils/url';

export async function httpPost<Tin, Tout>(
  url: string,
  data: Tin
): Promise<Tout> {
  const defaultWithAuthHeaders = await defaultHeadersAsync();

  let body;

  if (data instanceof FormData) {
    if ('Content-Type' in defaultWithAuthHeaders) {
      delete defaultWithAuthHeaders['Content-Type'];
    }
    body = data;
  } else {
    body = JSON.stringify(data);
  }

  const serverUrl = joinUrl(process.env.NEXT_PERCEPT_API_URL || '', url);
  return fetch(serverUrl, {
    method: 'POST',
    headers: {
      ...defaultWithAuthHeaders,
    },
    body: body,
  })
    .then(async (response) => {
      if (!response.ok) {
        const errorResponse = await getFormattedErrorMessage(response);
        throw new Error(errorResponse);
      }
      return response.json();
    })
    .catch((error) => {
      throw new Error(error);
    });
}
