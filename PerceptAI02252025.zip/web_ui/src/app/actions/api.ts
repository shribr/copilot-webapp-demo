import { httpVerbs } from '@/types/httpVerbs';
import { httpGet } from './httpGet';
import { httpPost } from './httpPost';
import { httpDownload } from './httpDownload';
import { httpDelete } from './httpDelete';
import { httpPatch } from './httpsPatch';
import { httpPut } from './httpsPut';
import { httpUpload } from './httpUpload';

export const api: httpVerbs = {
  get: httpGet,
  post: httpPost,
  delete: httpDelete,
  download: httpDownload,
  patch: httpPatch,
  put: httpPut,
  upload: httpUpload,
};
