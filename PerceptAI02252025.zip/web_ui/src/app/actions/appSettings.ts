'use server';

import { ClientAppSettings } from '@/types/clientAppSettings';

/* eslint-disable security/detect-object-injection */
export async function GetAppSettings(setting: string): Promise<string> {
  return process.env[setting] ?? '';
}

export async function GetClientAppSettings(): Promise<
  Omit<ClientAppSettings, 'WorkspaceConfiguration'>
> {
  return {
    NEXT_TITLE: process.env.NEXT_TITLE || '',
    NEXT_LOGO: process.env.NEXT_LOGO || '',
    NEXT_WATERMARK_IMAGE: process.env.NEXT_WATERMARK_IMAGE || '',
    NEXT_CLASSIFICATION_MESSAGE: process.env.NEXT_CLASSIFICATION_MESSAGE || '',
    NEXT_CLASSIFICATION_BG_COLOR:
      process.env.NEXT_CLASSIFICATION_BG_COLOR || '',
    NEXT_THEME: process.env.NEXT_THEME || '',
    NEXT_PERCEPT_API_URL: process.env.NEXT_PERCEPT_API_URL || '',
    NEXT_ENABLE_MARKDOWN: process.env.NEXT_ENABLE_MARKDOWN || 'false',
    NEXT_APP_LABEL: process.env.NEXT_APP_LABEL || '',
    NEXT_API_SCOPES: process.env.NEXT_API_SCOPES || '',
    NEXT_HELP_URL: process.env.NEXT_HELP_URL || '',
    NEXT_HELP_URL_NAME: process.env.NEXT_HELP_URL_NAME || '',
  };
}
