'use server';
import {
  defaultHeadersAsync,
  getFormattedErrorMessage,
} from '@/utils/apiUtils';
import { joinUrl } from '@/utils/url';

export async function httpPut<Tin>(url: string, data: Tin): Promise<boolean> {
  const defaultWithAuthHeaders = await defaultHeadersAsync();

  const body = JSON.stringify(data);

  const serverUrl = joinUrl(process.env.NEXT_PERCEPT_API_URL || '', url);
  return fetch(serverUrl, {
    method: 'PUT',
    headers: {
      ...defaultWithAuthHeaders,
    },
    body: body,
  })
    .then(async (response) => {
      if (!response.ok) {
        const errorResponse = await getFormattedErrorMessage(response);
        throw new Error(errorResponse);
      }
      return response.ok;
    })
    .catch((error) => {
      throw new Error(error);
    });
}
