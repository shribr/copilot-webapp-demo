'use client'; // Error boundaries must be Client Components
import ErrorPage from './_components/ErrorPage';

export default function GlobalError({
  error,
}: {
  error: Error & { digest?: string };
}) {
  return (
    // global-error must include html and body tags
    <html>
      <body>
        <ErrorPage error={error} />
      </body>
    </html>
  );
}
