import type { Preview } from '@storybook/react';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { withThemeFromJSXProvider } from '@storybook/addon-themes';
import { createCustomTheme } from '../src/styles/theme';
import { paletteMap } from '../src/styles/palettes';
import { useClassificationsStore } from '../src/components/Classifications';
import { useEffect } from 'react';
import {
  basicControls,
  basicValueOptions,
} from '../src/utils/storybookData/classifications';

// Set Classification context for all stories
const withClassificationSettings = (Story) => {
  const setClassificationSettings = useClassificationsStore(
    (state) => state.setClassificationSettings
  );

  useEffect(() => {
    setClassificationSettings({
      classificationControls: basicControls,
      classificationValueOptions: basicValueOptions,
    });
  }, [setClassificationSettings]);

  return Story();
};

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },

  decorators: [
    withClassificationSettings,
    withThemeFromJSXProvider({
      GlobalStyles: CssBaseline,
      Provider: ThemeProvider,
      themes: {
        light: createCustomTheme(paletteMap.default.light),
        dark: createCustomTheme(paletteMap.default.dark),
      },
      defaultTheme: 'light',
    }),
  ],
};

export default preview;
