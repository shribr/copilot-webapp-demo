﻿using AutoFixture;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.DocumentStorage;
using Moq;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Controllers;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Services;
using Percept.Workspaces.Services.Interfaces;
using System.Security.Claims;
using static Microsoft.KernelMemory.DocumentUploadRequest;

namespace PerceptApiTest.Workspaces
{
    public class WorkspaceSourcesControllerTest
    {
        public Fixture Fixture { get; } = new Fixture();

        private readonly ILogger<WorkspaceSourcesController> _logger;
        private readonly Mock<IHttpContextAccessor> _mockContextAccessor;
        private readonly Mock<IWorkspaceService> _mockWorkspaceService;
        private readonly Mock<IWorkspaceSourcesService> _mockWorkspaceSourcesService;
        private readonly Mock<IUserIdentityService> _mockUserIdentityService;
        private readonly HttpContext _httpContext;
        private readonly string _userObjectId = "123";
        private readonly string _userName = "User 123";

        public IMapper Mapper { get; }
        private readonly WorkspaceSourcesController _controller;
        private readonly Guid _workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");

        public WorkspaceSourcesControllerTest()
        {
            var workspacesConfig = new WorkspacesConfiguration
            {
                Enabled = true,
                MaxWorkspaces = 10,
                MaxSources = 5,
                EnableCollaboration = true,
                UserIdClaim = "user_id",
                UserNameClaim = "user_name"
            };
            _logger = new Mock<ILogger<WorkspaceSourcesController>>().Object;

            _mockWorkspaceService = new Mock<IWorkspaceService>();
            var mockWorkspace = Fixture.Build<Workspace>()
                .With(w => w.Id, _workspaceId)
                .With(w => w.CreatedByUserId, _userObjectId)
                .Create();
            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(mockWorkspace);
            _mockWorkspaceSourcesService = new Mock<IWorkspaceSourcesService>();

            var config = new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>());
            config.AssertConfigurationIsValid();
            Mapper = config.CreateMapper();

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(workspacesConfig.UserIdClaim, _userObjectId),
                new Claim(workspacesConfig.UserNameClaim, _userName)
            }));
            _httpContext = new DefaultHttpContext { User = user };
            _httpContext.Request.Scheme = "http";
            _httpContext.Request.Host = new HostString("localhost");

            _mockUserIdentityService = new Mock<IUserIdentityService>();
            _mockUserIdentityService
                .Setup(x => x.GetUser())
                .Returns((_userObjectId, _userName));

            _mockContextAccessor = new Mock<IHttpContextAccessor>();
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            _controller = new WorkspaceSourcesController(
                _logger,
                workspacesConfig,
                _mockWorkspaceService.Object,
                Mapper,
                _mockWorkspaceSourcesService.Object,
                _mockUserIdentityService.Object
            );
            _controller.ControllerContext.HttpContext = _httpContext;
        }

        [Fact]
        public async Task Upload_Returns()
        {
            // Arrange
            var fileMock = new Mock<IFormFile>();
            var content = "Hello World from a Fake File";
            var fileName = "test.txt";
            var ms = new MemoryStream();
            var writer = new StreamWriter(ms);
            writer.Write(content);
            writer.Flush();
            ms.Position = 0;
            fileMock.Setup(_ => _.OpenReadStream()).Returns(ms);
            fileMock.Setup(_ => _.FileName).Returns(fileName);
            fileMock.Setup(_ => _.Length).Returns(ms.Length);

            var uploadRequest = new HttpSourcesDocumentUploadRequest
            {
                Files = new List<IFormFile> { fileMock.Object },
                Tags = new TagCollection { { "key1", "value1" } }
            };
            _httpContext.Request.Form = new FormCollection(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>
            {
                { "tags", "key1:value1" }
            }, new FormFileCollection { fileMock.Object });

            _mockWorkspaceSourcesService.Setup(s => s.UploadFilesAsync(It.IsAny<string>(), It.IsAny<TagCollection>(), It.IsAny<List<UploadedFile>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new List<DocumentUpload>());

            // Act
            var result = await _controller.UploadAsync(_workspaceId, CancellationToken.None);

            // Assert
            var uploadResult = Assert.IsType<ActionResult<UploadsAccepted>>(result);
            var acceptedResult = Assert.IsType<AcceptedResult>(uploadResult.Result);
            Assert.Equal(202, acceptedResult.StatusCode);
        }

        [Fact]
        public async Task Upload_NoFiles_Fails()
        {
            // Arrange
            var uploadRequest = new HttpSourcesDocumentUploadRequest
            {
                Tags = new TagCollection { { "key1", "value1" } }
            };

            _httpContext.Request.Form = new FormCollection(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>
            {
                { "tags", "key1:value1" }
            }, new FormFileCollection { });

            _mockWorkspaceSourcesService.Setup(s => s.UploadFilesAsync(It.IsAny<string>(), It.IsAny<TagCollection>(), It.IsAny<List<UploadedFile>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new List<DocumentUpload>());

            // Act
            var result = await _controller.UploadAsync(_workspaceId, CancellationToken.None);

            // Assert
            var uploadResult = Assert.IsType<ActionResult<UploadsAccepted>>(result);
            var problemResult = Assert.IsType<ObjectResult>(uploadResult.Result);
            Assert.Equal(400, problemResult.StatusCode);
        }

        // GetSources
        [Fact]
        public async Task GetSourcesAsync_ReturnsOkResult_WithSources()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var sources = new List<Source> { new Source {
                FileName = "testfile.txt",
                CreatedBy= "tester",
                CreatedOn=DateTime.UtcNow,
                DocumentId = "doc1" }
            };

            _mockWorkspaceSourcesService.Setup(s => s.GetSourcesAsync(indexName, It.IsAny<CancellationToken>()))
                .ReturnsAsync(sources);

            // Act
            var result = await _controller.GetSourcesAsync(_workspaceId, CancellationToken.None);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsAssignableFrom<IEnumerable<Source>>(okResult.Value);
            Assert.Single(returnValue);
            Assert.Equal("doc1", returnValue.First().DocumentId);
        }

        // DeleteSources
        [Fact]
        public async Task DeleteSourcesAsync_ReturnsOkResult_WithDeletedSources()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var documentIds = new List<string> { "doc1", "doc2" };
            var deletedSources = new List<Source> {
                 new Source {
                FileName = "testfile.txt",
                CreatedBy= "tester",
                CreatedOn=DateTime.UtcNow,
                DocumentId = "doc1" } ,
                new Source {
                FileName = "testfile2.txt",
                CreatedBy= "tester",
                CreatedOn=DateTime.UtcNow,
                DocumentId = "doc2" }  };

            _mockWorkspaceSourcesService.Setup(s =>
                s.DeleteSourcesAsync(indexName, documentIds, It.IsAny<CancellationToken>()))
                .ReturnsAsync(deletedSources);

            // Act
            var result = await _controller.DeleteSourcesAsync(_workspaceId, documentIds, CancellationToken.None);

            // Assert
            var okResult = Assert.IsType<ActionResult<IEnumerable<Source>>>(result);
            var valueObjectResult = Assert.IsType<OkObjectResult>(okResult.Result);
            var valueResult = Assert.IsAssignableFrom<IEnumerable<Source>>(valueObjectResult.Value);
            Assert.Equal(2, valueResult.ToList().Count);
            Assert.Equal("doc1", valueResult.ToList()[0].DocumentId);
            Assert.Equal("doc2", valueResult.ToList()[1].DocumentId);
        }

        // DownloadFile
        [Fact]
        public async Task DownloadAsync_ReturnsFileStreamResult_WithFileContent()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var documentId = "doc1";
            var filename = "file.txt";
            var preview = false;
            var fileContent = new MemoryStream();
            var file = new StreamableFileContent(fileName: filename,
                fileType: "text/plain",
                fileSize: fileContent.Length,
                lastWriteTimeUtc: DateTime.UtcNow,
                asyncStreamDelegate: () => Task.FromResult<Stream>(fileContent));

            _mockWorkspaceSourcesService.Setup(s => s.DownloadFileAsync(indexName, documentId, filename, It.IsAny<CancellationToken>()))
                .ReturnsAsync(file);

            // Act
            var result = await _controller.DownloadAsync(_workspaceId, documentId, filename, preview, CancellationToken.None);

            // Assert
            var fileResult = Assert.IsType<FileStreamResult>(result);

            Assert.Equal("text/plain", fileResult.ContentType);
            Assert.Equal(filename, fileResult.FileDownloadName);
        }

        [Fact]
        public async Task DownloadAsync_ReturnsNotFound_WhenFileNotFound()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var documentId = "doc1";
            var filename = "file.txt";
            var preview = false;
            var fileContent = new MemoryStream();
            var file = new StreamableFileContent(fileName: filename,
                fileType: "text/plain",
                fileSize: fileContent.Length,
                lastWriteTimeUtc: DateTime.UtcNow,
                asyncStreamDelegate: () => Task.FromResult<Stream>(fileContent));

            _mockWorkspaceSourcesService.Setup(s => s.DownloadFileAsync(indexName, documentId, filename, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new DocumentStorageFileNotFoundException("File not found"));

            // Act
            var result = await _controller.DownloadAsync(_workspaceId, documentId, filename, preview, CancellationToken.None);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal(404, notFoundResult.StatusCode);
            Assert.Equal("File not found", notFoundResult.Value);
        }

        [Fact]
        public async Task DownloadAsync_ReturnsProblem_WhenExceptionOccurs()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var documentId = "doc1";
            var filename = "file.txt";
            var preview = false;
            var fileContent = new MemoryStream();
            var file = new StreamableFileContent(fileName: filename,
                fileType: "text/plain",
                fileSize: fileContent.Length,
                lastWriteTimeUtc: DateTime.UtcNow,
                asyncStreamDelegate: () => Task.FromResult<Stream>(fileContent));

            _mockWorkspaceSourcesService.Setup(s => s.DownloadFileAsync(indexName, documentId, filename, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("An error occurred"));

            // Act
            var result = await _controller.DownloadAsync(_workspaceId, documentId, filename, preview, CancellationToken.None);

            // Assert
            var problemResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(503, problemResult.StatusCode);
            Assert.Equal("An error occurred", (problemResult.Value as ProblemDetails)?.Detail);
        }

        // Download Preview
        [Fact]
        public async Task DownloadAsync_Preview_ReturnsFileStreamResult_WithInlineHeader()
        {
            // Arrange
            var indexName = BuildIndexName(_userObjectId, _workspaceId);
            var documentId = "doc1";
            var filename = "file.txt";
            var preview = true;
            var fileContent = new MemoryStream();
            var file = new StreamableFileContent(
                fileName: filename,
                fileType: "text/plain",
                fileSize: fileContent.Length,
                lastWriteTimeUtc: DateTime.UtcNow,
                asyncStreamDelegate: () => Task.FromResult<Stream>(fileContent));

            _mockWorkspaceSourcesService.Setup(s => s.DownloadFileAsync(indexName, documentId, filename, It.IsAny<CancellationToken>()))
                .ReturnsAsync(file);

            // Act
            var result = await _controller.DownloadAsync(_workspaceId, documentId, filename, preview, CancellationToken.None);

            // Assert
            var fileResult = Assert.IsType<FileStreamResult>(result);
            Assert.Equal("text/plain", fileResult.ContentType);
            Assert.Empty(fileResult.FileDownloadName); // FileDownloadName should be null for preview

            var contentDisposition = _httpContext.Response.Headers["Content-Disposition"].ToString();
            Assert.Contains("inline", contentDisposition);
            Assert.Contains($"filename=\"{filename}\"", contentDisposition);
        }

        private string BuildIndexName(string userObjectId, Guid workspaceId)
        {
            return $"{userObjectId}-workspace-{workspaceId}";
        }
    }
}