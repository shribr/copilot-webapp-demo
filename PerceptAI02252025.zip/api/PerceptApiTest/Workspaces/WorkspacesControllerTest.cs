using AutoFixture;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Moq;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Controllers;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Services;
using Percept.Workspaces.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApiTest.Workspaces
{
    public class WorkspacesControllerTest
    {
        public Fixture Fixture { get; } = new Fixture();

        private readonly ILogger<WorkspacesController> _logger;
        private readonly Mock<IHttpContextAccessor> _mockContextAccessor;
        private readonly Mock<IWorkspaceService> _mockWorkspaceService;
        private readonly Mock<IUserIdentityService> _mockUserIdentityService;
        private readonly HttpContext _httpContext;
        private readonly string _userId = "user_id";

        public IMapper Mapper { get; }
        private readonly WorkspacesController _controller;

        public WorkspacesControllerTest()
        {
            var workspacesConfig = new WorkspacesConfiguration
            {
                Enabled = true,
                MaxWorkspaces = 10,
                MaxSources = 5,
                EnableCollaboration = true,
                UserIdClaim = _userId
            };
            _logger = new Mock<ILogger<WorkspacesController>>().Object;

            _mockContextAccessor = new Mock<IHttpContextAccessor>();
            _mockWorkspaceService = new Mock<IWorkspaceService>();

            var config = new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>());
            config.AssertConfigurationIsValid();
            Mapper = config.CreateMapper();

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(_userId, "123")
            }));
            _httpContext = new DefaultHttpContext { User = user };
            _httpContext.Request.Scheme = "http";
            _httpContext.Request.Host = new HostString("localhost");

            _mockUserIdentityService = new Mock<IUserIdentityService>();
            _mockUserIdentityService
             .Setup(x => x.GetUser())
             .Returns((_userId, "123"));


            _controller = new WorkspacesController(
                _logger,
                workspacesConfig,
                _mockWorkspaceService.Object,
                Mapper,
                _mockUserIdentityService.Object
            );
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);
        }

        [Fact]
        public void Get_ReturnsWorkspacesConfiguration()
        {
            // Act
            var result = _controller.Get();

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Enabled);
            Assert.Equal(10, result.MaxWorkspaces);
            Assert.Equal(5, result.MaxSources);
            Assert.True(result.EnableCollaboration);
            Assert.Equal(_userId, result.UserIdClaim);
        }

        [Fact]
        public async Task Post_ReturnsCreatedResult()
        {
            // Arrange
            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");

            var workspace = Fixture.Build<Workspace>()
                .With(x => x.CreatedByUserId, _userId)
                .With(x => x.Id, workspaceId)
                .Create();
            _mockWorkspaceService.Setup(x => x.CreateAsync(It.IsAny<Workspace>()))
                .ReturnsAsync(workspace);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Post(new WorkspaceRequest { Name = "Test Workspace" });

            // Assert
            var createdResult = Assert.IsType<ActionResult<WorkspaceResponseItem>>(result);
            var valueObjectResult = Assert.IsType<CreatedResult>(createdResult.Result);
            var valueResult = Assert.IsType<WorkspaceResponseItem>(valueObjectResult.Value);
            Assert.Equal($"http://localhost/{workspaceId}", valueObjectResult.Location);
            Assert.Equal(workspaceId, valueResult.Id);
        }

        [Fact]
        public async Task Post_Disabled_Returns_NotAllowedResult()
        {
            // Arrange
            var workspacesConfig = new WorkspacesConfiguration
            {
                Enabled = false,
            };
            var configuration = WorkspaceTestUtils.BuildConfiguration(workspacesConfig);
            var controller = new WorkspacesController(
                _logger,
                workspacesConfig,
                _mockWorkspaceService.Object,
                Mapper,
                _mockUserIdentityService.Object
            );

            // Act
            var result = await controller.Post(new WorkspaceRequest { Name = "Test Workspace" });

            // Assert
            var postResult = Assert.IsType<ActionResult<WorkspaceResponseItem>>(result);
            var valueObjectResult = Assert.IsType<StatusCodeResult>(postResult.Result);
            Assert.Equal(405, valueObjectResult.StatusCode);
        }

        [Fact]
        public async Task Patch_Returns_Ok()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Build<Workspace>()
                .With(x => x.CreatedByUserId, _userId)
                .Create();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _mockWorkspaceService.Setup(x => x.UpdateAsync(It.IsAny<Workspace>(), It.IsAny<string>())).ReturnsAsync(workspace);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Patch(workspaceId, new WorkspaceRequest { Name = "Test Workspace" });

            // Assert
            var patchResult = Assert.IsType<OkObjectResult>(result.Result);
            var valueResult = Assert.IsType<bool>(patchResult.Value);
            Assert.True(valueResult);
        }

        [Fact]
        public async Task Patch_NotExists_Returns_NotFound()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            Workspace? workspace = null;

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Patch(workspaceId, new WorkspaceRequest { Name = "Test Workspace" });

            // Assert
            var getResult = Assert.IsType<ActionResult<bool>>(result);
            Assert.IsType<NotFoundObjectResult>(getResult.Result);
        }

        [Fact]
        public async Task Patch_NotMine_Returns_UnauthorizedResult()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Create<Workspace>();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>()))
                          .ReturnsAsync(workspace);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Patch(workspaceId, new WorkspaceRequest { Name = "Test Workspace" });

            // Assert
            var getResult = Assert.IsType<ActionResult<bool>>(result);
            Assert.IsType<UnauthorizedResult>(getResult.Result);
        }

        [Fact]
        public async Task Delete_Returns_Ok()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Build<Workspace>()
                .With(x => x.CreatedByUserId, _userId)
                .Create();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _mockWorkspaceService.Setup(x => x.DeleteAsync(It.IsAny<Workspace>())).ReturnsAsync(true);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Delete(workspaceId);

            // Assert
            var deleteResult = Assert.IsType<ActionResult<bool>>(result);
            var valueObjectResult = Assert.IsType<OkObjectResult>(deleteResult.Result);
            var valueResult = Assert.IsType<bool>(valueObjectResult.Value);
            Assert.True(valueResult);
        }

        [Fact]
        public async Task Delete_Idempotent()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            Workspace? workspace = null;

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _mockWorkspaceService.Setup(x => x.DeleteAsync(It.IsAny<Workspace>())).ReturnsAsync(true);
            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = (await _controller.Delete(workspaceId));

            // Assert
            var deleteResult = Assert.IsType<ActionResult<bool>>(result);
            var valueObjectResult = Assert.IsType<OkObjectResult>(deleteResult.Result);
            var valueResult = Assert.IsType<bool>(valueObjectResult.Value);
            Assert.True(valueResult);
        }

        [Fact]
        public async Task Delete_NotMine_Returns_UnauthorizedResult()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Create<Workspace>();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>()))
                          .ReturnsAsync(workspace);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Delete(workspaceId);

            // Assert
            var updateResult = Assert.IsType<ActionResult<bool>>(result);
            var valueObjectResult = Assert.IsType<UnauthorizedResult>(updateResult.Result);
        }

        [Fact]
        public async Task Get_Returns_Workspace()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Build<Workspace>()
                .With(x => x.CreatedByUserId, _userId)
                .With(x => x.Id, workspaceId)
                .Create();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Get(workspaceId);

            // Assert
            var getResult = Assert.IsType<ActionResult<WorkspaceResponse>>(result);
            var valueObjectResult = Assert.IsType<OkObjectResult>(getResult.Result);
            var valueResult = Assert.IsType<WorkspaceResponse>(valueObjectResult.Value);
            Assert.Equal(workspaceId, valueResult.Id);
        }

        [Fact]
        public async Task Get_NotExists_Returns_NotFound()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            Workspace? workspace = null;

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>())).ReturnsAsync(workspace);
            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Get(workspaceId);

            // Assert
            var getResult = Assert.IsType<ActionResult<WorkspaceResponse>>(result);
            var valueObjectResult = Assert.IsType<NotFoundObjectResult>(getResult.Result);
        }

        [Fact]
        public async Task Get_NotMine_Returns_UnauthorizedResult()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceId = new Guid("AAA3D25C-9893-4D11-AB7E-C884EBD017B4");
            var workspace = Fixture.Create<Workspace>();

            _mockWorkspaceService.Setup(x => x.GetAsync(It.IsAny<Guid>()))
                          .ReturnsAsync(workspace);

            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = await _controller.Get(workspaceId);

            // Assert
            var updateResult = Assert.IsType<UnauthorizedResult>(result.Result);
        }

        [Fact]
        public void Get_Users_Workspaces_Returns_Enumerable()
        {
            // Arrange
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(_httpContext);

            var workspaceList = Fixture.Build<Workspace>()
                .With(x => x.CreatedByUserId, _userId)
                .CreateMany(2);

            _mockWorkspaceService.Setup(x => x.GetAll(It.IsAny<string>())).Returns(workspaceList);
            _controller.ControllerContext.HttpContext = _httpContext;

            // Act
            var result = _controller.GetUsersWorkspaces();

            // Assert
            var getResult = Assert.IsType<ActionResult<IEnumerable<WorkspaceResponseItem>>>(result);
            var valueObjectResult = Assert.IsType<OkObjectResult>(getResult.Result);
            var valueResult = Assert.IsAssignableFrom<IEnumerable<WorkspaceResponseItem>>(valueObjectResult.Value);
            Assert.Equal(2, valueResult.Count());
        }
    }
}
