﻿using Microsoft.Extensions.Configuration;
using Percept.Workspaces.Configuration;

namespace PerceptApiTest.Workspaces
{
    internal class WorkspaceTestUtils
    {
        public static IConfiguration BuildConfiguration(WorkspacesConfiguration workspacesConfig)
        {
            var inMemorySettings = new Dictionary<string, string>
                {
                    {"Percept:Workspaces:Enabled", workspacesConfig.Enabled.ToString()},
                    {"Percept:Workspaces:MaxWorkspaces", workspacesConfig.MaxWorkspaces.ToString()},
                    {"Percept:Workspaces:MaxSources", workspacesConfig.MaxSources.ToString()},
                    {"Percept:Workspaces:EnableCollaboration", workspacesConfig.EnableCollaboration.ToString()},
                    {"Percept:Workspaces:UserIdClaim", workspacesConfig.UserIdClaim}
                };

            return new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
        }
    }
}
