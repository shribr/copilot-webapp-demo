using PerceptApi.Attributes;
using System.ComponentModel.DataAnnotations;

namespace PerceptApiTest.Attributes
{
    public class TagCollectionValidationAttributeTests
    {
        [Fact]
        public void IsValid_ShouldReturnSuccess_WhenNoInvalidKeys()
        {
            // Arrange
            var attribute = new TagCollectionValidationAttribute();
            var validTags = new Dictionary<string, List<string?>>
            {
                { "validKey1", new List<string?> { "value1" } },
                { "validKey2", new List<string?> { "value2" } }
            };

            // Act
            var result = attribute.GetValidationResult(validTags, new ValidationContext(validTags));

            // Assert
            Assert.Equal(ValidationResult.Success, result);
        }

        [Fact]
        public void IsValid_ShouldReturnValidationError_WhenInvalidKeysPresent()
        {
            // Arrange
            var attribute = new TagCollectionValidationAttribute();
            var invalidTags = new Dictionary<string, List<string?>>
            {
                { $"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}invalidKey1", new List<string?> { "value1" } },
                { "validKey2", new List<string?> { "value2" } }
            };

            // Act
            var result = attribute.GetValidationResult(invalidTags, new ValidationContext(invalidTags));

            // Assert
            Assert.NotNull(result);
            Assert.NotEqual(ValidationResult.Success, result);
            Assert.Contains("Keys cannot start with a Reserved Tag Prefix", result.ErrorMessage);
        }
    }
}
