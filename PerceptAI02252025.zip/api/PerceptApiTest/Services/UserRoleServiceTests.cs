﻿using FluentAssertions;
using Microsoft.Extensions.Azure;
using Microsoft.Graph.Models;
using Microsoft.Kiota.Abstractions;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace PerceptApiTest.Services
{
    public class UserRoleServiceTests
    {
        [Fact]
        public void CTOR_ThrowsArgumentNullException_WhenUserRoleRepositoryIsNull()
        {
            // Arrange
            var userServiceMock = new Mock<IUserService>().Object;

            // Act
            Action action = () => new UserRoleService(null, userServiceMock, Mock.Of<IGraphService>());

            // Assert
            action.Should().Throw<ArgumentNullException>().WithMessage("Value cannot be null. (Parameter 'userRoleRepository')");
        }

        [Fact]
        public void CTOR_ThrowsArgumentNullException_WhenUserServiceIsNull()
        {
            // Arrange
            var userRoleRepository = new Mock<IBaseRepository<UserRole>>().Object;

            // Act
            Action action = () => new UserRoleService(userRoleRepository, null, Mock.Of<IGraphService>());

            // Assert
            action.Should().Throw<ArgumentNullException>().WithMessage("Value cannot be null. (Parameter 'userService')");
        }

        [Fact]
        public async Task RemovePermissionAsync_ShouldDeleteUserRole_WhenPermissionBecomes0()
        {
            // Arrange
            var userRole = new UserRole
            {
                ApplicationId = Guid.NewGuid(),
                Permission = (int)AppRoles.Owner,
            };
            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetById(It.IsAny<Guid>(), It.IsAny<bool>())).Returns(userRole);

            var userServiceMock = new Mock<IUserService>();
            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.RemovePermissionAsync(userRole, AppRoles.Owner);

            // Assert
            result.Should().BeTrue();
            userRole.Permission.Should().Be(0);
            userRoleRepository.Verify(x => x.Update(userRole), Times.Never());
            userRoleRepository.Verify(x => x.Remove(userRole), Times.Once());
        }

        [Fact]
        public async Task RemovePermissionAsync_ShouldUpdateUserRole_WhenPermissionIsNot0()
        {
            // Arrange
            var userRole = new UserRole
            {
                ApplicationId = Guid.NewGuid(),
                Permission = (int)AppRoles.Owner | (int)AppRoles.User,
            };
            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetById(It.IsAny<Guid>(), It.IsAny<bool>())).Returns(userRole);

            var userServiceMock = new Mock<IUserService>();
            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.RemovePermissionAsync(userRole, AppRoles.Owner);

            // Assert
            result.Should().BeTrue();
            userRole.Permission.Should().Be((int)AppRoles.User);
            userRoleRepository.Verify(x => x.Remove(userRole), Times.Never());
            userRoleRepository.Verify(x => x.Update(userRole), Times.Once());
        }

        [Fact]
        public async Task RemovePermissionAsync_ReturnsTrue_WhenPermissionToBeRemovedIsNotAttatched()
        {
            // Arrange
            var userRole = new UserRole
            {
                ApplicationId = Guid.NewGuid(),
                Permission = (int)AppRoles.Owner,
            };
            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            var userServiceMock = new Mock<IUserService>();
            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.RemovePermissionAsync(userRole, AppRoles.User);

            // Assert
            result.Should().BeTrue();
            userRole.Permission.Should().Be((int)AppRoles.Owner);
            userRoleRepository.Verify(x => x.Update(userRole), Times.Never());
        }

        [Fact]
        public async Task AddPermissionAsync_ShouldCreateUserRole_WhenDoesNotExist()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole>().AsQueryable());


            var userServiceMock = new Mock<IUserService>();
            userServiceMock.Setup(x => x.GetOrCreateDirectoryEntryAsync(objectId, false))
                .ReturnsAsync(directoryEntry);

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.AddPermissionAsync(appId, entityId, EntityTypes.DataSource, objectId, false, AppRoles.User);

            // Assert
            result.Should().NotBeNull();
            result.DirectoryEntryId.Should().Be(directoryEntry.Id);
            result.EntityId.Should().Be(entityId);
            result.Permission.Should().Be((int)AppRoles.User);
            userRoleRepository.Verify(x => x.Add(It.IsAny<UserRole>()), Times.Once());
            userRoleRepository.Verify(x => x.Update(It.IsAny<UserRole>()), Times.Never());
        }

        [Fact]
        public async Task AddPermissionAsync_ShouldUpdateUserRole_WhenUserRoleAlreadyExist()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRole = new UserRole
            {
                Id = Guid.NewGuid(),
                ApplicationId = Guid.NewGuid(),
                DirectoryEntryId = directoryEntry.Id,
                EntityId = entityId,
                EntityType = EntityTypes.DataSource,
                IsGroup = false,
                Permission = (int)AppRoles.Owner,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole> { userRole }.AsQueryable());

            var userServiceMock = new Mock<IUserService>();
            userServiceMock.Setup(x => x.GetOrCreateDirectoryEntryAsync(objectId, It.IsAny<bool>()))
                .ReturnsAsync(directoryEntry);

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.AddPermissionAsync(appId, entityId, EntityTypes.DataSource, objectId, false, AppRoles.User);

            // Assert
            result.Should().NotBeNull();
            result.DirectoryEntryId.Should().Be(directoryEntry.Id);
            result.EntityId.Should().Be(entityId);
            result.Permission.Should().Be((int)AppRoles.User + (int)AppRoles.Owner);
            userRoleRepository.Verify(x => x.Add(It.IsAny<UserRole>()), Times.Never());
            userRoleRepository.Verify(x => x.Update(It.IsAny<UserRole>()), Times.Once());
        }

        [Fact]
        public async Task AddPermissionAsync_ShouldNotUpdateUserRole_WhenUserRoleAlreadyExistWithSamePermission()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRole = new UserRole
            {
                Id = Guid.NewGuid(),
                ApplicationId = appId,
                DirectoryEntryId = directoryEntry.Id,
                EntityId = entityId,
                EntityType = EntityTypes.DataSource,
                IsGroup = false,
                Permission = (int)AppRoles.User,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole> { userRole }.AsQueryable());

            var userServiceMock = new Mock<IUserService>();
            userServiceMock.Setup(x => x.GetOrCreateDirectoryEntryAsync(objectId, It.IsAny<bool>()))
                .ReturnsAsync(directoryEntry);

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = await service.AddPermissionAsync(appId, entityId, EntityTypes.DataSource, objectId, false, AppRoles.User);

            // Assert
            result.Should().NotBeNull();
            result.DirectoryEntryId.Should().Be(directoryEntry.Id);
            result.EntityId.Should().Be(entityId);
            result.Permission.Should().Be((int)AppRoles.User);
            userRoleRepository.Verify(x => x.Add(It.IsAny<UserRole>()), Times.Never());
            userRoleRepository.Verify(x => x.Update(It.IsAny<UserRole>()), Times.Never());
        }

        [Fact]
        public async Task GetAsync_ShouldReturnNull_WheNPermissionDoesNotExist()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRole = new UserRole
            {
                Id = Guid.NewGuid(),
                ApplicationId = Guid.NewGuid(),
                DirectoryEntryId = directoryEntry.Id,
                EntityId = entityId,
                EntityType = EntityTypes.DataSource,
                IsGroup = false,
                Permission = (int)AppRoles.Owner,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole> { userRole }.AsQueryable());

            var userServiceMock = new Mock<IUserService>();

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = service.Get(appId, entityId, EntityTypes.DataSource, directoryEntry, AppRoles.User);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetAsync_ShouldReturnRole_WhenPermissionExist()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRole = new UserRole
            {
                Id = Guid.NewGuid(),
                ApplicationId = appId,
                DirectoryEntryId = directoryEntry.Id,
                EntityId = entityId,
                EntityType = EntityTypes.DataSource,
                IsGroup = false,
                Permission = (int)AppRoles.User,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole> { userRole }.AsQueryable());


            var userServiceMock = new Mock<IUserService>();

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = service.Get(appId, entityId, EntityTypes.DataSource, directoryEntry, AppRoles.User);

            // Assert
            result.Should().Be(userRole);
        }

        [Fact]
        public async Task GetAsync_ShouldReturnRole_WhenPermissionExistWithMultiplePermissions()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var userRole = new UserRole
            {
                Id = Guid.NewGuid(),
                ApplicationId = appId,
                DirectoryEntryId = directoryEntry.Id,
                EntityId = entityId,
                EntityType = EntityTypes.DataSource,
                IsGroup = false,
                Permission = (int)AppRoles.User + (int)AppRoles.Owner,
            };

            var userRoleRepository = new Mock<IBaseRepository<UserRole>>();
            userRoleRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<UserRole, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<UserRole> { userRole }.AsQueryable());


            var userServiceMock = new Mock<IUserService>();

            var service = new UserRoleService(userRoleRepository.Object, userServiceMock.Object, Mock.Of<IGraphService>());

            // Act
            var result = service.Get(appId, entityId, EntityTypes.DataSource, directoryEntry, AppRoles.User);

            // Assert
            result.Should().Be(userRole);
        }
    }
}
