﻿using AutoFixture;
using FluentAssertions;
using Microsoft.KernelMemory;
using Moq;
using PerceptApi.Agents.Interfaces;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.Enums;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;

namespace PerceptApiTest.Services
{
    public class MemoryStoreServiceTests
    {
        public Fixture Fixture { get; }

        public MemoryStoreServiceTests()
        {
            Fixture = new Fixture();
            this.Fixture.Behaviors.Add(new OmitOnRecursionBehavior());
        }

        [Fact]
        public async Task Create_Adds_New_MemoryStore()
        {
            // Arrange
            var store = Fixture.Create<DataSource>();

            var mockRepo = new Mock<IBaseRepository<DataSource>>();
            var mockKM = new Mock<IKernelMemory>();
            var mockAgent = new Mock<IAgentService>();
            var mockSystemAgents = new Mock<IEnumerable<ISystemAgent>>();
            var memoryStoreService = new MemoryStoreService(mockRepo.Object, mockKM.Object, mockAgent.Object,
                Mock.Of<IKernelMemoryDocumentService>(),
                Mock.Of<IBaseRepository<UserRole>>(), Mock.Of<AzureOpenAIConfig>());

            // Act
            var result = await memoryStoreService.CreateAsync(store);

            // Assert
            Assert.NotNull(result);
            mockRepo.Verify(repo => repo.Add(store), Times.Once);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Once);
        }

        [Fact]
        public void Retrieve_By_Id_Returns_When_Exists()
        {
            // Arrange
            var storeId = Guid.NewGuid();
            var store = Fixture.Build<DataSource>().With(x => x.Id, storeId).Create();
            store.Name = "TestIndex";

            var mockRepo = new Mock<IBaseRepository<DataSource>>();
            mockRepo.Setup(repo => repo.GetById(storeId, false)).Returns(store);

            var mockKM = new Mock<IKernelMemory>();
            var mockAgent = new Mock<IAgentService>();
            var mockSystemAgents = new Mock<IEnumerable<ISystemAgent>>();
            var memoryStoreService = new MemoryStoreService(mockRepo.Object, mockKM.Object, mockAgent.Object,
                Mock.Of<IKernelMemoryDocumentService>(),
                Mock.Of<IBaseRepository<UserRole>>(), Mock.Of<AzureOpenAIConfig>());

            // Act
            var result = memoryStoreService.GetById(storeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(storeId, result.Id);
            Assert.Equal(store.Name, result.Name);
        }

        [Fact]
        public void Retrieve_By_Id_Null_When_Not_Exists()
        {
            // Arrange
            var mockRepo = new Mock<IBaseRepository<DataSource>>();
            var mockKM = new Mock<IKernelMemory>();
            var mockAgent = new Mock<IAgentService>();
            var mockSystemAgents = new Mock<IEnumerable<ISystemAgent>>();
            var memoryStoreService = new MemoryStoreService(mockRepo.Object, mockKM.Object, mockAgent.Object,
                Mock.Of<IKernelMemoryDocumentService>(),
                Mock.Of<IBaseRepository<UserRole>>(), Mock.Of<AzureOpenAIConfig>());

            // Act
            var result = memoryStoreService.GetById(Guid.NewGuid());

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void Delete_Removes_From_KernelMemory_And_Database()
        {
            // Arrange
            var storeId = Guid.NewGuid();
            var kmConfiguration = new KernelMemoryDataSourceConfiguration { IndexName = "test" };
            var store = Fixture.Build<DataSource>().With(x => x.Id, storeId)
                .With(x=> x.Configuration, kmConfiguration).Create();
            var agentDS = new AgentDataSource { DataSourceId = storeId, AgentId = Guid.NewGuid(), PluginId = Guid.Empty };
            store.AgentDataSources.Clear();
            store.AgentDataSources.Add(agentDS);
            store.Name = "TestIndex";

            var mockRepo = new Mock<IBaseRepository<DataSource>>();
            var mockKM = new Mock<IKernelMemory>();
            var mockAgent = new Mock<IAgentService>();
            var memoryStoreService = new MemoryStoreService(mockRepo.Object, mockKM.Object, mockAgent.Object,
                Mock.Of<IKernelMemoryDocumentService>(),
                Mock.Of<IBaseRepository<UserRole>>(), Mock.Of<AzureOpenAIConfig>());

            mockRepo.Setup(repo => repo.GetAllByCondition(ds=> ds.Id == storeId, false)).Returns(new List<DataSource> { store }.AsQueryable());
            var cancellationToken = new CancellationToken();

            // Act
            var result = memoryStoreService.DeleteAsync(Guid.NewGuid(), storeId);

            // Assert
            mockRepo.Verify(repo => repo.GetAllByCondition(ds => ds.Id == storeId, false), Times.Once);
            mockKM.Verify(memory => memory.DeleteIndexAsync($"{store.ApplicationId}-{kmConfiguration.IndexName}", cancellationToken), Times.Once);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Once);
        }



        [Fact]
        public void Delete_Removes_UserRoles()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var dataSourceId = Guid.NewGuid();
            var kmConfiguration = new KernelMemoryDataSourceConfiguration { IndexName = "test" };
            var store = Fixture.Build<DataSource>().With(x => x.Id, dataSourceId)
                .With(x => x.Configuration, kmConfiguration).Create();
            var agentDS = new AgentDataSource { DataSourceId = dataSourceId, AgentId = Guid.NewGuid(), PluginId = Guid.Empty };
            store.AgentDataSources.Clear();
            store.AgentDataSources.Add(agentDS);
            store.Name = "TestIndex";

            var mockRepo = new Mock<IBaseRepository<DataSource>>();
            var mockKM = new Mock<IKernelMemory>();
            var mockAgent = new Mock<IAgentService>();
            var userRoleRepo = new Mock<IBaseRepository<UserRole>>();
            var memoryStoreService = new MemoryStoreService(mockRepo.Object, mockKM.Object, mockAgent.Object,
                Mock.Of<IKernelMemoryDocumentService>(),
                userRoleRepo.Object, Mock.Of<AzureOpenAIConfig>());

            var userRole1 = new UserRole { ApplicationId = appId, EntityId = dataSourceId, EntityType = EntityTypes.DataSource };
            var userRole2 = new UserRole { ApplicationId = appId, EntityId = dataSourceId, EntityType = EntityTypes.DataSource };
            userRoleRepo.Setup(x => x.GetAllByCondition(x => x.EntityId == dataSourceId && x.EntityType == EntityTypes.DataSource, false))
                .Returns(new List<UserRole> { userRole1, userRole2 }.AsQueryable());

            mockRepo.Setup(repo => repo.GetAllByCondition(ds => ds.Id == dataSourceId, false)).Returns(new List<DataSource> { store }.AsQueryable());
            var cancellationToken = new CancellationToken();

            // Act
            var result = memoryStoreService.DeleteAsync(appId, dataSourceId);

            // Assert
            mockRepo.Verify(repo => repo.GetAllByCondition(ds => ds.Id == dataSourceId, false), Times.Once);
            mockKM.Verify(memory => memory.DeleteIndexAsync($"{store.ApplicationId}-{kmConfiguration.IndexName}", cancellationToken), Times.Once);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Once);
            userRoleRepo.Verify(repo => repo.Remove(userRole1), Times.Once);
            userRoleRepo.Verify(repo => repo.Remove(userRole2), Times.Once);
        }
    }
}
