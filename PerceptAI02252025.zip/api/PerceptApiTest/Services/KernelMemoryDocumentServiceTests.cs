﻿using AutoFixture;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.MemoryStorage;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;

namespace PerceptApiTest.Services
{
    public class KernelMemoryDocumentServiceTests
    {
        public Fixture Fixture { get; }

        public KernelMemoryDocumentServiceTests()
        {
            Fixture = new Fixture();
            this.Fixture.Behaviors.Add(new OmitOnRecursionBehavior());
        }

        [Fact]
        public async Task DocumentId_is_Required()
        {
            // Arrange
            var mockMemoryDb = new Mock<IMemoryDb>();
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            var tagsToAdd = new TagCollection
            {
                { "tag1", new List<string?> { "value1", "value2" } }
            };

            // Act
            // Assert
            await Assert.ThrowsAsync<NullReferenceException>(
                async () => await documentService.UpdateDocumentTagsAsync("index", null, tagsToAdd, new TagCollection())
            );
        }

        [Fact]
        public async Task Requested_Tags_Are_Added()
        {
            // Arrange
            var records = Fixture.CreateMany<MemoryRecord>(10);
            var mockMemoryDb = new Mock<IMemoryDb>();
            var mockPerceptDb = new Mock<IPerceptMemoryDb>();
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, mockPerceptDb.Object);

            mockMemoryDb
                .Setup(db => db.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());

            mockPerceptDb.Setup(db => db.UpsertBatchAsync("index", It.IsAny<List<MemoryRecord>>(), It.IsAny<CancellationToken>()))
                     .ReturnsAsync(new string[] { "Record.Id" });

            var tagsToAdd = new TagCollection
            {
                { "tag1", new List<string?> { "value1", "value2" } }
            };

            var documentsToUpdate = new List<UpdateDocumentRequestDto>
            {
                new UpdateDocumentRequestDto { DocumentId = "X", TagsToAdd = tagsToAdd }
            };

            //// Act
            var result = await documentService.UpdateDocumentsTagsAsync("index", documentsToUpdate);

            //// Assert
            mockMemoryDb.Verify(
                repo => repo.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>()), Times.Once);
            mockPerceptDb.Verify(
                repo => repo.UpsertBatchAsync("index", It.IsAny<List<MemoryRecord>>(), It.IsAny<CancellationToken>()),
                Times.Exactly(1));
            Assert.True(records.All(r =>
                r.Tags.ContainsKey("tag1") &&
                r.Tags["tag1"].Contains("value1") &&
                r.Tags["tag1"].Contains("value2")
            ));
        }

        [Fact]
        public async Task Requested_Tags_Are_Removed()
        {
            // Arrange
            // Function to avoid the side effects of working with object references
            var tags = () => new TagCollection
            {
                { "tag1", new List<string?> { "value1", "value2" } },
                { "tag2", new List<string?> { "value1", "value2" } }
            };
            var records = Fixture.CreateMany<MemoryRecord>(10);
            ;
            foreach (var item in records)
            {
                item.Tags = tags();
            }

            var mockMemoryDb = new Mock<IMemoryDb>(); 
            var mockPerceptDb = new Mock<IPerceptMemoryDb>();
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, mockPerceptDb.Object);

            mockMemoryDb
                .Setup(db => db.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());

            mockPerceptDb.Setup(db => db.UpsertBatchAsync("index", It.IsAny<List<MemoryRecord>>(), It.IsAny<CancellationToken>()))
                     .ReturnsAsync(new string[] { "Record.Id" });

            var tagsToRemove = new TagCollection
            {
                { "tag1", new List<string?> { "value1" } },
                { "tag2", new List<string?> { "value2" } }
            };

            var documentsToUpdate = new List<UpdateDocumentRequestDto>
            {
                new UpdateDocumentRequestDto { DocumentId = "X", TagsToRemove = tagsToRemove }
            };

            //// Act
            var result = await documentService.UpdateDocumentsTagsAsync("index", documentsToUpdate);

            //// Assert
            mockMemoryDb.Verify(
                repo => repo.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>()), Times.Once);
            mockPerceptDb.Verify(
                repo => repo.UpsertBatchAsync("index", It.IsAny<List<MemoryRecord>>(), It.IsAny<CancellationToken>()),
                Times.Exactly(1));
            Assert.True(records.All(r =>
                r.Tags.ContainsKey("tag1") &&
                r.Tags.ContainsKey("tag2")));
            Assert.True(records.All(r =>
                !r.Tags["tag1"].Contains("value1") &&
                !r.Tags["tag2"].Contains("value2")
            ));
            Assert.True(records.All(r =>
                r.Tags["tag1"].Contains("value2") &&
                r.Tags["tag2"].Contains("value1")
            ));
        }

        [Fact]
        public async Task Requested_Tags_Removal_Idempotent()
        {
            // Arrange
            // Function to avoid the side effects of working with object references
            var tags = () => new TagCollection
            {
                { "tag1", new List<string?> { "value1", "value2" } },
                { "tag2", new List<string?> { "value1", "value2" } }
            };
            var records = Fixture.CreateMany<MemoryRecord>(10);
            foreach (var item in records)
            {
                item.Tags = tags();
            }

            var mockMemoryDb = new Mock<IMemoryDb>();
            var mockPerceptDb = new Mock<IPerceptMemoryDb>();
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, mockPerceptDb.Object);

            mockMemoryDb
                .Setup(db => db.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());

            mockPerceptDb.Setup(db => db.UpsertBatchAsync("index", It.IsAny<List<MemoryRecord>>(), It.IsAny<CancellationToken>()))
                     .ReturnsAsync(new string[] { "Record.Id" });

            var tagsToRemove = new TagCollection
            {
                { "tag1", new List<string?> { "value1" } },
                { "tag2", new List<string?> { "value2" } }
            };

            var documentsToUpdate = new List<UpdateDocumentRequestDto>
            {
                new UpdateDocumentRequestDto { DocumentId = "X", TagsToRemove = tagsToRemove }
            };

            //// Act
            var result = await documentService.UpdateDocumentsTagsAsync("index", documentsToUpdate);
            var result2 = await documentService.UpdateDocumentsTagsAsync("index", documentsToUpdate);

            //// Assert
            Assert.True(result2.Length == 0);
        }

        [Fact]
        public async Task No_update_when_no_changes()
        {
            // Arrange
            // Function to avoid the side effects of working with object references
            var tags = () => new TagCollection
            {
                { "tag1", new List<string?> { "value1", "value2" } },
                { "tag2", new List<string?> { "value1", "value2" } }
            };
            var records = Fixture.CreateMany<MemoryRecord>(10);
            foreach (var item in records)
            {
                item.Tags = tags();
            }

            var mockMemoryDb = new Mock<IMemoryDb>();
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            mockMemoryDb
                .Setup(db => db.GetListAsync("index", It.IsAny<List<MemoryFilter>>(), int.MaxValue, true,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            mockMemoryDb.Setup(db => db.UpsertAsync("index", It.IsAny<MemoryRecord>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync("Record.Id");

            var tagsToAdd = new TagCollection
            {
                { "tag1", new List<string?> { "value1" } },
                { "tag2", new List<string?> { "value1" } }
            };
            var tagsToRemove = new TagCollection
            {
                { "tag1", new List<string?> { "value3" } },
                { "tag2", new List<string?> { "value3" } }
            };

            var documentsToUpdate = new List<UpdateDocumentRequestDto>
            {
                new UpdateDocumentRequestDto { DocumentId = "X", TagsToAdd = tagsToAdd, TagsToRemove = tagsToRemove }
            };

            //// Act
            var result = await documentService.UpdateDocumentsTagsAsync("index", documentsToUpdate);

            //// Assert
            mockMemoryDb.Verify(
                repo => repo.UpsertAsync("index", It.IsAny<MemoryRecord>(), It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task GetUniqueTagsByIndexAsync_ShouldReturnSortedTags()
        {
            // Arrange
            var index = "index";
            var categoriesNames = new List<string> { "tag1", "tag2", "tag3" };

            var memoryStore = Fixture.Build<DataSource>()
                .With(x => x.Name, index)
                .Create();
            var records = Fixture.Build<MemoryRecord>()
                .With(r => r.Tags, new TagCollection
                {
                    { "tag3", new List<string?> { "c", "a", "b" } },
                    { "tag1", new List<string?> { "a" } }
                })
                .CreateMany(1)
                .Concat(Fixture.Build<MemoryRecord>()
                    .With(r => r.Tags, new TagCollection
                    {
                        { "tag2", new List<string?> { "b", "a" } },
                        { "tag1", new List<string?> { "b" } }
                    })
                    .CreateMany(1))
                .ToList();
            var mockMemoryDb = new Mock<IMemoryDb>();
            mockMemoryDb
                .Setup(db => db.GetListAsync(index, It.IsAny<List<MemoryFilter>>(), int.MaxValue, false,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            // Act
            var result = await documentService.GetUniqueTagsByIndexAsync(memoryStore.Name, categoriesNames);

            // Assert
            Assert.Equal(3, result.Count);
            Assert.True(result.ContainsKey("tag1"));
            Assert.True(result.ContainsKey("tag2"));
            Assert.True(result.ContainsKey("tag3"));

            Assert.Equal(["a", "b"], result["tag1"]);
            Assert.Equal(["a", "b"], result["tag2"]);
            Assert.Equal(["a", "b", "c"], result["tag3"]);
        }

        [Fact]
        public async Task GetUniqueTagsByIndexAsync_ShouldHandleEmptyTags()
        {
            // Arrange
            var index = "index";
            var categoriesNames = new List<string> { "tag1", "tag2", "tag3" };

            var memoryStore = Fixture.Build<DataSource>()
                .With(x => x.Name, index)
                .Create();
            var records = Fixture.Build<MemoryRecord>()
                .With(r => r.Tags, new TagCollection
                {
                    { "tag1", new List<string?>() },
                    { "tag2", new List<string?> { "b", "a" } }
                })
                .CreateMany(1)
                .ToList();

            var mockMemoryDb = new Mock<IMemoryDb>();
            mockMemoryDb
                .Setup(db => db.GetListAsync(index, It.IsAny<List<MemoryFilter>>(), int.MaxValue, false,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            // Act
            var result = await documentService.GetUniqueTagsByIndexAsync(memoryStore.Name, categoriesNames);

            // Assert
            Assert.Equal(2, result.Count);
            Assert.True(result.ContainsKey("tag1"));
            Assert.True(result.ContainsKey("tag2"));

            Assert.Empty(result["tag1"]);
            Assert.Equal(["a", "b"], result["tag2"]);
        }

        [Fact]
        public async Task GetUniqueTagsByIndexAsync_ShouldReturnEmptyTagCollection_WhenNoRecords()
        {
            // Arrange
            var index = "index";
            var categoriesNames = new List<string> { "tag1", "tag2", "tag3" };

            var memoryStore = Fixture.Build<DataSource>()
                .With(x => x.Name, index)
                .Create();
            var records = new List<MemoryRecord>();

            var mockMemoryDb = new Mock<IMemoryDb>();
            mockMemoryDb
                .Setup(db => db.GetListAsync(index, It.IsAny<List<MemoryFilter>>(), int.MaxValue, false,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            // Act
            var result = await documentService.GetUniqueTagsByIndexAsync(memoryStore.Name, categoriesNames);

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetUniqueTagsByIndexAsync_ShouldHandleDuplicateTagsWithDifferentValues()
        {
            // Arrange
            var index = "index";
            var categoriesNames = new List<string> { "tag1", "tag2", "tag3" };

            var memoryStore = Fixture.Build<DataSource>()
                .With(x => x.Name, index)
                .Create();
            var records = Fixture.Build<MemoryRecord>()
                .With(r => r.Tags, new TagCollection
                {
                    { "tag1", new List<string?> { "a", "b" } }
                })
                .CreateMany(1)
                .Concat(Fixture.Build<MemoryRecord>()
                    .With(r => r.Tags, new TagCollection
                    {
                        { "tag1", new List<string?> { "b", "c" } }
                    })
                    .CreateMany(1))
                .ToList();

            var mockMemoryDb = new Mock<IMemoryDb>();
            mockMemoryDb
                .Setup(db => db.GetListAsync(index, It.IsAny<List<MemoryFilter>>(), int.MaxValue, false,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            // Act
            var result = await documentService.GetUniqueTagsByIndexAsync(memoryStore.Name, categoriesNames);

            // Assert
            Assert.Single(result);
            Assert.True(result.ContainsKey("tag1"));

            Assert.Equal(new List<string?> { "a", "b", "c" }, result["tag1"]);
        }

        [Fact]
        public async Task GetUniqueTagsByIndexAsync_ShouldNotReturnTagsForNonExistentCategories()
        {
            // Arrange
            var index = "index";
            var categoriesNames = new List<string> { "tag1", "tag2", "tag3" };

            var memoryStore = Fixture.Build<DataSource>()
                .With(x => x.Name, index)
                .Create();
            var records = Fixture.Build<MemoryRecord>()
                .With(r => r.Tags, new TagCollection
                {
                    { "tag3", new List<string?> { "c", "a", "b" } },
                    { "nonExistentTag", new List<string?> { "x", "y" } },
                    { "tag1", new List<string?> { "a" } }
                })
                .CreateMany(1)
                .Concat(Fixture.Build<MemoryRecord>()
                    .With(r => r.Tags, new TagCollection
                    {
                        { "tag2", new List<string?> { "b", "a" } },
                        { "nonExistentTag2", new List<string?> { "z" } }
                    })
                    .CreateMany(1))
                .ToList();
            var mockMemoryDb = new Mock<IMemoryDb>();
            mockMemoryDb
                .Setup(db => db.GetListAsync(index, It.IsAny<List<MemoryFilter>>(), int.MaxValue, false,
                    It.IsAny<CancellationToken>())).Returns(records.ToAsyncEnumerable());
            var documentService = new KernelMemoryDocumentService(mockMemoryDb.Object, Mock.Of<IPerceptMemoryDb>());

            // Act
            var result = await documentService.GetUniqueTagsByIndexAsync(memoryStore.Name, categoriesNames);

            // Assert
            Assert.Equal(3, result.Count);
            Assert.True(result.ContainsKey("tag1"));
            Assert.True(result.ContainsKey("tag2"));
            Assert.True(result.ContainsKey("tag3"));

            Assert.Equal(["a"], result["tag1"]);
            Assert.Equal(["a", "b"], result["tag2"]);
            Assert.Equal(["a", "b", "c"], result["tag3"]);

            Assert.False(result.ContainsKey("nonExistentTag"));
            Assert.False(result.ContainsKey("nonExistentTag2"));
        }
    }
}