﻿using AutoFixture;
using Microsoft.AspNetCore.Http;
using Microsoft.KernelMemory.Prompts;
using Moq;
using PerceptApi.Constants;
using PerceptApi.Data.Entities;
using PerceptApi.ErrorHandling;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApiTest.Services;

public class ConversationServiceTests
{
    public Fixture Fixture { get; }

    public ConversationServiceTests()
    {
        Fixture = new Fixture();
    }

    [Fact]
    public async Task Get_or_Create_Throws_Without_Authenticated_UserId()
    {
        var mockConversationRepo = new Mock<IBaseRepository<ChatConversation>>();
        var mockAccessor = new Mock<IHttpContextAccessor>();
        var mockPromptProvider = new Mock<IPromptProvider>();
        var mockAgentService = new Mock<IAgentService>();
        var service = new ConversationService(mockConversationRepo.Object,
             mockAccessor.Object,
             Mock.Of<ISystemAgentFactory>(),
             Mock.Of<IAgentService>()
            );
        mockAccessor.SetupGet(a => a.HttpContext.User).Returns(new ClaimsPrincipal());
        var query = new PerceptApi.DTOs.AgentQuery { };

        // Act
        // Assert
        Assert.Throws<UnauthorizedAccessException>(
              () => service.GetOrCreateConversation(query)
            );
    }

    [Fact]
    public async Task Get_or_Create_Returns_Existing()
    {
        var mockConversationRepo = new Mock<IBaseRepository<ChatConversation>>();
        var mockAccessor = new Mock<IHttpContextAccessor>();
        var mockPromptProvider = new Mock<IPromptProvider>();
        var mockAgentService = new Mock<IAgentService>();
        var service = new ConversationService(mockConversationRepo.Object,
             mockAccessor.Object,
             Mock.Of<ISystemAgentFactory>(),
             Mock.Of<IAgentService>()
             );
        var conversation = new ChatConversation { Name = "Test", Id = Guid.NewGuid() };
        var query = new PerceptApi.DTOs.AgentQuery { ConversationId = conversation.Id };

        mockConversationRepo.Setup(repo => repo.GetById(conversation.Id, true)).Returns(conversation);

        // Act
        var result = service.GetOrCreateConversation(query);

        // Assert
        Assert.IsType<ChatConversation>(result);
        Assert.Equal("Test", result.Name);
    }

    [Fact]
    public async Task Get_or_Create_Throws_Without_Agent()
    {
        DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
        var userClaims = new List<Claim> {
            new Claim("Name", "Test User"),
            new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
        var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

        var mockConversationRepo = new Mock<IBaseRepository<ChatConversation>>();
        var mockAccessor = new Mock<IHttpContextAccessor>();
        var mockPromptProvider = new Mock<IPromptProvider>();
        var mockAgentService = new Mock<IAgentService>();
        var service = new ConversationService(mockConversationRepo.Object,
             mockAccessor.Object,
             Mock.Of<ISystemAgentFactory>(),
             Mock.Of<IAgentService>()
             );
        mockAccessor.SetupGet(a => a.HttpContext.User).Returns(testPrincipal);
        mockAgentService.Setup(s => s.GetByApp(It.IsAny<Guid>())).Returns(Array.Empty<Agent>().AsQueryable());
        var query = new PerceptApi.DTOs.AgentQuery { };

        // Act
        // Assert
        Assert.Throws<AgentNotFoundException>(
              () => service.GetOrCreateConversation(query)
            );
    }
}