using Microsoft.EntityFrameworkCore;
using Moq;
using Percept.Shared.Data.Entities;
using Percept.Shared.Enums;
using Percept.Shared.Services;
using PerceptApi.Data;

namespace PerceptApiTest.Services
{
    public class DocumentStatusServiceTests
    {
        private readonly Mock<IDbContextFactory<PerceptDbContext>> _dbContextFactoryMock;
        private readonly PerceptDbContext _dbContext;
        private readonly DocumentStatusService<PerceptDbContext> _service;

        public DocumentStatusServiceTests()
        {
            var options = new DbContextOptionsBuilder<PerceptDbContext>()
                .UseInMemoryDatabase(databaseName: "MockDatabase")
                .Options;

            _dbContext = new PerceptDbContext(options, null);
            _dbContextFactoryMock = new Mock<IDbContextFactory<PerceptDbContext>>();
            _dbContextFactoryMock.Setup(factory => factory.CreateDbContext()).Returns(_dbContext);
            _service = new DocumentStatusService<PerceptDbContext>(_dbContextFactoryMock.Object);

        }

        [Fact]
        public async Task GetDocument_ReturnsDocumentUploadStatus_WhenDocumentExists()
        {
            // Arrange
            var documentId = Guid.NewGuid();
            var document = new DocumentUploadStatus
            {
                Id = documentId,
                DocumentId = "doc123",
                FileName = "testfile.txt",
                Index = "test-index",
                State = DocumentState.Completed
            };
            // we can mock DocumentUploadStatus if virtual property is used
            //_dbContextMock.Setup(db => db.DocumentUploadStatus).ReturnsDbSet(new List<DocumentUploadStatus> { document }.AsQueryable());

            _dbContext.DocumentUploadStatus.Add(document);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetDocument(documentId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(documentId, result.Id);
        }

        [Fact]
        public async Task GetDocument_ReturnsNull_WhenDocumentDoesNotExist()
        {
            // Arrange
            var documentId = Guid.NewGuid();

            // Act
            var result = await _service.GetDocument(documentId);

            // Assert
            Assert.Null(result);
        }
    }
}
