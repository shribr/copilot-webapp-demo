﻿using AutoFixture;
using AutoMapper;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;
using System.Linq.Expressions;

namespace PerceptApiTest.Services
{
    public class UserSerivceTests
    {
        private List<DataSource> Stores { get; }
        private List<DirectoryEntry> Users { get; }
        public Fixture Fixture { get; }
        public IMapper Mapper { get; }

        public UserSerivceTests()
        {
            Fixture = new Fixture();
            Users = new List<DirectoryEntry> {
                new DirectoryEntry { Id = new Guid("1D8E4AEC-A58F-4A6E-BD59-15382EB2BBD6"), ObjectId=Guid.NewGuid(), DisplayName="U1"},
                new DirectoryEntry { Id = new Guid("65112968-69E2-46C3-9A44-EE945AC1C7D4"), ObjectId=Guid.NewGuid(), DisplayName="U2"} ,
                new DirectoryEntry { Id = new Guid("FC70DAC6-8654-4D3F-9610-49024DCF25FA"), ObjectId=Guid.NewGuid(), DisplayName="U3"}
            };
            var perceptConfig = new PerceptConfig();
            Stores = new List<DataSource>
            {
                new DataSource { Id = new Guid(), ApplicationId=new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"), Type = DataSourceType.Documents, Name = "One" },
                new DataSource { Id = new Guid(), ApplicationId=new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"), Type = DataSourceType.Documents, Name = "Two" },
                new DataSource { Id = new Guid(), ApplicationId=new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"), Type = DataSourceType.Documents, Name = "Three" }
            };
            var config = new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>());
            config.AssertConfigurationIsValid();
            Mapper = config.CreateMapper();
            Fixture = new Fixture();
        }

        [Fact]
        public async Task GetOrCreateDirectoryEntryAsync_ShouldCreateUser_WhenUserDoesntExist()
        {
            // Arrange
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = false,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var directoryEntryRepository = new Mock<IBaseRepository<DirectoryEntry>>();
            directoryEntryRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<DirectoryEntry, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<DirectoryEntry>().AsQueryable());

            var graphService = new Mock<IGraphService>();
            graphService.Setup(x => x.GetUserAsync(objectId))
                .ReturnsAsync(directoryEntry);

            var mockCache = new Mock<IDistributedCache>();
            var mockLogger = new Mock<ILogger<UserService>>();
            var service = new UserService(directoryEntryRepository.Object, graphService.Object, mockCache.Object, mockLogger.Object);

            // Act
            var result = await service.GetOrCreateDirectoryEntryAsync(objectId, false);

            // Assert
            graphService.Verify(x => x.GetGroupAsync(It.IsAny<Guid>()), Times.Never);
            directoryEntryRepository.Verify(x => x.Add(directoryEntry), Times.Once());
        }

        [Fact]
        public async Task GetOrCreateDirectoryEntryAsync_ShouldCreateGroup_WhenUserDoesntExist()
        {
            // Arrange
            var entityId = Guid.NewGuid();
            var objectId = Guid.NewGuid();

            var directoryEntry = new DirectoryEntry
            {
                Id = Guid.NewGuid(),
                IsGroup = true,
                DisplayName = "Test",
                Email = "Email@email.com",
                ObjectId = objectId,
            };

            var directoryEntryRepository = new Mock<IBaseRepository<DirectoryEntry>>();
            directoryEntryRepository.Setup(x => x.GetAllByCondition(It.IsAny<Expression<Func<DirectoryEntry, bool>>>(), It.IsAny<bool>()))
                .Returns(new List<DirectoryEntry>().AsQueryable());

            var graphService = new Mock<IGraphService>();
            graphService.Setup(x => x.GetGroupAsync(objectId))
                .ReturnsAsync(directoryEntry);

            var mockCache = new Mock<IDistributedCache>();
            var mockLogger = new Mock<ILogger<UserService>>();
            var service = new UserService(directoryEntryRepository.Object, graphService.Object, mockCache.Object, mockLogger.Object);

            // Act
            var result = await service.GetOrCreateDirectoryEntryAsync(objectId, true);

            // Assert
            graphService.Verify(x => x.GetUserAsync(It.IsAny<Guid>()), Times.Never);
            directoryEntryRepository.Verify(x => x.Add(directoryEntry), Times.Once());
        }
    }
}
