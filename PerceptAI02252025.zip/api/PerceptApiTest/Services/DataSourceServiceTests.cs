﻿using AutoFixture;
using Microsoft.KernelMemory;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.ErrorHandling;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;

namespace PerceptApiTest.Services
{
    public class DataSourceServiceTests
    {
        private readonly Fixture _fixture;
        private readonly Mock<IBaseRepository<DataSource>> _mockRepository;
        private readonly Mock<IDataSourceService> _mockDataSourceService;
        private readonly Mock<IBaseRepository<UserRole>> _mockUserRoleRepository;
        private readonly Mock<IKernelMemory> _mockKernelMemory;
        private readonly DataSourceService _dataSourceService;

        public DataSourceServiceTests()
        {
            _fixture = new Fixture();
            _fixture.Behaviors.OfType<ThrowingRecursionBehavior>().ToList()
                .ForEach(b => _fixture.Behaviors.Remove(b));
            _fixture.Behaviors.Add(new OmitOnRecursionBehavior());

            _mockRepository = new Mock<IBaseRepository<DataSource>>();
            _mockDataSourceService = new Mock<IDataSourceService>();
            _mockUserRoleRepository = new Mock<IBaseRepository<UserRole>>();
            _mockKernelMemory = new Mock<IKernelMemory>();
            _dataSourceService = new DataSourceService(_mockRepository.Object, _mockKernelMemory.Object, _mockUserRoleRepository.Object);
        }

        [Fact]
        public async Task CreateDataSourceAsync_WithValidDataSourceRequest_ReturnsDataSource()
        {
            // Arrange
            var dataSourceRequest = _fixture.Create<DataSourceRequestDto>();
            var dataSource = new DataSource
            {
                Id = Guid.NewGuid(),
                ApplicationId = dataSourceRequest.ApplicationId,
                Name = dataSourceRequest.Name,
                Type = dataSourceRequest.Type,
                Description = dataSourceRequest.Description,
                Configuration = dataSourceRequest.Configuration
            };

            _mockRepository.Setup(x => x.Add(It.IsAny<DataSource>()));
            _mockRepository.Setup(x => x.SaveAsync()).Returns(Task.CompletedTask);
            // Act
            var result = await _dataSourceService.CreateAsync(dataSource);
            // Assert
            Assert.NotNull(result);
            Assert.Equal(dataSourceRequest.ApplicationId, result.ApplicationId);
            Assert.Equal(dataSourceRequest.Name, result.Name);
            Assert.Equal(dataSourceRequest.Type, result.Type);
        }
        

        [Fact]
        public async Task DeleteDataSourceAsync_WithValidDataSourceId_ReturnsTrue()
        {
            // Arrange
            var dataSourceId = Guid.NewGuid();
            var dataSource = _fixture.Create<DataSource>();
            _mockRepository.Setup(x => x.GetById(dataSourceId, It.IsAny<bool>())).Returns(dataSource);
            _mockRepository.Setup(x => x.Remove(dataSource));
            _mockRepository.Setup(x => x.SaveAsync()).Returns(Task.CompletedTask);
            // Act
            var result = await _dataSourceService.DeleteAsync(dataSourceId);
            // Assert
            Assert.True(result);
        }
      

        [Fact]
        public async Task UpdateDataSourceAsync_WithValidDataSourceRequest_ReturnsDataSource()
        {
            // Arrange
            var dataSourceRequest = _fixture.Create<DataSourceRequestDto>();
            var dataSource = new DataSource
            {
                Id = Guid.NewGuid(),
                ApplicationId = dataSourceRequest.ApplicationId,
                Name = dataSourceRequest.Name,
                Type = dataSourceRequest.Type,
                Description = dataSourceRequest.Description,
                Configuration = dataSourceRequest.Configuration
            };

            var existingDataSource = new DataSource
            {
                Id = dataSource.Id, // Ensure the ID matches
                ApplicationId = dataSourceRequest.ApplicationId,
                Name = "Existing Name",
                Type = dataSourceRequest.Type,
                Description = "Existing Description",
                Configuration = dataSourceRequest.Configuration,
                CreatedBy = "ExistingUser",
                CreatedOn = DateTime.UtcNow
            };

            _mockRepository.Setup(x => x.GetById(dataSource.Id, It.IsAny<bool>())).Returns(existingDataSource);
            _mockRepository.Setup(x => x.Update(It.IsAny<DataSource>()));
            _mockRepository.Setup(x => x.SaveAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _dataSourceService.UpdateAsync(dataSource);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(dataSourceRequest.ApplicationId, result.ApplicationId);
            Assert.Equal(dataSourceRequest.Name, result.Name);
            Assert.Equal(dataSourceRequest.Type, result.Type);
        }        

        [Fact]
        public async Task UpdateDataSourceAsync_WithInvalidDataSourceId_ThrowsException()
        {
            // Arrange
            var dataSourceRequest = _fixture.Create<DataSourceRequestDto>();
            var dataSource = new DataSource
            {
                Id = Guid.NewGuid(),
                ApplicationId = dataSourceRequest.ApplicationId,
                Name = dataSourceRequest.Name,
                Type = dataSourceRequest.Type,
                Description = dataSourceRequest.Description,
                Configuration = dataSourceRequest.Configuration
            };
            // Act
            async Task Act() => await _dataSourceService.UpdateAsync(dataSource);
            // Assert
            await Assert.ThrowsAsync<NotFoundException>(Act);
        }

        [Fact]
        public async Task GetDataSourceById_WithValidDataSourceId_ReturnsDataSource()
        {
            // Arrange
            var dataSourceId = Guid.NewGuid();
            var dataSource = _fixture.Create<DataSource>();
            dataSource.Id = dataSourceId; // Ensure the Id matches the dataSourceId
            _mockRepository.Setup(x => x.GetById(dataSourceId, false)).Returns(dataSource);
            // Act
            var result = await Task.FromResult(_dataSourceService.GetById(dataSourceId, false));
            // Assert
            Assert.NotNull(result);
            Assert.Equal(dataSourceId, result.Id);
        }

        [Fact]
        public async Task GetDataSourceById_WithInvalidDataSourceId_ReturnsNull()
        {
            // Arrange
            var dataSourceId = Guid.NewGuid();
            _mockRepository.Setup(x => x.GetById(dataSourceId, false)).Returns((DataSource?)null);
            // Act
            var result = await Task.FromResult(_dataSourceService.GetById(dataSourceId, false));
            // Assert
            Assert.Null(result);
        }
    }
}