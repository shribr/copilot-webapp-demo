﻿using AutoFixture;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.ErrorHandling;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;

namespace PerceptApiTest.Services
{
    public class AgentServiceTests
    {
        private readonly Fixture _fixture;
        private readonly Mock<IBaseRepository<Agent>> _mockRepository;
        private readonly Mock<IDataSourceService> _mockDataSourceService;
        private readonly AgentService _agentService;

        public AgentServiceTests()
        {
            _fixture = new Fixture();
            _mockRepository = new Mock<IBaseRepository<Agent>>();
            _mockDataSourceService = new Mock<IDataSourceService>();
            _agentService = new AgentService(_mockRepository.Object, _mockDataSourceService.Object);
        }

        [Fact]
        public async Task CreateAsync_ShouldCreateAgent_WhenDataSourcesAreValid()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid()) // Set the ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList()) // Create 3 DataSourceIds
                .Create();

            var dataSources = agentRequest.DataSourceIds.Select(id =>
                _fixture.Build<DataSource>()
                    .With(ds => ds.Id, id)
                    .With(ds => ds.ApplicationId, agentRequest.ApplicationId) // Set the same ApplicationId
                    .Without(ds => ds.AgentDataSources) // Avoid circular reference
                    .Create()
            ).ToList();

            // Mock GetByIdWithAgent to return the corresponding DataSource for each ID
            foreach (var dataSource in dataSources)
            {
                _mockDataSourceService.Setup(s => s.GetById(dataSource.Id, false)).Returns(dataSource);
            }
            _mockRepository.Setup(r => r.SaveAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _agentService.CreateAgentAsync(agentRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(agentRequest.ApplicationId, result.ApplicationId);
            Assert.Equal(agentRequest.DataSourceIds.Count, result.DataSources.Count);

            _mockRepository.Verify(r => r.SaveAsync(), Times.Once);
        }

        [Fact]
        public async Task CreateAsync_ShouldThrowException_WhenDataSourcesApplicationIdMismatch()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid()) // Set an ApplicationId
                .Create();

            var dataSources = agentRequest.DataSourceIds.Select(id =>
                _fixture.Build<DataSource>()
                    .With(ds => ds.Id, id)
                    .Without(ds => ds.AgentDataSources) // Avoid circular reference
                    .Create()
            ).ToList();

            // Mock GetByIdWithAgent to return the corresponding DataSource for each ID
            foreach (var dataSource in dataSources)
            {
                _mockDataSourceService.Setup(s => s.GetById(dataSource.Id, false)).Returns(dataSource);
            }

            // Act & Assert
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => _agentService.CreateAgentAsync(agentRequest));

            Assert.Contains("Mismatched ApplicationId found in DataSources", exception.Message);

            // Ensure repository.SaveAsync was never called due to validation failure
            _mockRepository.Verify(r => r.SaveAsync(), Times.Never);
        }

        [Fact]
        public async Task CreateAgentAsync_ShouldThrowNotFoundException_WhenDataSourceNotFound()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid()) // Set the ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList()) // Create 3 DataSourceIds
                .Create();

            var validDataSource = _fixture.Build<DataSource>()
                .With(ds => ds.Id, agentRequest.DataSourceIds[0]) // Set the ID for the first DataSource
                .With(ds => ds.ApplicationId, agentRequest.ApplicationId) // Set the same ApplicationId
                .Without(ds => ds.AgentDataSources) // Avoid circular reference
                .Create();

            // Mock GetByIdWithAgent to return a valid DataSource for the first ID and null for the second ID
            _mockDataSourceService.Setup(s => s.GetById(agentRequest.DataSourceIds[0], false)).Returns(validDataSource);
            _mockDataSourceService.Setup(s => s.GetById(agentRequest.DataSourceIds[1], false)).Returns((DataSource)null); // Simulate not found for this ID

            // Act & Assert
            var exception = await Assert.ThrowsAsync<DataSourceNotFound>(() => _agentService.CreateAgentAsync(agentRequest));

            Assert.Equal($"Data source with ID {agentRequest.DataSourceIds[1]} was not found.", exception.Message);

            _mockRepository.Verify(r => r.SaveAsync(), Times.Never); // Ensure that SaveAsync was never called
        }

        [Fact]
        public async Task PutAsync_ShouldUpdateAgent_WhenDataSourceIdsAreValid()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid())  // Set the ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList())  // Generate DataSourceIds
                .Create();

            var dataSources = agentRequest.DataSourceIds.Select(id =>
                _fixture.Build<DataSource>()
                    .With(ds => ds.Id, id)
                    .With(ds => ds.ApplicationId, agentRequest.ApplicationId)  // Matching ApplicationId
                    .Without(ds => ds.AgentDataSources) // Avoid circular reference
                    .Create()
            ).ToList();

            var agent = _fixture.Build<Agent>()
                .With(a => a.ApplicationId, agentRequest.ApplicationId)  // Agent with matching ApplicationId
                .With(a => a.DataSources, new List<AgentDataSource>())  // Initialize empty DataSources
                .Create();

            // Mock DataSourceService.GetByIdWithAgent for each DataSourceId
            foreach (var dataSource in dataSources)
            {
                _mockDataSourceService
                    .Setup(s => s.GetById(dataSource.Id, false))
                    .Returns(dataSource);
            }

            // Mock repository methods
            _mockRepository.Setup(r => r.SaveAsync()).Returns(Task.CompletedTask);
            _mockRepository.Setup(r => r.Update(It.IsAny<Agent>()));

            // Act
            var result = await _agentService.PutAsync(agent, agentRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(agentRequest.ApplicationId, result.ApplicationId);
            Assert.Equal(agentRequest.DataSourceIds.Count, result.DataSources.Count);

            // Ensure that repository.SaveAsync was called once after the update
            _mockRepository.Verify(r => r.SaveAsync(), Times.Once);

            // Ensure that repository.Update was called with the correct agent
            _mockRepository.Verify(r => r.Update(agent), Times.Once);
        }

        [Fact]
        public async Task PutAsync_ShouldThrowException_WhenDataSourceIdsApplicationIdMismatch()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid())  // Set an ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList())  // Generate DataSourceIds
                .Create();

            var validDataSources = agentRequest.DataSourceIds.Skip(1).Select(id =>
                _fixture.Build<DataSource>()
                    .With(ds => ds.Id, id)
                    .With(ds => ds.ApplicationId, agentRequest.ApplicationId)  // Valid ApplicationId
                    .Without(ds => ds.AgentDataSources) // Avoid circular reference
                    .Create()
            ).ToList();

            // Create a mismatch by setting a different ApplicationId for the first DataSource
            var invalidDataSource = _fixture.Build<DataSource>()
                .With(ds => ds.Id, agentRequest.DataSourceIds.First())
                .With(ds => ds.ApplicationId, Guid.NewGuid())  // Mismatched ApplicationId
                .Without(ds => ds.AgentDataSources) // Avoid circular reference
               .Create();

            // Mock DataSourceService.GetByIdWithAgent
            _mockDataSourceService
                .Setup(s => s.GetById(invalidDataSource.Id, false))
                .Returns(invalidDataSource);

            foreach (var dataSource in validDataSources)
            {
                _mockDataSourceService
                    .Setup(s => s.GetById(dataSource.Id, false))
                    .Returns(dataSource);
            }

            var agent = _fixture.Build<Agent>()
                .With(a => a.ApplicationId, agentRequest.ApplicationId)
                .With(a => a.DataSources, new List<AgentDataSource>())
                .Create();

            // Act & Assert
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => _agentService.PutAsync(agent, agentRequest));

            Assert.Contains("Mismatched ApplicationId found in DataSources", exception.Message);

            // Ensure repository.SaveAsync was never called due to validation failure
            _mockRepository.Verify(r => r.SaveAsync(), Times.Never);

            // Ensure repository.Update was never called
            _mockRepository.Verify(r => r.Update(It.IsAny<Agent>()), Times.Never);
        }

        [Fact]
        public async Task PutAsync_ShouldAddNewDataSourceIds_AndRemoveOldOnes()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid())  // Set ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList())  // Generate DataSourceIds
                .Create();

            var newDataSources = agentRequest.DataSourceIds.Select(id =>
                _fixture.Build<DataSource>()
                    .With(ds => ds.Id, id)
                    .With(ds => ds.ApplicationId, agentRequest.ApplicationId)  // Matching ApplicationId
                    .Without(ds => ds.AgentDataSources) // Avoid circular reference
                    .Create()
            ).ToList();

            var existingDataSource = _fixture.Build<AgentDataSource>()
                .With(ds => ds.DataSourceId, Guid.NewGuid())  // Existing DataSource to remove
                .Without(ds => ds.Agent)  // Avoid circular reference
                .Without(ds => ds.DataSource)  // Avoid circular reference
                .Create();

            var agent = _fixture.Build<Agent>()
                .With(a => a.ApplicationId, agentRequest.ApplicationId)
                .With(a => a.DataSources, new List<AgentDataSource> { existingDataSource })  // Existing DataSource
                .Create();

            // Mock DataSourceService.GetByIdWithAgent
            foreach (var dataSource in newDataSources)
            {
                _mockDataSourceService
                    .Setup(s => s.GetById(dataSource.Id, false))
                    .Returns(dataSource);
            }

            // Mock repository methods
            _mockRepository.Setup(r => r.SaveAsync()).Returns(Task.CompletedTask);
            _mockRepository.Setup(r => r.Update(It.IsAny<Agent>()));

            // Act
            var result = await _agentService.PutAsync(agent, agentRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(agentRequest.ApplicationId, result.ApplicationId);
            Assert.Equal(agentRequest.DataSourceIds.Count, result.DataSources.Count);

            // Ensure the old DataSource was removed and new ones were added
            Assert.DoesNotContain(agent.DataSources, ds => ds.DataSourceId == existingDataSource.DataSourceId);

            // Ensure repository.SaveAsync was called once after the update
            _mockRepository.Verify(r => r.SaveAsync(), Times.Once);

            // Ensure repository.Update was called with the correct agent
            _mockRepository.Verify(r => r.Update(agent), Times.Once);
        }

        [Fact]
        public async Task PutAsync_ShouldThrowNotFoundException_WhenDataSourceNotFound()
        {
            // Arrange
            var agentRequest = _fixture.Build<AgentRequestDto>()
                .With(ar => ar.ApplicationId, Guid.NewGuid()) // Set the ApplicationId
                .With(ar => ar.DataSourceIds, _fixture.CreateMany<Guid>(3).ToList()) // Create 3 DataSourceIds
                .Create();

            var validDataSource = _fixture.Build<DataSource>()
                .With(ds => ds.Id, agentRequest.DataSourceIds[0]) // Set the ID for the first DataSource
                .With(ds => ds.ApplicationId, agentRequest.ApplicationId) // Set the same ApplicationId
                .Without(ds => ds.AgentDataSources) // Avoid circular reference
                .Create();

            var agent = _fixture.Build<Agent>()
                .With(a => a.ApplicationId, agentRequest.ApplicationId)  // Agent with matching ApplicationId
                .With(a => a.DataSources, new List<AgentDataSource>())  // Initialize empty DataSources
                .Create();

            // Mock GetByIdWithAgent to return a valid DataSource for the first ID and null for the second ID
            _mockDataSourceService.Setup(s => s.GetById(agentRequest.DataSourceIds[0], false)).Returns(validDataSource);
            _mockDataSourceService.Setup(s => s.GetById(agentRequest.DataSourceIds[1], false)).Returns((DataSource)null); // Simulate not found for this ID

            // Act & Assert
            var exception = await Assert.ThrowsAsync<DataSourceNotFound>(() => _agentService.PutAsync(agent, agentRequest));

            Assert.Equal($"Data source with ID {agentRequest.DataSourceIds[1]} was not found.", exception.Message);

            _mockRepository.Verify(r => r.SaveAsync(), Times.Never); // Ensure that SaveAsync was never called
        }
    }
}
