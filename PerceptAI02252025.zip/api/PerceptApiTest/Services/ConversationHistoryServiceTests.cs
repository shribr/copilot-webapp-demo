﻿using Microsoft.KernelMemory;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Moq;
using PerceptApi.Services;

namespace PerceptApiTest.Services;

public class ConversationHistoryServiceTests
{
    [Fact]
    public void No_History_For_Empty_Results()
    {
        // Arrange
        var chatHistory = new ChatHistory();
        var answer = new MemoryAnswer { NoResult = true };
        var mockChatCompletionService = new Mock<IChatCompletionService>();
        var service = new ConversationHistoryService(mockChatCompletionService.Object);

        // Act
        ChatHistory result = service.AddChatInteraction(chatHistory, answer);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public void History_Contains_QandA_For_Results()
    {
        // Arrange
        var chatHistory = new ChatHistory();
        var answer = new MemoryAnswer { NoResult = false, Question = "Question", Result = "Answer" };
        var mockChatCompletionService = new Mock<IChatCompletionService>();
        var service = new ConversationHistoryService(mockChatCompletionService.Object);

        // Act
        ChatHistory result = service.AddChatInteraction(chatHistory, answer);

        // Assert
        Assert.Equal(2, result.Count);
    }

    [Fact]
    public async Task Create_Question_Calls_SK_and_Adds_History()
    {
        // Arrange
        var chatHistory = new ChatHistory();
        var mockChatCompletionService = new Mock<IChatCompletionService>();
        var service = new ConversationHistoryService(mockChatCompletionService.Object);
        var chatMessageContent = new ChatMessageContent() { Content = "ReformulatedQuestion" };
        mockChatCompletionService.Setup(s => s.GetChatMessageContentsAsync(chatHistory, It.IsAny<PromptExecutionSettings>(), It.IsAny<Kernel>(), It.IsAny<CancellationToken>()))
        .ReturnsAsync(new List<ChatMessageContent> { chatMessageContent });

        // Act
        var result = await service.CreateQuestionAsync(chatHistory, "Question");

        // Assert
        mockChatCompletionService.Verify(s => s.GetChatMessageContentsAsync(chatHistory, It.IsAny<PromptExecutionSettings>(), It.IsAny<Kernel>(), It.IsAny<CancellationToken>()), Times.Once());
        Assert.Equal(2, chatHistory.Count);
        Assert.Equal("ReformulatedQuestion", result);
    }

}

