﻿using AutoFixture;
using Moq;
using PerceptApi.Data.Entities;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;

namespace PerceptApiTest.Services
{
    public class FeedbackServiceTests
    {
        public Fixture Fixture { get; }

        public FeedbackServiceTests()
        {
            Fixture = new Fixture();
        }

        [Fact]
        public void Get_Returns_PagedResponse_Of_Feedback()
        {
            // Arrange
            var feedbackList = Fixture.CreateMany<Feedback>();

            var mockRepo = new Mock<IBaseRepository<Feedback>>();
            mockRepo.Setup(repo => repo.GetAll()).Returns(feedbackList.AsQueryable());

            var feedbackService = new FeedbackService(mockRepo.Object);

            // Act
            var result = feedbackService.Get();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.CurrentPage);
            Assert.Equal(25, result.PageSize);
            Assert.Equal(1, result.Pages);
            Assert.Equal(feedbackList.Count(), result.Items.Count());
            Assert.Equal(feedbackList, result.Items);
        }

        [Fact]
        public void Get_Returns_Feedback_By_Id()
        {
            // Arrange
            var feedbackId = Guid.NewGuid();
            var feedback = Fixture.Build<Feedback>().With(x => x.Id, feedbackId).Create();

            var mockRepo = new Mock<IBaseRepository<Feedback>>();
            mockRepo.Setup(repo => repo.GetById(feedbackId, false)).Returns(feedback);

            var feedbackService = new FeedbackService(mockRepo.Object);

            // Act
            var result = feedbackService.GetById(feedbackId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(feedbackId, result.Id);
            Assert.Equal(feedback.Comment, result.Comment);
        }

        [Fact]
        public async Task Create_Adds_New_Feedback()
        {
            // Arrange
            var feedback = Fixture.Create<Feedback>();

            var mockRepo = new Mock<IBaseRepository<Feedback>>();

            var feedbackService = new FeedbackService(mockRepo.Object);

            // Act
            var result = await feedbackService.CreateAsync(feedback);

            // Assert
            Assert.NotNull(result);
            mockRepo.Verify(repo => repo.Add(feedback), Times.Once);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Once);
        }

        [Fact]
        public async Task Delete_Removes_Existing_Feedback()
        {
            // Arrange
            var feedbackId = Guid.NewGuid();
            var feedback = Fixture.Build<Feedback>().With(x => x.Id, feedbackId).Create();

            var mockRepo = new Mock<IBaseRepository<Feedback>>();
            mockRepo.Setup(repo => repo.GetById(feedbackId, false)).Returns(feedback);

            var feedbackService = new FeedbackService(mockRepo.Object);

            // Act
            await feedbackService.DeleteAsync(feedbackId);

            // Assert
            mockRepo.Verify(repo => repo.Remove(feedback), Times.Once);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Once);
        }

        [Fact]
        public async Task Delete_Does_Nothing_If_Feedback_Not_Found()
        {
            // Arrange
            var feedbackId = Guid.NewGuid();

            var mockRepo = new Mock<IBaseRepository<Feedback>>();
            var feedbackService = new FeedbackService(mockRepo.Object);

            // Act
            await feedbackService.DeleteAsync(feedbackId);

            // Assert
            mockRepo.Verify(repo => repo.Remove(It.IsAny<Feedback>()), Times.Never);
            mockRepo.Verify(repo => repo.SaveAsync(), Times.Never);
        }
    }
}