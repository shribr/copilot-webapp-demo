﻿using Percept.Classifications.Data;

namespace PerceptApiTest.Classifications
{
    public class ClassificationTests
    {
       [Fact]
       public void CanCreateControlDefinition()
        {
            ClassificationControlConfiguration control = new()
            {
                Id = "test",
                Label = "Test",
                HelperText = "Test",
                AllowMultiple = true,
                Required = true,
            };

            Assert.NotNull(control);
        }

        [Fact]
        public void CanCreateControlValueOption()
        {
            ClassificationControlValueOption option = new()
            {
                ControlId="test",
                Value = "test",
                Label= "test",
                HelperText = "Test",
                MarkingColor = "green",
            };

            Assert.NotNull(option);
        }
    }
}
