﻿using Microsoft.AspNetCore.Mvc;
using PerceptApi.Controllers;

namespace PerceptApiTest.Controllers
{
    public class ApiControllerTest
    {
        [Fact]
        public void GetVersion_ReturnsVersion()
        {
            // Arrange
            var controller = new ApiController();
            // Act
            var result = controller.GetVersion();
            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var version = Assert.IsType<string>(okResult.Value);
            Assert.False(string.IsNullOrEmpty(version));            
        }
    }
}
