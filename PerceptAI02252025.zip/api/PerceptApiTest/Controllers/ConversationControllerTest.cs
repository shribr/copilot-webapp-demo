﻿using AutoFixture;
using AutoFixture.Kernel;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.KernelMemory;
using Moq;
using PerceptApi.Constants;
using PerceptApi.Controllers;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApiTest.Controllers
{
    public class ConversationControllerTest
    {
        public IMapper Mapper { get; }
        public Fixture Fixture { get; } = new Fixture();


        public ConversationControllerTest()
        {
            var config = new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>());
            config.AssertConfigurationIsValid();
            Mapper = config.CreateMapper();
            this.Fixture.Behaviors.Add(new OmitOnRecursionBehavior());
        }

        [Fact]
        public async Task Ask_Returns_If_Users_Conversation()
        {
            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mochConversationRepo = new Mock<IBaseRepository<ChatConversation>>();
            var mockMessageRepo = new Mock<IBaseRepository<ChatMessage>>();
            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(testPrincipal, It.IsAny<object>(), It.IsAny<string>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var conversation = new ChatConversation { Name = "Test", Id = Guid.NewGuid(), DirectoryEntryId = testUser.Id };
            var query = new PerceptApi.DTOs.AgentQuery { ConversationId = conversation.Id };

            mockService.Setup(svc => svc.GetOrCreateConversation(query)).Returns(conversation);

            // Act
            var result = await controller.AskAsync(query, Guid.NewGuid(), new CancellationToken());

            // Assert
            Assert.IsType<ActionResult<ChatMessage>>(result);
        }

        [Fact]
        public async Task Ask_Returns_Unauthorized_If_Not_Users_Conversation()
        {
            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mochConversationRepo = new Mock<IBaseRepository<ChatConversation>>();
            var mockMessageRepo = new Mock<IBaseRepository<ChatMessage>>();
            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var conversation = new ChatConversation { Name = "Test", Id = Guid.NewGuid() };
            var query = new AgentQuery { ConversationId = conversation.Id };

            mockService.Setup(svc => svc.GetOrCreateConversation(query)).Returns(conversation);

            // Act
            var result = await controller.AskAsync(query, Guid.NewGuid(), new CancellationToken());

            // Assert
            Assert.IsType<UnauthorizedResult>(result.Result);
        }

        [Fact]
        public async Task PatchAsync_Returns_True_If_Users_Conversation()
        {
            // Arrange
            Fixture.Customizations.Add(new TypeRelay(typeof(Citations), typeof(KernelMemoryCitations)));

            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);

            var conversation = Fixture.Build<ChatConversation>()
                    .With(c => c.DirectoryEntryId, testUser.Id)
                    .Create();
            conversation.Agent.IsDisabled = false;

            var updateConversationDto = Fixture.Create<UpdateConversationDto>();

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            mockService.Setup(svc => svc.UpdateAsync(It.IsAny<ChatConversation>()));

            // Act
            var result = await controller.PatchAsync(conversation.Id, Guid.NewGuid(), updateConversationDto);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<bool>(actionResult.Value);
            Assert.True(returnValue);
            mockService.Verify(svc => svc.UpdateAsync(It.Is<ChatConversation>(c => c.Name == updateConversationDto.Name)), Times.Once);
        }

        [Fact]
        public async Task PatchAsync_Returns_Unauthorized_If_Not_Users_Conversation()
        {
            // Arrange
            Fixture.Customizations.Add(new TypeRelay(typeof(Citations), typeof(KernelMemoryCitations)));

            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);

            var conversation = Fixture.Build<ChatConversation>()
                    .With(c => c.DirectoryEntryId, Guid.NewGuid()) // Different user
                    .Create();
            conversation.Agent.IsDisabled = false;

            var updateConversationDto = Fixture.Create<UpdateConversationDto>();

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            // Act
            var result = await controller.PatchAsync(conversation.Id, Guid.NewGuid(), updateConversationDto);

            // Assert
            Assert.IsType<UnauthorizedResult>(result);
        }

        [Fact]
        public async Task DeleteAsync_Returns_Ok_If_Users_Conversation()
        {
            // Arrange
            Fixture.Customizations.Add(new TypeRelay(typeof(Citations), typeof(KernelMemoryCitations)));

            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var mockControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = testPrincipal }
            };
            controller.ControllerContext = mockControllerContext;

            var conversation = Fixture.Build<ChatConversation>()
                    .With(c => c.DirectoryEntryId, testUser.Id)
                    .Create();
            conversation.Agent.IsDisabled = false;

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            mockService.Setup(svc => svc.SoftDeleteAsync(conversation.Id))
                .ReturnsAsync(true);

            // Act
            var result = await controller.DeleteAsync(conversation.Id, Guid.NewGuid());

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.True((bool)okResult.Value);
            mockService.Verify(svc => svc.SoftDeleteAsync(conversation.Id), Times.Once);
        }

        [Fact]
        public async Task DeleteAsync_Returns_Unauthorized_If_Not_Users_Conversation()
        {
            // Arrange
            Fixture.Customizations.Add(new TypeRelay(typeof(Citations), typeof(KernelMemoryCitations)));

            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var mockControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = testPrincipal }
            };
            controller.ControllerContext = mockControllerContext;

            var conversation = Fixture.Build<ChatConversation>()
                    .With(c => c.DirectoryEntryId, Guid.NewGuid()) // Different user
                    .Create();
            conversation.Agent.IsDisabled = false;

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            // Act
            var result = await controller.DeleteAsync(conversation.Id, Guid.NewGuid());

            // Assert
            Assert.IsType<UnauthorizedResult>(result.Result);
        }

        [Fact]
        public async Task Get_Conversation_Returns_If_Users_Conversation()
        {
            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var conversation = new ChatConversation
            {
                Name = "Test",
                Id = Guid.NewGuid(),
                DirectoryEntryId = testUser.Id,
                Agent = new Agent
                {
                    ApplicationId = Guid.Empty,
                    Name = "Agent"
                }
            };
            var query = new AgentQuery { ConversationId = conversation.Id };
            var memoryAnswer = new MemoryAnswer { };

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            // Act
            var result = await controller.Get(conversation.Id, Guid.NewGuid());

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
        }

        [Fact]
        public async Task Get_Conversation_Returns_Unauthorized_If_Not_Users_Conversation()
        {
            DirectoryEntry testUser = Fixture.Create<DirectoryEntry>();
            var userClaims = new List<Claim> { new Claim(PerceptClaimTypes.UserId, testUser.Id.ToString()) };
            var testPrincipal = new ClaimsPrincipal(new ClaimsIdentity(userClaims));

            var mockLogger = new Mock<ILogger<ConversationsController>>();
            var mockService = new Mock<IConversationService>();
            var appService = new Mock<IAppRegistrationService>();
            appService.Setup(x => x.GetById(It.IsAny<Guid>(), false)).Returns(new AppRegistration { Id = Guid.NewGuid(), Description = "", Name = "", Organization = "", RouteName = "" });
            var authService = new Mock<IAuthorizationService>();
            authService.Setup(x => x.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), It.IsAny<object>(), It.IsAny<IEnumerable<IAuthorizationRequirement>>())).ReturnsAsync(AuthorizationResult.Success());
            var controller = new ConversationsController(mockService.Object, mockLogger.Object, appService.Object, authService.Object, Mapper, testPrincipal);
            var conversation = new ChatConversation
            {
                Name = "Test",
                Id = Guid.NewGuid(),
                Agent = new Agent() { ApplicationId = Guid.NewGuid(), Name = "Test" }
            };
            var query = new AgentQuery { ConversationId = conversation.Id };

            mockService.Setup(svc => svc.GetByIdWithAgent(It.IsAny<Guid>()))
                 .Returns(conversation);

            // Act
            var result = await controller.Get(conversation.Id, Guid.NewGuid());

            // Assert
            Assert.IsType<UnauthorizedResult>(result.Result);
        }
    }
}
