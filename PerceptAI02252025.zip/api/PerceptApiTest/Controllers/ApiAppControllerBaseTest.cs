using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using PerceptApi.Controllers;
using PerceptApi.DTOs;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using Percept.Shared.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Xunit;

namespace PerceptApiTest.Controllers
{
    public class ApiAppControllerBaseTest
    {
        private readonly Mock<IAppBaseService<TestEntity>> _mockService;
        private readonly Mock<ILogger<ApiAppControllerBase<TestEntity, TestRequest, TestResponse>>> _mockLogger;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<IAuthorizationService> _mockAuthorizationService;
        private readonly ApiAppControllerBase<TestEntity, TestRequest, TestResponse> _controller;

        public ApiAppControllerBaseTest()
        {
            _mockService = new Mock<IAppBaseService<TestEntity>>();
            _mockLogger = new Mock<ILogger<ApiAppControllerBase<TestEntity, TestRequest, TestResponse>>>();
            _mockMapper = new Mock<IMapper>();
            _mockAuthorizationService = new Mock<IAuthorizationService>();

            _controller = new TestApiAppControllerBase(
                _mockService.Object,
                _mockLogger.Object,
                _mockMapper.Object,
                _mockAuthorizationService.Object
            );
        }

        [Fact]
        public async Task Get_ReturnsFilteredAndSortedItems()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var testEntities = new List<TestEntity>
            {
                new TestEntity { Id = Guid.NewGuid(), ApplicationId = appId, Name = "Test1" },
                new TestEntity { Id = Guid.NewGuid(), ApplicationId = appId, Name = "Test2" }
            }.AsQueryable();

            _mockService.Setup(s => s.GetByApp(appId)).Returns(testEntities);

            _mockMapper.Setup(m => m.Map<PagedResponseDto<TestResponse>>(It.IsAny<PagedResponse<TestEntity>>()))
                .Returns(new PagedResponseDto<TestResponse>());

            // Act
            var result = await _controller.Get(appId, 1, 25, "Test", "Name", "Ascending");

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.IsType<PagedResponseDto<TestResponse>>(okResult.Value);
        }
        
        [Fact]
        public async Task GetById_ReturnsNotFoundResult_WhenEntityNotFound()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var id = Guid.NewGuid();
            _mockService.Setup(s => s.GetById(id, false)).Returns((TestEntity?)null);
            // Act
            var result = await _controller.GetById(appId, id);
            // Assert
            var actionResult = Assert.IsType<ActionResult<TestResponse>>(result);
            Assert.IsType<NotFoundResult>(actionResult.Result);
        }      

        [Fact]
        public async Task GetById_ReturnsOkResult_WhenEntityFoundAndAuthorized()
        {
            // Arrange
            var appId = Guid.NewGuid();
            var id = Guid.NewGuid();
            var entity = new TestEntity { Id = id, ApplicationId = appId };
            _mockService.Setup(s => s.GetById(id, false)).Returns(entity);
            _mockAuthorizationService.Setup(a => a.AuthorizeAsync(It.IsAny<ClaimsPrincipal>(), entity, "ReadPolicy"))
                .ReturnsAsync(AuthorizationResult.Success());
            _mockMapper.Setup(m => m.Map<TestResponse>(entity)).Returns(new TestResponse());
            // Act
            var result = await _controller.GetById(appId, id);
            // Assert
            var actionResult = Assert.IsType<ActionResult<TestResponse>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            Assert.IsType<TestResponse>(okResult.Value);
        }


        private class TestApiAppControllerBase : ApiAppControllerBase<TestEntity, TestRequest, TestResponse>
        {
            public TestApiAppControllerBase(IAppBaseService<TestEntity> service, ILogger logger, IMapper mapper, IAuthorizationService authorizationService)
                : base(service, logger, mapper, authorizationService)
            {
            }
        }

        public class TestEntity : IHasGuidId, IHasApplicationId
        {
            public Guid Id { get; set; }
            public Guid ApplicationId { get; set; }
            public string Name { get; set; }
        }

        public class TestRequest { }

        public class TestResponse : IHasGuidId
        {
            public Guid Id { get; set; }
        }
    }
}