﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Logging;
using Moq;
using Percept.Shared.Events;
using Percept.Shared.Loggers;
using System.Text.Json;


namespace PerceptApiTest.Loggers
{
    public class InsightsLoggerTests
    {
        [Fact]
        public void AddTelemetryClient_ShouldInitializeTelemetryClient()
        {
            // Arrange
            var mockTelemetryClientWrapper = new Mock<ITelemetryClientWrapper>();

            typeof(InsightsLogger)
                .GetField("_telemetryClientWrapper", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
                .SetValue(null, mockTelemetryClientWrapper.Object);
            var telemetryConfiguration = TelemetryConfiguration.CreateDefault();
            telemetryConfiguration.InstrumentationKey = "your-instrumentation-key";
            var telemetryClient = new TelemetryClient(telemetryConfiguration);

            // Act
            InsightsLogger.AddTelemetryClient(telemetryClient);

            // Assert
            mockTelemetryClientWrapper.Verify(tc => tc.Initialize(telemetryClient), Times.Once);
            mockTelemetryClientWrapper.Verify(tc => tc.CustomEvent("Initialize telemetry client", null), Times.Once);

        }

        [Fact]
        public void AddTelemetryClient_ShouldThrowNullException()
        {
            // Arrange
            TelemetryClient telemetryClient = null;

            // Act & Assert
            var exception = Assert.Throws<ArgumentNullException>(() => InsightsLogger.AddTelemetryClient(telemetryClient));

        }

        [Fact]
        public void AuditSuccess_CustomEvent()
        {
            // Arrange
            var mockLogger = new Mock<ILogger>();
            var mockTelemetryClientWrapper = new Mock<ITelemetryClientWrapper>();
            var perceptEvent = new PerceptEvent(100, "TestEvent")
            {
                EventId = 1,
                Description = "Test Description"
            };
            var perceptEventArgs = new { Param1 = "Value1" };

            typeof(InsightsLogger)
                .GetField("_telemetryClientWrapper", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
                .SetValue(null, mockTelemetryClientWrapper.Object);
            var telemetryConfiguration = TelemetryConfiguration.CreateDefault();
            telemetryConfiguration.InstrumentationKey = "your-instrumentation-key";
            var telemetryClient = new TelemetryClient(telemetryConfiguration);

            mockTelemetryClientWrapper.Setup(tc => tc.telemetryClient).Returns(telemetryClient);

            var serializedArgs = JsonSerializer.Serialize(perceptEventArgs);

            // Act
            InsightsLogger.AuditSuccess(mockLogger.Object, perceptEvent, perceptEventArgs);

            // Assert
            mockTelemetryClientWrapper.Verify(tc => tc.CustomEvent(
                It.Is<string>(s => s == perceptEvent.EventName),
                It.Is<Dictionary<string, string>>(d =>
                    d["LogLevel"] == LogLevel.Information.ToString() &&
                    d["EventId"] == perceptEvent.EventId.ToString() &&
                    d["Message"] == $"Audit Success: {perceptEvent.Description}" &&
                    d["Args"] == serializedArgs
                )), Times.Once);
        }

        [Fact]
        public void AuditFailure_LogsError()
        {
            // Arrange
            var mockLogger = new Mock<ILogger>();
            var perceptEvent = new PerceptEvent(100, "TestEvent")
            {
                EventId = 1,
                Description = "Test Description"
            };
            var perceptEventArgs = new { Param1 = "Value1" };

            // Act
            InsightsLogger.AuditFailure(mockLogger.Object, perceptEvent, perceptEventArgs);

            // Assert
            mockLogger.Verify(logger => logger.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Audit Failure: Test Description")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }
    }
}
