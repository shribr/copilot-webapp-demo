﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Microsoft.EntityFrameworkCore;
using Percept.Shared.Converter;
using Percept.Shared.Enums;
using Percept.Shared.Services;
using Percept.Shared.Services.Interfaces;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Data;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Services
{
    public static class ConfigureServices
    {
        public static void AddWorkspaces(this IServiceCollection services, IConfiguration configuration)
        {
            // Configuration
            var workspacesConfig = new WorkspacesConfiguration();
            configuration.GetSection("Percept:Workspaces").Bind(workspacesConfig);
            services.AddSingleton(workspacesConfig);

            // Services
            services.AddScoped<IUserIdentityService, UserIdentityService>();
            services.AddScoped<IWorkspaceService, WorkspaceService>();
            services.AddScoped<IWorkspaceSourcesService, WorkspaceSourcesService>();
            services.AddScoped<IDocumentStatusService<WorkspacesContext>, DocumentStatusService<WorkspacesContext>>();

            var workspacesKernelMemoryConfig = configuration.GetSection("Percept:Workspaces:KernelMemory");
            services.AddSingleton<IWorkspacesKernelMemory>(new WorkspacesKernelMemory(workspacesKernelMemoryConfig));

            // Database
            services.AddDbContextFactory<WorkspacesContext>(options =>
            {
                options.UseSqlServer(workspacesConfig.SqlConnectionString);
            }, ServiceLifetime.Scoped);

            // Automapper
            services.AddAutoMapper(typeof(MappingProfile).Assembly);

            // Controllers
            services.AddControllers(options =>
            {
                options.ModelMetadataDetailsProviders.Add(new SystemTextJsonValidationMetadataProvider());
            })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new EnumNameConverter<DocumentState>());
                options.JsonSerializerOptions.Converters.Add(new EnumNameConverter<UploadStatus>());
            })
            .AddApplicationPart(assembly: typeof(Controllers.WorkspacesControllerBase).Assembly);
        }
    }
}
