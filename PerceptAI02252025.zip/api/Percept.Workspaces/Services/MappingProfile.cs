﻿using AutoMapper;
using Microsoft.KernelMemory;
using Percept.Shared.Enums;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Entities;


namespace Percept.Workspaces.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Workspace, WorkspaceResponseItem>()
                .ForMember(des => des.SourcesCount, opt => opt.Ignore()) // TODO: Once we have a Sources Reference List : opt.MapFrom(src => src.Sources.Count());
                .ForMember(des => des.IsShared, opt => opt.Ignore()); // TODO: Once we have Sharing List : opt.MapFrom(src => src.SharedWith.Any());
            CreateMap<Workspace, WorkspaceResponse>()
                .ForMember(des => des.SourcesCount, opt => opt.Ignore())
                .ForMember(des => des.IsShared, opt => opt.Ignore());
            CreateMap<Citation, Source>()
                .ForMember(dto => dto.FileName, opt => opt.MapFrom(src => src.SourceName))
                .ForMember(dto => dto.State, opt => opt.MapFrom(x => DocumentState.Completed))
                .ForMember(dto => dto.Message, opt => opt.Ignore())
                .ForMember(dto => dto.CreatedBy, opt => opt.MapFrom(src => src.Partitions.First().Tags[Tags.UserName]))
                .ForMember(dto => dto.CreatedOn, opt => opt.MapFrom(src => src.Partitions.First().LastUpdate.DateTime));
            CreateMap<WorkspaceRequest, Workspace>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedBy, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedByUserId, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedOn, opt => opt.Ignore());
        }
    }
}
