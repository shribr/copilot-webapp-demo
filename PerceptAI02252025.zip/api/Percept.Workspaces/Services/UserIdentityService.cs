﻿using Percept.Workspaces.Configuration;
using Percept.Workspaces.Extensions;
using Percept.Workspaces.Services.Interfaces;
using System.Security.Claims;

namespace Percept.Workspaces.Services
{
    public class UserIdentityService(IHttpContextAccessor contextAccessor, WorkspacesConfiguration workspacesConfiguration) : IUserIdentityService
    {
        public (string? UserId, string? UserName) GetUser()
        {
            var user = contextAccessor.HttpContext?.User ?? Thread.CurrentPrincipal as ClaimsPrincipal;
            var id = user?.GetIdClaimValue(workspacesConfiguration.UserIdClaim);
            var userName = user?.GetIdClaimValue(workspacesConfiguration.UserNameClaim);
            return (id, userName);
        }
    }
}
