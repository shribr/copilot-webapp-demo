﻿namespace Percept.Workspaces.Services.Interfaces
{
    public interface IUserIdentityService
    {
        (string? UserId, string? UserName) GetUser();
    }
}