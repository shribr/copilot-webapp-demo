﻿using Microsoft.KernelMemory;
using Percept.Workspaces.DTOs;

namespace Percept.Workspaces.Services.Interfaces
{
    public interface IWorkspaceSourcesService
    {
        Task<IEnumerable<Source>> DeleteSourcesAsync(string indexName, IEnumerable<string> souceDocumentIds, CancellationToken cancellationToken);
        Task<StreamableFileContent> DownloadFileAsync(string indexName, string documentId, string fileName, CancellationToken cancellationToken);
        Task<IEnumerable<Source>> GetSourcesAsync(string indexName, CancellationToken cancellationToken);
        Task<IEnumerable<DocumentUpload>> UploadFilesAsync(string indexName,
            TagCollection tags,
            List<DocumentUploadRequest.UploadedFile> Files,
            CancellationToken cancellationToken);
    }
}