﻿using Microsoft.KernelMemory;

namespace Percept.Workspaces.Services.Interfaces
{
    public interface IWorkspacesKernelMemory
    {
        IKernelMemory KernelMemory { get; }
    }
}
