﻿using Percept.Workspaces.Entities;

namespace Percept.Workspaces.Services.Interfaces
{
    public interface IWorkspaceService
    {
        Task<Workspace> CreateAsync(Workspace workspace);
        Task<bool> DeleteAsync(Workspace workspace);
        IEnumerable<Workspace> GetAll(string userObjectId);
        Task<Workspace?> GetAsync(Guid id);
        Task<Workspace> UpdateAsync(Workspace workspace, string name);
    }
}