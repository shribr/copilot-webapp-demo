﻿using AutoMapper;
using Microsoft.KernelMemory;
using Percept.Shared.Enums;
using Percept.Shared.Models;
using Percept.Shared.Services.Interfaces;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Data;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Exceptions;
using Percept.Workspaces.Services.Interfaces;
using System.Globalization;

namespace Percept.Workspaces.Services
{
    public class WorkspaceSourcesService : IWorkspaceSourcesService
    {
        private readonly IKernelMemory _workspacesKernelMemory;
        private readonly IDocumentStatusService<WorkspacesContext> _documentStatusService;
        private readonly IMapper _mapper;

        public WorkspaceSourcesService(
            IWorkspacesKernelMemory workspacesKernelMemory,
            IDocumentStatusService<WorkspacesContext> documentStatusService,
            IMapper mapper)
        {
            _workspacesKernelMemory = workspacesKernelMemory.KernelMemory;
            _documentStatusService = documentStatusService;
            _mapper = mapper;
        }

        public async Task<IEnumerable<DocumentUpload>> UploadFilesAsync(string indexName, TagCollection tags, List<DocumentUploadRequest.UploadedFile> Files, CancellationToken cancellationToken)
        {
            var uploads = new List<DocumentUpload>();
            var kernelMemory = _workspacesKernelMemory;
            try
            {
                foreach (var file in Files)
                {
                    var fileTags = new TagCollection();
                    foreach (var tag in tags)
                    {
                        fileTags.Add(tag.Key, tag.Value);
                    }
                    fileTags.Add(Tags.FileName, file.FileName);

                    string? documentId = null;
                    string? errorMessage = null;
                    var status = UploadStatus.Completed;
                    var uploadRequest = new DocumentUploadRequest
                    {
                        DocumentId = RandomId(),
                        Index = indexName,
                        Tags = fileTags,
                        Files = new List<DocumentUploadRequest.UploadedFile>
                        {
                            file
                        }
                    };

                    DataPipelineStatus? dataPipelineStatus = null;
                    try
                    {
                        documentId = await kernelMemory.ImportDocumentAsync(
                            uploadRequest: uploadRequest,
                            cancellationToken: cancellationToken)
                            .ConfigureAwait(false); ;
                        dataPipelineStatus = await kernelMemory.GetDocumentStatusAsync(documentId, indexName, cancellationToken);
                        // Only log status for successful uploads
                        if (dataPipelineStatus != null)
                        {
                            var pipelineStatus = new DocumentPipelineStatus(dataPipelineStatus);
                            await _documentStatusService.UpdateStatusAsync(pipelineStatus, file.FileName);
                        }
                    }
                    catch (Exception ex)
                    {
                        errorMessage = ex.Message;
                        status = UploadStatus.Failed;
                    }

                    uploads.Add(new DocumentUpload
                    {
                        FileName = file.FileName,
                        DocumentId = documentId,
                        UploadStatus = status,
                        Message = errorMessage,
                        CreatedBy = "s",
                        CreatedOn = DateTime.UtcNow
                    });
                }
            }
            catch (Exception e)
            {
                throw new WorkspaceStorageException("Document upload failed", e);
            }

            return uploads;
        }

        private static string RandomId()
        {
            const string LocalDateFormat = "yyyyMMddhhmmssfffffff";
            return Guid.NewGuid().ToString("N") + DateTimeOffset.Now.ToString(LocalDateFormat, CultureInfo.InvariantCulture);
        }

        public async Task<IEnumerable<Source>> GetSourcesAsync(string indexName, CancellationToken cancellationToken)
        {
            List<Source> result;

            // Default filter if none specified is records tagged with tag eq '__part_n:0'
            // This should result in the first partition of each document
            var filters = new List<MemoryFilter> { MemoryFilters.ByTag(Constants.ReservedFilePartitionNumberTag, "0") };

            // get all sources from the index
            SearchResult answer = await _workspacesKernelMemory.SearchAsync(
                    query: "*",
                    index: indexName,
                    filters: filters,
                    cancellationToken: cancellationToken)
            .ConfigureAwait(false);
            var sources = _mapper.Map<IEnumerable<Source>>(answer.Results);

            // get all sources from Document Status
            var uploaded = _documentStatusService.GetDocuments(indexName, includeCompleted: false)
                .Select(s => new Source
                {
                    DocumentId = s.DocumentId,
                    FileName = s.FileName,
                    State = s.State,
                    Message = s.ErrorMessage,
                    CreatedBy = string.Empty, //  Status is not currently capturing this
                    CreatedOn = s.LastUpdated.DateTime
                });
            // if a document is pending delete we want to return it that way instead of completed
            var statusIds = uploaded.Select(s => s.DocumentId).ToList();

            result = sources.Where(source=> !statusIds.Contains(source.DocumentId)).Concat(uploaded).ToList();

            return result
                   .OrderBy(s => s.State != DocumentState.Completed)
                   .ThenByDescending(s => s.State)
                   .ThenBy(s => s.FileName)
                   .ToList();
        }

        private async Task<Source?> GetSourceAsync(string indexName, string documentId, CancellationToken cancellationToken)
        {
            Source? result = null;
            var filters = new List<MemoryFilter> {
                MemoryFilters.ByTag(Constants.ReservedDocumentIdTag, documentId),
                MemoryFilters.ByTag(Constants.ReservedFilePartitionNumberTag, "0")
            };

            // get all sources from the index
            SearchResult answer = await _workspacesKernelMemory.SearchAsync(
                    query: "*",
                    index: indexName,
                    filters: filters,
                    cancellationToken: cancellationToken)
            .ConfigureAwait(false);
            if (answer.Results.Count > 0)
            {
                result = _mapper.Map<Source>(answer.Results.First());
            }
            else
            {
                // If not found then get resultSource from KernelMemory Status
                var kmStatus = await _workspacesKernelMemory.GetDocumentStatusAsync(documentId, indexName, cancellationToken);
                if (kmStatus != null)
                {
                    var fileName = kmStatus.Tags.TryGetValue(Tags.FileName, out List<string?> fileNames) ?
                        fileNames.First() ?? string.Empty
                        : string.Empty;
                    var createdBy = kmStatus.Tags.TryGetValue(Tags.UserName, out List<string?> userNames) ?
                        userNames.First() ?? string.Empty
                        : string.Empty;
                    result = new Source
                    {
                        DocumentId = documentId,
                        FileName = fileName,
                        State = kmStatus.Completed ? DocumentState.Completed : DocumentState.Processing,
                        CreatedBy = createdBy,
                        CreatedOn = kmStatus.Creation.DateTime
                    };
                }
            }
            return result;
        }

        public async Task<IEnumerable<Source>> DeleteSourcesAsync(string indexName, IEnumerable<string> souceDocumentIds, CancellationToken cancellationToken)
        {
            var kernelMemory = _workspacesKernelMemory;

            var result = new List<Source>();
            foreach (var documentId in souceDocumentIds)
            {
                Source? resultSource = null;
                try
                {
                    var source = await GetSourceAsync(indexName, documentId, cancellationToken);
                    if (source != null)
                    {
                        resultSource = source;
                        await kernelMemory.DeleteDocumentAsync(documentId, indexName, cancellationToken);
                        await _documentStatusService.SetPendingDeleteAsync(indexName, documentId, source.FileName);
                        resultSource.State = DocumentState.PendingDelete;
                    }
                    else
                    {
                        resultSource = new Source
                        {
                            DocumentId = documentId,
                            FileName = string.Empty,
                            State = DocumentState.Deleted,
                            CreatedBy = string.Empty,
                            CreatedOn = DateTime.UtcNow
                        };
                    }
                }
                catch (Exception e)
                {
                    resultSource = new Source
                    {
                        DocumentId = documentId,
                        FileName = string.Empty,
                        State = DocumentState.Error,
                        Message = e.Message,
                        CreatedBy = string.Empty,
                        CreatedOn = DateTime.UtcNow
                    };
                }

                result.Add(resultSource);
            }
            return result;
        }

        public async Task<StreamableFileContent> DownloadFileAsync(string indexName, string documentId, string fileName, CancellationToken cancellationToken)
        {
            var memory = _workspacesKernelMemory;

            return await memory.ExportFileAsync(
            documentId: documentId,
            fileName: fileName,
            index: indexName,
            cancellationToken: cancellationToken)
            .ConfigureAwait(false);
        }
    }
}