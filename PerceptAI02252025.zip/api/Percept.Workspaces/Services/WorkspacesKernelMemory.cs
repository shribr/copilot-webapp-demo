﻿using Microsoft.KernelMemory;
using Microsoft.KernelMemory.MemoryDb.SQLServer;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Services
{
    public class WorkspacesKernelMemory : IWorkspacesKernelMemory
    {
        private readonly IKernelMemory _kernelMemory;

        public WorkspacesKernelMemory(IConfigurationSection config)
        {
            _kernelMemory = CreateKernel(config);
        }

        public IKernelMemory KernelMemory => _kernelMemory;

        private static IKernelMemory CreateKernel(IConfigurationSection config)
        {
            var azureBlobs = new AzureBlobsConfig();
            var azureQueues = new AzureQueuesConfig();
            var azureOpenAIEmbeddingConfig = new AzureOpenAIConfig();
            var azureOpenAIConfig = new AzureOpenAIConfig();
            var sqlServerConfig = new SqlServerConfig();
            config
                .BindSection("Services:AzureBlobs", azureBlobs)
                .BindSection("Services:AzureQueues", azureQueues)
                .BindSection("Services:AzureOpenAIText", azureOpenAIConfig)
                .BindSection("Services:AzureOpenAIEmbedding", azureOpenAIEmbeddingConfig)
                .BindSection("Services:SqlServer", sqlServerConfig);
            var services = new ServiceCollection();
            var memoryBuilder = new KernelMemoryBuilder(services)
                .WithAzureQueuesOrchestration(azureQueues)
                .WithAzureBlobsDocumentStorage(azureBlobs)
                .WithAzureOpenAITextGeneration(azureOpenAIConfig)
                .WithAzureOpenAITextEmbeddingGeneration(azureOpenAIEmbeddingConfig)
                .WithSqlServerMemoryDb(sqlServerConfig);

            return memoryBuilder.Build();
        }
    }
}
