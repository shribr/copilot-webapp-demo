﻿using Microsoft.EntityFrameworkCore;
using Percept.Workspaces.Data;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Services
{
    public class WorkspaceService(WorkspacesContext context) : IWorkspaceService
    {
        public async Task<Workspace> CreateAsync(Workspace workspace)
        {
            context.Add(workspace);
            await context.SaveChangesAsync();
            return workspace;
        }

        public async Task<bool> DeleteAsync(Workspace workspace)
        {
            context.Remove(workspace);
            await context.SaveChangesAsync();
            return await GetAsync(workspace.Id) == null;
        }

        public IEnumerable<Workspace> GetAll(string userObjectId)
        {
            var workspaces = context.Workspaces.Where(w => w.CreatedByUserId == userObjectId)
                .OrderBy(w => w.Name)
                .AsEnumerable();
            return workspaces;
        }

        public async Task<Workspace?> GetAsync(Guid id)
        {
            return await context.FindAsync<Workspace>(id);
        }

        public async Task<Workspace> UpdateAsync(Workspace workspace, string name)
        {
            workspace.Name = name;
            context.Update(workspace);
            await context.SaveChangesAsync();
            return workspace;
        }
    }
}
