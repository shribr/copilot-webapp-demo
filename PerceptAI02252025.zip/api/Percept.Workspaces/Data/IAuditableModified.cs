﻿namespace Percept.Workspaces.Data
{
    public interface IAuditableModified
    {
        string? ModifiedBy { get; set; }
        string? ModifiedByUserId { get; set; }
        DateTime? ModifiedOn { get; set; }
    }
}
