﻿namespace Percept.Workspaces.Data
{
    public interface IAuditable : IAuditableCreated, IAuditableModified { }
}
