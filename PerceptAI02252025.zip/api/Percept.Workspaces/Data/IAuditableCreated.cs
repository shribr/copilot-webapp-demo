﻿namespace Percept.Workspaces.Data
{
    public interface IAuditableCreated
    {
        string CreatedBy { get; set; }
        string CreatedByUserId { get; set; }
        DateTime CreatedOn { get; set; }
    }
}
