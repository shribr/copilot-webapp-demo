﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Percept.Shared.Data;
using Percept.Shared.Data.Entities;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Services.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Text.Json;

namespace Percept.Workspaces.Data
{
    public class WorkspacesContext(DbContextOptions<WorkspacesContext> options, IUserIdentityService userIdentityService) : DbContext(options), IDocumentUploadStatusDbContext
    {
        public DbSet<Workspace> Workspaces { get; set; }
        public DbSet<DocumentUploadStatus> DocumentUploadStatus { get; set; }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            AuditEntities();
            return await base.SaveChangesAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var dictionaryConverter = new ValueConverter<Dictionary<string, List<string>>?, string>(
               v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
               v => JsonSerializer.Deserialize<Dictionary<string, List<string>>>(v, (JsonSerializerOptions?)null) ?? new Dictionary<string, List<string>>());

            modelBuilder.Entity<Workspace>()
                .Property(w => w.Classification)
                .HasConversion(dictionaryConverter);
        }

        private void AuditCreation(IAuditableCreated auditable)
        {
            var (userId, userName) = userIdentityService.GetUser();
            auditable.CreatedBy = userName ?? "UNKNOWN";
            auditable.CreatedByUserId = userId ?? "UNKNOWN";
            auditable.CreatedOn = DateTime.UtcNow;
        }

        private void AuditModification(IAuditableModified auditable)
        {
            var (userId, userName) = userIdentityService.GetUser();
            auditable.ModifiedBy = userName ?? "UNKNOWN";
            auditable.ModifiedByUserId = userId ?? "UNKNOWN";
            auditable.ModifiedOn = DateTime.UtcNow;
        }

        private void AuditEntities()
        {
            // Handle added entities
            var addedEntries = ChangeTracker.Entries()
                .Where(u => u.State == EntityState.Added && (u.Entity is IAuditable || u.Entity is IAuditableCreated))
                .ToList();

            foreach (var entry in addedEntries)
            {
                if (entry.Entity is IAuditableCreated created)
                {
                    AuditCreation(created);
                }
                if (entry.Entity is IAuditableModified modified)
                {
                    AuditModification(modified);
                }
                ValidateEntity(entry);
            }

            // Handle modified entities
            var modifiedEntries = ChangeTracker.Entries()
                .Where(u => u.State == EntityState.Modified && (u.Entity is IAuditable || u.Entity is IAuditableModified))
                .ToList();

            foreach (var entry in modifiedEntries)
            {
                if (entry.Entity is IAuditableModified modified)
                {
                    AuditModification(modified);
                }
                ValidateEntity(entry);
            }
        }

        private static void ValidateEntity(EntityEntry entry)
        {
            try { Validator.ValidateObject(entry.Entity, new ValidationContext(entry.Entity), validateAllProperties: true); }
            catch (ValidationException e)
            {
                Debug.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:", entry.Entity.GetType(), entry.State);
                Debug.WriteLine(e.Message);
                throw;
            }
        }
    }
}