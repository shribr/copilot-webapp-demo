Define Configuration for Workspaces in appSettings.json

    "Percept": {
        "Workspaces": {
          "Enabled": "true",
          "MaxWorkspaces": 5,
          "MaxSources": 50,
          "EnableCollaboration": true,
          "UserIdClaim": "http://schemas.microsoft.com/identity/claims/objectidentifier"
        },
        "WorkspacesSqlConnectionString": "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PerceptAI_Workspaces;Integrated Security=True;Connect Timeout=60;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False"  },

    }

Register the Services in Program or Startup passing the configuration and using configuration to enable

    var workspacesConfig = new WorkspacesConfiguration();
    configuration.GetSection("Percept:Workspaces").Bind(workspacesConfig);
    if (workspacesConfig.Enabled)
    {
        builder.Services.AddWorkspaces(configuration);
    }


Create the database

    PM> update-database -Context WorkspacesContext