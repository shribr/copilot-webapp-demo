﻿using Percept.Shared.Events;

namespace Percept.Workspaces.Events
{
    public static class WorkspaceEvents
    { 
        public static class Workspaces
        {
            const string EventName = "Workspaces";
            const int EventIdBase = 10000;

            public static readonly PerceptEvent Create = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "Workspace Created"
            };

            public static readonly PerceptEvent Delete = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 2,
                Description = "Workspace Deleted"
            };

            public static readonly PerceptEvent Update = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 3,
                Description = "Workspace Updated"
            };
        }

        public static class Sources
        {
            const string EventName = "WorkspaceSources";
            const int EventIdBase = 10100;

            public static readonly PerceptEvent Upload = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "Source Uploaded"
            };

            public static readonly PerceptEvent Delete = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 2,
                Description = "Sources Deleted"
            };


            public static readonly PerceptEvent Download = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 3,
                Description = "Source Downloaded"
            };


            public static readonly PerceptEvent Preview = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 4,
                Description = "Source Previewied"
            };

        }
    } 
}

