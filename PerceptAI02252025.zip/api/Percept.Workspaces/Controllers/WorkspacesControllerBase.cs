﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Controllers
{
    public class WorkspacesControllerBase : Controller
    {
        internal readonly WorkspacesConfiguration _workspacesConfig;
        internal readonly ILogger _logger;
        internal readonly IWorkspaceService _workspaceService;
        internal readonly IMapper _mapper;
        internal readonly IUserIdentityService _userIdentityService;

        public WorkspacesControllerBase(
            ILogger logger,
            WorkspacesConfiguration workspacesConfiguration,
            IWorkspaceService workspaceService,
            IMapper mapper,
            IUserIdentityService userIdentityService)
        {
            _workspacesConfig = workspacesConfiguration;
            _logger = logger;
            _workspaceService = workspaceService;
            _mapper = mapper;
            _userIdentityService = userIdentityService;
        }

        protected (ActionResult?, string) ValidateUser()
        {
            string? userObjectId = string.Empty;
            if (!_workspacesConfig.Enabled) { return (new StatusCodeResult(405), userObjectId); }
            (userObjectId, _) = _userIdentityService.GetUser();
            if (userObjectId == null) { return (new UnauthorizedResult(), userObjectId ?? string.Empty); }
            return (null, userObjectId); ;
        }

        protected async Task<(ActionResult?, Workspace)> ValidateWorkspaceAsync(Guid workspaceId)
        {
            var emptyWorkspace = new Workspace { Name = string.Empty, CreatedBy = string.Empty, CreatedByUserId = string.Empty };
            Workspace? workspace = emptyWorkspace;
            var (userValidationResult, userObjectId) = ValidateUser();
            if (userValidationResult != null)
            { return (userValidationResult, workspace); }

            workspace = await _workspaceService.GetAsync(workspaceId);
            if (workspace == null) { return (NotFound("Requested workspace not found"), emptyWorkspace); }
            if (workspace.CreatedByUserId != userObjectId) { return (new UnauthorizedResult(), workspace); }
            return (null, workspace);
        }

        protected string BuildIndexName(string userObjectId, Guid workspaceId)
        {
            return $"{userObjectId}-workspace-{workspaceId}";
        }
    }
}
