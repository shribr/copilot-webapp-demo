﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Percept.Shared.Loggers;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Entities;
using Percept.Workspaces.Events;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class WorkspacesController : WorkspacesControllerBase
    {
        public WorkspacesController(
            ILogger<WorkspacesController> logger,
            WorkspacesConfiguration configuration,
            IWorkspaceService workspaceService,
            IMapper mapper,
            IUserIdentityService userIdentityService) :
            base(logger, configuration, workspaceService, mapper, userIdentityService)
        {

        }

        [HttpGet("Configuration")]
        public WorkspacesConfiguration Get()
        {
            return _workspacesConfig;
        }

        [HttpGet("")]
        public ActionResult<IEnumerable<WorkspaceResponseItem>> GetUsersWorkspaces()
        {
            var (userValidationResult, userObjectId) = ValidateUser();
            if (userValidationResult != null)
            { return userValidationResult; }
            var workspaces = _workspaceService.GetAll(userObjectId);
            return Ok(_mapper.Map<IEnumerable<WorkspaceResponseItem>>(workspaces));
        }

        [HttpPost("")]
        public async Task<ActionResult<WorkspaceResponseItem>> Post([FromBody] WorkspaceRequest request)
        {
            var (userValidationResult, userObjectId) = ValidateUser();
            if (userValidationResult != null)
            { return userValidationResult; }

            var workspace = _mapper.Map<Workspace>(request);

            var result = await _workspaceService.CreateAsync(workspace);
            InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Workspaces.Create, result);

            var requestUrl = Request.GetDisplayUrl();
            return Created($"{requestUrl}/{result.Id}", _mapper.Map<WorkspaceResponseItem>(result));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkspaceResponse>> Get([FromRoute] Guid id)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(id);
            if (workspaceValidationResult != null)
            { return workspaceValidationResult; }

            return Ok(_mapper.Map<WorkspaceResponse>(workspace));
        }

        [HttpPatch("{id}")]
        public async Task<ActionResult<bool>> Patch([FromRoute] Guid id, [FromBody] WorkspaceRequest request)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(id);
            if (workspaceValidationResult != null)
            { return workspaceValidationResult; }

            var result = await _workspaceService.UpdateAsync(workspace, request.Name);
            InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Workspaces.Update, result);
            return Ok(result != null);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> Delete([FromRoute] Guid id)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(id);
            if (workspaceValidationResult != null)
            {
                if (workspaceValidationResult is NotFoundObjectResult)
                {
                    return Ok(true);
                }
                else
                {
                    InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Workspaces.Delete, new { workspaceId = id });
                    return workspaceValidationResult;
                }
            }

            var result = await _workspaceService.DeleteAsync(workspace);
            InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Workspaces.Delete, workspace);
            return Ok(result);
        }
    }
}
