﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.KernelMemory.DocumentStorage;
using Microsoft.KernelMemory.Service.AspNetCore.Models;
using Microsoft.Net.Http.Headers;
using Percept.Shared.Loggers;
using Percept.Shared.Utils;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.DTOs;
using Percept.Workspaces.Events;
using Percept.Workspaces.Services.Interfaces;

namespace Percept.Workspaces.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/Workspaces/{workspaceId:guid}/Sources")]
    public class WorkspaceSourcesController(
        ILogger<WorkspaceSourcesController> logger,
        WorkspacesConfiguration configuration,
        IWorkspaceService workspaceService,
        IMapper mapper,
        IWorkspaceSourcesService sourceService,
        IUserIdentityService userIdentityService) : WorkspacesControllerBase(logger, configuration, workspaceService, mapper, userIdentityService)
    {
        [HttpOptions("", Order = 2)]
        [AllowAnonymous]
        public void GetUploadOptions()
        { }

        [HttpPost("")]
        [Consumes("multipart/form-data")]
        public async Task<ActionResult<UploadsAccepted>> UploadAsync([FromRoute] Guid workspaceId,
            CancellationToken cancellationToken)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(workspaceId);
            if (workspaceValidationResult != null)
            { return workspaceValidationResult; }

            // KM Validation that a file was provided and Tags meet requirements
            (HttpDocumentUploadRequest input, bool isValid, string errMsg)
                = await HttpDocumentUploadRequest.BindHttpRequestAsync(Request, cancellationToken)
            .ConfigureAwait(false);
            if (!isValid)
            {
                InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Sources.Upload, errMsg);
                return Problem(detail: errMsg, statusCode: 400);
            }

            var documentUpload = input.ToDocumentUploadRequest();
            try
            {
                var (userObjectId, userName) = _userIdentityService.GetUser();
                if (string.IsNullOrEmpty(userObjectId))
                {
                    return Problem(detail: "User object ID is null", statusCode: 400);
                }
                documentUpload.Tags.Add(Tags.UserName, userName);
                documentUpload.Tags.Add(Tags.UserObjectId, userObjectId);

                var workspaceCreatedByUserId = workspace.CreatedByUserId;
                var indexName = BuildIndexName(workspaceCreatedByUserId, workspaceId);

                var uploads = await sourceService.UploadFilesAsync(indexName, documentUpload.Tags, documentUpload.Files, cancellationToken);

                InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Sources.Upload, uploads);
                return Accepted(new UploadsAccepted
                {
                    Index = indexName,
                    Documents = uploads.ToList(),
                    Message = "Document uploads completed"
                });
            }
            catch (Exception e)
            {
                return Problem(title: "Document upload failed", detail: e.Message, statusCode: 503);
            }
        }

        [HttpGet("")]
        public async Task<ActionResult<IEnumerable<Source>>> GetSourcesAsync([FromRoute] Guid workspaceId, CancellationToken cancellationToken)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(workspaceId);
            if (workspaceValidationResult != null)
            { return workspaceValidationResult; }
            var userObjectId = workspace.CreatedByUserId;
            var indexName = BuildIndexName(userObjectId, workspaceId);
            var sources = await sourceService.GetSourcesAsync(indexName, cancellationToken);
            return Ok(sources);
        }

        [HttpDelete("")]
        public async Task<ActionResult<IEnumerable<Source>>> DeleteSourcesAsync([FromRoute] Guid workspaceId, [FromQuery] List<string> documentIds, CancellationToken cancellationToken)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(workspaceId);
            if (workspaceValidationResult != null)
            {
                InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Sources.Delete, new { workspaceId, documentIds });
                return workspaceValidationResult;
            }
            var userObjectId = workspace.CreatedByUserId;
            var indexName = BuildIndexName(userObjectId, workspaceId);
            var sources = await sourceService.DeleteSourcesAsync(indexName, documentIds, cancellationToken);
            InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Sources.Delete, new { workspaceId, documents = sources });
            return Ok(sources);
        }

        [HttpOptions("download", Order = 2)]
        [AllowAnonymous]
        public void GetOptions()
        { }

        [HttpGet("download")]
        public async Task<IActionResult> DownloadAsync(
            [FromRoute] Guid workspaceId,
            [FromQuery]
            string documentId,
            [FromQuery]
            string filename,
            [FromQuery]
            bool preview,
            CancellationToken cancellationToken)
        {
            var (workspaceValidationResult, workspace) = await ValidateWorkspaceAsync(workspaceId);
            if (workspaceValidationResult != null)
            { return workspaceValidationResult; }

            var userObjectId = workspace.CreatedByUserId;
            var indexName = BuildIndexName(userObjectId, workspaceId);

            try
            {
                var file = await sourceService.DownloadFileAsync(
                    documentId: documentId,
                    fileName: filename,
                    indexName: indexName,
                    cancellationToken: cancellationToken)
                    .ConfigureAwait(false);

                if (file == null)
                {

                    InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Sources.Download, new { workspaceId, documentId, filename });
                    throw new DocumentStorageFileNotFoundException("Storage returned a NULL value");
                }

                // logger.LogTrace("Downloading file '{0}', size '{1}', type '{2}'", filename, file.FileSize, file.FileType);

                EntityTagHeaderValue etag = HttpFileHelpers.GenerateETag(file.LastWrite);

                FileStreamResult response = File(
                    fileStream: await file.GetStreamAsync(),
                    contentType: file.FileType,
                    fileDownloadName: !preview ? filename : null, // remove here for preview so we can set inline header
                    lastModified: file.LastWrite,
                    entityTag: etag,
                    enableRangeProcessing: true);

                if (preview)
                {
                    HttpContext.Response.Headers.Append(HeaderNames.ContentDisposition, $"inline; filename=\"{filename}\"; filename*=UTF-8''\"{filename}\"");
                    InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Sources.Preview, new { workspaceId, documentId, filename });
                }
                else
                {
                    InsightsLogger.AuditSuccess(_logger, WorkspaceEvents.Sources.Download, new { workspaceId, documentId, filename });
                }

                HttpContext.Response.Headers.Append("Access-Control-Expose-Headers", HeaderNames.ContentDisposition);
                return response;
            }
            catch (DocumentStorageFileNotFoundException e)
            {
                InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Sources.Download, new { workspaceId, documentId, filename });
                return NotFound(e.Message);
            }
            catch (Exception e)
            {
                InsightsLogger.AuditFailure(_logger, WorkspaceEvents.Sources.Download, new { workspaceId, documentId, filename });
                return Problem(title: "File download failed", detail: e.Message, statusCode: 503);
            }
        }
    }
}
