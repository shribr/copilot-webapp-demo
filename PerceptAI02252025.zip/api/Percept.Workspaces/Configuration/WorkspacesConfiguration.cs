﻿using Microsoft.KernelMemory;
using System.Text.Json.Serialization;

namespace Percept.Workspaces.Configuration
{
    public class WorkspacesConfiguration
    {
        public bool Enabled { get; set; } = true;
        public int MaxWorkspaces { get; set; } = 5;
        public int MaxSources { get; set; } = 50;
        public bool EnableCollaboration { get; set; } = true;
        [JsonIgnore()]
        public string SqlConnectionString { get; set; } = string.Empty;
        [JsonIgnore()]
        public string UserIdClaim { get; set; } = "http://schemas.microsoft.com/identity/claims/objectidentifier";
        [JsonIgnore()]
        public string UserNameClaim { get; set; } = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
        [JsonIgnore]
        public KernelMemoryConfig KernelMemory { get; set; } = new KernelMemoryConfig();
    }
}
