﻿using Microsoft.KernelMemory;

namespace Percept.Workspaces.Configuration
{
    public static class WorkspaceConstants
    {
        public const string UploadStagingContainer = "workspaces-upload-staging";
        public const string BlobClientServiceName = "Percept.Workspaces.BlobClient";
        public const string QueueClientServiceName = "Percept.Workspaces.QueueClient";
    }

    public static class Tags
    {
        public static readonly string ValueDelimiter = "|";
        public static readonly string UserName = $"{Constants.ReservedTagsPrefix}user_name";
        public static readonly string UserObjectId = $"{Constants.ReservedTagsPrefix}user_objectid";
        public static readonly string FileName = $"{Constants.ReservedTagsPrefix}file_name";
    }
}
