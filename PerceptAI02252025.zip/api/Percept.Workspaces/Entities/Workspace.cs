﻿using Microsoft.EntityFrameworkCore;
using Percept.Workspaces.Data;

namespace Percept.Workspaces.Entities
{
    [Index(nameof(CreatedByUserId))]
    public class Workspace: IAuditableCreated
    {
        public Guid Id { get; set; }
        public required string Name { get; set; }
        public required string CreatedBy { get; set; }
        public required string CreatedByUserId { get; set; }
        public DateTime CreatedOn { get; set; }
        public Dictionary<string, List<string>>? Classification { get; set; }
    }
}
