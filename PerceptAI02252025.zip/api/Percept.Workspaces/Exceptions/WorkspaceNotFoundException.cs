﻿namespace Percept.Workspaces.Exceptions
{
    public class WorkspaceNotFoundException(string? message) : Exception(message)
    {

    }

    public class WorkspaceStorageException(string? message, Exception? innerException) :
        Exception(message, innerException)
    {

    }
}
