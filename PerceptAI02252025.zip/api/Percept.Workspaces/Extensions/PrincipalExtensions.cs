﻿using System.Security.Claims;
using System.Security.Principal;

namespace Percept.Workspaces.Extensions
{
    public static class PrincipalExtensions
    {
        public static string? GetIdClaimValue(this IPrincipal principal, string claimName)
        {
            ArgumentNullException.ThrowIfNull(principal);
            var claimsPrincipal = principal as ClaimsPrincipal;
            var idClaim = claimsPrincipal?.FindFirst(claimName);
            return idClaim?.Value;
        }
    }
}