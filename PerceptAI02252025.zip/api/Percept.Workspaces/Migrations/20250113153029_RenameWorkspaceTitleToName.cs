﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Percept.Workspaces.Migrations
{
    /// <inheritdoc />
    public partial class RenameWorkspaceTitleToName : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Title",
                table: "Workspaces",
                newName: "Name");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Workspaces",
                newName: "Title");
        }
    }
}
