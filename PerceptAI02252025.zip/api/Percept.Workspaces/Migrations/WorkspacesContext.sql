﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250107201827_InitialWorkspacesDb'
)
BEGIN
    CREATE TABLE [Workspaces] (
        [Id] uniqueidentifier NOT NULL,
        [Title] nvarchar(max) NOT NULL,
        [CreatedBy] nvarchar(450) NOT NULL,
        [CreatedOn] datetime2 NULL,
        CONSTRAINT [PK_Workspaces] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250107201827_InitialWorkspacesDb'
)
BEGIN
    CREATE INDEX [IX_Workspaces_CreatedBy] ON [Workspaces] ([CreatedBy]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250107201827_InitialWorkspacesDb'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250107201827_InitialWorkspacesDb', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250113153029_RenameWorkspaceTitleToName'
)
BEGIN
    EXEC sp_rename N'[Workspaces].[Title]', N'Name', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250113153029_RenameWorkspaceTitleToName'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250113153029_RenameWorkspaceTitleToName', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250121232308_UploadStatus'
)
BEGIN
    CREATE TABLE [DocumentUploadStatus] (
        [Id] uniqueidentifier NOT NULL,
        [DocumentId] nvarchar(max) NOT NULL,
        [FileName] nvarchar(max) NOT NULL,
        [Index] nvarchar(max) NOT NULL,
        [State] int NOT NULL,
        [ErrorMessage] nvarchar(max) NOT NULL,
        [LastUpdated] datetimeoffset NOT NULL,
        [CompletedSteps] nvarchar(max) NOT NULL,
        [RemainingSteps] nvarchar(max) NOT NULL,
        [isArchived] bit NOT NULL,
        CONSTRAINT [PK_DocumentUploadStatus] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250121232308_UploadStatus'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250121232308_UploadStatus', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    DROP INDEX [IX_Workspaces_CreatedBy] ON [Workspaces];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    DECLARE @var sysname;
    SELECT @var = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Workspaces]') AND [c].[name] = N'CreatedOn');
    IF @var IS NOT NULL EXEC(N'ALTER TABLE [Workspaces] DROP CONSTRAINT [' + @var + '];');
    EXEC(N'UPDATE [Workspaces] SET [CreatedOn] = ''0001-01-01T00:00:00.0000000'' WHERE [CreatedOn] IS NULL');
    ALTER TABLE [Workspaces] ALTER COLUMN [CreatedOn] datetime2 NOT NULL;
    ALTER TABLE [Workspaces] ADD DEFAULT '0001-01-01T00:00:00.0000000' FOR [CreatedOn];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Workspaces]') AND [c].[name] = N'CreatedBy');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [Workspaces] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [Workspaces] ALTER COLUMN [CreatedBy] nvarchar(max) NOT NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    ALTER TABLE [Workspaces] ADD [Classification] nvarchar(max) NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    ALTER TABLE [Workspaces] ADD [CreatedByUserId] nvarchar(450) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    CREATE INDEX [IX_Workspaces_CreatedByUserId] ON [Workspaces] ([CreatedByUserId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250124161319_AddClassification'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250124161319_AddClassification', N'9.0.1');
END;

COMMIT;
GO

