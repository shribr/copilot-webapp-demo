﻿using Percept.Shared.Converter;
using Percept.Shared.Enums;
using System.Text.Json.Serialization;

namespace Percept.Workspaces.DTOs
{
    public class Source : SourceBase
    {
        public required string DocumentId { get; set; }
        [JsonConverter(typeof(EnumNameConverter<DocumentState>))]
        public DocumentState State { get; set; }
    }
}
