﻿namespace Percept.Workspaces.DTOs
{
    public abstract class SourceBase
    {
        public required string FileName { get; set; }
        public required string CreatedBy { get; set; }
        public required DateTime CreatedOn { get; set; }
        public string? Message { get; set; }
    }
}
