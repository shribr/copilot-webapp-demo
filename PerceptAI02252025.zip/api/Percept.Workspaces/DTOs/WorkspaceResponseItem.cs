﻿namespace Percept.Workspaces.DTOs
{
    public class WorkspaceResponseItem: WorkspaceRequest
    {
        public Guid Id { get; set; }
        public bool IsShared { get; set; }
        public string CreatedBy { get; set; } = "";
        public string CreatedByUserId { get; set; } = "";
        public DateTime CreatedOn { get; set; }
        public int SourcesCount { get; set; }
    }

    public class WorkspaceResponse: WorkspaceResponseItem
    {
        // Sources
        // Users Conversation History
    }
}
