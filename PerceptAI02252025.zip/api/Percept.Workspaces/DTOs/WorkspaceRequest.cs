﻿using System.ComponentModel.DataAnnotations;

namespace Percept.Workspaces.DTOs
{
    public class WorkspaceRequest
    {
        [Required(ErrorMessage = "Name is required.")]
        public required string Name { get; set; }
        public Dictionary<string, List<string>>? Classification { get; set; }
    }
}
