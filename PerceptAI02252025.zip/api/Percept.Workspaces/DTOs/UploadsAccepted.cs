﻿using System.Text.Json.Serialization;

namespace Percept.Workspaces.DTOs
{
    public class UploadsAccepted
    {
        [JsonPropertyName("index")]
        [JsonPropertyOrder(1)]
        public string Index { get; set; } = string.Empty;

        [JsonPropertyName("documents")]
        [JsonPropertyOrder(2)]
        public List<DocumentUpload> Documents { get; set; } = new List<DocumentUpload>();

        [JsonPropertyName("message")]
        [JsonPropertyOrder(3)]
        public string Message { get; set; } = string.Empty;
    }
}
