﻿using Microsoft.KernelMemory;

namespace Percept.Workspaces.DTOs
{
    // Using this to make API discoverable via OpenAPI
    public class HttpSourcesDocumentUploadRequest
    {
        public IEnumerable<IFormFile> Files { get; set; } = [];
        public TagCollection Tags { get; set; } = [];
    }
}
