﻿namespace Percept.Workspaces.DTOs
{
    public enum UploadStatus
    {
        Completed = 1,
        Failed = 2
    }
}
