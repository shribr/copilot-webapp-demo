﻿using Percept.Shared.Converter;
using System.Text.Json.Serialization;

namespace Percept.Workspaces.DTOs
{

    public class DocumentUpload : SourceBase
    {
        public virtual string? DocumentId { get; set; }
        [JsonConverter(typeof(EnumNameConverter<UploadStatus>))]
        public UploadStatus UploadStatus { get; set; }
    }
}
