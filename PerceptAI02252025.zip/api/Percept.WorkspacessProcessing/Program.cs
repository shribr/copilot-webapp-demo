using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.AI;
using Microsoft.KernelMemory.Configuration;
using Microsoft.KernelMemory.Diagnostics;
using Microsoft.KernelMemory.DocumentStorage;
using Microsoft.KernelMemory.MemoryStorage;
using Microsoft.KernelMemory.Pipeline;

// Reference the Kernel Memory Program.cs in the Service Project for starting Configuration Steps 
SensitiveDataLogger.Enabled = false;

// *************************** APP BUILD *******************************

int asyncHandlersCount = 0;
int syncHandlersCount = 0;
string memoryType = string.Empty;

// Usual .NET web app builder with settings from appsettings.json, appsettings.<ENV>.json, and env vars
WebApplicationBuilder appBuilder = WebApplication.CreateBuilder();

if (Environment.GetEnvironmentVariable("APPLICATIONINSIGHTS_CONNECTION_STRING") != null)
{
    appBuilder.Services.AddApplicationInsightsTelemetry();
}

// Add config files, user secretes, and env vars
appBuilder.Configuration.AddKernelMemoryConfigurationSources();

// Read KM settings, needed before building the app.
KernelMemoryConfig config = appBuilder.Configuration.GetSection("KernelMemory").Get<KernelMemoryConfig>()
                            ?? throw new ConfigurationException("Unable to load configuration");

// Prepare memory builder, sharing the service collection used by the hosting service
// Internally build the memory client and make it available for dependency injection
appBuilder.AddKernelMemory(memoryBuilder =>
{
    // Prepare the builder with settings from config files
    memoryBuilder.ConfigureDependencies(appBuilder.Configuration).WithoutDefaultHandlers();

    // When using distributed orchestration, handlers are hosted in the current app and need to be configured
    asyncHandlersCount = AddHandlersAsHostedServices(config, memoryBuilder, appBuilder);
},
    memory =>
    {
        // When using in process orchestration, handlers are hosted by the memory orchestrator
        syncHandlersCount = AddHandlersToServerlessMemory(config, memory);

        memoryType = ((memory is MemoryServerless) ? "Sync - " : "Async - ") + memory.GetType().FullName;
    },
    services =>
    {
        long? maxSize = config.Service.GetMaxUploadSizeInBytes();
        if (!maxSize.HasValue) { return; }

        services.Configure<IISServerOptions>(x => { x.MaxRequestBodySize = maxSize.Value; });
        services.Configure<KestrelServerOptions>(x => { x.Limits.MaxRequestBodySize = maxSize.Value; });
        services.Configure<FormOptions>(x =>
        {
            x.MultipartBodyLengthLimit = maxSize.Value;
            x.ValueLengthLimit = int.MaxValue;
        });
    });

// Build .NET web app as usual
WebApplication app = appBuilder.Build();

// *************************** START ***********************************

var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
if (string.IsNullOrEmpty(env))
{
    app.Logger.LogError("ASPNETCORE_ENVIRONMENT env var not defined.");
}

Console.WriteLine("***************************************************************************************************************************");
Console.WriteLine("* Environment         : " + (string.IsNullOrEmpty(env) ? "WARNING: ASPNETCORE_ENVIRONMENT env var not defined" : env));
Console.WriteLine("* Memory type         : " + memoryType);
Console.WriteLine("* Pipeline handlers   : " + $"{syncHandlersCount} synchronous / {asyncHandlersCount} asynchronous");
Console.WriteLine("* Web service         : " + (config.Service.RunWebService ? "Enabled" : "Disabled"));

Console.WriteLine("* Memory Db           : " + app.Services.GetService<IMemoryDb>()?.GetType().FullName);
Console.WriteLine("* Document storage    : " + app.Services.GetService<IDocumentStorage>()?.GetType().FullName);
Console.WriteLine("* Embedding generation: " + app.Services.GetService<ITextEmbeddingGenerator>()?.GetType().FullName);
Console.WriteLine("* Text generation     : " + app.Services.GetService<ITextGenerator>()?.GetType().FullName);
#pragma warning disable KMEXP05 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
Console.WriteLine("* Content moderation  : " + app.Services.GetService<IContentModeration>()?.GetType().FullName);
#pragma warning restore KMEXP05 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
Console.WriteLine("* Log level           : " + app.Logger.GetLogLevelName());
Console.WriteLine("***************************************************************************************************************************");

app.Logger.LogInformation(
    "Starting Kernel Memory service, .NET Env: {EnvironmentType}, Log Level: {LogLevel}, Web service: {WebServiceEnabled}, Auth: {WebServiceAuthEnabled}, Pipeline handlers: {HandlersEnabled}",
    env,
    app.Logger.GetLogLevelName(),
    config.Service.RunWebService,
    config.ServiceAuthorization.Enabled,
    config.Service.RunHandlers);

// Start web service and handler services
try
{
    app.Run();
}
catch (IOException e)
{
    Console.WriteLine($"I/O error: {e.Message}");
    Environment.Exit(-1);
}

/// <summary>
/// Register handlers as asynchronous hosted services
/// </summary>
static int AddHandlersAsHostedServices(
    KernelMemoryConfig config,
    IKernelMemoryBuilder memoryBuilder,
    WebApplicationBuilder appBuilder)
{
    if (!string.Equals(config.DataIngestion.OrchestrationType, KernelMemoryConfig.OrchestrationTypeDistributed, StringComparison.OrdinalIgnoreCase))
    {
        return 0;
    }

    if (!config.Service.RunHandlers) { return 0; }

    // Handlers are enabled via configuration in appsettings.json and/or appsettings.<env>.json
    memoryBuilder.WithoutDefaultHandlers();

    // You can add handlers in the configuration or manually here using one of these syntaxes:
    // appBuilder.Services.AddHandlerAsHostedService<...CLASS...>("...STEP NAME...");
    // appBuilder.Services.AddHandlerAsHostedService("...assembly file name...", "...type full name...", "...STEP NAME...");

    // Register all pipeline handlers defined in the configuration to run as hosted services
    foreach (KeyValuePair<string, HandlerConfig> handlerConfig in config.Service.Handlers)
    {
        appBuilder.Services.AddHandlerAsHostedService(config: handlerConfig.Value, stepName: handlerConfig.Key);
    }

    // Return registered handlers count
    return appBuilder.Services.Count(s => typeof(IPipelineStepHandler).IsAssignableFrom(s.ServiceType));
}

/// <summary>
/// Register handlers instances inside the synchronous orchestrator
/// </summary>
static int AddHandlersToServerlessMemory(
    KernelMemoryConfig config, IKernelMemory memory)
{
    if (memory is not MemoryServerless) { return 0; }

    var orchestrator = ((MemoryServerless)memory).Orchestrator;
    foreach (KeyValuePair<string, HandlerConfig> handlerConfig in config.Service.Handlers)
    {
        orchestrator.AddSynchronousHandler(handlerConfig.Value, handlerConfig.Key);
    }

    return orchestrator.HandlerNames.Count;
}
