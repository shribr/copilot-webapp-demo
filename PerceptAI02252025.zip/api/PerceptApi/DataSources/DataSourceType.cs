﻿using System.ComponentModel;

namespace PerceptApi.DataSources
{
    public enum DataSourceType
    {
        [Description("KernelMemoryDataSourceConfiguration")]
        Documents = 0,
        [Description("SqlDataSourceConfiguration")]
        Database = 1
    }
}