﻿namespace PerceptApi.DataSources
{
    public class DataSourceConstants
    {
        public static Guid KernelMemoryTypeId = new Guid("10350695-4C07-4E2F-8DC8-CD70ACC89941");
        public static Guid SqlTypeId = new Guid("7FAF5552-8ED0-4DBB-9440-9551AD4264D7");
    }
}
