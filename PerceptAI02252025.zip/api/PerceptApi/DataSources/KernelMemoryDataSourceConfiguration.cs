﻿namespace PerceptApi.DataSources
{
    public class KernelMemoryDataSourceConfiguration : DataSourceConfigurationBase
    {
        // Kernel Memory replaces Underscore with Dash in IndexNames
        public string IndexName { get; set; } = string.Empty;
        public List<string> Categories { get; set; } = new();
    }
}