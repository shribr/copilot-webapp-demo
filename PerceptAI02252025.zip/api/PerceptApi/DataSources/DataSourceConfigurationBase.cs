﻿using PerceptApi.Attributes;
using System.Text.Json.Serialization;

namespace PerceptApi.DataSources
{
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
    [JsonDerivedType(typeof(KernelMemoryDataSourceConfiguration), typeDiscriminator: nameof(KernelMemoryDataSourceConfiguration))]
    [JsonDerivedType(typeof(SqlDataSourceConfiguration), typeDiscriminator: nameof(SqlDataSourceConfiguration))]
    [SwaggerBase]
    public class DataSourceConfigurationBase
    {

    }
}