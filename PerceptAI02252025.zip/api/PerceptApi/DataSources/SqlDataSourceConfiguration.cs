﻿using PerceptApi.Sql;

namespace PerceptApi.DataSources
{
    public class SqlDataSourceConfiguration : DataSourceConfigurationBase
    {
        public string ConnectionString { get; set; } = string.Empty;

        public SchemaDefinition Schema { get; set; }
    }
}