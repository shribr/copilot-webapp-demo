﻿using Azure.Identity;
using Azure.Monitor.OpenTelemetry.AspNetCore;
using OpenTelemetry.Trace;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Percept.Shared.Loggers;

namespace PerceptApi.Extensions
{
    public static class WebApplicationBuilderExtensions
    {
        public static WebApplicationBuilder AddAppInsights(this WebApplicationBuilder builder, IConfiguration configuration)
        {
            var appInsightsConnectionString = configuration.GetValue<string>("Logging:ApplicationInsights:ConnectionString");
            if (!string.IsNullOrWhiteSpace(appInsightsConnectionString))
            {

                builder.Services.AddApplicationInsightsTelemetry(new ApplicationInsightsServiceOptions
                {
                    ConnectionString = appInsightsConnectionString,
                    EnableDiagnosticsTelemetryModule = false,
                    EnablePerformanceCounterCollectionModule = false,
                    EnableQuickPulseMetricStream = false,
                    EnableEventCounterCollectionModule = false,
                }).AddSingleton<TelemetryClient>();

                var serviceProvider = builder.Services.BuildServiceProvider();
                var telemetryClient = serviceProvider.GetRequiredService<TelemetryClient>();

                // Make TelemetryClient available to InsightsLogger
                InsightsLogger.AddTelemetryClient(telemetryClient);
            }
            return builder;
        }
    }
}
