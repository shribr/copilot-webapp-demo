﻿using PerceptApi.Constants;
using System.Security.Claims;
using System.Security.Principal;

namespace PerceptApi.Extensions
{

    public static class PrincipalExtensions
    {
        public static Guid? GetUserId(this IPrincipal principal)
        {
            var claimsPrincipal = principal as ClaimsPrincipal;
            var idClaim = claimsPrincipal?.FindFirst(PerceptClaimTypes.UserId);
            return (idClaim != null ? new Guid(idClaim.Value) : null);
        }

        public static Guid? GetObjectId(this IPrincipal principal)
        {
            var claimsPrincipal = principal as ClaimsPrincipal;
            var idClaim =
                claimsPrincipal?.FindFirst(PerceptClaimTypes.Jwt_oid) ??
                claimsPrincipal?.FindFirst(PerceptClaimTypes.ObjectIdentifier);
            return (idClaim != null ? new Guid(idClaim.Value) : null);
        }
    }
}
