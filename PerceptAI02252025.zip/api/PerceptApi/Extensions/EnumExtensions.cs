﻿namespace PerceptApi.Extensions
{
    public static class EnumExtensions
    {
        public static IEnumerable<T> GetFlags<T>(this T input) where T : Enum
        {
            foreach (Enum value in Enum.GetValues(input.GetType()))
            {
                if (input.HasFlag(value))
                {
                    yield return (T)(object)value;
                }
            }
        }
    }
}
