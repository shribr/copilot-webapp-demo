﻿using PerceptApi.Data.Entities;
using PerceptApi.DataSources;

namespace PerceptApi.Extensions
{
    public static class DataSourceExtensions
    {
        public static string GetIndexName(this DataSource dataSource)
        {
            if (dataSource.Type != DataSourceType.Documents)
            {
                throw new InvalidDataException("Index name is only on document data sources.");
            }

            var configuration = dataSource.Configuration?.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();

            if (configuration == null)
            {
                throw new InvalidDataException("Kernel memory data source configuration is missing.");
            }

            return dataSource.IsLegacy ? configuration.IndexName : $"{dataSource.ApplicationId}-{configuration.IndexName}";
        }
    }
}
