﻿using Azure.Core;
using Microsoft.KernelMemory;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using PerceptApi.Data.Entities;
using PerceptApi.Models;
using ChatMessage = PerceptApi.Models.ChatMessage;

namespace PerceptApi.Extensions
{
    public static class ChatConversationExtensions
    {
        public static ThoughtProcess? GetThoughtProcess(this ChatConversation chatConversation, string messageId, HttpRequest request)
        {
            var chatMessage = chatConversation.GetChatAnswerMessage(messageId);

            if (chatMessage is null)
            {
                return null;
            }

            chatConversation.Citations.TryGetValue(messageId, out var citations);

            if (citations is KernelMemoryCitations kmCitations)
            {
                foreach (var citation in kmCitations.Citations)
                {
                    citation.DownloadUrl = BuildKernelMemoryUrlCitation(citation, request);
                }
                citations = kmCitations;
            }

            var systemAnswer = new SystemAnswer
            {
                Result = chatMessage.Items.OfType<TextContent>().First().Text ?? "Result could not be found",
                RelevantSources = citations,
            };

            if (chatMessage.Metadata != null && chatMessage.Metadata.TryGetValue("CreatedAt", out var createdValue) && DateTime.TryParse(createdValue.ToString(), out var createdOn))
            {
                return new ThoughtProcess
                {
                    ChatConversationId = chatConversation.Id,
                    CreatedOn = createdOn,
                    Id = messageId,
                    Model = chatMessage.ModelId ?? "Model is unknown",
                    Prompt = chatConversation.GetPrompt(),
                    SystemAnswer = systemAnswer,
                };
            }

            return null;
        }

        public static string GetPrompt(this ChatConversation chatConversation)
        {
            if (chatConversation.ChatHistory is null)
            {
                return string.Empty;
            }

            return string.Join(Environment.NewLine, chatConversation.ChatHistory.Where(x => x.Role == AuthorRole.System).Select(x => x.Items.OfType<TextContent>().First().Text));
        }

        public static ChatMessageContent? GetChatAnswerMessage(this ChatConversation chatConversation, string messageId)
        {
            return chatConversation.ChatHistory?.FirstOrDefault(x => x.Metadata is not null && x.Metadata.ContainsKey("Id") && x.Metadata["Id"].ToString() == messageId);
        }

        public static string BuildKernelMemoryUrlCitation(Citation citation, HttpRequest request)
        {
            var citationUrl = new RequestUriBuilder()
            {
                Scheme = request.Scheme,
                Host = request.Host.Host,
                Port = request.Host.Port ?? (request.IsHttps ? 443 : 80),
            };

            citationUrl.AppendPath("api/", false);
            citationUrl.AppendPath("kernelMemory/", false);
            citationUrl.AppendPath("download");

            citationUrl.AppendQuery("index", citation.Index);
            citationUrl.AppendQuery("documentId", citation.DocumentId);
            citationUrl.AppendQuery("filename", citation.SourceName);

            return citationUrl.ToString();
        }

        public static IEnumerable<ChatMessage> GetChatMessages(this ChatConversation chatConversation, HttpRequest request)
        {
            var chatMessages = new List<ChatMessage>();

            foreach (var chat in chatConversation.ChatHistory ?? new())
            {
                if (chat.Role == AuthorRole.User)
                {
                    chatMessages.Add(new UserChatMessage
                    {
                        Id = Guid.NewGuid().ToString(),
                        ConversationId = chatConversation.Id,
                        Message = chat.Items.OfType<TextContent>().First().Text ?? string.Empty,
                    });
                }
                else if (chat.Role == AuthorRole.Assistant && chat.Items.Any(x => x is TextContent) && chat.Metadata is not null && chat.Metadata.ContainsKey("Id"))
                {
                    chatConversation.Citations.TryGetValue(chat.Metadata["Id"]?.ToString() ?? string.Empty, out var citation);

                    List<ChatMessageCitation> chatMessageCitations = new List<ChatMessageCitation>();
                    if (citation is KernelMemoryCitations kmCitations)
                    {
                        chatMessageCitations = kmCitations.Citations.Select(x => new ChatMessageCitation
                        {
                            SourceName = x.SourceName,
                            SourceUrl = BuildKernelMemoryUrlCitation(x, request),
                        }).ToList();
                    }

                    chatMessages.Add(new AIChatMessage
                    {
                        Id = chat.Metadata["Id"]?.ToString() ?? string.Empty,
                        ConversationId = chatConversation.Id,
                        Message = chat.Items.OfType<TextContent>().First().Text ?? string.Empty,
                        Citations = chatMessageCitations,
                    });
                }
            }

            return chatMessages;
        }
    }
}
