﻿using Microsoft.Data.SqlClient;

namespace PerceptApi.Extensions
{
    public static class SqlExtensions
    {
        public static bool HasIntegratedSecurity(this string connectionString)
        {
            var connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);
            return string.IsNullOrWhiteSpace(connectionStringBuilder.Password);
        }
    }
}
