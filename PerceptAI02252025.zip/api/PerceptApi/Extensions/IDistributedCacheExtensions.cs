﻿using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace PerceptApi.Extensions;

public static class IDistributedCacheExtensions
{
    public static T? Get<T>(this IDistributedCache cache, string key)
    {
        var byteArray = cache.Get(key);
        if (byteArray == null) { return default; };
        return JsonSerializer.Deserialize<T>(byteArray);
    }

    public static void Set<T>(this IDistributedCache cache, string key, T value, DistributedCacheEntryOptions options)
    {
        var byteArray = JsonSerializer.SerializeToUtf8Bytes(value);
        cache.Set(key, byteArray, options);
    }

    public static async Task<T?> GetAsync<T>(this IDistributedCache cache, string key, CancellationToken token = default)
    {
        var byteArray = await cache.GetAsync(key, token);
        if (byteArray == null) { return default; };
        return JsonSerializer.Deserialize<T>(byteArray);
    }

    public static Task SetAsync<T>(this IDistributedCache cache, string key, T value, DistributedCacheEntryOptions options, CancellationToken token = default)
    {
        var byteArray = JsonSerializer.SerializeToUtf8Bytes(value);
        return cache.SetAsync(key, byteArray, options, token);
    }
}


