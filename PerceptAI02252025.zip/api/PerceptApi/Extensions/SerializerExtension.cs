﻿using System.Text.Json;

namespace PerceptApi.Extensions
{
    public static class SerializerExtension
    {
        public static T ConvertFromDictionary<T>(this IDictionary<string, object?> input) where T : class, new()
        {
            var newObject = new T();
            var properties = typeof(T).GetProperties();

            foreach (var property in properties)
            {
                if (input.ContainsKey(property.Name))
                {
                    var value = input[property.Name];
                    if (value != null)
                    {
                        var jsonValue = JsonSerializer.Serialize(value);
                        var convertedValue = JsonSerializer.Deserialize(jsonValue, property.PropertyType);
                        property.SetValue(newObject, convertedValue);
                    }
                }
            }

            return newObject;
        }

        public static Dictionary<string, object?> ConvertToDictionary<T>(this T obj)
        {
            var dictionary = new Dictionary<string, object?>();
            var properties = typeof(T).GetProperties();

            foreach (var property in properties)
            {
                var value = property.GetValue(obj);
                dictionary[property.Name] = value;
            }

            return dictionary;
        }

        public static T ConvertFromJsonObject<T>(this object obj) where T : class, new()
        {
            return JsonSerializer.Deserialize<T?>(JsonSerializer.Serialize<object>(obj)) ?? new();
        }
    }
}
