﻿using System.Text.Json.Serialization;

namespace PerceptApi.DTOs
{
    public class DocumentDto
    {
        /// <summary>
        /// Link to the source, if available.
        /// </summary>
        [JsonPropertyName("link")]
        [JsonPropertyOrder(1)]
        public string Link { get; set; } = string.Empty;

        [JsonPropertyName("dataSourceId")]
        [JsonPropertyOrder(2)]
        public Guid DataSourceId { get; set; } = Guid.Empty;

        /// <summary>
        /// Link to the source, if available.
        /// </summary>
        [JsonPropertyName("documentId")]
        [JsonPropertyOrder(3)]
        public string DocumentId { get; set; } = string.Empty;

        /// <summary>
        /// Link to the source, if available.
        /// </summary>
        [JsonPropertyName("fileId")]
        [JsonPropertyOrder(4)]
        public string FileId { get; set; } = string.Empty;

        /// <summary>
        /// Type of source, e.g. PDF, Word, Chat, etc.
        /// </summary>
        [JsonPropertyName("sourceContentType")]
        [JsonPropertyOrder(5)]
        public string SourceContentType { get; set; } = string.Empty;

        /// <summary>
        /// Name of the source, e.g. file name.
        /// </summary>
        [JsonPropertyName("sourceName")]
        [JsonPropertyOrder(6)]
        public string SourceName { get; set; } = string.Empty;

        /// <summary>
        /// Timestamp about the file/text partition.
        /// </summary>
        [JsonPropertyName("lastUpdate")]
        [JsonPropertyOrder(7)]
        public DateTimeOffset LastUpdate { get; set; } = DateTimeOffset.MinValue;
    }
}
