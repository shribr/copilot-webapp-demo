﻿namespace PerceptApi.DTOs
{
    public class CategoryRequestDto
    {
        public required string Name { get; set; }

    }
}
