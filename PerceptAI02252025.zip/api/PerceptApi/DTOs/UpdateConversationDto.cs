﻿using System.ComponentModel.DataAnnotations;

namespace PerceptApi.DTOs
{
    public class UpdateConversationDto
    {
        [Required(ErrorMessage = "The conversation name is required.")]
        public required string Name { get; set; }
    }
}
