﻿using Percept.Shared.Data.Entities;
using PerceptApi.Attributes;

namespace PerceptApi.DTOs
{
    public class AppRegistrationRequestDto
    {
        public required string Name { get; set; }
        public required string Description { get; set; }
        public required string Organization { get; set; }
        [RouteNameValidation]
        public required string RouteName { get; set; }
    }

    public class AppRegistrationDto : AppRegistrationRequestDto, IHasGuidId
    {
        public Guid Id { get; set; }
        public bool IsDisabled { get; set; }
        public required string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}