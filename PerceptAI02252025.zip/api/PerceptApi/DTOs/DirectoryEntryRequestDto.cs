﻿namespace PerceptApi.DTOs
{
    public class DirectoryEntryRequestDto: DirectoryEntryBaseDto
    {
        public Guid? Id { get; set; }
    }
}
