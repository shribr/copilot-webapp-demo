﻿namespace PerceptApi.DTOs
{
    public class DirectoryEntryBaseDto
    {
        public required Guid ObjectId { get; set; }
        public required string DisplayName { get; set; }
        public string? Email { get; set; }
        public required bool IsGroup { get; set; }
    }
}
