﻿using System.Text.Json.Serialization;

namespace PerceptApi.DTOs
{
    public class AgentQuery
    {
        [JsonPropertyName("agentId")]
        [JsonPropertyOrder(1)]
        public Guid? AgentId { get; init; }

        [JsonPropertyName("conversationId")]
        [JsonPropertyOrder(2)]
        public Guid? ConversationId { get; init; }

        [JsonPropertyName("question")]
        [JsonPropertyOrder(10)]
        public string Question { get; set; } = string.Empty;

        [JsonPropertyOrder(100)]
        public AgentQueryContext ContextArguments { get; set; } = new();
    }
}