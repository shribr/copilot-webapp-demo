﻿namespace PerceptApi.DTOs
{
    public abstract class AuditableDto
    {
        public required string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public required string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
    }
}
