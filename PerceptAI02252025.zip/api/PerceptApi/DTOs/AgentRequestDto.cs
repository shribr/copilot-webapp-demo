﻿using PerceptApi.Agents;
namespace PerceptApi.DTOs
{
    public class AgentRequestDto
    {
        public required Guid ApplicationId { get; set; }
        public required string Name { get; set; }
        public required string Description { get; set; }
        public AgentConfiguration? Configuration { get; set; }
        public List<Guid> DataSourceIds { get; set; } = [];
    }
}
