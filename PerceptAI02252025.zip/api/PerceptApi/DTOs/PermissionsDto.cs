﻿namespace PerceptApi.DTOs
{
    public class RoleDto<T> where T:Enum
    {
        public required T RoleId { get;set; }
        public required string RoleName { get; set; }
        public string Description { get; set; } = string.Empty;
        public List<DirectoryEntryDto> DirectoryEntries { get; set; }
    }
}
