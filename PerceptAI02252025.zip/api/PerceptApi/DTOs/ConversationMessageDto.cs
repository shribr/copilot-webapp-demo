﻿namespace PerceptApi.DTOs;

public record class ConversationMessageDto
{
    public Guid Id { get; set; }
    public string Question { get; set; } = string.Empty;
    public string Answer { get; set; } = string.Empty;
    public required object? RelevantSources { get; init; }
}
