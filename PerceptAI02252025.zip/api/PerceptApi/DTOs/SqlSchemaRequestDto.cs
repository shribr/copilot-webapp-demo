﻿namespace PerceptApi.DTOs
{
    public class SqlSchemaRequestDto
    {
        public required string ConnectionString { get; set; }
        public string Description { get; set; }
    }
}
