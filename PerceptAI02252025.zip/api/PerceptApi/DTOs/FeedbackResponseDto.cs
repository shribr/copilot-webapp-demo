﻿using Percept.Shared.Data.Entities;

namespace PerceptApi.DTOs
{
    public class FeedbackResponseDto : FeedbackRequestDto, IHasGuidId
    {

        /// <summary>
        /// The unique identifier for the feedback.
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// The date and time when the feedback was submitted.
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// The username of the user providing feedback. This field is required.
        /// </summary>
        public string UserName { get; set; } = string.Empty;
    }
}
