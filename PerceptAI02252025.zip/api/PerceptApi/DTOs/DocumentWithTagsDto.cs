﻿using Microsoft.KernelMemory;
using System.Text.Json.Serialization;

namespace PerceptApi.DTOs
{
    public class DocumentWithTagsDto : DocumentDto
    {
        /// <summary>
        /// Tags associated with the Document
        /// </summary>
        [JsonPropertyName("tags")]
        [JsonPropertyOrder(8)]
        public TagCollection Tags { get; set; } = new TagCollection();
    }
}
