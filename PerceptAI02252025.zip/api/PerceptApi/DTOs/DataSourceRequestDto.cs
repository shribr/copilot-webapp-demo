﻿using PerceptApi.DataSources;

namespace PerceptApi.DTOs
{
    public class DataSourceRequestDto
    {
        public required Guid ApplicationId { get; set; }
        public required DataSourceType Type { get; set; }
        public required string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public DataSourceConfigurationBase? Configuration { get; set; }
    }
}
