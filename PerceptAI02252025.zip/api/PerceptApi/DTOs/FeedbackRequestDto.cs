using PerceptApi.Enums;
using System.ComponentModel.DataAnnotations;

namespace PerceptApi.DTOs
{
    public class FeedbackRequestDto
    {
        /// <summary>
        /// The AI response that the feedback is about. This field is required.
        /// </summary>
        [Required]
        public string Response { get; set; } = string.Empty;

        /// <summary>
        /// The user's question that prompted the AI response. This field is required.
        /// </summary>
        [Required]
        public string Question { get; set; } = string.Empty;

        /// <summary>
        /// The user's reaction to the AI response.
        /// </summary>
        [Required]
        public Reaction Reaction { get; set; }

        /// <summary>
        /// Any additional comments the user may have about the AI response. This field is optional.
        /// </summary>
        public string? Comment { get; set; }

        [Required]
        public Guid ApplicationId { get; set; }
    }
}
