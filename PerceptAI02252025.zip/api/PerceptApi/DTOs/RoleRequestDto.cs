﻿using PerceptApi.Enums;

namespace PerceptApi.DTOs
{
    public class RoleRequestDto<T> where T : Enum
    {
        public required RoleAction Action { get; set; }
        public required T RoleId { get; set; }
        public List<DirectoryEntryRequestDto> DirectoryEntries { get; set; } = new();

        public string ToAuditString()
        {
            return $"{Action} AppRole:{RoleId} for Directory Entry ObjectIds: {string.Join(",", DirectoryEntries.Select(e => e.ObjectId.ToString()))}";
        }
    }
}
