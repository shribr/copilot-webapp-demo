﻿namespace PerceptApi.DTOs
{
    public class DirectoryEntryDto: DirectoryEntryBaseDto
    {
        public required Guid Id { get; set; }
    }
}
