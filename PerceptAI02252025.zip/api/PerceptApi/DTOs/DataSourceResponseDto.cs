﻿using Percept.Shared.Data.Entities;
namespace PerceptApi.DTOs
{
    public class DataSourceResponseDto : DataSourceRequestDto, IHasGuidId
    {
        public Guid Id { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedOn { get; set; }
        public List<AgentItemDto> Agents { get; set; } = [];
    }
}
