﻿using PerceptApi.Models;

namespace PerceptApi.DTOs;

public class ChatConversationDto : ChatConversationItemDto
{
    public required IEnumerable<ChatMessage> Messages { get; set; }
    public required AgentQueryContext AgentQueryContext { get; set; }
}
