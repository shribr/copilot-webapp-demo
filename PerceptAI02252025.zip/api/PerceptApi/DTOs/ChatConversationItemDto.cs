﻿namespace PerceptApi.DTOs;

public class ChatConversationItemDto
{
    public Guid Id { get; set; }
    public Guid AgentId { get; set; }
    public string AgentName { get; set; } = string.Empty;
    public required string Name { get; set; }
    public DateTime CreatedOn { get; set; }
}
