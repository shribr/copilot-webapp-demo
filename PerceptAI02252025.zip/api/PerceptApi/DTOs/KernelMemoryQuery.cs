﻿using Microsoft.KernelMemory;

namespace PerceptApi.DTOs
{
    public class KernelMemoryQuery : AgentQueryContext
    {
        public List<MemoryFilter>? Filters { get; set; }
        public double MinRelevance { get; set; } = 0.8d;
        public Dictionary<string, object?>? ContextArguments { get; set; }
    }
}