﻿namespace PerceptApi.DTOs
{
    public class MessageDto
    {
        public string Message { get; set; }
    }
}
