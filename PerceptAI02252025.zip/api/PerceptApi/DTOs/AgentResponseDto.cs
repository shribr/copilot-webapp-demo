﻿using PerceptApi.Agents;

namespace PerceptApi.DTOs
{

    public class AgentResponseDto : AgentItemDto
    {
        public string? Description { get; set; }
        public bool IsDisabled { get; set; }
        public AgentConfiguration Configuration { get; set; }
        public List<DataSourceResponseDto> DataSources { get; set; } = [];
    }
}
