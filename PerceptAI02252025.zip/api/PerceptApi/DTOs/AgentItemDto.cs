﻿using Percept.Shared.Data.Entities;

namespace PerceptApi.DTOs
{
    public class AgentItemDto : AuditableDto, IHasGuidId
    {
        public Guid Id { get; set; }
        public Guid ApplicationId { get; set; }
        public required string Name { get; set; }
     
    }
}
