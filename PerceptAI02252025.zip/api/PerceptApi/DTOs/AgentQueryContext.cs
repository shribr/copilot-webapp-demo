﻿using PerceptApi.Attributes;
using System.Text.Json.Serialization;

namespace PerceptApi.DTOs
{
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
    [JsonDerivedType(typeof(KernelMemoryQuery), typeDiscriminator: nameof(KernelMemoryQuery))]
    [SwaggerBase]
    public class AgentQueryContext
    {
        public string? Prompt { get; set; }
    }
}