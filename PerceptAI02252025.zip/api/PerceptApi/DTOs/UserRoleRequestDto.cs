﻿namespace PerceptApi.DTOs
{
    public class UserRoleRequestDto<T> where T : Enum
    {
        public Guid ObjectId { get; set; }
        public bool IsGroup { get; set; }
        public T Permission { get; set; }
    }
}
