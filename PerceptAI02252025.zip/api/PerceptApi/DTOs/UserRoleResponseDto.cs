﻿using PerceptApi.Enums;

namespace PerceptApi.DTOs
{
    public class UserRoleResponseDto
    {
        public Guid Id { get; set; }
        public Guid DirectoryEntryId { get; set; }
        public bool IsGroup { get; set; }
        public Guid EntityId { get; set; }
        public EntityTypes EntityType { get; set; }
        public int Permission { get; set; }
    }
}
