﻿namespace PerceptApi.DTOs
{
    public class PermissionDto<T> where T : Enum
    {
        public T Permission { get; set; }
    }
}
