﻿using Percept.Shared.Data.Entities;
using Percept.Shared.Enums;

namespace PerceptApi.DTOs
{
    public class DocumentStatusResponseDto : IHasGuidId
    {
        public required Guid Id { get; set; }
        public required string DocumentId { get; set; }
        public required string FileName { get; set; }
        public required string Index { get; set; }
        public DocumentState State { get; set; }
        public string ErrorMessage { get; set; }
        public DateTimeOffset LastUpdated { get; set; }
        public List<string> CompletedSteps { get; set; } = new();
        public List<string> RemainingSteps { get; set; } = new();

    }
}
