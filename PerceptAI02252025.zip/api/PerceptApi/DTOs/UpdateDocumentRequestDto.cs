﻿using Microsoft.KernelMemory;
using PerceptApi.Attributes;

namespace PerceptApi.DTOs
{
    public class UpdateDocumentRequestDto
    {
        public required string DocumentId { get; set; }
        [TagCollectionValidationAttribute]
        public TagCollection TagsToAdd { get; set; } = [];
        [TagCollectionValidationAttribute]
        public TagCollection TagsToRemove { get; set; } = [];
    }
}
