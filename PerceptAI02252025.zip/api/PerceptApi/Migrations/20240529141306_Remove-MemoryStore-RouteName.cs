﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class RemoveMemoryStoreRouteName : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_MemoryStores_RouteName",
                table: "MemoryStores");

            migrationBuilder.DropColumn(
                name: "RouteName",
                table: "MemoryStores");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RouteName",
                table: "MemoryStores",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_MemoryStores_RouteName",
                table: "MemoryStores",
                column: "RouteName",
                unique: true);
        }
    }
}
