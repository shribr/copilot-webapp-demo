﻿using Microsoft.EntityFrameworkCore.Migrations;
using PerceptApi.DataSources;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class DataSources : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_DirectoryEntryId",
                table: "ChatConversations");

            migrationBuilder.DropForeignKey(
                name: "FK_MemoryStores_Prompts_PromptId",
                table: "MemoryStores");

            migrationBuilder.DropIndex(
                name: "IX_ChatConversations_DirectoryEntryId",
                table: "ChatConversations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_MemoryStores",
                table: "MemoryStores");

            migrationBuilder.DropIndex(
                name: "IX_MemoryStores_Name",
                table: "MemoryStores");

            migrationBuilder.DropIndex(
                name: "IX_MemoryStores_PromptId",
                table: "MemoryStores");

            migrationBuilder.DropColumn(
                name: "PromptId",
                table: "MemoryStores");

            migrationBuilder.RenameTable(
                name: "MemoryStores",
                newName: "DataSources");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "DataSources",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<Guid>(
                name: "ApplicationId",
                table: "DataSources",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"));

            migrationBuilder.AddColumn<string>(
                name: "Configuration",
                table: "DataSources",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "TypeId",
                table: "DataSources",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: DataSourceConstants.KernelMemoryTypeId);

            migrationBuilder.AddPrimaryKey(
                name: "PK_DataSources",
                table: "DataSources",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "AgentDataSource",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AgentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DataSourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AgentDataSource", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AgentDataSource_Agents_AgentId",
                        column: x => x.AgentId,
                        principalTable: "Agents",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AgentDataSource_DataSources_DataSourceId",
                        column: x => x.DataSourceId,
                        principalTable: "DataSources",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DataSources_ApplicationId",
                table: "DataSources",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_AgentDataSource_AgentId",
                table: "AgentDataSource",
                column: "AgentId");

            migrationBuilder.CreateIndex(
                name: "IX_AgentDataSource_DataSourceId",
                table: "AgentDataSource",
                column: "DataSourceId");

            migrationBuilder.AddForeignKey(
                name: "FK_DataSources_AppRegistrations_ApplicationId",
                table: "DataSources",
                column: "ApplicationId",
                principalTable: "AppRegistrations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DataSources_AppRegistrations_ApplicationId",
                table: "DataSources");

            migrationBuilder.DropTable(
                name: "AgentDataSource");

            migrationBuilder.DropPrimaryKey(
                name: "PK_DataSources",
                table: "DataSources");

            migrationBuilder.DropIndex(
                name: "IX_DataSources_ApplicationId",
                table: "DataSources");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "DataSources");

            migrationBuilder.DropColumn(
                name: "Configuration",
                table: "DataSources");

            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "DataSources");

            migrationBuilder.RenameTable(
                name: "DataSources",
                newName: "MemoryStores");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "MemoryStores",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<Guid>(
                name: "PromptId",
                table: "MemoryStores",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_MemoryStores",
                table: "MemoryStores",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ChatConversations_DirectoryEntryId",
                table: "ChatConversations",
                column: "DirectoryEntryId");

            migrationBuilder.CreateIndex(
                name: "IX_MemoryStores_Name",
                table: "MemoryStores",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MemoryStores_PromptId",
                table: "MemoryStores",
                column: "PromptId");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_DirectoryEntryId",
                table: "ChatConversations",
                column: "DirectoryEntryId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MemoryStores_Prompts_PromptId",
                table: "MemoryStores",
                column: "PromptId",
                principalTable: "Prompts",
                principalColumn: "Id");
        }
    }
}
