﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class FeedbackByApp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "ApplicationId",
                table: "Feedbacks",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"));

            migrationBuilder.CreateIndex(
                name: "IX_Feedbacks_ApplicationId",
                table: "Feedbacks",
                column: "ApplicationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_AppRegistrations_ApplicationId",
                table: "Feedbacks",
                column: "ApplicationId",
                principalTable: "AppRegistrations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_AppRegistrations_ApplicationId",
                table: "Feedbacks");

            migrationBuilder.DropIndex(
                name: "IX_Feedbacks_ApplicationId",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "Feedbacks");
        }
    }
}
