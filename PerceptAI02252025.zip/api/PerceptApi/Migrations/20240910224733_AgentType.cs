﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class AgentType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "TypeId",
                table: "Agents",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("6D6587F6-1815-4E06-B72B-21BDA15C714B")); // KernelMemoryAgentTypeId

            var memoryStorestoAgent = File.ReadAllText(Path.Join("Migrations", "Queries", "MigrateMemoryStoreToAgent.sql"));
            migrationBuilder.Sql(memoryStorestoAgent);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "Agents");
        }
    }
}
