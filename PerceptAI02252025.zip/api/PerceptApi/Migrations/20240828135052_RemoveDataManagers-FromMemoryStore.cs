﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class RemoveDataManagersFromMemoryStore : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO UserRoles (ID, DirectoryEntryId, EntityId, IsGroup, EntityType, Permission) SELECT NEWID(), DataManagersId, MemoryStoresId, 0, 0, 2 FROM MemoryStoreUser");

            migrationBuilder.DropTable(
                name: "MemoryStoreUser");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MemoryStoreUser",
                columns: table => new
                {
                    DataManagersId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    MemoryStoresId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MemoryStoreUser", x => new { x.DataManagersId, x.MemoryStoresId });
                    table.ForeignKey(
                        name: "FK_MemoryStoreUser_DirectoryEntries_DataManagersId",
                        column: x => x.DataManagersId,
                        principalTable: "DirectoryEntries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MemoryStoreUser_MemoryStores_MemoryStoresId",
                        column: x => x.MemoryStoresId,
                        principalTable: "MemoryStores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MemoryStoreUser_MemoryStoresId",
                table: "MemoryStoreUser",
                column: "MemoryStoresId");

            migrationBuilder.Sql("INSERT INTO MemoryStoreUser (DataManagersId, MemoryStoresId) SELECT DirectoryEntryId, EntityId FROM UserRoles");
        }
    }
}
