﻿UPDATE Agents
SET Configuration = 
    CONCAT(
        '{',
        '"28e42582-dfce-45f3-8d37-d6e88235c060": {',
            '"IndexName": "', a.[Name], '",',
            '"ModelDeploymentName": "gpt4o"',
        '},',
        '"6d6587f6-1815-4e06-b72b-21bda15c714b": {',
            '"Instructions": "I Always want you to search kernel memory to find facts to answer the users question even if you think you know the answer.",',
            '"PluginsUsed": ["28e42582-dfce-45f3-8d37-d6e88235c060"],',
            '"MaxConversations": 30,',
            '"MemoryStoreId": "', ms.Id, '",',
            '"Categories": [', 
             (SELECT STRING_AGG('"' + [Name] + '"', ',') 
                 FROM Categories c
                 WHERE c.MemoryStoreId = ms.Id), ']',
        '}',
        '}'
    )
FROM Agents a left join MemoryStores ms on a.[Name] = ms.[Name]

