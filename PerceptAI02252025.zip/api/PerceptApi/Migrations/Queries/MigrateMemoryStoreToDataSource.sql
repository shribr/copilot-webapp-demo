﻿INSERT INTO AgentDataSource
SELECT 
	Id = newid(),	
	AgentId = a.Id,
	DataSourceId = ds.Id
FROM Agents a join DataSources ds on ds.[Name]=a.[Name]

