﻿UPDATE DataSources 
SET [Configuration] =
(SELECT '{"$type":"KernelMemoryDataSourceConfiguration","Categories":' +

(SELECT 
	JSON_QUERY([Configuration], '$."6d6587f6-1815-4e06-b72b-21bda15c714b".Categories') AS Categories
FROM Agents 
WHERE CONVERT(uniqueidentifier, JSON_VALUE([Configuration], '$."6d6587f6-1815-4e06-b72b-21bda15c714b".MemoryStoreId')) = ds.Id)
+ ',"IndexName":"'+ds.[Name]+'"}')

FROM DataSources ds

UPDATE DataSources
SET [Type] = 1 --SQL
WHERE JSON_QUERY([Configuration], '$."Categories"') is null