﻿INSERT INTO UserRoles
SELECT 
	Id = newid(),	
	DirectoryEntryId = OwnerId,
	IsGroup = (select IsGroup from DirectoryEntries where ID=OwnerId),
	EntityId = AppRegistrationId,
	EntityType = 2, --AppRegistration
	Permission = 2 -- Owner

FROM AppRegistrationDirectoryEntry