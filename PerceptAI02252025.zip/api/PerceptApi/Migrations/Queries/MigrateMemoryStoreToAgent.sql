﻿DELETE FROM Agents

INSERT INTO Agents (ID, ApplicationId, [Name], Configuration, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn, TypeId)
SELECT 
    ID,
    '2276a639-cdbf-4649-bee9-ac2886043765',
    [Name],
    CONCAT(
        '{',
        '"28e42582-dfce-45f3-8d37-d6e88235c060": {',
            '"IndexName": "', [Name], '",',
            '"ModelDeploymentName": "gpt4o"',
        '},',
        '"6D6587F6-1815-4E06-B72B-21BDA15C714B": {',
            '"Instructions": "I Always want you to search kernel memory to find facts to answer the users question even if you think you know the answer.",',
            '"PluginsUsed": ["28e42582-dfce-45f3-8d37-d6e88235c060"],',
            '"MaxConversations": 30,',
            '"MemoryStoreId": "', ID, '"',
        '}',
        '}'
    ) AS Configuration,
    'SYSTEM MIGRATION',
    GetDate(),
    'SYSTEM MIGRATION',
    GetDate(),
    '6D6587F6-1815-4E06-B72B-21BDA15C714B'
FROM MemoryStores;

