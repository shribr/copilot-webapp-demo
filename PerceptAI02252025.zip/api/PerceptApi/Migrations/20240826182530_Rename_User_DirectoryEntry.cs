﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class Rename_User_DirectoryEntry : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_UserId",
                table: "ChatConversations");

            migrationBuilder.DropForeignKey(
                name: "FK_UserRoles_DirectoryEntries_ObjectId",
                table: "UserRoles");

            migrationBuilder.RenameColumn(
                name: "ObjectId",
                table: "UserRoles",
                newName: "DirectoryEntryId");

            migrationBuilder.RenameIndex(
                name: "IX_UserRoles_ObjectId",
                table: "UserRoles",
                newName: "IX_UserRoles_DirectoryEntryId");

            migrationBuilder.RenameIndex(
                name: "IX_UserRoles_EntityId_ObjectId_EntityType_IsGroup",
                table: "UserRoles",
                newName: "IX_UserRoles_EntityId_DirectoryEntryId_EntityType_IsGroup");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "ChatConversations",
                newName: "DirectoryEntryId");

            migrationBuilder.RenameIndex(
                name: "IX_ChatConversations_UserId",
                table: "ChatConversations",
                newName: "IX_ChatConversations_DirectoryEntryId");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_DirectoryEntryId",
                table: "ChatConversations",
                column: "DirectoryEntryId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserRoles_DirectoryEntries_DirectoryEntryId",
                table: "UserRoles",
                column: "DirectoryEntryId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_DirectoryEntryId",
                table: "ChatConversations");

            migrationBuilder.DropForeignKey(
                name: "FK_UserRoles_DirectoryEntries_DirectoryEntryId",
                table: "UserRoles");

            migrationBuilder.RenameColumn(
                name: "DirectoryEntryId",
                table: "UserRoles",
                newName: "ObjectId");

            migrationBuilder.RenameIndex(
                name: "IX_UserRoles_EntityId_DirectoryEntryId_EntityType_IsGroup",
                table: "UserRoles",
                newName: "IX_UserRoles_EntityId_ObjectId_EntityType_IsGroup");

            migrationBuilder.RenameIndex(
                name: "IX_UserRoles_DirectoryEntryId",
                table: "UserRoles",
                newName: "IX_UserRoles_ObjectId");

            migrationBuilder.RenameColumn(
                name: "DirectoryEntryId",
                table: "ChatConversations",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_ChatConversations_DirectoryEntryId",
                table: "ChatConversations",
                newName: "IX_ChatConversations_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_UserId",
                table: "ChatConversations",
                column: "UserId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserRoles_DirectoryEntries_ObjectId",
                table: "UserRoles",
                column: "ObjectId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
