﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class User_UserRole_FK : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_UserRoles_ObjectId",
                table: "UserRoles",
                column: "ObjectId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserRoles_DirectoryEntries_ObjectId",
                table: "UserRoles",
                column: "ObjectId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserRoles_DirectoryEntries_ObjectId",
                table: "UserRoles");

            migrationBuilder.DropIndex(
                name: "IX_UserRoles_ObjectId",
                table: "UserRoles");
        }
    }
}
