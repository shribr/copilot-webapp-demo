﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class Updates_AppRegistration_RouteNameOwners : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Owner",
                table: "AppRegistrations");

            migrationBuilder.AddColumn<string>(
                name: "RouteName",
                table: "AppRegistrations",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "changeme");

            migrationBuilder.CreateTable(
                name: "AppRegistrationDirectoryEntry",
                columns: table => new
                {
                    AppRegistrationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    OwnerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppRegistrationDirectoryEntry", x => new { x.AppRegistrationId, x.OwnerId });
                    table.ForeignKey(
                        name: "FK_AppRegistrationDirectoryEntry_AppRegistrations_AppRegistrationId",
                        column: x => x.AppRegistrationId,
                        principalTable: "AppRegistrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AppRegistrationDirectoryEntry_DirectoryEntries_OwnerId",
                        column: x => x.OwnerId,
                        principalTable: "DirectoryEntries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppRegistrations_RouteName",
                table: "AppRegistrations",
                column: "RouteName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AppRegistrationDirectoryEntry_OwnerId",
                table: "AppRegistrationDirectoryEntry",
                column: "OwnerId");

            migrationBuilder.Sql(@"DECLARE @id uniqueidentifier, @related_id uniqueidentifier

DECLARE row_cursor CURSOR FOR
SELECT Id FROM AppRegistrations

OPEN row_cursor

FETCH NEXT FROM row_cursor INTO @id

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE related_cursor CURSOR FOR
    SELECT DISTINCT DirectoryEntryId FROM UserRoles

    OPEN related_cursor
    
	FETCH NEXT FROM related_cursor INTO @related_id

    WHILE @@FETCH_STATUS = 0
    BEGIN
        INSERT INTO AppRegistrationDirectoryEntry (AppRegistrationId, OwnerId) VALUES (@id, @related_id)

        FETCH NEXT FROM related_cursor INTO @related_id
    END

    CLOSE related_cursor
    DEALLOCATE related_cursor

    FETCH NEXT FROM row_cursor INTO @id
END

CLOSE row_cursor
DEALLOCATE row_cursor
");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppRegistrationDirectoryEntry");

            migrationBuilder.DropIndex(
                name: "IX_AppRegistrations_RouteName",
                table: "AppRegistrations");

            migrationBuilder.DropColumn(
                name: "RouteName",
                table: "AppRegistrations");

            migrationBuilder.AddColumn<string>(
                name: "Owner",
                table: "AppRegistrations",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
