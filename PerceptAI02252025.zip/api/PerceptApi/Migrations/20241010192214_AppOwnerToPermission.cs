﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class AppOwnerToPermission : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var dataMigration = File.ReadAllText(Path.Join("Migrations", "Queries", "MigrateAppOwnerToPermission.sql"));
            migrationBuilder.Sql(dataMigration);

            migrationBuilder.DropTable(
                name: "AppRegistrationDirectoryEntry");

            migrationBuilder.AddColumn<Guid>(
                name: "ApplicationId",
                table: "UserRoles",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("2276A639-CDBF-4649-BEE9-AC2886043765"));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "UserRoles");

            migrationBuilder.CreateTable(
                name: "AppRegistrationDirectoryEntry",
                columns: table => new
                {
                    AppRegistrationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    OwnerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppRegistrationDirectoryEntry", x => new { x.AppRegistrationId, x.OwnerId });
                    table.ForeignKey(
                        name: "FK_AppRegistrationDirectoryEntry_AppRegistrations_AppRegistrationId",
                        column: x => x.AppRegistrationId,
                        principalTable: "AppRegistrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AppRegistrationDirectoryEntry_DirectoryEntries_OwnerId",
                        column: x => x.OwnerId,
                        principalTable: "DirectoryEntries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppRegistrationDirectoryEntry_OwnerId",
                table: "AppRegistrationDirectoryEntry",
                column: "OwnerId");
        }
    }
}
