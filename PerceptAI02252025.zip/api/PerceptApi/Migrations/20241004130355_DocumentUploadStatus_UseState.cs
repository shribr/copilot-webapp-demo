﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class DocumentUploadStatus_UseState : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsCompleted",
                table: "DocumentUploadStatus");

            migrationBuilder.DropColumn(
                name: "IsError",
                table: "DocumentUploadStatus");

            migrationBuilder.AddColumn<int>(
                name: "State",
                table: "DocumentUploadStatus",
                type: "int",
                nullable: false,
                defaultValue: 2);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "State",
                table: "DocumentUploadStatus");

            migrationBuilder.AddColumn<bool>(
                name: "IsCompleted",
                table: "DocumentUploadStatus",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsError",
                table: "DocumentUploadStatus",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
