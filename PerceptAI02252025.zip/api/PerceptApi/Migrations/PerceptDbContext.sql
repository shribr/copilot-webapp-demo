﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240410202908_InitialCreate'
)
BEGIN
    CREATE TABLE [Feedbacks] (
        [Id] uniqueidentifier NOT NULL,
        [DateTime] datetime2 NOT NULL,
        [UserName] nvarchar(max) NOT NULL,
        [Response] nvarchar(max) NOT NULL,
        [Question] nvarchar(max) NOT NULL,
        [Reaction] int NOT NULL,
        [Comment] nvarchar(max) NULL,
        CONSTRAINT [PK_Feedbacks] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240410202908_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240410202908_InitialCreate', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515145502_MemoryStore'
)
BEGIN
    CREATE TABLE [MemoryStores] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(max) NOT NULL,
        [Description] nvarchar(max) NULL,
        [RouteName] nvarchar(max) NULL,
        [Categories] nvarchar(max) NULL,
        CONSTRAINT [PK_MemoryStores] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515145502_MemoryStore'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240515145502_MemoryStore', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515201150_Improved_MemoryStore'
)
BEGIN
    DECLARE @var sysname;
    SELECT @var = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[MemoryStores]') AND [c].[name] = N'Name');
    IF @var IS NOT NULL EXEC(N'ALTER TABLE [MemoryStores] DROP CONSTRAINT [' + @var + '];');
    ALTER TABLE [MemoryStores] ALTER COLUMN [Name] nvarchar(450) NOT NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515201150_Improved_MemoryStore'
)
BEGIN
    ALTER TABLE [MemoryStores] ADD [CreatedBy] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515201150_Improved_MemoryStore'
)
BEGIN
    ALTER TABLE [MemoryStores] ADD [CreatedOn] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515201150_Improved_MemoryStore'
)
BEGIN
    CREATE UNIQUE INDEX [IX_MemoryStores_Name] ON [MemoryStores] ([Name]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515201150_Improved_MemoryStore'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240515201150_Improved_MemoryStore', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515210317_AuditableEntities'
)
BEGIN
    EXEC sp_rename N'[Feedbacks].[UserName]', N'CreatedBy', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515210317_AuditableEntities'
)
BEGIN
    EXEC sp_rename N'[Feedbacks].[DateTime]', N'CreatedOn', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240515210317_AuditableEntities'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240515210317_AuditableEntities', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240516223522_Users'
)
BEGIN
    CREATE TABLE [Users] (
        [Id] uniqueidentifier NOT NULL,
        [DisplayName] nvarchar(max) NOT NULL,
        [Email] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_Users] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240516223522_Users'
)
BEGIN
    CREATE TABLE [MemoryStoreUser] (
        [DataManagersId] uniqueidentifier NOT NULL,
        [MemoryStoresId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_MemoryStoreUser] PRIMARY KEY ([DataManagersId], [MemoryStoresId]),
        CONSTRAINT [FK_MemoryStoreUser_MemoryStores_MemoryStoresId] FOREIGN KEY ([MemoryStoresId]) REFERENCES [MemoryStores] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_MemoryStoreUser_Users_DataManagersId] FOREIGN KEY ([DataManagersId]) REFERENCES [Users] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240516223522_Users'
)
BEGIN
    CREATE INDEX [IX_MemoryStoreUser_MemoryStoresId] ON [MemoryStoreUser] ([MemoryStoresId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240516223522_Users'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240516223522_Users', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240520185710_MemoryStore_RouteName_Unique'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[MemoryStores]') AND [c].[name] = N'RouteName');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [MemoryStores] DROP CONSTRAINT [' + @var1 + '];');
    EXEC(N'UPDATE [MemoryStores] SET [RouteName] = N'''' WHERE [RouteName] IS NULL');
    ALTER TABLE [MemoryStores] ALTER COLUMN [RouteName] nvarchar(450) NOT NULL;
    ALTER TABLE [MemoryStores] ADD DEFAULT N'' FOR [RouteName];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240520185710_MemoryStore_RouteName_Unique'
)
BEGIN
    CREATE UNIQUE INDEX [IX_MemoryStores_RouteName] ON [MemoryStores] ([RouteName]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240520185710_MemoryStore_RouteName_Unique'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240520185710_MemoryStore_RouteName_Unique', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240523021425_Categories'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[MemoryStores]') AND [c].[name] = N'Categories');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [MemoryStores] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [MemoryStores] DROP COLUMN [Categories];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240523021425_Categories'
)
BEGIN
    CREATE TABLE [Categories] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(450) NOT NULL,
        [MemoryStoreId] uniqueidentifier NOT NULL,
        [CreatedBy] nvarchar(max) NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        CONSTRAINT [PK_Categories] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Categories_MemoryStores_MemoryStoreId] FOREIGN KEY ([MemoryStoreId]) REFERENCES [MemoryStores] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240523021425_Categories'
)
BEGIN
    CREATE INDEX [IX_Categories_MemoryStoreId] ON [Categories] ([MemoryStoreId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240523021425_Categories'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Categories_Name] ON [Categories] ([Name]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240523021425_Categories'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240523021425_Categories', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240529141306_Remove-MemoryStore-RouteName'
)
BEGIN
    DROP INDEX [IX_MemoryStores_RouteName] ON [MemoryStores];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240529141306_Remove-MemoryStore-RouteName'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[MemoryStores]') AND [c].[name] = N'RouteName');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [MemoryStores] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [MemoryStores] DROP COLUMN [RouteName];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240529141306_Remove-MemoryStore-RouteName'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240529141306_Remove-MemoryStore-RouteName', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240531200646_Chat_Conversations'
)
BEGIN
    CREATE TABLE [ChatConversations] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(max) NOT NULL,
        [ChatHistoryJson] nvarchar(max) NOT NULL,
        [UserId] uniqueidentifier NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        CONSTRAINT [PK_ChatConversations] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_ChatConversations_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240531200646_Chat_Conversations'
)
BEGIN
    CREATE TABLE [ChatMessages] (
        [Id] uniqueidentifier NOT NULL,
        [OriginalQuestion] nvarchar(max) NOT NULL,
        [MemoryAnswerJson] nvarchar(max) NOT NULL,
        [ChatConversationId] uniqueidentifier NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        CONSTRAINT [PK_ChatMessages] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_ChatMessages_ChatConversations_ChatConversationId] FOREIGN KEY ([ChatConversationId]) REFERENCES [ChatConversations] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240531200646_Chat_Conversations'
)
BEGIN
    CREATE INDEX [IX_ChatConversations_UserId] ON [ChatConversations] ([UserId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240531200646_Chat_Conversations'
)
BEGIN
    CREATE INDEX [IX_ChatMessages_ChatConversationId] ON [ChatMessages] ([ChatConversationId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240531200646_Chat_Conversations'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240531200646_Chat_Conversations', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240730134509_CategoriesUpdate'
)
BEGIN
    DROP INDEX [IX_Categories_Name] ON [Categories];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240730134509_CategoriesUpdate'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Categories_Name_MemoryStoreId] ON [Categories] ([Name], [MemoryStoreId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240730134509_CategoriesUpdate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240730134509_CategoriesUpdate', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240806211832_Prompts'
)
BEGIN
    ALTER TABLE [MemoryStores] ADD [PromptId] uniqueidentifier NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240806211832_Prompts'
)
BEGIN
    CREATE TABLE [Prompts] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(max) NOT NULL,
        [Description] nvarchar(max) NULL,
        [Text] nvarchar(max) NOT NULL,
        [CreatedBy] nvarchar(max) NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        [ModifiedBy] nvarchar(max) NULL,
        [ModifiedOn] datetime2 NULL,
        CONSTRAINT [PK_Prompts] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240806211832_Prompts'
)
BEGIN
    CREATE INDEX [IX_MemoryStores_PromptId] ON [MemoryStores] ([PromptId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240806211832_Prompts'
)
BEGIN
    ALTER TABLE [MemoryStores] ADD CONSTRAINT [FK_MemoryStores_Prompts_PromptId] FOREIGN KEY ([PromptId]) REFERENCES [Prompts] ([Id]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240806211832_Prompts'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240806211832_Prompts', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240808175845_Save_Prompt_with_ChatMessage'
)
BEGIN
    ALTER TABLE [ChatMessages] ADD [Prompt] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240808175845_Save_Prompt_with_ChatMessage'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240808175845_Save_Prompt_with_ChatMessage', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240812152612_Add_UserRole'
)
BEGIN
    CREATE TABLE [UserRoles] (
        [Id] uniqueidentifier NOT NULL,
        [ObjectId] uniqueidentifier NOT NULL,
        [IsGroup] bit NOT NULL,
        [EntityId] uniqueidentifier NOT NULL,
        [EntityType] int NOT NULL,
        [Permission] int NOT NULL,
        CONSTRAINT [PK_UserRoles] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240812152612_Add_UserRole'
)
BEGIN
    CREATE UNIQUE INDEX [IX_UserRoles_EntityId_ObjectId_EntityType_IsGroup] ON [UserRoles] ([EntityId], [ObjectId], [EntityType], [IsGroup]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240812152612_Add_UserRole'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240812152612_Add_UserRole', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240816200257_MemoryStoreCache'
)
BEGIN
    CREATE TABLE [MemoryStoresCache] (
        [Id] nvarchar(449) NOT NULL,
        [Value] varbinary(max) NOT NULL,
        [ExpiresAtTime] datetimeoffset NOT NULL,
        [SlidingExpirationInSeconds] bigint NULL,
        [AbsoluteExpiration] datetimeoffset NULL,
        CONSTRAINT [PK_MemoryStoresCache] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240816200257_MemoryStoreCache'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240816200257_MemoryStoreCache', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240822130617_UpdateConversationModel'
)
BEGIN
    EXEC sp_rename N'[ChatMessages].[MemoryAnswerJson]', N'SystemAnswerJson', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240822130617_UpdateConversationModel'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240822130617_UpdateConversationModel', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240822221045_InitialAppRegistration'
)
BEGIN
    CREATE TABLE [AppRegistrations] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(max) NOT NULL,
        [Description] nvarchar(max) NOT NULL,
        [Owner] nvarchar(max) NOT NULL,
        [Organization] nvarchar(max) NOT NULL,
        [CreatedBy] nvarchar(max) NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        [ModifiedBy] nvarchar(max) NULL,
        [ModifiedOn] datetime2 NULL,
        CONSTRAINT [PK_AppRegistrations] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240822221045_InitialAppRegistration'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240822221045_InitialAppRegistration', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [ChatConversations] DROP CONSTRAINT [FK_ChatConversations_Users_UserId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [MemoryStoreUser] DROP CONSTRAINT [FK_MemoryStoreUser_Users_DataManagersId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [Users] DROP CONSTRAINT [PK_Users];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    EXEC sp_rename N'[Users]', N'DirectoryEntries', 'OBJECT';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[DirectoryEntries]') AND [c].[name] = N'Email');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [DirectoryEntries] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [DirectoryEntries] ALTER COLUMN [Email] nvarchar(max) NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [DirectoryEntries] ADD [IsGroup] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [DirectoryEntries] ADD [ObjectId] uniqueidentifier NOT NULL DEFAULT '00000000-0000-0000-0000-000000000000';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    UPDATE DirectoryEntries SET ObjectId = Id
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [DirectoryEntries] ADD CONSTRAINT [PK_DirectoryEntries] PRIMARY KEY ([Id]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD CONSTRAINT [FK_ChatConversations_DirectoryEntries_UserId] FOREIGN KEY ([UserId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    ALTER TABLE [MemoryStoreUser] ADD CONSTRAINT [FK_MemoryStoreUser_DirectoryEntries_DataManagersId] FOREIGN KEY ([DataManagersId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240823211942_ExtendUserEntityToSupportGroups'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240823211942_ExtendUserEntityToSupportGroups', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826163502_User_UserRole_FK'
)
BEGIN
    CREATE INDEX [IX_UserRoles_ObjectId] ON [UserRoles] ([ObjectId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826163502_User_UserRole_FK'
)
BEGIN
    ALTER TABLE [UserRoles] ADD CONSTRAINT [FK_UserRoles_DirectoryEntries_ObjectId] FOREIGN KEY ([ObjectId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826163502_User_UserRole_FK'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240826163502_User_UserRole_FK', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    ALTER TABLE [ChatConversations] DROP CONSTRAINT [FK_ChatConversations_DirectoryEntries_UserId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    ALTER TABLE [UserRoles] DROP CONSTRAINT [FK_UserRoles_DirectoryEntries_ObjectId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    EXEC sp_rename N'[UserRoles].[ObjectId]', N'DirectoryEntryId', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    EXEC sp_rename N'[UserRoles].[IX_UserRoles_ObjectId]', N'IX_UserRoles_DirectoryEntryId', 'INDEX';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    EXEC sp_rename N'[UserRoles].[IX_UserRoles_EntityId_ObjectId_EntityType_IsGroup]', N'IX_UserRoles_EntityId_DirectoryEntryId_EntityType_IsGroup', 'INDEX';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    EXEC sp_rename N'[ChatConversations].[UserId]', N'DirectoryEntryId', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    EXEC sp_rename N'[ChatConversations].[IX_ChatConversations_UserId]', N'IX_ChatConversations_DirectoryEntryId', 'INDEX';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD CONSTRAINT [FK_ChatConversations_DirectoryEntries_DirectoryEntryId] FOREIGN KEY ([DirectoryEntryId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    ALTER TABLE [UserRoles] ADD CONSTRAINT [FK_UserRoles_DirectoryEntries_DirectoryEntryId] FOREIGN KEY ([DirectoryEntryId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240826182530_Rename_User_DirectoryEntry'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240826182530_Rename_User_DirectoryEntry', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828135052_RemoveDataManagers-FromMemoryStore'
)
BEGIN
    INSERT INTO UserRoles (ID, DirectoryEntryId, EntityId, IsGroup, EntityType, Permission) SELECT NEWID(), DataManagersId, MemoryStoresId, 0, 0, 2 FROM MemoryStoreUser
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828135052_RemoveDataManagers-FromMemoryStore'
)
BEGIN
    DROP TABLE [MemoryStoreUser];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828135052_RemoveDataManagers-FromMemoryStore'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240828135052_RemoveDataManagers-FromMemoryStore', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828170022_AgentConfiguration'
)
BEGIN
    CREATE TABLE [Agents] (
        [Id] uniqueidentifier NOT NULL,
        [ApplicationId] uniqueidentifier NOT NULL,
        [Name] nvarchar(max) NOT NULL,
        [Configuration] nvarchar(max) NOT NULL,
        [CreatedBy] nvarchar(max) NOT NULL,
        [CreatedOn] datetime2 NOT NULL,
        [ModifiedBy] nvarchar(max) NULL,
        [ModifiedOn] datetime2 NULL,
        CONSTRAINT [PK_Agents] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Agents_AppRegistrations_ApplicationId] FOREIGN KEY ([ApplicationId]) REFERENCES [AppRegistrations] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828170022_AgentConfiguration'
)
BEGIN
    CREATE INDEX [IX_Agents_ApplicationId] ON [Agents] ([ApplicationId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240828170022_AgentConfiguration'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240828170022_AgentConfiguration', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240829135634_ChatMessageModel'
)
BEGIN
    ALTER TABLE [ChatMessages] ADD [Model] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240829135634_ChatMessageModel'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240829135634_ChatMessageModel', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    TRUNCATE TABLE [ChatMessages]
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    DELETE FROM [ChatConversations]
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD [AgentId] uniqueidentifier NOT NULL DEFAULT '00000000-0000-0000-0000-000000000000';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    CREATE INDEX [IX_ChatConversations_AgentId] ON [ChatConversations] ([AgentId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD CONSTRAINT [FK_ChatConversations_Agents_AgentId] FOREIGN KEY ([AgentId]) REFERENCES [Agents] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240905151354_Conversation_Determines_Agent'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240905151354_Conversation_Determines_Agent', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240906194907_Add_Citations_ChatConversation'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD [Citations] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240906194907_Add_Citations_ChatConversation'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240906194907_Add_Citations_ChatConversation', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910161757_UpdateChatHistory'
)
BEGIN
    EXEC sp_rename N'[ChatConversations].[ChatHistoryJson]', N'ChatHistory', 'COLUMN';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910161757_UpdateChatHistory'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240910161757_UpdateChatHistory', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910214530_Remove-ChatMessages'
)
BEGIN
    DROP TABLE [ChatMessages];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910214530_Remove-ChatMessages'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240910214530_Remove-ChatMessages', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910224733_AgentType'
)
BEGIN
    ALTER TABLE [Agents] ADD [TypeId] uniqueidentifier NOT NULL DEFAULT '6d6587f6-1815-4e06-b72b-21bda15c714b';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910224733_AgentType'
)
BEGIN
    DELETE FROM Agents

    INSERT INTO Agents (ID, ApplicationId, [Name], Configuration, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn, TypeId)
    SELECT 
        ID,
        '2276a639-cdbf-4649-bee9-ac2886043765',
        [Name],
        CONCAT(
            '{',
            '"28e42582-dfce-45f3-8d37-d6e88235c060": {',
                '"IndexName": "', [Name], '",',
                '"ModelDeploymentName": "gpt4o"',
            '},',
            '"6D6587F6-1815-4E06-B72B-21BDA15C714B": {',
                '"Instructions": "I Always want you to search kernel memory to find facts to answer the users question even if you think you know the answer.",',
                '"PluginsUsed": ["28e42582-dfce-45f3-8d37-d6e88235c060"],',
                '"MaxConversations": 30,',
                '"MemoryStoreId": "', ID, '"',
            '}',
            '}'
        ) AS Configuration,
        'SYSTEM MIGRATION',
        GetDate(),
        'SYSTEM MIGRATION',
        GetDate(),
        '6D6587F6-1815-4E06-B72B-21BDA15C714B'
    FROM MemoryStores;


END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240910224733_AgentType'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240910224733_AgentType', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240912134633_Conversation_SoftDelete'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD [SoftDelete] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240912134633_Conversation_SoftDelete'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240912134633_Conversation_SoftDelete', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240916230306_MoveCategoriesToAgentConfiguration'
)
BEGIN
    UPDATE Agents
    SET Configuration = 
        CONCAT(
            '{',
            '"28e42582-dfce-45f3-8d37-d6e88235c060": {',
                '"IndexName": "', a.[Name], '",',
                '"ModelDeploymentName": "gpt4o"',
            '},',
            '"6d6587f6-1815-4e06-b72b-21bda15c714b": {',
                '"Instructions": "I Always want you to search kernel memory to find facts to answer the users question even if you think you know the answer.",',
                '"PluginsUsed": ["28e42582-dfce-45f3-8d37-d6e88235c060"],',
                '"MaxConversations": 30,',
                '"MemoryStoreId": "', ms.Id, '",',
                '"Categories": [', 
                 (SELECT STRING_AGG('"' + [Name] + '"', ',') 
                     FROM Categories c
                     WHERE c.MemoryStoreId = ms.Id), ']',
            '}',
            '}'
        )
    FROM Agents a left join MemoryStores ms on a.[Name] = ms.[Name]


END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240916230306_MoveCategoriesToAgentConfiguration'
)
BEGIN
    DROP TABLE [Categories];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240916230306_MoveCategoriesToAgentConfiguration'
)
BEGIN
    ALTER TABLE [Agents] ADD [Description] nvarchar(max) NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240916230306_MoveCategoriesToAgentConfiguration'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240916230306_MoveCategoriesToAgentConfiguration', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[AppRegistrations]') AND [c].[name] = N'Owner');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [AppRegistrations] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [AppRegistrations] DROP COLUMN [Owner];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    ALTER TABLE [AppRegistrations] ADD [RouteName] nvarchar(450) NOT NULL DEFAULT N'changeme';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    CREATE TABLE [AppRegistrationDirectoryEntry] (
        [AppRegistrationId] uniqueidentifier NOT NULL,
        [OwnerId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_AppRegistrationDirectoryEntry] PRIMARY KEY ([AppRegistrationId], [OwnerId]),
        CONSTRAINT [FK_AppRegistrationDirectoryEntry_AppRegistrations_AppRegistrationId] FOREIGN KEY ([AppRegistrationId]) REFERENCES [AppRegistrations] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_AppRegistrationDirectoryEntry_DirectoryEntries_OwnerId] FOREIGN KEY ([OwnerId]) REFERENCES [DirectoryEntries] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    CREATE UNIQUE INDEX [IX_AppRegistrations_RouteName] ON [AppRegistrations] ([RouteName]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    CREATE INDEX [IX_AppRegistrationDirectoryEntry_OwnerId] ON [AppRegistrationDirectoryEntry] ([OwnerId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    DECLARE @id uniqueidentifier, @related_id uniqueidentifier

    DECLARE row_cursor CURSOR FOR
    SELECT Id FROM AppRegistrations

    OPEN row_cursor

    FETCH NEXT FROM row_cursor INTO @id

    WHILE @@FETCH_STATUS = 0
    BEGIN
    	DECLARE related_cursor CURSOR FOR
        SELECT DISTINCT DirectoryEntryId FROM UserRoles

        OPEN related_cursor
        
    	FETCH NEXT FROM related_cursor INTO @related_id

        WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO AppRegistrationDirectoryEntry (AppRegistrationId, OwnerId) VALUES (@id, @related_id)

            FETCH NEXT FROM related_cursor INTO @related_id
        END

        CLOSE related_cursor
        DEALLOCATE related_cursor

        FETCH NEXT FROM row_cursor INTO @id
    END

    CLOSE row_cursor
    DEALLOCATE row_cursor

END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240917170954_Updates_AppRegistration_RouteNameOwners'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240917170954_Updates_AppRegistration_RouteNameOwners', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918132506_DocumentUploadStatus'
)
BEGIN
    CREATE TABLE [DocumentUploadStatus] (
        [Id] uniqueidentifier NOT NULL,
        [DocumentId] nvarchar(max) NOT NULL,
        [FileName] nvarchar(max) NOT NULL,
        [IsCompleted] bit NOT NULL,
        [LastUpdated] datetimeoffset NOT NULL,
        [CompletedSteps] nvarchar(max) NOT NULL,
        [RemainingSteps] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_DocumentUploadStatus] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918132506_DocumentUploadStatus'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240918132506_DocumentUploadStatus', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918194217_DocumentUploadSatus_Index'
)
BEGIN
    ALTER TABLE [DocumentUploadStatus] ADD [Index] nvarchar(max) NOT NULL DEFAULT N'default';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918194217_DocumentUploadSatus_Index'
)
BEGIN
    ALTER TABLE [DocumentUploadStatus] ADD [IsError] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918194217_DocumentUploadSatus_Index'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240918194217_DocumentUploadSatus_Index', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918200158_DocumentUploadSatus_ErrorMessage'
)
BEGIN
    ALTER TABLE [DocumentUploadStatus] ADD [ErrorMessage] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240918200158_DocumentUploadSatus_ErrorMessage'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240918200158_DocumentUploadSatus_ErrorMessage', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [ChatConversations] DROP CONSTRAINT [FK_ChatConversations_DirectoryEntries_DirectoryEntryId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [MemoryStores] DROP CONSTRAINT [FK_MemoryStores_Prompts_PromptId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    DROP INDEX [IX_ChatConversations_DirectoryEntryId] ON [ChatConversations];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [MemoryStores] DROP CONSTRAINT [PK_MemoryStores];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    DROP INDEX [IX_MemoryStores_Name] ON [MemoryStores];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    DROP INDEX [IX_MemoryStores_PromptId] ON [MemoryStores];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    DECLARE @var6 sysname;
    SELECT @var6 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[MemoryStores]') AND [c].[name] = N'PromptId');
    IF @var6 IS NOT NULL EXEC(N'ALTER TABLE [MemoryStores] DROP CONSTRAINT [' + @var6 + '];');
    ALTER TABLE [MemoryStores] DROP COLUMN [PromptId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    EXEC sp_rename N'[MemoryStores]', N'DataSources', 'OBJECT';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    DECLARE @var7 sysname;
    SELECT @var7 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[DataSources]') AND [c].[name] = N'Name');
    IF @var7 IS NOT NULL EXEC(N'ALTER TABLE [DataSources] DROP CONSTRAINT [' + @var7 + '];');
    ALTER TABLE [DataSources] ALTER COLUMN [Name] nvarchar(max) NOT NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [DataSources] ADD [ApplicationId] uniqueidentifier NOT NULL DEFAULT '2276a639-cdbf-4649-bee9-ac2886043765';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [DataSources] ADD [Configuration] nvarchar(max) NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [DataSources] ADD [TypeId] uniqueidentifier NOT NULL DEFAULT '10350695-4c07-4e2f-8dc8-cd70acc89941';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [DataSources] ADD CONSTRAINT [PK_DataSources] PRIMARY KEY ([Id]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    CREATE TABLE [AgentDataSource] (
        [Id] uniqueidentifier NOT NULL,
        [AgentId] uniqueidentifier NOT NULL,
        [DataSourceId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_AgentDataSource] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_AgentDataSource_Agents_AgentId] FOREIGN KEY ([AgentId]) REFERENCES [Agents] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_AgentDataSource_DataSources_DataSourceId] FOREIGN KEY ([DataSourceId]) REFERENCES [DataSources] ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    CREATE INDEX [IX_DataSources_ApplicationId] ON [DataSources] ([ApplicationId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    CREATE INDEX [IX_AgentDataSource_AgentId] ON [AgentDataSource] ([AgentId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    CREATE INDEX [IX_AgentDataSource_DataSourceId] ON [AgentDataSource] ([DataSourceId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    ALTER TABLE [DataSources] ADD CONSTRAINT [FK_DataSources_AppRegistrations_ApplicationId] FOREIGN KEY ([ApplicationId]) REFERENCES [AppRegistrations] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240920221426_DataSources'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240920221426_DataSources', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240923171523_PersistQueryContext'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD [AgentQueryContexts] nvarchar(max) NOT NULL DEFAULT N'';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240923171523_PersistQueryContext'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240923171523_PersistQueryContext', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240925225211_CategoriesMoveToDataSource'
)
BEGIN
    DECLARE @var8 sysname;
    SELECT @var8 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[DataSources]') AND [c].[name] = N'TypeId');
    IF @var8 IS NOT NULL EXEC(N'ALTER TABLE [DataSources] DROP CONSTRAINT [' + @var8 + '];');
    ALTER TABLE [DataSources] DROP COLUMN [TypeId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240925225211_CategoriesMoveToDataSource'
)
BEGIN
    ALTER TABLE [DataSources] ADD [Type] int NOT NULL DEFAULT 0;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240925225211_CategoriesMoveToDataSource'
)
BEGIN
    UPDATE DataSources 
    SET [Configuration] =
    (SELECT '{"$type":"KernelMemoryDataSourceConfiguration","Categories":' +

    (SELECT 
    	JSON_QUERY([Configuration], '$."6d6587f6-1815-4e06-b72b-21bda15c714b".Categories') AS Categories
    FROM Agents 
    WHERE CONVERT(uniqueidentifier, JSON_VALUE([Configuration], '$."6d6587f6-1815-4e06-b72b-21bda15c714b".MemoryStoreId')) = ds.Id)
    + ',"IndexName":"'+ds.[Name]+'"}')

    FROM DataSources ds

    UPDATE DataSources
    SET [Type] = 1 --SQL
    WHERE JSON_QUERY([Configuration], '$."Categories"') is null
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20240925225211_CategoriesMoveToDataSource'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240925225211_CategoriesMoveToDataSource', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241002161353_SystemAgent_Refactor'
)
BEGIN
    UPDATE [dbo].[Agents] SET [Configuration] = '{}'
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241002161353_SystemAgent_Refactor'
)
BEGIN
    ALTER TABLE [AgentDataSource] ADD [PluginId] uniqueidentifier NOT NULL DEFAULT '28e42582-dfce-45f3-8d37-d6e88235c060';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241002161353_SystemAgent_Refactor'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241002161353_SystemAgent_Refactor', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241004130355_DocumentUploadStatus_UseState'
)
BEGIN
    DECLARE @var9 sysname;
    SELECT @var9 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[DocumentUploadStatus]') AND [c].[name] = N'IsCompleted');
    IF @var9 IS NOT NULL EXEC(N'ALTER TABLE [DocumentUploadStatus] DROP CONSTRAINT [' + @var9 + '];');
    ALTER TABLE [DocumentUploadStatus] DROP COLUMN [IsCompleted];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241004130355_DocumentUploadStatus_UseState'
)
BEGIN
    DECLARE @var10 sysname;
    SELECT @var10 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[DocumentUploadStatus]') AND [c].[name] = N'IsError');
    IF @var10 IS NOT NULL EXEC(N'ALTER TABLE [DocumentUploadStatus] DROP CONSTRAINT [' + @var10 + '];');
    ALTER TABLE [DocumentUploadStatus] DROP COLUMN [IsError];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241004130355_DocumentUploadStatus_UseState'
)
BEGIN
    ALTER TABLE [DocumentUploadStatus] ADD [State] int NOT NULL DEFAULT 2;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241004130355_DocumentUploadStatus_UseState'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241004130355_DocumentUploadStatus_UseState', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010113143_RemoveAgentTypeId'
)
BEGIN
    DECLARE @var11 sysname;
    SELECT @var11 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Agents]') AND [c].[name] = N'TypeId');
    IF @var11 IS NOT NULL EXEC(N'ALTER TABLE [Agents] DROP CONSTRAINT [' + @var11 + '];');
    ALTER TABLE [Agents] DROP COLUMN [TypeId];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010113143_RemoveAgentTypeId'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241010113143_RemoveAgentTypeId', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010192214_AppOwnerToPermission'
)
BEGIN
    INSERT INTO UserRoles
    SELECT 
    	Id = newid(),	
    	DirectoryEntryId = OwnerId,
    	IsGroup = (select IsGroup from DirectoryEntries where ID=OwnerId),
    	EntityId = AppRegistrationId,
    	EntityType = 2, --AppRegistration
    	Permission = 2 -- Owner

    FROM AppRegistrationDirectoryEntry
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010192214_AppOwnerToPermission'
)
BEGIN
    DROP TABLE [AppRegistrationDirectoryEntry];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010192214_AppOwnerToPermission'
)
BEGIN
    ALTER TABLE [UserRoles] ADD [ApplicationId] uniqueidentifier NOT NULL DEFAULT '2276a639-cdbf-4649-bee9-ac2886043765';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241010192214_AppOwnerToPermission'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241010192214_AppOwnerToPermission', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016141233_DataSource_IsLegacy'
)
BEGIN
    ALTER TABLE [DataSources] ADD [IsLegacy] bit NOT NULL DEFAULT CAST(1 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016141233_DataSource_IsLegacy'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241016141233_DataSource_IsLegacy', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016204123_FeedbackByApp'
)
BEGIN
    ALTER TABLE [Feedbacks] ADD [ApplicationId] uniqueidentifier NOT NULL DEFAULT '2276a639-cdbf-4649-bee9-ac2886043765';
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016204123_FeedbackByApp'
)
BEGIN
    CREATE INDEX [IX_Feedbacks_ApplicationId] ON [Feedbacks] ([ApplicationId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016204123_FeedbackByApp'
)
BEGIN
    ALTER TABLE [Feedbacks] ADD CONSTRAINT [FK_Feedbacks_AppRegistrations_ApplicationId] FOREIGN KEY ([ApplicationId]) REFERENCES [AppRegistrations] ([Id]) ON DELETE CASCADE;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241016204123_FeedbackByApp'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241016204123_FeedbackByApp', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241031133749_Remove-Prompt'
)
BEGIN
    DROP TABLE [Prompts];
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241031133749_Remove-Prompt'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241031133749_Remove-Prompt', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241105174905_AppRegistration_Archive_Disabled'
)
BEGIN
    ALTER TABLE [AppRegistrations] ADD [IsArchived] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241105174905_AppRegistration_Archive_Disabled'
)
BEGIN
    ALTER TABLE [AppRegistrations] ADD [IsDisabled] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241105174905_AppRegistration_Archive_Disabled'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241105174905_AppRegistration_Archive_Disabled', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241119151403_Agent_Disable_Archive'
)
BEGIN
    ALTER TABLE [Agents] ADD [IsArchived] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241119151403_Agent_Disable_Archive'
)
BEGIN
    ALTER TABLE [Agents] ADD [IsDisabled] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241119151403_Agent_Disable_Archive'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241119151403_Agent_Disable_Archive', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241120232043_ArchiveDocStatus'
)
BEGIN
    ALTER TABLE [DocumentUploadStatus] ADD [isArchived] bit NOT NULL DEFAULT CAST(0 AS bit);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241120232043_ArchiveDocStatus'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241120232043_ArchiveDocStatus', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250110170541_Classifications'
)
BEGIN
    CREATE TABLE [ClassificationControls] (
        [Id] nvarchar(450) NOT NULL,
        [ParentControl] nvarchar(max) NULL,
        [ParentValues] nvarchar(max) NULL,
        [Label] nvarchar(max) NOT NULL,
        [HelperText] nvarchar(max) NULL,
        [AllowMultiple] bit NOT NULL,
        [Required] bit NOT NULL,
        CONSTRAINT [PK_ClassificationControls] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250110170541_Classifications'
)
BEGIN
    CREATE TABLE [ClassificationValueOptions] (
        [Id] int NOT NULL IDENTITY,
        [GroupName] nvarchar(max) NULL,
        [ControlId] nvarchar(max) NOT NULL,
        [Value] nvarchar(max) NOT NULL,
        [Label] nvarchar(max) NOT NULL,
        [HelperText] nvarchar(max) NULL,
        [MarkingColor] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_ClassificationValueOptions] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250110170541_Classifications'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250110170541_Classifications', N'9.0.1');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250213004852_ChatConversation_Prompt'
)
BEGIN
    ALTER TABLE [ChatConversations] ADD [Prompts] nvarchar(max) NULL;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20250213004852_ChatConversation_Prompt'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20250213004852_ChatConversation_Prompt', N'9.0.1');
END;

COMMIT;
GO

