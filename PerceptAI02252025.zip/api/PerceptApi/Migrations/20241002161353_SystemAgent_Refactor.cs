﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class SystemAgent_Refactor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("UPDATE [dbo].[Agents] SET [Configuration] = '{}'");

            migrationBuilder.AddColumn<Guid>(
                name: "PluginId",
                table: "AgentDataSource",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("28e42582-dfce-45f3-8d37-d6e88235c060"));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PluginId",
                table: "AgentDataSource");
        }
    }
}
