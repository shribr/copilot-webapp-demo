﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class Conversation_Determines_Agent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("TRUNCATE TABLE [ChatMessages]");
            migrationBuilder.Sql("DELETE FROM [ChatConversations]");
            migrationBuilder.AddColumn<Guid>(
                name: "AgentId",
                table: "ChatConversations",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.CreateIndex(
                name: "IX_ChatConversations_AgentId",
                table: "ChatConversations",
                column: "AgentId");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_Agents_AgentId",
                table: "ChatConversations",
                column: "AgentId",
                principalTable: "Agents",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_Agents_AgentId",
                table: "ChatConversations");

            migrationBuilder.DropIndex(
                name: "IX_ChatConversations_AgentId",
                table: "ChatConversations");

            migrationBuilder.DropColumn(
                name: "AgentId",
                table: "ChatConversations");
        }
    }
}
