﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class CategoriesMoveToDataSource : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "DataSources");

            migrationBuilder.AddColumn<int>(
                name: "Type",
                table: "DataSources",
                type: "int",
                nullable: false,
                defaultValue: 0);

            var dataMigration = File.ReadAllText(Path.Join("Migrations", "Queries", "MigrateCategoriesToDataSource.sql"));
            migrationBuilder.Sql(dataMigration);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Type",
                table: "DataSources");

            migrationBuilder.AddColumn<Guid>(
                name: "TypeId",
                table: "DataSources",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }
    }
}
