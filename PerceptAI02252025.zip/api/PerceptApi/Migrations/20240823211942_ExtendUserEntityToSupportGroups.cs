﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class ExtendUserEntityToSupportGroups : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_Users_UserId",
                table: "ChatConversations");

            migrationBuilder.DropForeignKey(
                name: "FK_MemoryStoreUser_Users_DataManagersId",
                table: "MemoryStoreUser");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Users",
                table: "Users");

            migrationBuilder.RenameTable(
                name: "Users",
                newName: "DirectoryEntries");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "DirectoryEntries",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<bool>(
                name: "IsGroup",
                table: "DirectoryEntries",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<Guid>(
                name: "ObjectId",
                table: "DirectoryEntries",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.Sql("UPDATE DirectoryEntries SET ObjectId = Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_DirectoryEntries",
                table: "DirectoryEntries",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_UserId",
                table: "ChatConversations",
                column: "UserId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MemoryStoreUser_DirectoryEntries_DataManagersId",
                table: "MemoryStoreUser",
                column: "DataManagersId",
                principalTable: "DirectoryEntries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChatConversations_DirectoryEntries_UserId",
                table: "ChatConversations");

            migrationBuilder.DropForeignKey(
                name: "FK_MemoryStoreUser_DirectoryEntries_DataManagersId",
                table: "MemoryStoreUser");

            migrationBuilder.DropPrimaryKey(
                name: "PK_DirectoryEntries",
                table: "DirectoryEntries");

            migrationBuilder.DropColumn(
                name: "IsGroup",
                table: "DirectoryEntries");

            migrationBuilder.DropColumn(
                name: "ObjectId",
                table: "DirectoryEntries");

            migrationBuilder.RenameTable(
                name: "DirectoryEntries",
                newName: "Users");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Users",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Users",
                table: "Users",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatConversations_Users_UserId",
                table: "ChatConversations",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MemoryStoreUser_Users_DataManagersId",
                table: "MemoryStoreUser",
                column: "DataManagersId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
