﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerceptApi.Migrations
{
    /// <inheritdoc />
    public partial class DocumentUploadSatus_Index : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Index",
                table: "DocumentUploadStatus",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "default");

            migrationBuilder.AddColumn<bool>(
                name: "IsError",
                table: "DocumentUploadStatus",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Index",
                table: "DocumentUploadStatus");

            migrationBuilder.DropColumn(
                name: "IsError",
                table: "DocumentUploadStatus");
        }
    }
}
