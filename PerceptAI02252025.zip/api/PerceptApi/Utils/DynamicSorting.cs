﻿using PerceptApi.Constants;
using System.Globalization;
using System.Linq.Expressions;

namespace PerceptApi.Utils
{
    public class DynamicSorting
    {
        public static IQueryable<T> SortByProperty<T>(IQueryable<T> source, string propertyName, string direction)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentException("Property name cannot be null or empty", nameof(propertyName));
            }

            propertyName = char.ToUpper(propertyName[0], CultureInfo.InvariantCulture) + propertyName[1..];
            var param = Expression.Parameter(typeof(T), "x");
            var property = Expression.Property(param, propertyName);
            var selector = Expression.Lambda(property, param);

            var methodName = direction == SortingDirections.Ascending ? "OrderBy" : "OrderByDescending";
            var method = typeof(Queryable).GetMethods()
                .Where(m => m.Name == methodName && m.GetParameters().Length == 2)
                .Single()
                .MakeGenericMethod(typeof(T), property.Type);

            return (IQueryable<T>)method.Invoke(null, new object[] { source, selector });
        }
    }
}
