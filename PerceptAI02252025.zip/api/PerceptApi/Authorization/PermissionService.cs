﻿using ClosedXML.Excel;
using PerceptApi.Constants;
using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using PerceptApi.ErrorHandling;
using PerceptApi.Extensions;
using PerceptApi.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApi.Authorization
{
    public class PermissionService : IPermissionService
    {
        private readonly Guid GlobalAdminGroupId;
        private readonly Guid AppCreatorGroupId;
        private readonly IUserRoleService userRoleService;
        private readonly IDataSourceService dataSourceService;
        private readonly IGraphService graphService;

        public PermissionService(IConfiguration configuration,
                                 IUserRoleService userRoleService,
                                 IDataSourceService dataSourceService,
                                 IGraphService graphService)
        {
            ArgumentNullException.ThrowIfNull(configuration);

            this.userRoleService = userRoleService ?? throw new ArgumentNullException(nameof(userRoleService));
            this.dataSourceService = dataSourceService ?? throw new ArgumentNullException(nameof(dataSourceService));
            this.graphService = graphService ?? throw new ArgumentNullException(nameof(graphService));
            GlobalAdminGroupId = configuration.GetValue(RBACProperties.GlobalAdminGroupName, Guid.Empty);
            AppCreatorGroupId = configuration.GetValue(RBACProperties.AppCreatorGroupName, Guid.Empty);
        }

        public async Task<List<string>> GetPermissions(ClaimsPrincipal User, AppRegistration app)
        {
            var permissions = new List<string>();

            var appPermissions = GetAppPermissions(app.Id, false);
            var agentPermissions = GetAgentPermissions(app.Id, false);
            var feedBackPermissions = GetFeedbackPermissions(app.Id, false);
            var dataSourcePermissions = GetDataSourcePermissions(new Guid(), app.Id, false);

            permissions.AddRange((await VerifyPermissions(User, appPermissions)).Select(x => $"{nameof(AppRegistration)}.{x}"));
            permissions.AddRange((await VerifyPermissions(User, agentPermissions)).Select(x => $"{nameof(Agent)}.{x}"));
            permissions.AddRange((await VerifyPermissions(User, feedBackPermissions)).Select(x => $"{nameof(Feedback)}.{x}"));
            permissions.AddRange((await VerifyPermissions(User, dataSourcePermissions)).Select(x => $"{nameof(DataSource)}.{x}"));

            return permissions;
        }

        public async Task<List<string>> VerifyPermissions(ClaimsPrincipal User, Dictionary<string, List<RoleObject>> permissions)
        {
            var userId = User.GetUserId();
            if (userId == null)
            {
                throw new NotFoundException();
            }

            var userObjectId = User.GetObjectId();
            if (userObjectId == null)
            {
                throw new NotFoundException();
            }

            var groups = await graphService.GetGroupsAsync(userObjectId.Value);
            var verifiedPermissions = new List<string>();

            foreach (var permissonName in permissions.Keys)
            {
                foreach (var permission in permissions[permissonName])
                {
                    if (HasAppPermission(userId.Value, groups, permission))
                    {
                        verifiedPermissions.Add(permissonName);
                        break;
                    }
                }
            }

            return verifiedPermissions;
        }

        public bool HasPermission(Guid userId, IEnumerable<Microsoft.Graph.Models.DirectoryObject> groups, RoleObject permission)
        {
            if (permission.EntityType == EntityTypes.System)
            {
                return groups.Select(x => x.Id).Contains(permission.EntityId.ToString());
            }

            if (userRoleService.GetAllByCondition(x => x.DirectoryEntryId == userId && !x.IsGroup &&
                                                       x.EntityType == permission.EntityType &&
                                                       x.EntityId == permission.EntityId &&
                                                       (x.Permission & permission.Permission) > 0).Any())
            {
                return true;
            }

            return groups.Any(group => userRoleService.GetAllByCondition(x => x.DirectoryEntry.ObjectId.ToString() == group.Id && x.IsGroup &&
                                                                              x.EntityType == permission.EntityType &&
                                                                              x.EntityId == permission.EntityId &&
                                                                              (x.Permission & permission.Permission) > 0).Any());
        }

        public bool HasAppPermission(Guid userId, IEnumerable<Microsoft.Graph.Models.DirectoryObject> groups, RoleObject permission)
        {
            if (permission.EntityType == EntityTypes.System)
            {
                return groups.Select(x => x.Id).Contains(permission.EntityId.ToString());
            }

            if (userRoleService.GetAllByCondition(x => x.DirectoryEntryId == userId && !x.IsGroup &&
                                                       x.EntityType == permission.EntityType &&
                                                       x.ApplicationId == permission.ApplicationId &&
                                                       (x.Permission & permission.Permission) > 0).Any())
            {
                return true;
            }

            return groups.Any(group => userRoleService.GetAllByCondition(x => x.DirectoryEntry.ObjectId.ToString() == group.Id && x.IsGroup &&
                                                                              x.EntityType == permission.EntityType &&
                                                                              x.ApplicationId == permission.ApplicationId &&
                                                                              (x.Permission & permission.Permission) > 0).Any());
        }

        public Dictionary<string, List<RoleObject>> GetAppPermissions(Guid appId, bool isAppDisabled)
        {
            var dataSources = dataSourceService.GetByApp(appId).ToList();

            var readPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.FeedbackViewer, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.User, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.RBACAdmin, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };
            readPermissions.AddRange(dataSources.Select(x => new RoleObject { EntityType = EntityTypes.DataSource, EntityId = x.Id, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }));

            var rbacAdminPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.RBACAdmin, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var rbacViewerPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.RBACAdmin, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var createPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.System, EntityId = AppCreatorGroupId, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var updatePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId},
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId}
                };

            var chatPermissions = isAppDisabled ? new List<RoleObject>() : new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.User, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var adminPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.FeedbackViewer, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.RBACAdmin, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var disablePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var enablePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            var archivePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.System, EntityId = GlobalAdminGroupId, ApplicationId = appId }
                };

            return new Dictionary<string, List<RoleObject>>
            {
                [AppPermissions.Read.ToString()] = readPermissions,
                [AppPermissions.Create.ToString()] = createPermissions,
                [AppPermissions.Update.ToString()] = updatePermissions,
                [AppPermissions.RbacAdmin.ToString()] = rbacAdminPermissions,
                [AppPermissions.RbacViewer.ToString()] = rbacViewerPermissions,
                [AppPermissions.Chat.ToString()] = chatPermissions,
                [AppPermissions.Admin.ToString()] = adminPermissions,
                [AppPermissions.Enable.ToString()] = enablePermissions,
                [AppPermissions.Disable.ToString()] = disablePermissions,
                [AppPermissions.Archive.ToString()] = archivePermissions,
            };
        }

        public Dictionary<string, List<RoleObject>> GetAgentPermissions(Guid appId, bool isAgentDisabled)
        {
            var readPermissions = isAgentDisabled ? new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                } :
            new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.User, ApplicationId = appId }
                };

            var createPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var updatePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var deletePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var disablePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var enablePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var archivePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            return new Dictionary<string, List<RoleObject>>
            {
                [AgentPermissions.Read.ToString()] = readPermissions,
                [AgentPermissions.Create.ToString()] = createPermissions,
                [AgentPermissions.Update.ToString()] = updatePermissions,
                [AgentPermissions.Delete.ToString()] = deletePermissions,
                [AgentPermissions.Disable.ToString()] = disablePermissions,
                [AgentPermissions.Enable.ToString()] = enablePermissions,
                [AgentPermissions.Archive.ToString()] = archivePermissions,
            };
        }

        public Dictionary<string, List<RoleObject>> GetFeedbackPermissions(Guid appId, bool isAppDisabled)
        {
            var viewerPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.FeedbackViewer, ApplicationId = appId }
                };

            return new Dictionary<string, List<RoleObject>>
            {
                [FeedbackPermissions.Viewer.ToString()] = viewerPermissions
            };
        }

        public Dictionary<string, List<RoleObject>> GetDataSourcePermissions(Guid dataSourceId, Guid appId, bool isAppDisabled)
        {
            var readPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }
                };

            var createPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var updatePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }
                };

            var rbacAdminPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var rbacViewerPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }
                };

            var deletePermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId }
                };

            var tagViewerPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.Owner, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.User, ApplicationId = appId }
                };

            var downloadPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId },
                    new RoleObject { EntityType = EntityTypes.AppRegistration, EntityId = appId, Permission = (int)AppRoles.User, ApplicationId = appId }
                };

            var documentManagerPermissions =
                new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }
                };

            var documentViewerPermissions = new List<RoleObject>
                {
                    new RoleObject { EntityType = EntityTypes.DataSource, EntityId = dataSourceId, Permission = (int)DataSourceRoles.DataManager, ApplicationId = appId }
                };

            return new Dictionary<string, List<RoleObject>>
            {
                [DataSourcePermissions.Create.ToString()] = createPermissions,
                [DataSourcePermissions.Delete.ToString()] = deletePermissions,
                [DataSourcePermissions.Update.ToString()] = updatePermissions,
                [DataSourcePermissions.RbacAdmin.ToString()] = rbacAdminPermissions,
                [DataSourcePermissions.RbacViewer.ToString()] = rbacViewerPermissions,
                [DataSourcePermissions.Read.ToString()] = readPermissions,
                [DataSourcePermissions.TagViewer.ToString()] = tagViewerPermissions,
                [DataSourcePermissions.DocumentManager.ToString()] = documentManagerPermissions,
                [DataSourcePermissions.DocumentViewer.ToString()] = documentViewerPermissions,
                [DataSourcePermissions.Download.ToString()] = downloadPermissions
            };
        }

        public byte[] GetPermissionMatrixExcel(Guid appId, bool isAppDisabled = false, bool isAgentDisabled = false)
        {
            var permissionConfigs = new List<(Type, Type, Func<bool, Dictionary<string, List<RoleObject>>>, IEnumerable<string>, IEnumerable<string>)>
            {
                (typeof(AppPermissions), typeof(AppRoles),
                    isAppDisabled => GetAppPermissions(appId, isAppDisabled),
                    Enum.GetNames<AppRoles>(),
                    Enum.GetNames<AppPermissions>()),

                (typeof(AgentPermissions), typeof(AppRoles),
                    isAppDisabled => GetAgentPermissions(appId, isAgentDisabled),
                    Enum.GetNames<AppRoles>(),
                    Enum.GetNames<AgentPermissions>()),

                (typeof(FeedbackPermissions), typeof(AppRoles),
                    isAppDisabled => GetFeedbackPermissions(appId, isAppDisabled),
                    Enum.GetNames<AppRoles>(),
                    Enum.GetNames<FeedbackPermissions>()),

                (typeof(DataSourcePermissions), typeof(DataSourceRoles),
                    isAppDisabled => GetDataSourcePermissions(new Guid(), appId, isAppDisabled),
                    Enum.GetNames<DataSourceRoles>(),
                    Enum.GetNames<DataSourcePermissions>())
            };

            var result = GeneratePermissionMatrixExcel(permissionConfigs, isAppDisabled);

            return result;
        }

        public byte[] GeneratePermissionMatrixExcel(
            IEnumerable<(Type PermissionType, Type RoleType, Func<bool, Dictionary<string, List<RoleObject>>> GetPermissionsFunc, IEnumerable<string> Roles, IEnumerable<string> PermissionTypes)> permissionConfigs,
            bool isAppDisabled = false)
        {
            var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("Permissions Matrix");

            int currentRow = 1;

            foreach (var (PermissionType, RoleType, GetPermissionsFunc, Roles, PermissionTypes) in permissionConfigs)
            {
                var permissions = GetPermissionsFunc(isAppDisabled);

                var globalAdminRole = "GlobalAdminGroupId";
                var appCreatorRole = "AppCreatorGroupId";
                var allRoles = Roles
                   .Where(role => Enum.Parse(RoleType, role).GetHashCode() != 0) // Filter out None value
                   .Concat([globalAdminRole, appCreatorRole])
                   .ToList();

                // Header Label
                var headerLabel = $"{PermissionType.Name.Replace("Permissions", " Permissions")}";
                worksheet.Cell(currentRow, 1).Value = headerLabel;
                worksheet.Cell(currentRow, 1).Style.Font.Bold = true;
                worksheet.Range(currentRow, 1, currentRow, PermissionTypes.Count() + 1).Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                currentRow++;

                // Table Headers
                worksheet.Cell(currentRow, 1).Value = "Role";
                for (int i = 0; i < PermissionTypes.Count(); i++)
                {
                    worksheet.Cell(currentRow, i + 2).Value = PermissionTypes.ElementAt(i);
                }
                worksheet.Row(currentRow).Style.Font.Bold = true;
                currentRow++;

                // Fill Data
                foreach (var role in allRoles)
                {
                    worksheet.Cell(currentRow, 1).Value = role;

                    for (int i = 0; i < PermissionTypes.Count(); i++)
                    {
                        var permissionType = PermissionTypes.ElementAt(i);
                        bool hasPermission = permissions.ContainsKey(permissionType) &&
                                             permissions[permissionType].Any(p =>
                                                 Enum.GetName(RoleType, p.Permission) == role ||
                                                 (p.EntityType == EntityTypes.System &&
                                                  ((role == globalAdminRole && p.EntityId == GlobalAdminGroupId) ||
                                                   (role == appCreatorRole && p.EntityId == AppCreatorGroupId)))
                                             );
                        worksheet.Cell(currentRow, i + 2).Value = hasPermission ? "x" : "";
                    }

                    currentRow++;
                }

                // Add an empty row for spacing between tables
                currentRow++;
            }

            // Adjust Column Widths
            worksheet.Columns().AdjustToContents();

            using var stream = new MemoryStream();
            workbook.SaveAs(stream);
            return stream.ToArray();
        }
    }
}
