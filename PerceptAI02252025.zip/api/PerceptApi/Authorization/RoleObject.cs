﻿using PerceptApi.Enums;

namespace PerceptApi.Authorization
{
    public class RoleObject
    {
        public required EntityTypes EntityType { get; set; }
        public required Guid EntityId { get; set; }
        public required Guid ApplicationId { get; set; }
        public int Permission { get; set; }
    }
}