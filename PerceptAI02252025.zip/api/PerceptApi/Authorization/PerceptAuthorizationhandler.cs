﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Percept.Shared.Data.Entities;
using PerceptApi.Data.Entities;
using PerceptApi.Extensions;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Authorization
{

    public class PerceptAuthorizationhandler<TRequirement, TEntity> : AuthorizationHandler<TRequirement, TEntity> where TRequirement : OperationAuthorizationRequirement
    {
        private readonly IAppRegistrationService appRegistrationService;
        private readonly IGraphService graphService;
        private readonly IPermissionService permissionService;

        public PerceptAuthorizationhandler(IAppRegistrationService appRegistrationService,
                                           IGraphService graphService,
                                           IPermissionService permissionService)
        {
            this.appRegistrationService = appRegistrationService ?? throw new ArgumentNullException(nameof(appRegistrationService));
            this.graphService = graphService ?? throw new ArgumentNullException(nameof(graphService));
            this.permissionService = permissionService ?? throw new ArgumentNullException(nameof(permissionService));
        }

        private Dictionary<string, List<RoleObject>> GetPermissions(TEntity entity, Guid appId, bool isAppDisabled)
        {
            return entity switch
            {
                DataSource datasource => permissionService.GetDataSourcePermissions(datasource.Id, appId, isAppDisabled),
                Feedback feedback => permissionService.GetFeedbackPermissions(appId, isAppDisabled),
                Agent agent => permissionService.GetAgentPermissions(appId, isAppDisabled),
                AppRegistration app => permissionService.GetAppPermissions(app.Id, isAppDisabled),
                _ => new Dictionary<string, List<RoleObject>>()
            };
        }

        private bool IsArchived(TEntity entity)
        {
            var appId = GetAppId(entity);
            var app = appRegistrationService.GetById(appId);
            return app?.IsArchived ?? false;
        }

        private bool IsDisabled(TEntity entity)
        {
            var appId = GetAppId(entity);
            var app = appRegistrationService.GetById(appId);
            return app?.IsDisabled ?? false;
        }

        private Guid GetAppId(TEntity entity)
        {
            return entity switch
            {
                IHasApplicationId resource => resource.ApplicationId,
                AppRegistration appEntity => appEntity.Id,
                _ => Guid.Empty
            };
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, TRequirement requirement, TEntity resource)
        {
            if (IsArchived(resource))
            {
                return;
            }

            var isAppDisabled = IsDisabled(resource);
            var appId = GetAppId(resource);
            var userId = context.User.GetUserId();
            if (userId == null)
            {
                return;
            }

            var userObjectId = context.User.GetObjectId();
            if (userObjectId == null)
            {
                return;
            }

            var groups = await graphService.GetGroupsAsync(userObjectId.Value);
            var permissionTable = GetPermissions(resource, appId, isAppDisabled);

            if (permissionTable.TryGetValue(requirement.Name, out var permissions) && permissions.Any(permission => permissionService.HasPermission(userId.Value, groups, permission)))
            {
                context.Succeed(requirement);
            }
        }
    }
}