﻿using Microsoft.Graph.Models;
using PerceptApi.Data.Entities;
using System.Security.Claims;

namespace PerceptApi.Authorization
{
    public interface IPermissionService
    {
        Dictionary<string, List<RoleObject>> GetAgentPermissions(Guid appId, bool isAgentDisabled);
        Dictionary<string, List<RoleObject>> GetAppPermissions(Guid appId, bool isAppDisabled);
        Dictionary<string, List<RoleObject>> GetDataSourcePermissions(Guid dataSourceId, Guid appId, bool isAppDisabled);
        Dictionary<string, List<RoleObject>> GetFeedbackPermissions(Guid appId, bool isAppDisabled);
        byte[] GetPermissionMatrixExcel(Guid appId, bool isAppDisabled = false, bool isAgentDisabled = false);
        Task<List<string>> GetPermissions(ClaimsPrincipal User, AppRegistration app);
        bool HasPermission(Guid userId, IEnumerable<DirectoryObject> groups, RoleObject permission);
        Task<List<string>> VerifyPermissions(ClaimsPrincipal User, Dictionary<string, List<RoleObject>> permissions);
    }
}