﻿using Microsoft.AspNetCore.Authorization.Infrastructure;

namespace PerceptApi.Authorization
{
    public class AppOperationAuthorizationRequirement : OperationAuthorizationRequirement { }
}
