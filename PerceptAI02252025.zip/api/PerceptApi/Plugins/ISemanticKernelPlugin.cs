﻿

using PerceptApi.DataSources;
using PerceptApi.DTOs;

namespace PerceptApi.Plugins
{
    public interface ISemanticKernelPlugin
    {
        Guid Id { get; }
        string SystemMessage { get; }
        string Description { get; }

        void Initialize(IServiceCollection serviceCollection, IConfiguration appConfigration, DataSourceConfigurationBase configuration, AgentQuery query);
    }
}