﻿namespace PerceptApi.Plugins
{
    public class KernelMemoryPluginConstants
    {
        public static Guid PluginId = new Guid("28e42582-dfce-45f3-8d37-d6e88235c060");
    }
}
