﻿using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.AI;
using Microsoft.SemanticKernel;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Models;
using PerceptApi.Services;
using System.ComponentModel;
using System.Text;

namespace PerceptApi.Plugins
{

    public class KernelMemoryPlugin : ISemanticKernelPlugin
    {
        ITextEmbeddingGenerator tokenizer;
        private IKernelMemory memory;
        private const string CitationsKey = "Citations";
        private const string ChatHistoryTokensKey = "ChatHistoryTokens";

        private string indexName;
        private double minRelevance;
        private List<MemoryFilter> memoryFilters = new();

        private readonly ILogger<KernelMemoryPlugin> _logger;
        private int maxMatchesCount;

        public Guid Id => KernelMemoryPluginConstants.PluginId;

        public string SystemMessage => "I Always want you to search kernel memory to find facts to answer the users question even if you think you know the answer.";

        public string Description => "AI Agent that can query kernel memory for memories to answer questions.";


        public void Initialize(IServiceCollection serviceCollection, IConfiguration appConfiguration, DataSourceConfigurationBase pluginConfiguration, AgentQuery query)
        {
            if (pluginConfiguration is KernelMemoryDataSourceConfiguration kmPluginConfiguration)
            {
                if (!ValidatePluginConfiguration(kmPluginConfiguration, out var exception))
                {
                    throw exception ?? new InvalidDataException("configuration is missing required values.");
                }
                var memoryQuery = ValidateQuery(query, out exception);
                if (memoryQuery == null)
                {
                    throw exception ?? new InvalidDataException("query is missing required values.");
                }

                indexName = kmPluginConfiguration.IndexName;
                minRelevance = memoryQuery.MinRelevance;
                memoryFilters = memoryQuery.Filters;
                maxMatchesCount = appConfiguration.GetValue("KernelMemory:Retrieval:SearchClient:MaxMatchesCount", 100);

                serviceCollection.AddKernelMemory(appConfiguration);

                var serviceProvider = serviceCollection.BuildServiceProvider();
                memory = serviceProvider.GetRequiredService<IKernelMemory>();

                tokenizer = serviceProvider.GetRequiredService<ITextEmbeddingGenerator>();
            }
            else
            {
                throw new InvalidDataException("configuration is missing required values.");
            }
        }

        [KernelFunction("Search")]
        [Description("Finds facts by searching Kernel Memory. Using a specific memory store.")]
        [return: Description("relevant content related to the question")]
        public async Task<string> SearchAsync([Description("The text to search in memory")] string query, Kernel kernel)
        {
            var maxTokens = 128000;
            var currentTokens = 0;

            try
            {
                var memories = await memory.SearchAsync(query, indexName, minRelevance: minRelevance, limit: maxMatchesCount, filters: memoryFilters);

                kernel.Data[CitationsKey] = new KernelMemoryCitations
                {
                    Citations = memories.Results.Select(x => KernelMemoryCitation.Create(x)).ToList(),
                };

                if (kernel.Data.TryGetValue(ChatHistoryTokensKey, out var chatHistoryTokens) && chatHistoryTokens != null && int.TryParse(chatHistoryTokens.ToString(), out var chatTokens))
                {
                    currentTokens += chatTokens;
                }

                var factsStringBuilder = new StringBuilder();
                var tokenLimitReached = false;

                foreach (var result in memories.Results)
                {
                    foreach (var partition in result.Partitions)
                    {
                        var fact = $"Fact: {partition.Text}";
                        var factTokens = tokenizer.CountTokens(fact);
                        currentTokens += factTokens;

                        if (currentTokens < maxTokens)
                        {
                            factsStringBuilder.AppendLine(fact);
                        }
                        else
                        {
                            tokenLimitReached = true;
                            break;
                        }
                    }

                    if (tokenLimitReached)
                    {
                        break;
                    }
                }

                return factsStringBuilder.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while searching kernel memory.", ex);
                throw new InvalidOperationException("An error occurred while searching kernel memory.", ex);
            }
        }

        private static bool ValidatePluginConfiguration(KernelMemoryDataSourceConfiguration? config, out Exception? exception)
        {
            exception = null;
            if (config != null && !string.IsNullOrEmpty(config.IndexName))
            {
                return true;
            }

            exception = new Exception("KernelMemoryAgent requires an Index name to be provided in the configuration.");
            return false;
        }

        private static KernelMemoryQuery ValidateQuery(AgentQuery query, out Exception? exception)
        {
            exception = null;
            KernelMemoryQuery? result = null;
            try
            {
                result = query.ContextArguments as KernelMemoryQuery;
            }
            catch
            {
                exception = new Exception("KernelMemoryAgent requires Index, Filters, and MinRelevance to be provided in the input.");
            }
            return result ?? new();
        }
    }
}
