﻿using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Data.SqlClient;
using Microsoft.KernelMemory.AI;
using Microsoft.SemanticKernel;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Services;
using PerceptApi.Sql;
using System.ComponentModel;
using System.Text.Json;

namespace PerceptApi.Plugins
{

    public class SqlPlugin : ISemanticKernelPlugin
    {
        private const string sqlPrompt = @"<message role=""system"">
Generate a SQL SELECT query that is compatible with {{$data_platform}} and achieves the OBJECTIVE exclusively using only the tables and views described in ""SCHEMA:"" and never run queries against system/builtin tables.


Only generate SQL if the OBJECTIVE can be answered by querying a database with tables described in SCHEMA and only queries that do not modify the database.
</message>
<message role=""system"">
Respond with only with valid SQL
</message>
<message role=""user"">
SCHEMA:
  description: historical record of concerts, stadiums and singers
  tables:
    - stadium:
      columns:
        Stadium_ID:
        Location:
        Name:
        Capacity:
        Highest:
        Lowest:
        Average:
    - singer:
      columns:
        Singer_ID:
        Name:
        Country:
        Song_Name:
        Song_release_year:
        Age:
        Is_male:
    - concert:
      columns:
        concert_ID:
        concert_Name:
        Theme:
        Stadium_ID:
        Year:
    - singer_in_concert:
      columns:
        concert_ID:
        Singer_ID:
        references:
  concert.Stadium_ID: stadium.Stadium_ID
    references:
    singer_in_concert.concert_ID: concert.concert_ID
    singer_in_concert.Singer_ID: singer.Singer_ID

OBJECTIVE: How many heads of the departments are older than 56 ?
</message>
<message role=""assistant"">
select count(*) department_head_count from head where age > 56
</message>
<message role=""user"">
SCHEMA:
{{$data_schema}}

OBJECTIVE: {{$data_objective}}
</message>";
        public const string ContextParamObjective = "data_objective";
        public const string ContextParamSchema = "data_schema";
        public const string ContextParamSchemaId = "data_schema_id";
        public const string ContextParamPlatform = "data_platform";

        private string connectionString;
        private SchemaDefinition Schema;
        ITextEmbeddingGenerator tokenizer;

        public Guid Id => SqlPluginConstants.PluginId;

        public string SystemMessage => @"
                    You are an Azure OpenAI assistant that searches the data source for facts based on the users questions.
                    ";

        public string Description => "AI Agent that can query MS SQL to answer questions.";

        public void Initialize(IServiceCollection serviceCollection, IConfiguration appConfiguration, DataSourceConfigurationBase pluginConfiguration, AgentQuery query)
        {
            if (pluginConfiguration is SqlDataSourceConfiguration sqlPluginConfiguration)
            {
                connectionString = sqlPluginConfiguration.ConnectionString;
                Schema = sqlPluginConfiguration.Schema;

                serviceCollection.AddKernelMemory(appConfiguration);

                var serviceProvider = serviceCollection.BuildServiceProvider();

                tokenizer = serviceProvider.GetRequiredService<ITextEmbeddingGenerator>();
            }
            else
            {
                throw new InvalidDataException("configuration is missing required values.");
            }
        }

        [KernelFunction("SearchDataSource")]
        [Description("Searches data source for facts based on users questions.")]
        [return: Description("string of facts")]
        public async Task<string> SearchDataSource(string question, Kernel kernel)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    await connection.OpenAsync();

                    var arguments = new KernelArguments();
                    arguments[ContextParamObjective] = question;
                    arguments[ContextParamSchema] = Schema.ToJson();
                    arguments[ContextParamSchemaId] = Schema.Name;
                    arguments[ContextParamPlatform] = Schema.Platform;
                    var result = await kernel.InvokePromptAsync(sqlPrompt, arguments);
                    var sql = result.ToString();

                    if (!await IsValidSql(sql, kernel))
                    {
                        return "unauthorized to make this request";
                    }

                    if (await IsSqlSafe(sql, kernel))
                    {
                        var data = ExecuteQuery(connection, sql);
                        return JsonSerializer.Serialize(data);
                    }

                    return "unauthorized to make this request";
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        private async Task<bool> IsValidSql(string sqlQuery, Kernel kernel)
        {
            var isValid = await kernel.InvokePromptAsync($"return true if the query is a valid SQL query, otherwise return false. Query: '{sqlQuery}'. Do not explain your reasoning only return the result");
            if (bool.TryParse(isValid.ToString(), out var valid))
            {
                return valid;
            }

            return false;
        }

        private async Task<bool> IsSqlSafe(string sqlQuery, Kernel kernel)
        {
            var isSafe = await kernel.InvokePromptAsync($"return true if the query is read only and does not use any tables built in to the sql server. Return false if the sql modifies the database in any way or uses system tables. Query: '{sqlQuery}'. Do not explain your reasoning only return the result");
            if (bool.TryParse(isSafe.ToString(), out var safe))
            {
                return safe;
            }

            return false;
        }

        private IEnumerable<Dictionary<string, object>> ExecuteQuery(SqlConnection connection, string queryString)
        {
            var command = new SqlCommand(queryString.Trim('`').Replace("sql", ""), connection);
            var reader = command.ExecuteReader();
            try
            {
                return Serialize(reader);
            }
            finally
            {
                // Always call Close when done reading.
                reader.Close();
            }
        }

        public IEnumerable<Dictionary<string, object>> Serialize(SqlDataReader reader)
        {
            var results = new List<Dictionary<string, object>>();
            var cols = new List<string>();
            for (var i = 0; i < reader.FieldCount; i++)
                cols.Add(reader.GetName(i));

            while (reader.Read())
                results.Add(SerializeRow(cols, reader));

            return results;
        }

        private Dictionary<string, object> SerializeRow(IEnumerable<string> cols,
                                                        SqlDataReader reader)
        {
            var result = new Dictionary<string, object>();
            foreach (var col in cols)
                result.Add(col, reader[col]);
            return result;
        }
    }
}
