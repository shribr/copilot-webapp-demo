﻿namespace PerceptApi.Plugins
{
    public class SqlPluginConstants
    {
        public static Guid PluginId = new Guid("7067dc88-c942-41ee-8f7d-b842e4c0dd3a");
    }
}
