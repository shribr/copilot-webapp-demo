﻿
namespace PerceptApi.Constants
{
    public class PerceptClaimTypes
    {
        public static string UserId = "Percept_DirectoryEntryId";

        public static string Jwt_oid = "oid";
        public static string Jwt_scp = "scp";

        public static string ObjectIdentifier = "http://schemas.microsoft.com/identity/claims/objectidentifier";
        
    }
}
