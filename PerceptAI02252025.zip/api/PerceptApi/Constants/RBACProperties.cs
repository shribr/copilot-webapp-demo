﻿namespace PerceptApi.Constants
{
    public class RBACProperties
    {
        public const string SystemAdminName = "SystemAdmin";
        public const string AppCreatorRoleName = "AppCreator";
        public const string RoleClaimName = "role";
        public const string NameClaimName = "name";
        public const string AnyPermission = "Any";
        public const string AppCreatorGroupName = "Percept:AppCreatorGroupId";
        public const string GlobalAdminGroupName = "Percept:GlobalAdminGroupId";
    }
}
