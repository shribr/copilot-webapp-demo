﻿namespace PerceptApi.Constants
{
    internal static class SortingDirections
    {
        public const string Ascending = "asc";
        public const string Descending = "desc";
    }
}
