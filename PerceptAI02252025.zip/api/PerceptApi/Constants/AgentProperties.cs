﻿namespace PerceptApi.Constants
{
    internal static class AgentProperties
    {
        public const string Instructions = "Instructions";
    }
}
