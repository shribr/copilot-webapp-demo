﻿using Microsoft.KernelMemory;
using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    public class KernelMemoryCitation : Citation
    {
        public static KernelMemoryCitation Create(Citation citation)
        {
            var kernelMemoryCitation = new KernelMemoryCitation
            {
                SourceName = citation.SourceName,
                SourceUrl = citation.SourceUrl,
                DocumentId = citation.DocumentId,
                FileId = citation.FileId,
                Index = citation.Index,
                Link = citation.Link,
                Partitions = citation.Partitions,
                SourceContentType = citation.SourceContentType,
            };

            return kernelMemoryCitation;
        }

        [JsonPropertyName("downloadUrl")]
        public string DownloadUrl { get; set; } = string.Empty;
    }
}