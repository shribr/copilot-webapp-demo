﻿using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    public class ChatMessageCitation
    {
        [JsonPropertyName("sourceName")]
        public string SourceName { get; set; }

        [JsonPropertyName("sourceUrl")]
        public string SourceUrl { get; set; }
    }
}
