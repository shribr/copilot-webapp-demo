﻿using PerceptApi.Attributes;
using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
    [JsonDerivedType(typeof(KernelMemoryCitations), typeDiscriminator: nameof(KernelMemoryCitations))]
    [SwaggerBase]
    public abstract class Citations
    {
    }
}