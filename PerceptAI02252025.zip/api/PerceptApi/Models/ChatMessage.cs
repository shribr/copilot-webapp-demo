﻿using PerceptApi.Attributes;
using PerceptApi.Enums;
using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
    [JsonDerivedType(typeof(AIChatMessage), typeDiscriminator: nameof(AIChatMessage))]
    [JsonDerivedType(typeof(UserChatMessage), typeDiscriminator: nameof(UserChatMessage))]
    [SwaggerBase]
    public abstract class ChatMessage
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; }

        [JsonPropertyName("conversationId")]
        public Guid ConversationId { get; set; }

        [JsonPropertyName("from")]
        public UserType UserType { get; init; }
    }
}
