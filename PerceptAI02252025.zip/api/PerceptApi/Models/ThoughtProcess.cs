﻿namespace PerceptApi.Models
{
    public class ThoughtProcess
    {
        public string Id { get; set; } = string.Empty;
        public Guid ChatConversationId { get; set; } = Guid.Empty;
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public string Prompt { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public SystemAnswer? SystemAnswer { get; set; }
    }
}
