﻿namespace PerceptApi.Models
{
    public class DocumentIntelligenceConfig
    {
        public string Endpoint { get; set; }
        public string ApiKey { get; set; }
    }
}
