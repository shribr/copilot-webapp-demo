﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    public class SystemAnswer
    {
        private static readonly JsonSerializerOptions s_indentedJsonOptions = new() { WriteIndented = true };
        private static readonly JsonSerializerOptions s_notIndentedJsonOptions = new() { WriteIndented = false };
        private static readonly JsonSerializerOptions s_caseInsensitiveJsonOptions = new() { PropertyNameCaseInsensitive = true };

        [JsonPropertyName("noResult")]
        [JsonPropertyOrder(2)]
        public bool NoResult { get; set; } = true;

        /// <summary>
        /// Content of the answer.
        /// </summary>
        [JsonPropertyName("noResultReason")]
        [JsonPropertyOrder(3)]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string? NoResultReason { get; set; }

        /// <summary>
        /// Content of the answer.
        /// </summary>
        [JsonPropertyName("text")]
        [JsonPropertyOrder(10)]
        public string Result { get; set; } = string.Empty;

        /// <summary>
        /// List of the relevant sources used to produce the answer.
        /// Key = Document ID
        /// Value = List of partitions used from the document.
        /// </summary>
        [JsonPropertyName("relevantSources")]
        [JsonPropertyOrder(20)]
        public Citations? RelevantSources { get; set; }


        /// <summary>
        /// List of the functions used to produce the answer.
        /// </summary>
        [JsonPropertyName("functions")]
        [JsonPropertyOrder(30)]
        public List<SemanticFunctionResponse> Functions { get; set; } = new();


        /// <summary>
        /// List of the functions used to produce the answer.
        /// </summary>
        [JsonPropertyName("id")]
        [JsonPropertyOrder(40)]
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// Serialize using .NET JSON serializer, e.g. to avoid ambiguity
        /// with other serializers and other options
        /// </summary>
        /// <param name="indented">Whether to keep the JSON readable, e.g. for debugging and views</param>
        /// <returns>JSON serialization</returns>
        public string ToJson(bool indented = false)
        {
            return JsonSerializer.Serialize(this, indented ? s_indentedJsonOptions : s_notIndentedJsonOptions);
        }

        public SystemAnswer FromJson(string json)
        {
            return JsonSerializer.Deserialize<SystemAnswer>(json, s_caseInsensitiveJsonOptions)
                   ?? new SystemAnswer();
        }
    }
}
