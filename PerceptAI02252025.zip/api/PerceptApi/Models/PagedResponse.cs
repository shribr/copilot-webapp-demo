﻿namespace PerceptApi.Models
{
    /// <summary>
    /// Represents a paginated response.
    /// </summary>
    /// <typeparam name="T">The type of the paged items.</typeparam>
    public class PagedResponse<T> where T : notnull
    {
        public PagedResponse(int page, int pageSize, IQueryable<T> query)
        {
            CurrentPage = page;
            PageSize = pageSize;
            Pages = (int)Math.Ceiling(query.Count() / (double)pageSize);
            Items = [.. query.Skip((page - 1) * pageSize).Take(pageSize)];
            TotalCount = query.Count();
        }

        /// <summary>
        /// The current page number.
        /// </summary>
        public int CurrentPage { get; set; }

        /// <summary>
        /// The number of items per page.
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// The total count of all items.
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// The total number of pages given the page size.
        /// </summary>
        public int Pages { get; set; }

        /// <summary>
        /// The enumerable collection of paged items.
        /// </summary>
        public IEnumerable<T> Items { get; set; } = [];
    }
}
