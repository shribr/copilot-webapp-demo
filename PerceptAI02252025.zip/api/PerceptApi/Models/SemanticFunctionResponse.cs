﻿using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    public class SemanticFunctionResponse
    {
        [JsonPropertyName("pluginName")]
        public string PluginName { get; set; } = string.Empty;

        [JsonPropertyName("functionName")]
        public string FunctionName { get; set; } = string.Empty;

        [JsonPropertyName("result")]
        public string Result { get; set; } = string.Empty;

        [JsonPropertyName("arguments")]
        public string Arguments { get; set; } = string.Empty;
    }
}
