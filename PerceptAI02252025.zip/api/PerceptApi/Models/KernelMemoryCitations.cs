﻿namespace PerceptApi.Models
{
    public class KernelMemoryCitations : Citations
    {
        public List<KernelMemoryCitation> Citations { get; set; } = new();
    }
}