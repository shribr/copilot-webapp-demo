﻿using PerceptApi.Enums;
using System.Text.Json.Serialization;

namespace PerceptApi.Models
{
    public class AIChatMessage : ChatMessage
    {
        [JsonPropertyName("citations")]
        public List<ChatMessageCitation> Citations { get; set; } = new();

        public AIChatMessage()
        {
            UserType = UserType.AI;
        }
    }
}
