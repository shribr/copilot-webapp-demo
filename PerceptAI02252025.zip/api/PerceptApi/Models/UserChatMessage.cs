﻿namespace PerceptApi.Models
{
    public class UserChatMessage : ChatMessage
    {
        public UserChatMessage()
        {
            UserType = Enums.UserType.User;
        }
    }
}
