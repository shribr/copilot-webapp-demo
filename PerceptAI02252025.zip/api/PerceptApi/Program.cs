using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Percept.Classifications.Services;
using Percept.Shared.Configuration;
using Percept.Shared.Converter;
using Percept.Shared.Enums;
using Percept.Workspaces.Configuration;
using Percept.Workspaces.Services;
using PerceptApi.Data;
using PerceptApi.ErrorHandling;
using PerceptApi.Extensions;
using PerceptApi.Middleware;
using PerceptApi.Services;
using PerceptApi.Workers;
using System.Reflection;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        var configuration = builder.Configuration;

        var isDev = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.Equals("Development", StringComparison.OrdinalIgnoreCase) ?? false;
        if (isDev)
        {
            var entryAssembly = Assembly.GetEntryAssembly();
            if (entryAssembly != null)
                configuration.AddUserSecrets(entryAssembly, optional: true);
        }
        else
        {
            builder.AddAppInsights(configuration);
        }

        IWebHostEnvironment environment = builder.Environment;

        var config = ((IConfigurationBuilder)configuration).Build();

        builder.Services.AddControllers(options =>
        {
            options.ModelMetadataDetailsProviders.Add(new SystemTextJsonValidationMetadataProvider());

        })
        .AddJsonOptions(options =>
        {
            options.JsonSerializerOptions.Converters.Add(new EnumNameConverter<DocumentState>());
        })
        .ConfigureApplicationPartManager(apm =>
        {
            var mainAssembly = Assembly.GetExecutingAssembly();
            var partsToKeep = apm.ApplicationParts.Where(p => p.Name == mainAssembly.GetName().Name).ToList();

            apm.ApplicationParts.Clear();
            foreach (var part in partsToKeep)
            {
                apm.ApplicationParts.Add(part);
            }
        });

        // Add services to the container.
        var workspacesConfig = new WorkspacesConfiguration();
        configuration.GetSection("Percept:Workspaces").Bind(workspacesConfig);
        if (workspacesConfig.Enabled)
        {
            builder.Services.AddWorkspaces(configuration);
        }

        builder.Services.AddClassifications(configuration, typeof(PerceptDbContext));
        builder.Services.AddApplicationServices(configuration, isDev);
        builder.Services.AddAuthorizationServices();

        builder.Services.AddHostedService<FileProcessWorker>();

        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwagger();
        builder.Services.AddOutputCache();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseHttpsRedirection();
        }

        app.UseOutputCache();
        app.UseCors(config);
        app.UseApiAuth();
        app.MapControllers();
        var logger = app.Services.GetRequiredService<ILogger<Program>>();
        app.ConfigureExceptionHandler(logger);
        app.UseMiddleware<UserTelemetryMiddleware>();

        app.Run();
    }
}