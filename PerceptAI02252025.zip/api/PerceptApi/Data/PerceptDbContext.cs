using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.SemanticKernel.ChatCompletion;
using Percept.Classifications.Data;
using Percept.Shared.Data;
using Percept.Shared.Data.Entities;
using PerceptApi.Agents;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.ErrorHandling;
using PerceptApi.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Security.Claims;
using System.Security.Principal;
using System.Text.Json;

namespace PerceptApi.Data
{
    public class PerceptDbContext(DbContextOptions<PerceptDbContext> options, IHttpContextAccessor httpContext) :
        DbContext(options), IClassificationDbContext, IDocumentUploadStatusDbContext
    {
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<DataSource> DataSources { get; set; }
        public DbSet<DirectoryEntry> DirectoryEntries { get; set; }
        public DbSet<ChatConversation> ChatConversations { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<MemoryStoreCache> MemoryStoresCache { get; set; }
        public DbSet<AppRegistration> AppRegistrations { get; set; }
        public DbSet<Agent> Agents { get; set; }
        public DbSet<DocumentUploadStatus> DocumentUploadStatus { get; set; }

        // Add Classifications Support
        public DbSet<ClassificationControlConfiguration> ClassificationControls { get; set; }
        public DbSet<ClassificationControlValueOption> ClassificationValueOptions { get; set; }
        public DbContext Context => this;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseExceptionProcessor();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // JSON serialization of model properties
            JsonSerializerOptions? nullOptions = null;
            modelBuilder.Entity<Agent>()
                .Property(e => e.Configuration)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, typeof(AgentConfiguration), nullOptions),
                    v => (v != null ? JsonSerializer.Deserialize<AgentConfiguration>(v, nullOptions) : null) ?? new()
                    );

            modelBuilder.Entity<Agent>()
                .HasQueryFilter(x => x.IsArchived == false);

            modelBuilder.Entity<DataSource>()
                .Property(e => e.Configuration)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, typeof(DataSourceConfigurationBase), nullOptions),
                    v => (v != null ? JsonSerializer.Deserialize<DataSourceConfigurationBase?>(v, nullOptions) : null)
                    );

            modelBuilder.Entity<ChatConversation>()
                .HasQueryFilter(x => x.SoftDelete == false)
                .Property(e => e.Citations)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, typeof(Dictionary<string, Citations>), nullOptions),
                    v => JsonSerializer.Deserialize<Dictionary<string, Citations>>(v, nullOptions) ?? new(),
                    new DictionaryValueComparer<string, Citations?>()
                    );

            modelBuilder.Entity<ChatConversation>()
                .Property(e => e.AgentQueryContexts)
                 .HasConversion(
                    v => JsonSerializer.Serialize(v, typeof(Dictionary<string, AgentQueryContext>), nullOptions),
                    v => !string.IsNullOrEmpty(v) ? (JsonSerializer.Deserialize<Dictionary<string, AgentQueryContext>>(v, nullOptions) ?? new()) : new(),
                     new DictionaryValueComparer<string, AgentQueryContext?>()
                    );

            modelBuilder.Entity<ChatConversation>()
                .Property(e => e.ChatHistory)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, typeof(ChatHistory), nullOptions),
                    v => JsonSerializer.Deserialize<ChatHistory>(v, nullOptions) ?? new()
                    );

            // Add Classifications Serialization Support
            modelBuilder.EnableSerializationOfClassifications();
        }

        private static void AuditCreation(IAuditableCreated auditable, IPrincipal user)
        {
            auditable.CreatedBy = user.Identity?.Name ?? "UNKNOWN";
            auditable.CreatedOn = DateTime.UtcNow;
        }

        private static void AuditModification(IAuditableModified auditable, IPrincipal user)
        {
            auditable.ModifiedBy = user.Identity?.Name ?? "UNKNOWN";
            auditable.ModifiedOn = DateTime.UtcNow;
        }

        private static void ValidateEntity(EntityEntry entry)
        {
            try { Validator.ValidateObject(entry.Entity, new ValidationContext(entry.Entity), validateAllProperties: true); }
            catch (ValidationException e)
            {
                Debug.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:", entry.Entity.GetType(), entry.State);
                Debug.WriteLine(e.Message);
                throw;
            }
        }

        private void AuditEntities()
        {
            ClaimsPrincipal user = httpContext?.HttpContext?.User ?? Thread.CurrentPrincipal as ClaimsPrincipal;

            // Handle added entities
            var addedEntries = ChangeTracker.Entries()
                .Where(u => u.State == EntityState.Added && (u.Entity is IAuditable || u.Entity is IAuditableCreated))
                .ToList();

            foreach (var entry in addedEntries)
            {
                if (entry.Entity is IAuditableCreated created)
                {
                    AuditCreation(created, user);
                }
                if (entry.Entity is IAuditableModified modified)
                {
                    AuditModification(modified, user);
                }
                ValidateEntity(entry);
            }

            // Handle modified entities
            var modifiedEntries = ChangeTracker.Entries()
                .Where(u => u.State == EntityState.Modified && (u.Entity is IAuditable || u.Entity is IAuditableModified))
                .ToList();

            foreach (var entry in modifiedEntries)
            {
                if (entry.Entity is IAuditableModified modified)
                {
                    AuditModification(modified, user);
                }
                ValidateEntity(entry);
            }

            // Handle deleted entities
            var deletedEntries = ChangeTracker.Entries()
                .Where(u => u.State == EntityState.Deleted &&
                            u.Entity is IHasGuidId &&
                            u.Entity is IHasApplicationId &&
                            u.Entity is not UserRole)
                .ToList();

            foreach (var entry in deletedEntries)
            {
                var entityId = ((IHasGuidId)entry.Entity).Id;
                var entityType = ResolveEntityType(entry.Entity.GetType());
                var entityApplicationId = ((IHasApplicationId)entry.Entity).ApplicationId;

                var userRoles = UserRoles
                    .Where(ur => ur.ApplicationId.Equals(entityApplicationId) &&
                                 ur.EntityType.Equals(entityType) &&
                                 ur.EntityId.Equals(entityId))
                    .ToList();

                UserRoles.RemoveRange(userRoles);
            }
        }

        private static EntityTypes ResolveEntityType(Type entityType)
        {
            return Enum.Parse<EntityTypes>(entityType.Name);
        }

        public override int SaveChanges()
        {
            AuditEntities();
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            AuditEntities();
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}
