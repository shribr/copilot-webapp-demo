﻿using System.ComponentModel.DataAnnotations;

namespace PerceptApi.Data.Entities
{
    public class MemoryStoreCache
    {
        [MaxLength(449)]
        public string Id { get; set; } = string.Empty;
        public required byte[] Value { get; set; }
        public DateTimeOffset ExpiresAtTime { get; set; }
        public long? SlidingExpirationInSeconds { get; set; }
        public DateTimeOffset? AbsoluteExpiration { get; set; }
    }
}
