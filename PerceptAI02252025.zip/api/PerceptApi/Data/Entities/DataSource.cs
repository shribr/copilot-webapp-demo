﻿using Percept.Shared.Data.Entities;
using PerceptApi.DataSources;

namespace PerceptApi.Data.Entities
{
    public class DataSource : AuditableCreated, IHasGuidId, IHasApplicationId
    {
        public Guid Id { get; set; }
        public required DataSourceType Type { get; set; }
        public required string Name { get; set; }
        public string? Description { get; set; }
        public bool IsLegacy { get; internal set; }
        public DataSourceConfigurationBase? Configuration { get; set; }
        public required Guid ApplicationId { get; set; }
        public virtual AppRegistration Application { get; set; }
        public ICollection<AgentDataSource> AgentDataSources { get; set; }
    }
}
