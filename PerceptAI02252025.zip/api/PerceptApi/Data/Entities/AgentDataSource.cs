﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PerceptApi.Data.Entities
{
    public class AgentDataSource
    {
        public Guid Id { get; set; }
        [ForeignKey("Agents")]
        public required Guid AgentId { get; set; }
        public Agent Agent { get; set; }
        [ForeignKey("DataSources")]
        public required Guid DataSourceId { get; set; }
        public DataSource DataSource { get; set; }
        public required Guid PluginId { get; set; }
    }
}
