﻿namespace PerceptApi.Data.Entities
{
    public interface ISoftDelete
    {
        public bool SoftDelete { get; set; }
    }
}
