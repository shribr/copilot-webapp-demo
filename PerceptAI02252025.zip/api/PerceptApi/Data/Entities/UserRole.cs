﻿using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data.Entities;
using PerceptApi.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace PerceptApi.Data.Entities
{
    [Index(nameof(EntityId), nameof(DirectoryEntryId), nameof(EntityType), nameof(IsGroup), IsUnique = true)]
    public class UserRole : IHasGuidId, IHasApplicationId
    {
        public Guid Id { get; set; }
        public required Guid ApplicationId { get; set; }
        public Guid DirectoryEntryId { get; set; }
        public bool IsGroup { get; set; }
        public Guid EntityId { get; set; }
        public EntityTypes EntityType { get; set; }
        public int Permission { get; set; }
        [ForeignKey(nameof(DirectoryEntryId))]
        public DirectoryEntry DirectoryEntry { get; set; }
    }
}
