﻿using Percept.Shared.Data.Entities;
using PerceptApi.Agents;

namespace PerceptApi.Data.Entities
{
    public class Agent : Auditable, IHasGuidId, IHasApplicationId
    {
        public Guid Id { get; set; }
        public required Guid ApplicationId { get; set; }
        public virtual AppRegistration Application { get; set; }

        public required string Name { get; set; }
        public string? Description { get; set; }
        public bool IsArchived { get; set; }
        public bool IsDisabled { get; set; }
        public AgentConfiguration Configuration { get; set; } = new();
        public virtual List<AgentDataSource> DataSources { get; set; } = new();
    }
}
