﻿using Percept.Shared.Data.Entities;
using PerceptApi.Enums;

namespace PerceptApi.Data.Entities
{
    /// <summary>
    /// Captures user feedback on AI responses.
    /// </summary>
    public class Feedback : AuditableCreated, IHasGuidId, IHasApplicationId
    {
        /// <summary>
        /// The unique identifier for the feedback.
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// The AI response that the feedback is about. This field is required.
        /// </summary>
        public required string Response { get; set; }

        /// <summary>
        /// The user's question that prompted the AI response. This field is required.
        /// </summary>
        public required string Question { get; set; }

        /// <summary>
        /// The user's reaction to the AI response.
        /// </summary>
        public Reaction Reaction { get; set; }

        /// <summary>
        /// Any additional comments the user may have about the AI response. This field is optional.
        /// </summary>
        public string? Comment { get; set; }

        public required Guid ApplicationId { get; set; }
        public virtual AppRegistration Application { get; set; }
    }
}
