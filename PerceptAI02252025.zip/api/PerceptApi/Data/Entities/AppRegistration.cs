﻿using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data.Entities;

namespace PerceptApi.Data.Entities
{
    [Index(nameof(RouteName), IsUnique = true)]
    public class AppRegistration : Auditable, IHasGuidId
    {
        public Guid Id { get; set; }
        public required string Name { get; set; }
        public required string Description { get; set; }
        public required string Organization { get; set; }
        public required string RouteName { get; set; }
        public bool IsArchived { get; set; }
        public bool IsDisabled { get; set; }
    }
}
