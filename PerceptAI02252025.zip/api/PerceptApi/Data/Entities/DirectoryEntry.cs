﻿using Percept.Shared.Data.Entities;

namespace PerceptApi.Data.Entities
{
    public class DirectoryEntry : IHasGuidId, IEqualityComparer<DirectoryEntry>
    {
        public Guid Id { get; set; } = Guid.Empty;
        public required Guid ObjectId { get; set; }
        public required string DisplayName { get; set; }
        public string? Email { get; set; }
        public bool IsGroup { get; set; } = false;

        public bool Equals(DirectoryEntry? x, DirectoryEntry? y)
        {
            if (x == null && y == null)
            {
                return true;
            }

            if (x == null || y == null)
            {
                return false;
            }

            return x.ObjectId == y.ObjectId && x.IsGroup == y.IsGroup;
        }

        public int GetHashCode(DirectoryEntry obj)
        {
            if (obj == null)
            {
                return 0;
            }

            int hashObjectId = obj.ObjectId.GetHashCode();
            int hashIsGroup = obj.IsGroup.GetHashCode();

            // Use XOR to combine the hash codes
            return hashObjectId ^ hashIsGroup;
        }
    }
}
