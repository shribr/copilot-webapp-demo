﻿using Microsoft.SemanticKernel.ChatCompletion;
using Percept.Shared.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Models;
using System.ComponentModel.DataAnnotations;

namespace PerceptApi.Data.Entities;

public class ChatConversation : IHasGuidId, ISoftDelete
{
    public Guid Id { get; set; }
    public required string Name { get; set; }
    [MaxLength, Required]
    public ChatHistory ChatHistory { get; set; }
    public Guid DirectoryEntryId { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public Guid AgentId { get; set; }
    public virtual Agent Agent { get; set; }

    public Dictionary<string, Citations> Citations { get; set; } = new();
    public bool SoftDelete { get; set; }
    public Dictionary<string, AgentQueryContext> AgentQueryContexts { get; set; } = new();

    public string? Prompts { get; set; } = string.Empty;

    public ChatHistory GetOrCreateChatHistory(string agentInstructions, string userPrompt)
    {
        if (ChatHistory is null)
        {
            ChatHistory = new ChatHistory(agentInstructions);
            ChatHistory.AddSystemMessage(userPrompt);
        }
        return ChatHistory;
    }
}
