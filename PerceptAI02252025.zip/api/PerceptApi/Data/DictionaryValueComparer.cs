﻿using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace PerceptApi.Data
{
    public class DictionaryValueComparer<K, V> : ValueComparer<Dictionary<K, V>> where K : notnull
    {
        public DictionaryValueComparer() : base(
            (d1, d2) => CompareDictionaries(d1, d2),
            d => GetDictionaryHashCode(d),
            d => new Dictionary<K, V>(d))
        {
        }

        private static bool CompareDictionaries(Dictionary<K, V>? x, Dictionary<K, V>? y)
        {
            if (x == null || y == null)
                return x == y;
            if (x.Count != y.Count)
                return false;

            foreach (var kvp in x)
            {
                if (!y.TryGetValue(kvp.Key, out var value) || !EqualityComparer<V>.Default.Equals(kvp.Value, value))
                    return false;
            }

            return true;
        }

        private static int GetDictionaryHashCode(Dictionary<K, V> obj)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));

            int hash = 17;
            foreach (var kvp in obj)
            {
                hash = hash * 31 + (kvp.Key?.GetHashCode() ?? 0);
                hash = hash * 31 + (kvp.Value?.GetHashCode() ?? 0);
            }

            return hash;
        }
    }
}
