﻿namespace PerceptApi.Data
{
    public interface IAuditableModified
    {
        string? ModifiedBy { get; set; }
        DateTime? ModifiedOn { get; set; }
    }
}
