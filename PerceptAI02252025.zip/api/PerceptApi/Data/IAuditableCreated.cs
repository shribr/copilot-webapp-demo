﻿namespace PerceptApi.Data
{
    public interface IAuditableCreated
    {
        string CreatedBy { get; set; }
        DateTime CreatedOn { get; set; }
    }
}
