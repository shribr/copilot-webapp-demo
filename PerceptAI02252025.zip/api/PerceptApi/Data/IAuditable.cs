﻿namespace PerceptApi.Data
{
    public interface IAuditable : IAuditableCreated, IAuditableModified { }
}
