﻿using Percept.Shared.Events;

namespace PerceptApi.Events
{
    public static class PerceptEvents
    {
        public static class RoleAssignment
        {
            const string EventName = "RoleAssignment";
            const int EventIdBase = 100;

            public static readonly PerceptEvent Add = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "Role assigned to user or group"
            };

            public static readonly PerceptEvent Remove = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 2,
                Description = "Role un-assigned from user or group"
            };
        }

        public static class DataManagerAssignment
        {
            const string EventName = "DataManagerAssignment";
            const int EventIdBase = 200;

            public static readonly PerceptEvent Add = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "Role assigned to user or group"
            };

            public static readonly PerceptEvent Remove = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 2,
                Description = "Role un-assigned from user or group"
            };
        }

        public static class Documents
        {
            const string EventName = "Documents";
            const int EventIdBase = 300;

            public static readonly PerceptEvent Download = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "Document downloaded"
            };

            public static readonly PerceptEvent Upload = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 2,
                Description = "Document uploaded"
            };

            public static readonly PerceptEvent GetStatus = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 3,
                Description = "Getting document status"
            };

            public static readonly PerceptEvent Delete = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 4,
                Description = "Deleting document(s)"
            };

            public static readonly PerceptEvent Update = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 5,
                Description = "Updating document"
            };

            public static readonly PerceptEvent Archive = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 6,
                Description = "Archiving document"
            };
        }

        public static class User
        {
            const string EventName = "User";
            const int EventIdBase = 400;

            public static readonly PerceptEvent GetGroupMemberships = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "List all groups that user is a member of"
            };
        }

        public static class AppSettings
        {
            const string EventName = "AppSettings";
            const int EventIdBase = 500;

            public static readonly PerceptEvent GetValue = new PerceptEvent(EventIdBase, EventName)
            {
                EventId = 1,
                Description = "List app setting configuration"
            };
        }
    }
}