﻿namespace PerceptApi.Middleware
{
    public class UserTelemetryMiddleware
    {
        private readonly RequestDelegate _next;

        public UserTelemetryMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var currentActivity = System.Diagnostics.Activity.Current;
            if (currentActivity != null && context.User.Identity.IsAuthenticated)
            {
                var userName = context.User.Identity.Name;

                currentActivity.SetTag("userName", userName);
            }

            await _next(context);
        }
    }
}
