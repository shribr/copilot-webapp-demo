﻿using LangChain.Splitters.Text;
using Microsoft.KernelMemory.AI;
using Microsoft.KernelMemory.Configuration;
using Microsoft.KernelMemory.Context;
using Microsoft.KernelMemory.Diagnostics;
using Microsoft.KernelMemory.Handlers;
using Microsoft.KernelMemory.Pipeline;
using System.Security.Cryptography;
using System.Text;

#pragma warning disable KMEXP00 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
namespace PerceptApi.Handlers
{
    public class MarkDownTextPartitioningHandler : IPipelineStepHandler
    {
        private readonly IPipelineOrchestrator _orchestrator;
        private readonly TextPartitioningOptions _options;
        private readonly ITextEmbeddingGenerator tokenizer;
        private readonly ILogger<TextPartitioningHandler> _log;

        /// <inheritdoc />
        public string StepName { get; }

        /// <summary>
        /// Handler responsible for partitioning text in small chunks.
        /// Note: stepName and other params are injected with DI.
        /// </summary>
        /// <param name="stepName">Pipeline step for which the handler will be invoked</param>
        /// <param name="orchestrator">Current orchestrator used by the pipeline, giving access to content and other helps.</param>
        /// <param name="options">The customize text partitioning option</param>
        /// <param name="loggerFactory">Application logger factory</param>
        public MarkDownTextPartitioningHandler(
            string stepName,
            IPipelineOrchestrator orchestrator,
            ITextEmbeddingGenerator tokenizer,
            TextPartitioningOptions? options = null,
            ILoggerFactory? loggerFactory = null)
        {
            StepName = stepName;
            _orchestrator = orchestrator;

            _options = options ?? new TextPartitioningOptions();
            _options.Validate();

            this.tokenizer = tokenizer;

            _log = (loggerFactory ?? DefaultLogger.Factory).CreateLogger<TextPartitioningHandler>();
            _log.LogInformation("Handler '{0}' ready", stepName);
        }

        /// <inheritdoc />
        public async Task<(ReturnType returnType, DataPipeline updatedPipeline)> InvokeAsync(
            DataPipeline pipeline, CancellationToken cancellationToken = default)
        {
            _log.LogDebug("Partitioning text, pipeline '{0}/{1}'", pipeline.Index, pipeline.DocumentId);

            if (pipeline.Files.Count == 0)
            {
                _log.LogWarning("Pipeline '{0}/{1}': there are no files to process, moving to next pipeline step.", pipeline.Index, pipeline.DocumentId);
                return (ReturnType.Success, pipeline);
            }

            var context = pipeline.GetContext();

            foreach (DataPipeline.FileDetails uploadedFile in pipeline.Files)
            {
                // Track new files being generated (cannot edit originalFile.GeneratedFiles while looping it)
                Dictionary<string, DataPipeline.GeneratedFileDetails> newFiles = new();

                foreach (KeyValuePair<string, DataPipeline.GeneratedFileDetails> generatedFile in uploadedFile.GeneratedFiles)
                {
                    var file = generatedFile.Value;
                    if (file.AlreadyProcessedBy(this))
                    {
                        _log.LogTrace("File {0} already processed by this handler", file.Name);
                        continue;
                    }

                    // Partition only the original text
                    if (file.ArtifactType != DataPipeline.ArtifactTypes.ExtractedText)
                    {
                        _log.LogTrace("Skipping file {0} (not original text)", file.Name);
                        continue;
                    }

                    // Use a different partitioning strategy depending on the file type
                    List<string> partitions = new();
                    BinaryData partitionContent = await _orchestrator.ReadFileAsync(pipeline, file.Name, cancellationToken).ConfigureAwait(false);
                    string partitionsMimeType = MimeTypes.PlainText;

                    // Skip empty partitions. Also: partitionContent.ToString() throws an exception if there are no bytes.
                    if (partitionContent.ToArray().Length == 0)
                    {
                        continue;
                    }

                    _log.LogDebug("Partitioning MarkDown file {0}", file.Name);
                    string content = partitionContent.ToString();
                    partitionsMimeType = MimeTypes.MarkDown;

                    var maxTokensPerParagraph = context.GetCustomPartitioningMaxTokensPerParagraphOrDefault(_options.MaxTokensPerParagraph);
                    var overlappingTokens = context.GetCustomPartitioningOverlappingTokensOrDefault(_options.OverlappingTokens);

                    var splitter = new MarkdownHeaderTextSplitter();
                    var partitionList = splitter.SplitText(content).ToList();

                    for (var i = 0; i < partitionList.Count; i++)
                    {
                        var stringBuilder = new StringBuilder();
                        stringBuilder.AppendLine(partitionList[i]);
                        var tokencount = tokenizer.CountTokens(partitionList[i]);

                        while (tokencount < maxTokensPerParagraph && i < partitionList.Count - 1)
                        {
                            tokencount += tokenizer.CountTokens(partitionList[i + 1]);
                            if (tokencount <= maxTokensPerParagraph)
                            {
                                i++;
                                stringBuilder.AppendLine(partitionList[i]);
                            }
                            else
                            {
                                break;
                            }
                        }

                        // If single partition is too large, split into multiple partitions with 10% overlap
                        if (tokenizer.CountTokens(stringBuilder.ToString()) > maxTokensPerParagraph)
                        {
                            var textSplitter = new CharacterTextSplitter(" ", maxTokensPerParagraph, overlappingTokens, (x) => tokenizer.CountTokens(x));
                            partitions.AddRange(textSplitter.SplitText(stringBuilder.ToString()));                            
                        }
                        else
                        {
                            partitions.Add(stringBuilder.ToString());
                        }
                    }

                    if (partitions.Count == 0) { continue; }

                    _log.LogDebug("Saving {0} file partitions", partitions.Count);
                    for (int partitionNumber = 0; partitionNumber < partitions.Count; partitionNumber++)
                    {
                        // TODO: turn partitions in objects with more details, e.g. page number
                        string text = partitions[partitionNumber];
                        int sectionNumber = 0; // TODO: use this to store the page number (if any)
                        BinaryData textData = new(text);

                        var destFile = uploadedFile.GetPartitionFileName(partitionNumber);
                        await _orchestrator.WriteFileAsync(pipeline, destFile, textData, cancellationToken).ConfigureAwait(false);

                        var destFileDetails = new DataPipeline.GeneratedFileDetails
                        {
                            Id = Guid.NewGuid().ToString("N"),
                            ParentId = uploadedFile.Id,
                            Name = destFile,
                            Size = text.Length,
                            MimeType = partitionsMimeType,
                            ArtifactType = DataPipeline.ArtifactTypes.TextPartition,
                            PartitionNumber = partitionNumber,
                            SectionNumber = sectionNumber,
                            Tags = pipeline.Tags,
                            ContentSHA256 = CalculateSHA256(textData),
                        };
                        newFiles.Add(destFile, destFileDetails);
                        destFileDetails.MarkProcessedBy(this);
                    }

                    file.MarkProcessedBy(this);
                }

                // Add new files to pipeline status
                foreach (var file in newFiles)
                {
                    uploadedFile.GeneratedFiles.Add(file.Key, file.Value);
                }
            }

            return (ReturnType.Success, pipeline);
        }

        public static string CalculateSHA256(BinaryData binaryData)
        {
            byte[] byteArray = SHA256.HashData(binaryData.ToMemory().Span);
            return Convert.ToHexString(byteArray).ToLowerInvariant();
        }
    }
}

#pragma warning restore KMEXP00 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.