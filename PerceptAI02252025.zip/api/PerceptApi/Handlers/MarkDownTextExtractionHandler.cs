﻿using Azure;
using Azure.AI.DocumentIntelligence;
using Azure.Core;
using Microsoft.Extensions.Azure;
using Microsoft.KernelMemory.DataFormats;
using Microsoft.KernelMemory.Diagnostics;
using Microsoft.KernelMemory.Handlers;
using Microsoft.KernelMemory.Pipeline;
using Percept.Shared.Configuration;
using System.Text;

namespace PerceptApi.Handlers
{
    public class MarkDownTextExtractionHandler : IPipelineStepHandler
    {
        public string StepName { get; }

        private readonly IPipelineOrchestrator _orchestrator;
        private readonly IEnumerable<IContentDecoder> _decoders;
        private readonly ILogger<TextExtractionHandler> _log;
        private readonly DocumentIntelligenceClient _client;

        public MarkDownTextExtractionHandler(
            string stepName,
            IPipelineOrchestrator orchestrator,
            IEnumerable<IContentDecoder> decoders,
            IAzureClientFactory<DocumentIntelligenceClient> azureFactory,
            ILoggerFactory? loggerFactory = null)
        {
            StepName = stepName;
            _orchestrator = orchestrator;
            _decoders = decoders;
            _log = (loggerFactory ?? DefaultLogger.Factory).CreateLogger<TextExtractionHandler>();

            _client = azureFactory.CreateClient(ConfigurationProperties.DocumentIntelligenceClientServiceName);

            _log.LogInformation("Handler '{0}' ready", stepName);
        }

        public async Task<(ReturnType returnType, DataPipeline updatedPipeline)> InvokeAsync(DataPipeline pipeline, CancellationToken cancellationToken = default)
        {
            _log.LogDebug("Extracting text, pipeline '{0}/{1}'", pipeline.Index, pipeline.DocumentId);

            foreach (DataPipeline.FileDetails uploadedFile in pipeline.Files)
            {
                if (uploadedFile.AlreadyProcessedBy(this))
                {
                    _log.LogTrace("File {0} already processed by this handler", uploadedFile.Name);
                    continue;
                }

                var sourceFile = uploadedFile.Name;
                var destFile = $"{uploadedFile.Name}.extract.txt";
                var destFile2 = $"{uploadedFile.Name}.extract.json";
                BinaryData fileContent = await _orchestrator.ReadFileAsync(pipeline, sourceFile, cancellationToken).ConfigureAwait(false);

                string text = string.Empty;
                FileContent content = new(MimeTypes.PlainText);
                bool skipFile = false;

                if (fileContent.ToArray().Length > 0)
                {
                    (text, content, skipFile) = await ExtractTextAsync(uploadedFile, fileContent, cancellationToken).ConfigureAwait(false);
                }

                // If the handler cannot extract text, we move on. There might be other handlers in the pipeline
                // capable of doing so, and in any case if a document contains multiple docs, the pipeline will
                // not fail, only do its best to export as much data as possible. The user can inspect the pipeline
                // status to know if a file has been ignored.
                if (!skipFile)
                {
                    // Text file
                    _log.LogDebug("Saving extracted text file {0}", destFile);
                    await _orchestrator.WriteFileAsync(pipeline, destFile, new BinaryData(text), cancellationToken).ConfigureAwait(false);
                    var destFileDetails = new DataPipeline.GeneratedFileDetails
                    {
                        Id = Guid.NewGuid().ToString("N"),
                        ParentId = uploadedFile.Id,
                        Name = destFile,
                        Size = text.Length,
                        MimeType = content.MimeType,
                        ArtifactType = DataPipeline.ArtifactTypes.ExtractedText,
                        Tags = pipeline.Tags,
                    };
                    destFileDetails.MarkProcessedBy(this);
                    uploadedFile.GeneratedFiles.Add(destFile, destFileDetails);

                    // Structured content (pages)
                    _log.LogDebug("Saving extracted content {0}", destFile2);
                    await _orchestrator.WriteFileAsync(pipeline, destFile2, new BinaryData(content), cancellationToken).ConfigureAwait(false);
                    var destFile2Details = new DataPipeline.GeneratedFileDetails
                    {
                        Id = Guid.NewGuid().ToString("N"),
                        ParentId = uploadedFile.Id,
                        Name = destFile2,
                        Size = text.Length,
                        MimeType = content.MimeType,
                        ArtifactType = DataPipeline.ArtifactTypes.ExtractedContent,
                        Tags = pipeline.Tags,
                    };
                    destFile2Details.MarkProcessedBy(this);
                    uploadedFile.GeneratedFiles.Add(destFile2, destFile2Details);
                }

                uploadedFile.MarkProcessedBy(this);
            }

            return (ReturnType.Success, pipeline);
        }

        private async Task<(string text, FileContent content, bool skipFile)> ExtractTextAsync(
            DataPipeline.FileDetails uploadedFile,
            BinaryData fileContent,
            CancellationToken cancellationToken)
        {
            // Define default empty content
            var content = new FileContent(MimeTypes.MarkDown);

            if (string.IsNullOrEmpty(uploadedFile.MimeType))
            {
                uploadedFile.Log(this, $"File MIME type is empty, ignoring the file {uploadedFile.Name}");
                _log.LogWarning("Empty MIME type, file '{0}' will be ignored", uploadedFile.Name);
                return (text: string.Empty, content, skipFile: true);
            }

            _log.LogDebug("Extracting text from file '{FileName}' mime type '{MimeType}' using extractor 'Markdown'",
                    uploadedFile.Name, uploadedFile.MimeType);

            var analyzeDocumentOptions = new AnalyzeDocumentOptions("prebuilt-layout", fileContent)
            {
                OutputContentFormat = DocumentContentFormat.Markdown
            };
            var operation = await _client.AnalyzeDocumentAsync(WaitUntil.Completed, analyzeDocumentOptions, cancellationToken);
            var result = operation.Value;

            content.Sections.Add(new FileSection(1, result.Content, true));

            var textBuilder = new StringBuilder();
            foreach (var section in content.Sections)
            {
                var sectionContent = section.Content.Trim();
                if (string.IsNullOrEmpty(sectionContent)) { continue; }

                textBuilder.Append(sectionContent);

                // Add a clean page separation
                if (section.SentencesAreComplete)
                {
                    textBuilder.AppendLine();
                    textBuilder.AppendLine();
                }
            }

            var text = textBuilder.ToString().Trim();

            return (text, content, skipFile: false);
        }
    }
}
