﻿namespace PerceptApi.Enums
{
    public enum UserType
    {
        User,
        System,
        AI,
    }
}
