﻿namespace PerceptApi.Enums
{
    public enum AppPermissions
    {
        Read = 0,
        Create,
        Update,
        RbacAdmin,
        RbacViewer,
        Chat,
        Admin,
        Enable,
        Disable,
        Archive,
    }
}
