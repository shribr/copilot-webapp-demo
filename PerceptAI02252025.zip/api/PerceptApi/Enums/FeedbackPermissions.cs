﻿namespace PerceptApi.Enums
{
    [Flags]
    public enum FeedbackPermissions
    {
        None = 0,
        Viewer = 1,
    }
}
