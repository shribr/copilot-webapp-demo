﻿namespace PerceptApi.Enums
{
    [Flags]
    public enum DataSourceRoles
    {
        None = 0,
        DataManager = 2,
    }
}
