﻿namespace PerceptApi.Enums
{
    public enum DataSourcePermissions
    {
        Create = 0,
        Update,
        RbacAdmin,
        RbacViewer,
        Delete,
        Read,
        TagViewer,
        Download,
        DocumentManager,
        DocumentViewer,
    }
}
