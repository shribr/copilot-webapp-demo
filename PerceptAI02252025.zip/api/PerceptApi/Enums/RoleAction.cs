﻿namespace PerceptApi.Enums
{
    public enum RoleAction
    {
        Add = 1,
        Remove = 2
    }
}
