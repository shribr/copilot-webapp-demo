﻿namespace PerceptApi.Enums
{
    public enum Reaction
    {
        Any = -1,
        Dislike = 0,
        Like = 1
    }
}
