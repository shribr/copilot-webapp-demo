﻿namespace PerceptApi.Enums
{
    public enum AgentPermissions
    {
        None = 0,
        Read,
        Create,
        Update,
        Delete,
        Archive,
        Disable,
        Enable,
    }
}
