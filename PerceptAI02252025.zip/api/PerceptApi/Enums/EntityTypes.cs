﻿namespace PerceptApi.Enums
{
    public enum EntityTypes
    {
        DataSource = 0,
        Agent = 1,
        AppRegistration = 2,
        System = 100,
    }
}
