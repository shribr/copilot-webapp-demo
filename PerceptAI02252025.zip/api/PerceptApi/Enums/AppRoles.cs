﻿using System.ComponentModel;

namespace PerceptApi.Enums
{
    [Flags]
    public enum AppRoles
    {
        [Attributes.DisplayName("Deny Access"), Description("NOT IN USE AT THIS TIME")]
        None = 0,
        [Attributes.DisplayName("App User"), Description("Can chat with agents and submit feedback")]
        User = 1,
        [Attributes.DisplayName("App Owner"), Description("Can administer all aspects of the app, including RBAC, creating agents, and creating data sources/connectors")]
        Owner = 2,
        [Attributes.DisplayName("RBAC Administrator"), Description("Can administer permissions")]
        RBACAdmin = 4,
        [Attributes.DisplayName("Feedback Viewer"), Description("Can review feedback submissions")]
        FeedbackViewer = 8
    }
}
