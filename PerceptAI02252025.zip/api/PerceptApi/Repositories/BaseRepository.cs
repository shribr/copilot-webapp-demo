using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data.Entities;
using PerceptApi.Data;
using PerceptApi.Repositories.Interfaces;
using System.Linq.Expressions;

namespace PerceptApi.Repositories
{
    public class BaseRepository<TEntity>(PerceptDbContext context) : IBaseRepository<TEntity> where TEntity : class, IHasGuidId
    {
        protected readonly DbContext Context = context;
        private readonly DbSet<TEntity> _entities = context.Set<TEntity>();

        public TEntity? GetById(Guid id, bool trackChanges = false)
        {
            return GetAllByCondition(x => x.Id.Equals(id), trackChanges).FirstOrDefault();
        }

        public IQueryable<TEntity> GetAllByCondition(Expression<Func<TEntity, bool>> expression, bool trackChanges)
        {
            return trackChanges
                    ? GetAll().Where(expression)
                    : GetAll().Where(expression).AsNoTracking();
        }

        public IQueryable<TEntity> GetAll()
        {
            return _entities.AsQueryable();
        }

        public IQueryable<TEntity> FromSqlRaw(string query, params SqlParameter[] parameters)
        {
            return _entities.FromSqlRaw(query, parameters);
        }

        public void Add(TEntity entity)
        {
            _entities.Add(entity);
        }

        public void Remove(TEntity entity)
        {
            _entities.Remove(entity);
        }

        public async Task SaveAsync()
        {
            await Context.SaveChangesAsync();
        }

        public void Update(TEntity entity)
        {
            _entities.Update(entity);
        }
    }
}