﻿using Microsoft.Data.SqlClient;
using System.Linq.Expressions;

namespace PerceptApi.Repositories.Interfaces
{
    public interface IBaseRepository<TEntity> where TEntity : class
    {
        TEntity? GetById(Guid id, bool trackChanges = false);
        IQueryable<TEntity> GetAll();
        void Add(TEntity entity);
        void Remove(TEntity entity);
        Task SaveAsync();
        IQueryable<TEntity> GetAllByCondition(Expression<Func<TEntity, bool>> expression, bool trackChanges);
        void Update(TEntity entity);
        IQueryable<TEntity> FromSqlRaw(string query, params SqlParameter[] parameters);
    }
}
