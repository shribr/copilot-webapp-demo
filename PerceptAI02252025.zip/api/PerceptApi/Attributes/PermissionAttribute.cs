﻿using Microsoft.AspNetCore.Authorization.Infrastructure;

namespace PerceptApi.Attributes
{
    public class PermissionAttribute : Attribute
    {
        public OperationAuthorizationRequirement Operation { get; set; }
        public bool OnlyAuthorizeFirst { get; set; }
    }

    public class PermissionAttribute<TRequirement, TPermission> : PermissionAttribute where TRequirement : OperationAuthorizationRequirement, new() where TPermission : Enum
    {
        public PermissionAttribute(TPermission permission, bool onlyAuthorizeFirst = false)
        {
            Operation = new TRequirement { Name = permission.ToString() };
            OnlyAuthorizeFirst = onlyAuthorizeFirst;
        }
    }
}
