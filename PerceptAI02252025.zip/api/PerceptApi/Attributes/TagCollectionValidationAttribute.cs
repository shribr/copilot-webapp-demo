﻿using System.ComponentModel.DataAnnotations;

namespace PerceptApi.Attributes
{
    public class TagCollectionValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value is IDictionary<string, List<string?>> tagCollection)
            {
                var invalidKeys = tagCollection.Keys.Where(key => key.StartsWith(Microsoft.KernelMemory.Constants.ReservedTagsPrefix, StringComparison.Ordinal)).ToList();
                if (invalidKeys.Count != 0)
                {
                    return new ValidationResult($"Keys cannot start with a Reserved Tag Prefix. Invalid keys: {string.Join(", ", invalidKeys)}");
                }
            }
            return ValidationResult.Success;
        }
    }
}