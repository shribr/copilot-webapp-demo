﻿using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Web;

namespace PerceptApi.Attributes
{
    public class RouteNameValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            var unauthorizedCharacters = new List<string>();

            var routeName = value?.ToString() ?? string.Empty;
            for (var i = 0; i < routeName.Length; i++)
            {
                var character = routeName[i];
                var encodedValue = HttpUtility.UrlEncode(Encoding.UTF8.GetBytes([character]));
                if (character.ToString() != encodedValue)
                {
                    var unauthorizedChar = character == ' ' ? "<Space>" : character.ToString();
                    unauthorizedCharacters.Add(unauthorizedChar);
                }
            }

            if (unauthorizedCharacters.Any())
            {
                return new ValidationResult($"These characters are not allowed: {string.Join(',', unauthorizedCharacters.Distinct())}");
            }
            else
            {
                return ValidationResult.Success;
            }
        }
    }
}
