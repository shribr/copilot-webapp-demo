﻿namespace PerceptApi.Attributes
{
    public class SwaggerBaseAttribute : Attribute
    {
    }
}
