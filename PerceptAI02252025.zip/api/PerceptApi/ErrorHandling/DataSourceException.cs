﻿namespace PerceptApi.ErrorHandling
{
    public class DataSourceException : Exception
    {
        public DataSourceException(string? message) : base(message) { }
    }
}
