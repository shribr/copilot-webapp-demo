﻿namespace PerceptApi.ErrorHandling
{
    public class AppRegistrationNotFoundException(string? message) : Exception(message)
    {
    }
}
