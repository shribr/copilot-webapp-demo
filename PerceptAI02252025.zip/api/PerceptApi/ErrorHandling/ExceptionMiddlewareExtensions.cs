﻿using Microsoft.AspNetCore.Diagnostics;

namespace PerceptApi.ErrorHandling
{
    public static class ExceptionMiddlewareExtensions
    {
        public static void ConfigureExceptionHandler(this WebApplication app, ILogger logger)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.ContentType = "application/json";

                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if (contextFeature != null)
                    {
                        context.Response.StatusCode = contextFeature.Error switch
                        {
                            NotFoundException or DataSourceNotFound or AppRegistrationNotFoundException => StatusCodes.Status404NotFound,
                            AgentNotFoundException => StatusCodes.Status503ServiceUnavailable,
                            _ => StatusCodes.Status500InternalServerError
                        };

                        var error = contextFeature.Error;

                        logger.LogError("Error: {error}", error);

                        await context.Response.WriteAsync(contextFeature.Error.Message);
                    }
                });
            });
        }
    }
}