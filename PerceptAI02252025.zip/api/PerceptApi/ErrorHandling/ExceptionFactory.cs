﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Data.Common;

namespace PerceptApi.ErrorHandling;

static class ExceptionFactory
{
    internal static Exception Create<T>(ExceptionProcessorInterceptor<T>.DatabaseError error, DbUpdateException exception, IReadOnlyList<EntityEntry> entries) where T : DbException
    {
        var innerException = exception.InnerException ?? new Exception();
        return error switch
        {
            ExceptionProcessorInterceptor<T>.DatabaseError.CannotInsertNull when entries.Count > 0 => new CannotInsertNullException("Cannot insert null", innerException, entries),
            ExceptionProcessorInterceptor<T>.DatabaseError.CannotInsertNull when entries.Count == 0 => new CannotInsertNullException("Cannot insert null", innerException),
            ExceptionProcessorInterceptor<T>.DatabaseError.MaxLength when entries.Count > 0 => new MaxLengthExceededException("Maximum length exceeded", innerException, entries),
            ExceptionProcessorInterceptor<T>.DatabaseError.MaxLength when entries.Count == 0 => new MaxLengthExceededException("Maximum length exceeded", innerException),
            ExceptionProcessorInterceptor<T>.DatabaseError.NumericOverflow when entries.Count > 0 => new NumericOverflowException("Numeric overflow", innerException, entries),
            ExceptionProcessorInterceptor<T>.DatabaseError.NumericOverflow when entries.Count == 0 => new NumericOverflowException("Numeric overflow", innerException),
            ExceptionProcessorInterceptor<T>.DatabaseError.ReferenceConstraint when entries.Count > 0 => new ReferenceConstraintException("Reference constraint violation", innerException, entries),
            ExceptionProcessorInterceptor<T>.DatabaseError.ReferenceConstraint when entries.Count == 0 => new ReferenceConstraintException("Reference constraint violation", innerException),
            ExceptionProcessorInterceptor<T>.DatabaseError.UniqueConstraint when entries.Count > 0 => new UniqueConstraintException("Unique constraint violation", innerException, entries),
            ExceptionProcessorInterceptor<T>.DatabaseError.UniqueConstraint when entries.Count == 0 => new UniqueConstraintException("Unique constraint violation", innerException),
            _ => throw new InvalidOperationException("Unhandled database error."),
        };
    }

}