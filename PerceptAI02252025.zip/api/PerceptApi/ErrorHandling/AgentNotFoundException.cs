﻿namespace PerceptApi.ErrorHandling
{
    public class AgentNotFoundException : Exception
    {
        public AgentNotFoundException(string? message) : base(message)
        {
        }
    }
}
