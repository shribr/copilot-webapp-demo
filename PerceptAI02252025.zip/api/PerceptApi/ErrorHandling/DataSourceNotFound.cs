﻿namespace PerceptApi.ErrorHandling
{
    public class DataSourceNotFound(string? message) : Exception(message)
    {
    }
}
