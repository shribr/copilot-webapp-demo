﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.Extensions;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using System.Security.Principal;

namespace PerceptApi.Controllers
{
    [ApiController]
    [Route("api/AppRegistrations/{appId:guid}/[controller]")]
    public class ConversationsController(IConversationService conversationService, ILogger<ConversationsController> logger, IAppRegistrationService appRegistrationService, IAuthorizationService authorizationService, IMapper mapper, IPrincipal authenticatedUser) : AuthorizationController<AppRegistration>(authorizationService)
    {
        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpPost("ask")]
        public async Task<ActionResult<ChatMessage>> AskAsync([FromBody] AgentQuery query, [FromRoute] Guid appId, CancellationToken cancellationToken)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            // NOTE: Do not log questions to limit risk of storing a question that may contain CUI
            logger.LogTrace("Conversation Request, ConversationId '{0}', AgentId {1}", query.ConversationId, query.AgentId);
            var conversation = conversationService.GetOrCreateConversation(query);
            var authenticatedUserId = authenticatedUser.GetUserId();
            if (!conversation.DirectoryEntryId.Equals(authenticatedUserId))
            {
                return Unauthorized();
            }

            var answer = await conversationService.AskAsync(conversation, query, cancellationToken);
            return Ok(answer);
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpGet("my")]
        public async Task<ActionResult<IEnumerable<ChatConversationItemDto>>> GetConversations([FromRoute] Guid appId)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            // Ignore the id in the route because users can only retrieve thier own conversations
            var authenticatedUserId = authenticatedUser.GetUserId();
            if (!authenticatedUserId.HasValue)
            {
                return Unauthorized();
            }
            var appUserConversations = conversationService.GetAppUserChatConversations(appId, authenticatedUserId.Value);
            return Ok(mapper.Map<IEnumerable<ChatConversationItemDto>>(appUserConversations));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpGet("{id}")]
        public async Task<ActionResult<ChatConversationDto>> Get(Guid id, [FromRoute] Guid appId)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var ownershipValidationResult = ValidateConversationOwnership(id, true);
            if (ownershipValidationResult.Result != null)
            {
                return ownershipValidationResult.Result;
            }

            var conversation = ownershipValidationResult.Value;

            var chatConversationDto = new ChatConversationDto
            {
                Name = conversation.Name,
                CreatedOn = conversation.CreatedOn,
                Id = conversation.Id,
                AgentId = conversation.AgentId,
                AgentName = conversation.Agent.Name,
                Messages = conversation.GetChatMessages(Request),
                AgentQueryContext = conversation.AgentQueryContexts.LastOrDefault().Value,
            };

            return Ok(chatConversationDto);
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpGet("{id}/Messages/{messageId}/ThoughtProcess")]
        public async Task<ActionResult<ThoughtProcess>> GetConversationCitations(Guid id, string messageId, [FromRoute] Guid appId)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }
            var ownershipValidationResult = ValidateConversationOwnership(id, true);
            if (ownershipValidationResult.Result != null)
            {
                return ownershipValidationResult.Result;
            }

            var conversation = ownershipValidationResult.Value;

            return Ok(conversation.GetThoughtProcess(messageId, Request));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpPatch("{id}")]
        public async Task<IActionResult> PatchAsync([FromRoute] Guid id, [FromRoute] Guid appId, [FromBody] UpdateConversationDto updateConversationDto)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }
            var ownershipValidationResult = ValidateConversationOwnership(id);
            if (ownershipValidationResult.Result != null)
            {
                return ownershipValidationResult.Result;
            }

            var conversation = ownershipValidationResult.Value!;
            conversation.Name = updateConversationDto.Name;

            await conversationService.UpdateAsync(conversation);
            return Ok(true);
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid id, [FromRoute] Guid appId)
        {
            var app = appRegistrationService.GetById(appId);
            if (app is null)
            {
                return NotFound("Unable to find app registration");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var ownershipValidationResult = ValidateConversationOwnership(id);

            if (ownershipValidationResult.Result is NotFoundResult)
            {
                return Ok(false);
            }

            if (ownershipValidationResult.Result != null)
            {
                return ownershipValidationResult.Result;
            }
            logger.LogInformation("{UserName} is deleting {Type} with Id={Id}", User.GetDisplayName(), typeof(ChatConversation), id);
            var result = await conversationService.SoftDeleteAsync(id);
            return Ok(result);
        }

        private ActionResult<ChatConversation> ValidateConversationOwnership(Guid id, bool includeMessages = false)
        {
            var authenticatedUserId = authenticatedUser.GetUserId();

            var conversation = conversationService.GetByIdWithAgent(id);

            if (conversation == null || conversation.Agent.IsDisabled)
            {
                return NotFound();
            }

            if (!conversation.DirectoryEntryId.Equals(authenticatedUserId))
            {
                return Unauthorized();
            }

            return conversation;
        }
    }
}
