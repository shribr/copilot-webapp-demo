﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using Microsoft.KernelMemory;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Constants;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using PerceptApi.Utils;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;

namespace PerceptApi.Controllers
{
    [Route("api/AppRegistrations/{appId:guid}/[controller]")]
    [ApiController]
    public class AgentsController(IAgentService agentService, ILogger<AgentsController> logger, IMapper mapper, IMemoryStoreService memoryStoreService,
        IAuthorizationService authorizationService) :
        ApiAppControllerBase<Agent, AgentRequestDto, AgentResponseDto>(agentService, logger, mapper, authorizationService)
    {
        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Read)]
        public override Task<ActionResult<AgentResponseDto>> GetById([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.GetById(appId, id);
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Delete)]
        public override Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.DeleteAsync(appId, id);
        }        

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Read)]
        [HttpGet()]
        public override async Task<ActionResult<PagedResponseDto<AgentResponseDto>>> Get([FromRoute] Guid appId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {
            // TODO: Story #8716 Authorize the User for the AppRegistration
            var agents = agentService.GetByApp(appId);

            if (!string.IsNullOrEmpty(filter))
            {
                agents = agents.Where(a => a.Name.ToLower().Contains(filter.ToLower()));
            }

            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(sortDirection))
            {
                agents = DynamicSorting.SortByProperty(agents, sortBy, sortDirection);
            }
            else
            {
                agents = agents.OrderBy(a => a.Name);
            }

            var authAgents = await FilterAuthorized(agents);

            var result = _mapper.Map<PagedResponseDto<AgentResponseDto>>(new PagedResponse<Agent>(page, pageSize, authAgents.AsQueryable()));
            return Ok(result);
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Read)]
        [HttpGet("Chat")]
        public async Task<ActionResult<PagedResponseDto<AgentResponseDto>>> GetForChat([FromRoute] Guid appId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
        {
            // TODO: Story #8716 Authorize the User for the AppRegistration
            var agents = agentService.GetByApp(appId)
                                     .Where(x => !x.IsDisabled)
                                     .OrderBy(a => a.Name);

            var authAgents = await FilterAuthorized(agents);

            var result = _mapper.Map<PagedResponseDto<AgentResponseDto>>(new PagedResponse<Agent>(page, pageSize, authAgents.AsQueryable()));
            return Ok(result);
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Read)]
        [HttpGet("{id}/tags")]
        [OutputCache(Duration = 600, VaryByRouteValueNames = ["id"], Tags = ["{id}"])]
        public async Task<ActionResult<TagCollection>> GetTags([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            var agent = agentService.GetById(id);
            if (agent == null)
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(agent))
            {
                return Unauthorized();
            }

            var tags = await memoryStoreService.GetTagsAsync(id);
            var filteredTags = Services.TagCollectionExtensions.FilterReservedTags(tags);
            return Ok(filteredTags);
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Create)]
        [HttpPost()]
        public override async Task<ActionResult<AgentResponseDto>> CreateAsync([FromRoute] Guid appId, [FromBody] AgentRequestDto agentRequest)
        {
            if (!agentRequest.ApplicationId.Equals(appId))
            {
                return BadRequest(new { message = "The ApplicationId in the request body does not match the appId in the route." });
            };

            if (!await isAuthorized(_mapper.Map<Agent>(agentRequest)))
            {
                return Unauthorized();
            }

            var result = await agentService.CreateAgentAsync(agentRequest);
            return CreatedAtAction(nameof(GetById), new { appId, id = result.Id }, _mapper.Map<AgentResponseDto>(result));
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Update)]
        [HttpPut("{id}")]
        public async Task<ActionResult<bool>> PutAsync([FromRoute] Guid appId, [FromRoute] Guid id, [FromBody] AgentRequestDto agentRequest)
        {
            // TODO: Story #8717 Authorize the User for the AppRegistration
            // TODO: Story #8716 Authorize the User for Update the Agent
            if (agentRequest.ApplicationId != appId)
            {
                return BadRequest(new { message = "The ApplicationId in the request body does not match the appId in the route." });
            }
            var agent = agentService.GetById(id, true);
            if (agent == null) { return NotFound(); }
            if (agent.ApplicationId != appId)
            {
                return BadRequest();
            }

            if (!await isAuthorized(agent))
            {
                return Unauthorized();
            }

            var result = await agentService.PutAsync(agent, agentRequest);
            return Ok(result != null);
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Disable)]
        [HttpPut("{id}/Disable")]
        public async Task<ActionResult<AgentResponseDto>> DisableAsync([FromRoute] Guid id)
        {
            var agent = agentService.GetById(id, true);
            if (agent is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(agent))
            {
                return Unauthorized();
            }
            agent.IsDisabled = true;

            await agentService.CommitTransactionAsync();
            return Ok(mapper.Map<AgentResponseDto>(agent));
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Enable)]
        [HttpPut("{id}/Enable")]
        public async Task<ActionResult<AgentResponseDto>> EnableAsync([FromRoute] Guid id)
        {
            var agent = agentService.GetById(id, true);
            if (agent is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(agent))
            {
                return Unauthorized();
            }

            agent.IsDisabled = false;

            await agentService.CommitTransactionAsync();
            return Ok(mapper.Map<AgentResponseDto>(agent));
        }

        [Permission<AgentOperationAuthorizationRequirement, AgentPermissions>(AgentPermissions.Archive)]
        [HttpPut("{id}/Archive")]
        public async Task<ActionResult<AgentResponseDto>> ArchiveAsync([FromRoute] Guid id)
        {
            var agent = agentService.GetById(id, true);
            if (agent is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(agent))
            {
                return Unauthorized();
            }

            agent.IsArchived = true;

            await agentService.CommitTransactionAsync();
            return Ok(mapper.Map<AgentResponseDto>(agent));
        }
    }
}