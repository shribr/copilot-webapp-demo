﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.ErrorHandling;
using PerceptApi.Events;
using Percept.Shared.Loggers;
using PerceptApi.Models;
using PerceptApi.Services;
using PerceptApi.Services.Interfaces;
using PerceptApi.Utils;
using System.ComponentModel;
using System.Reflection;
using DisplayNameAttribute = PerceptApi.Attributes.DisplayNameAttribute;

namespace PerceptApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AppRegistrationsController(IAppRegistrationService appRegistrationService, ILogger<AppRegistrationsController> logger, IMapper mapper,
        IAuthorizationService authorizationService, IUserRoleService userRoleService, IPermissionService permissionService, IHttpContextAccessor contextAccessor) : AuthorizationController<AppRegistration>(authorizationService)
    {
        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Read)]
        [HttpGet]
        public virtual Task<ActionResult<PagedResponseDto<AppRegistrationDto>>> Get([FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {
            return GetApps(page, pageSize, nameof(Get), filter, sortBy, sortDirection);
        }        

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Admin)]
        [HttpGet("Admin")]
        public virtual Task<ActionResult<PagedResponseDto<AppRegistrationDto>>> GetForRegistration([FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {
            return GetApps(page, pageSize, nameof(GetForRegistration), filter, sortBy, sortDirection);
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Chat)]
        [HttpGet("Chat")]
        public virtual Task<ActionResult<PagedResponseDto<AppRegistrationDto>>> GetForChat([FromQuery] int page = 1, [FromQuery] int pageSize = 25)
        {
            return GetApps(page, pageSize, nameof(GetForChat));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Read)]
        [HttpGet("{routeName}")]
        public async Task<ActionResult<AppRegistrationDto>> GetByRouteName([FromRoute] string routeName)
        {
            var app = appRegistrationService.GetByRouteName(routeName) ?? throw new AppRegistrationNotFoundException($"App {routeName} not found.");

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var dto = mapper.Map<AppRegistrationDto>(app);
            return dto;
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Read)]
        [HttpGet("{id:guid}")]
        public async Task<ActionResult<AppRegistrationDto>> GetById([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id);
            if (app == null)
            {
                throw new AppRegistrationNotFoundException($"App {id} not found.");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var dto = mapper.Map<AppRegistrationDto>(app);
            return dto;
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Create)]
        [HttpPost]
        public async Task<ActionResult<AppRegistrationDto>> CreateAsync([FromBody] AppRegistrationRequestDto appRegistration)
        {
            var app = mapper.Map<AppRegistration>(appRegistration);

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var entityResult = await appRegistrationService.CreateAsync(app);

            var requestUrl = Request.GetDisplayUrl();
            return Created($"{requestUrl}/{entityResult.Id}", mapper.Map<AppRegistrationDto>(entityResult));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Update)]
        [HttpPut("{id}")]
        public async Task<ActionResult<AppRegistrationDto>> UpdateAsync([FromRoute] Guid id, [FromBody] AppRegistrationRequestDto appRegistration)
        {
            var updateApp = mapper.Map<AppRegistration>(appRegistration);
            updateApp.Id = id;

            if (!await isAuthorized(updateApp))
            {
                return Unauthorized();
            }

            var entityResult = await appRegistrationService.UpdateAsync(updateApp);
            return Ok(mapper.Map<AppRegistrationDto>(entityResult));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Disable)]
        [HttpPut("{id}/Disable")]
        public async Task<ActionResult<AppRegistrationDto>> DisableAsync([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id, true);
            if (app is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            app.IsDisabled = true;

            await appRegistrationService.CommitTransactionAsync();
            return Ok(mapper.Map<AppRegistrationDto>(app));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Enable)]
        [HttpPut("{id}/Enable")]
        public async Task<ActionResult<AppRegistrationDto>> EnableAsync([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id, true);
            if (app is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            app.IsDisabled = false;

            await appRegistrationService.CommitTransactionAsync();
            return Ok(mapper.Map<AppRegistrationDto>(app));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.Archive)]
        [HttpPut("{id}/Archive")]
        public async Task<ActionResult<AppRegistrationDto>> ArchiveAsync([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id, true);
            if (app is null)
            {
                return NotFound();
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            app.IsArchived = true;

            await appRegistrationService.CommitTransactionAsync();
            return Ok(mapper.Map<AppRegistrationDto>(app));
        }

        [HttpGet("{id:guid}/permissions/my")]
        public async Task<ActionResult<List<string>>> GetPermissions2([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id);
            if (app == null)
            {
                throw new AppRegistrationNotFoundException($"App {id} not found.");
            }

            return Ok(await permissionService.GetPermissions(contextAccessor.HttpContext.User, app));
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.RbacViewer)]
        [HttpGet("{id:guid}/permissions")]
        public async Task<ActionResult<IEnumerable<RoleDto<AppRoles>>>> GetPermissions([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id);
            if (app == null)
            {
                throw new AppRegistrationNotFoundException($"App {id} not found.");
            }

            if (!await isAuthorized(app))
            {
                return Unauthorized();
            }

            var appUserRoles = await userRoleService.GetByApp(id)
                                             .Include(ur => ur.DirectoryEntry)
                                             .Where(ur => ur.EntityType.Equals(EntityTypes.AppRegistration))
                                             .ToListAsync();

            var appRoles = Enum.GetValues<AppRoles>()
                               .Cast<AppRoles>()
                               .Where(permission => permission > 0)
                               .Select(permission =>
                               {
                                   var entriesInRole = appUserRoles
                                       .Where(ur => ((AppRoles)ur.Permission).HasFlag(permission))
                                       .Select(ur => ur.DirectoryEntry)
                                       .ToList();

                                   return ToRoleDto(permission, entriesInRole);
                               })
                               .ToList();

            return Ok(appRoles);
        }

        [HttpGet("{id:guid}/roles/my")]
        public async Task<ActionResult<IEnumerable<RoleDto<AppRoles>>>> GetMyRoles([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id);
            if (app == null)
            {
                throw new AppRegistrationNotFoundException($"App {id} not found.");
            }

            // Roles from DB
            var appUserRoles = (await userRoleService.GetUserRolesAsync(id, id, EntityTypes.AppRegistration, contextAccessor.HttpContext.User))
                .ToList();

            // Convert to Roles Enum and DTO
            var result = appUserRoles
                .SelectMany(ur => Enum.GetValues<AppRoles>()
                .Where(ar => (ur.Permission & (int)ar) != 0))
                .Distinct()
                .Select(role => ToRoleDto(role, new List<DirectoryEntry>()));

            return Ok(result);
        }

        [Permission<AppOperationAuthorizationRequirement, AppPermissions>(AppPermissions.RbacAdmin)]
        [HttpPatch("{id:guid}/permissions")]
        public async Task<ActionResult<bool>> UpdatePermissions([FromRoute] Guid id, [FromBody] RoleRequestDto<AppRoles>[] rolesToUpdate)
        {
            var app = appRegistrationService.GetById(id);
            if (app is null)
            {
                throw new AppRegistrationNotFoundException($"App {id} not found.");
            }

            var auditString = rolesToUpdate.Select(r => r.ToAuditString()).Aggregate((a, b) => $"{a}, {b}");

            if (!await isAuthorized(app))
            {
                InsightsLogger.AuditFailure(logger, PerceptEvents.RoleAssignment.Add, new { id, rolesToUpdate });
                return Unauthorized();
            }

            // reduce role to entry mapping to a single list of entry changes.
            var entryAdds = ReducePermissionChanges(rolesToUpdate.Where(r => r.Action == RoleAction.Add));
            var entryRemoves = ReducePermissionChanges(rolesToUpdate.Where(r => r.Action == RoleAction.Remove));

            // Not currently combining the add/remove into a single request. 
            // API is expecting a batch of add or remove only at this time
            if (entryAdds.Any() && entryRemoves.Any())
            {
                throw new ArgumentException("Update Permissions expects a batch of Add or Remove updates. It does not currently support a combination of Add and Remove in a single call.");
            }

            await userRoleService.AddPermissionsToUsersAsync(id, id, EntityTypes.AppRegistration, entryAdds);
            if (entryAdds.Any())
            {
                InsightsLogger.AuditSuccess(logger, PerceptEvents.RoleAssignment.Add, new { id, entryAdds });
            }
            await userRoleService.RemovePermissionsFromUsersAsync(id, id, EntityTypes.AppRegistration, entryRemoves);
            if (entryRemoves.Any())
            {
                InsightsLogger.AuditSuccess(logger, PerceptEvents.RoleAssignment.Remove, new { id, entryRemoves });
            }

            var requestUrl = Request.GetDisplayUrl();
            return Ok(true);
        }

        [HttpGet("{id:guid}/permissionMatrix")]
        public IActionResult GetAppPermissionMatrixExcel([FromRoute] Guid id)
        {
            var app = appRegistrationService.GetById(id) ?? throw new AppRegistrationNotFoundException($"App {id} not found.");

            var result = permissionService.GetPermissionMatrixExcel(id, app.IsDisabled);
            return File(result, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "PermissionMatrix.xlsx");
        }

        private static IEnumerable<DirectoryEntryRoleChange<T>> ReducePermissionChanges<T>(IEnumerable<RoleRequestDto<T>> roles) where T : Enum
        {
            var directoryEntryRoles = new Dictionary<Guid, DirectoryEntryRoleChange<T>>();

            foreach (var role in roles)
            {
                foreach (var entry in role.DirectoryEntries)
                {
                    if (directoryEntryRoles.TryGetValue(entry.ObjectId, out var entryRole))
                    {
                        entryRole.RoleFlagChange = (T)(object)((int)(object)entryRole.RoleFlagChange | (int)(object)role.RoleId);
                    }
                    else
                    {
                        directoryEntryRoles[entry.ObjectId] = new DirectoryEntryRoleChange<T>
                        {
                            Id = entry.Id.Value,
                            ObjectId = entry.ObjectId,
                            DisplayName = entry.DisplayName,
                            Email = entry.Email,
                            IsGroup = entry.IsGroup,
                            RoleFlagChange = role.RoleId
                        };
                    }
                }
            }

            return directoryEntryRoles.Values;
        }
 

        private async Task<ActionResult<PagedResponseDto<AppRegistrationDto>>> GetApps([FromQuery] int page = 1, [FromQuery] int pageSize = 25, string callingMember = "", [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {
            var entityResult = appRegistrationService.GetAll(false);

            if (!string.IsNullOrEmpty(filter))
            {
                entityResult = entityResult.Where(a => a.Name.Contains(filter, StringComparison.OrdinalIgnoreCase));
            }
            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(sortDirection))
            {
                entityResult = DynamicSorting.SortByProperty<AppRegistration>(entityResult.AsQueryable(), sortBy, sortDirection).AsEnumerable();
            }
            else
            {
                entityResult = entityResult.OrderBy(a => a.Name);
            }

            var filteredResults = new PagedResponse<AppRegistration>(page, pageSize, (await FilterAuthorized(entityResult, callingMember)).AsQueryable());

            var result = mapper.Map<PagedResponseDto<AppRegistrationDto>>(filteredResults);
            return Ok(result);
        }

        private RoleDto<AppRoles> ToRoleDto(AppRoles role, List<DirectoryEntry> entriesInRole)
        {
            var field = typeof(AppRoles).GetField(role.ToString());
            var displayName = field?.GetCustomAttribute<DisplayNameAttribute>()?.DisplayName ?? field?.Name;
            var description = field?.GetCustomAttribute<DescriptionAttribute>()?.Description ?? string.Empty;

            return new RoleDto<AppRoles>
            {
                RoleId = role,
                Description = description,
                RoleName = displayName,
                DirectoryEntries = mapper.Map<List<DirectoryEntryDto>>(entriesInRole)
            };
        }

    }
}
