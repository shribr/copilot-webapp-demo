﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PerceptApi.Controllers
{
    [Route("api/version")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        [HttpGet]
        public ActionResult<string> GetVersion()
        {
            var version = typeof(ApiController).Assembly.GetName().Version?.ToString() ?? "Version not found";
            return Ok(version);
        }
    }
}
