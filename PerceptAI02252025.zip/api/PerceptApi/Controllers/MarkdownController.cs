﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PerceptApi.DTOs;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class MarkdownController : ControllerBase
    {
        private readonly IMarkdownService markdownService;

        public MarkdownController(IMarkdownService markdownService)
        {
            this.markdownService = markdownService ?? throw new ArgumentNullException(nameof(markdownService));
        }

        [HttpPost("ExtractExcel")]
        public async Task<IActionResult> ExtractExcelAsync([FromBody] MessageDto markdownMessage)
        {
            using (var stream = markdownService.TableToExcel(markdownMessage.Message))
            {
                return File(stream.ToArray(), "application/octet-stream", "output.xlsx");
            }
        }
    }
}
