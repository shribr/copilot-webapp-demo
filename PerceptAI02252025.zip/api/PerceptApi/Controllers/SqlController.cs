﻿using Microsoft.AspNetCore.Mvc;
using PerceptApi.DTOs;
using PerceptApi.Extensions;
using PerceptApi.Sql;

namespace PerceptApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class SqlController : ControllerBase
    {
        [HttpPost()]
        //Auth: app owner (check for any app owner unless we cant reuse same auth handler then pass app id)
        public async Task<ActionResult<SchemaDefinition>> Get([FromBody] SqlSchemaRequestDto request)
        {
            try
            {
                if (!request.ConnectionString.HasIntegratedSecurity())
                {
                    return BadRequest("Integrated Security is required.");
                }

                var sqlProvider = new SqlSchemaProvider(request.ConnectionString);
                return Ok(await sqlProvider.GetSchemaAsync(request.Description));
            }
            catch (ArgumentException)
            {
                return BadRequest($"'{request.ConnectionString}' is not a valid connection string.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
