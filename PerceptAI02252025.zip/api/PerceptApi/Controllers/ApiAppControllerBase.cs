﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Percept.Shared.Data.Entities;
using PerceptApi.Constants;
using PerceptApi.DTOs;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Controllers
{
    public abstract class ApiAppControllerBase<T, TRequest, TResponse>(IAppBaseService<T> service, ILogger logger, IMapper mapper, IAuthorizationService authorizationService)
    : AuthorizationController<T>(authorizationService)
        where T : class, IHasGuidId, IHasApplicationId
    where TRequest : class
    where TResponse : class, IHasGuidId
    {
        protected readonly IAppBaseService<T> _service = service;
        protected readonly ILogger _logger = logger;
        protected readonly IMapper _mapper = mapper;        

        [HttpGet]
        public virtual async Task<ActionResult<PagedResponseDto<TResponse>>> Get(
            [FromRoute] Guid appId,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 25,
            [FromQuery] string? filter = null,
            [FromQuery] string? sortBy = null,
            [FromQuery] string? sortDirection = null)
        {
            var query = await internalGet(appId, nameof(Get));

            if (!string.IsNullOrEmpty(filter))
            {
                _logger.LogInformation($"Filtering {typeof(T)} by {filter}");
                query = query.Where(x => x.ToString().ToLower().Contains(filter.ToLower()));
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                _logger.LogInformation($"Sorting {typeof(T)} by {sortBy} {sortDirection}");
                query = sortDirection == SortingDirections.Descending ? query.OrderByDescending(x => EF.Property<object>(x, sortBy))
                                 : query.OrderBy(x => EF.Property<object>(x, sortBy));
            }

            var response = new PagedResponse<T>(page, pageSize, query);
            return Ok(_mapper.Map<PagedResponseDto<TResponse>>(response));
        }

        [HttpGet("{id:guid}")]
        public virtual async Task<ActionResult<TResponse>> GetById([FromRoute] Guid appId, [FromRoute] Guid id)
        {           
            var entityResult = _service.GetById(id);
            if (entityResult == null || !entityResult.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(entityResult))
            {
                return Unauthorized();
            }

            return Ok(_mapper.Map<TResponse>(entityResult));
        }

        [HttpPost]
        public virtual async Task<ActionResult<TResponse>> CreateAsync([FromRoute] Guid appId, [FromBody] TRequest item)
        {
            var entityToCreate = _mapper.Map<T>(item);

            if (!await isAuthorized(entityToCreate))
            {
                return Unauthorized();
            }

            var entityResult = await _service.CreateAsync(entityToCreate);
            if (!entityResult.ApplicationId.Equals(appId))
            {
                return BadRequest(new { message = "The ApplicationId in the request body does not match the appId in the route." });
            };

            var requestUrl = Request.GetDisplayUrl();
            return Created($"{requestUrl}/{entityResult.Id}", _mapper.Map<TResponse>(entityResult));
        }

        [HttpDelete("{id}")]
        public virtual async Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            _logger.LogInformation($"{User.GetDisplayName()} is deleting {typeof(T)} with Id={id}");

            var entityResult = _service.GetById(id);

            if (!await isAuthorized(entityResult))
            {
                return Unauthorized();
            }

            var result = await _service.DeleteAsync(id);
            return Ok(result);
        }

        protected async Task<IQueryable<T>> internalGet(Guid appId, string callingMember = "")
        {
            var results = _service.GetAllByCondition(x => x.ApplicationId.Equals(appId), false).ToList();

            return (await FilterAuthorized(results, callingMember)).AsQueryable();
        }

        protected async Task<IEnumerable<T>> internalGet(IQueryable<T> entityQuery, string callingMember = "")
        {
            var results = entityQuery.ToList();                

            return (await FilterAuthorized(results, callingMember));
        }

    }

}
