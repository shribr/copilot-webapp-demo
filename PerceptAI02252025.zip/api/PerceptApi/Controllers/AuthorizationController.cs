﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Percept.Shared.Data.Entities;
using PerceptApi.Attributes;
using System.Runtime.CompilerServices;

namespace PerceptApi.Controllers
{
    public abstract class AuthorizationController<T> : ControllerBase where T : class, IHasGuidId
    {
        private readonly IAuthorizationService authorizationService;

        public AuthorizationController(IAuthorizationService authorizationService)
        {
            this.authorizationService = authorizationService ?? throw new ArgumentNullException(nameof(authorizationService));
        }

        protected async Task<bool> isAuthorized(T entity, [CallerMemberName] string methodName = "")
        {
            var attribute = GetType().GetMethod(methodName)?.GetCustomAttributes(typeof(PermissionAttribute), false).Cast<PermissionAttribute>().FirstOrDefault();

            return await isAuthorized(attribute, entity);
        }

        protected async Task<bool> isAuthorized(PermissionAttribute attribute, T entity)
        {
            // No auth required if there isnt an attribute.
            if (attribute is null)
            {
                return true;
            }

            var authorized = await authorizationService.AuthorizeAsync(User, entity, attribute.Operation);
            return authorized.Succeeded;
        }

        protected async Task<IEnumerable<T>> FilterAuthorized(IEnumerable<T> entity, [CallerMemberName] string methodName = "")
        {
            var attribute = GetType().GetMethod(methodName)?.GetCustomAttributes(typeof(PermissionAttribute), false).Cast<PermissionAttribute>().FirstOrDefault();

            if (attribute is null)
            {
                //No authorization required return object.
                return entity;
            }

            if (attribute.OnlyAuthorizeFirst && entity.Any())
            {
                var authorized = await isAuthorized(attribute, entity.First());
                if (authorized)
                {
                    return entity;
                }

                return Array.Empty<T>();
            }

            return entity.ToList().Where(x =>
            {
                var authorizedTask = isAuthorized(attribute, x);
                authorizedTask.Wait();
                return authorizedTask.Result;
            });
        }
    }
}
