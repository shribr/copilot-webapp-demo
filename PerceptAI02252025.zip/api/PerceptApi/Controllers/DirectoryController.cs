using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web.Resource;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DirectoryController(IMapper mapper, IGraphService graphService) : ControllerBase
    {
        [HttpGet("UsersAndGroups")]
        public async Task<ActionResult<IEnumerable<DirectoryEntryDto>>> Search([FromQuery] string? query = null)
        {
            var members = await graphService.SearchUsersAndGroups(query);
            var result = mapper.Map<IEnumerable<DirectoryEntry>, IEnumerable<DirectoryEntryDto>>(members);
            return Ok(result);
        }
    }
}
