﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web;
using Percept.Shared.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Controllers
{

    public abstract class ApiControllerBase<T, TRequest, TResponse>(IBaseService<T> service, ILogger logger, IMapper mapper, IAuthorizationService authorizationService) : ControllerBase
    where T : class, IHasGuidId
    where TRequest : class
    where TResponse : class, IHasGuidId
    {
        protected readonly IBaseService<T> _service = service;
        protected readonly ILogger _logger = logger;
        protected readonly IMapper _mapper = mapper;

        [HttpGet]
        public virtual ActionResult<PagedResponseDto<TResponse>> Get([FromQuery] int page = 1, [FromQuery] int pageSize = 25)
        {
            var entityResult = _service.Get(page, pageSize);
            var result = _mapper.Map<PagedResponseDto<TResponse>>(entityResult);
            return Ok(result);
        }

        [HttpGet("{id:guid}")]
        public virtual ActionResult<TResponse> GetById([FromRoute] Guid id)
        {
            var entityResult = _service.GetById(id);
            if (entityResult == null)
            {
                return new NotFoundResult();
            }

            return Ok(_mapper.Map<TResponse>(entityResult));
        }

        [HttpPost]
        public virtual async Task<ActionResult<TResponse>> CreateAsync([FromBody] TRequest item)
        {
            var entityResult = await _service.CreateAsync(_mapper.Map<T>(item));
            var requestUrl = Request.GetDisplayUrl();
            return Created($"{requestUrl}/{entityResult.Id}", _mapper.Map<TResponse>(entityResult));
        }

        [HttpDelete("{id}")]
        public virtual async Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid id)
        {
            _logger.LogInformation($"{User.GetDisplayName()} is deleting {typeof(T)} with Id={id}");
            var result = await _service.DeleteAsync(id);
            return Ok(result);
        }
    }
}
