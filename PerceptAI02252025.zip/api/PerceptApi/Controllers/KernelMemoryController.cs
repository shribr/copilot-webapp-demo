using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.Extensions.Primitives;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.DocumentStorage;
using Microsoft.KernelMemory.Service.AspNetCore.Models;
using Microsoft.Net.Http.Headers;
using Percept.Shared.Constants;
using Percept.Shared.Data.Entities;
using Percept.Shared.Services.Interfaces;
using Percept.Shared.Utils;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Data;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.Extensions;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using PerceptApi.Utils;
using PerceptApi.Events;
using Percept.Shared.Loggers;

namespace PerceptApi.Controllers
{
    [ApiController]
    [Route("api/AppRegistrations/{appId:guid}/[controller]")]
    public class KernelMemoryController(IKernelMemory memory,
                                        IKernelMemoryDocumentService kernelMemoryDocumentService,
                                        ILogger<KernelMemoryController> logger,
                                        IMapper mapper,
                                        IOutputCacheStore cache,
                                        IDocumentService documentService,
                                        IDataSourceService dataSourceService,
                                        IDocumentStatusService<PerceptDbContext> documentStatusService,
                                        IAuthorizationService authorizationService) : AuthorizationController<DataSource>(authorizationService)
    {
        [HttpOptions("download", Order = 2)]
        [AllowAnonymous]
        public void GetOptions()
        { }

        // answer.sources sourceUrl = "/download?indexName=default&documentId=di2201557.pdf&filename=di2201557.pdf"
        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Download)]
        [HttpGet("/api/[controller]/download")]
        public async Task<IActionResult> DownloadAsync(
            [FromQuery]
            string? appId,
            [FromQuery]
            string? dataSourceId,
            [FromQuery(Name = Microsoft.KernelMemory.Constants.WebService.IndexField)]
            string index,
            [FromQuery(Name = Microsoft.KernelMemory.Constants.WebService.DocumentIdField)]
            string documentId,
            [FromQuery(Name = Microsoft.KernelMemory.Constants.WebService.FilenameField)]
            string filename,
            [FromQuery]
            bool preview,
            CancellationToken cancellationToken)
        {
            var isValid = !(string.IsNullOrWhiteSpace(documentId) ||
                                string.IsNullOrWhiteSpace(filename));
            var errMsg = "Missing required parameter";

            // Citations use index
            var indexName = index;
            var dataSourceName = string.Empty;

            // Document Manager uses DataSourceId
            if (!string.IsNullOrEmpty(dataSourceId))
            {
                var dataSource = dataSourceService.GetById(new Guid(dataSourceId));

                if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(new Guid(appId)))
                {
                    return new NotFoundResult();
                }

                if (!await isAuthorized(dataSource))
                {
                    return Unauthorized();
                }

                indexName = dataSource.GetIndexName();
                dataSourceName = dataSource.Name;
            }

            logger.LogTrace("New download file HTTP request, index {0}, documentId {1}, fileName {3}", indexName, documentId, filename);

            if (!isValid)
            {
                logger.LogError(errMsg);
                return Problem(detail: errMsg, statusCode: 400);
            }

            try
            {
                // DownloadRequest => Document
                var file = await memory.ExportFileAsync(
                    documentId: documentId,
                    fileName: filename,
                    index: indexName,
                    cancellationToken: cancellationToken)
                    .ConfigureAwait(false);

                if (file == null)
                {
                    logger.LogWarning("Returned file is NULL, file not found");
                    throw new DocumentStorageFileNotFoundException("Storage returned a NULL value");
                }

                logger.LogTrace("Downloading file '{0}', size '{1}', type '{2}'", filename, file.FileSize, file.FileType);

                EntityTagHeaderValue etag = HttpFileHelpers.GenerateETag(file.LastWrite);

                var response = File(
                    fileStream: await file.GetStreamAsync(),
                    contentType: file.FileType,
                    fileDownloadName: !preview ? filename : null, // remove here for preview so we can set inline header
                    lastModified: file.LastWrite,
                    entityTag: etag,
                    enableRangeProcessing: true);

                if (preview)
                {
                    HttpContext.Response.Headers.Append(HeaderNames.ContentDisposition, $"inline; filename=\"{filename}\"; filename*=UTF-8''\"{filename}\"");
                }

                HttpContext.Response.Headers.Append("Access-Control-Expose-Headers", HeaderNames.ContentDisposition);
                InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.Download, new { dataSourceName, fileName = filename, appId, documentId, dataSourceId });
                return response;
            }
            catch (DocumentStorageFileNotFoundException e)
            {
                InsightsLogger.AuditFailure(logger, PerceptEvents.Documents.Download, new { dataSourceName, fileName = filename, appId, documentId, dataSourceId });
                return Problem(title: "File not found", detail: e.Message, statusCode: 404);
            }
            catch (Exception e)
            {
                InsightsLogger.AuditFailure(logger, PerceptEvents.Documents.Download, new { dataSourceName, fileName = filename, appId, documentId, dataSourceId });
                return Problem(title: "File download failed", detail: e.Message, statusCode: 503);
            }
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentManager)]
        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        public async Task<ActionResult<UploadAccepted>> UploadAsync([FromQuery] bool? useMarkdown, [FromForm] HttpDocumentUploadRequest upload, CancellationToken cancellationToken)
        {
            logger.LogTrace("New upload HTTP request, content length {0}", Request.ContentLength);

            // Note: .NET doesn't yet support binding multipart forms including data and files
            (HttpDocumentUploadRequest input, bool isValid, string errMsg)
                = await HttpDocumentUploadRequest.BindHttpRequestAsync(Request, cancellationToken)
            .ConfigureAwait(false);

            // Read form
            IFormCollection form = await Request.ReadFormAsync(cancellationToken).ConfigureAwait(false);
            if (form.TryGetValue("dataSourceId", out StringValues ids) && ids.Count > 1)
            {
                return new BadRequestResult();
            }
            var dataSourceId = new Guid(ids.First());
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null)
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var kmConfiguration = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();
            var indexName = dataSource.GetIndexName();

            var documentUpload = input.ToDocumentUploadRequest();
            documentUpload.Index = indexName;

            logger.LogTrace("Index '{0}'", indexName);

            if (!isValid)
            {
                logger.LogError(errMsg);
                return Problem(detail: errMsg, statusCode: 400);
            }

            try
            {
                if (useMarkdown.HasValue && useMarkdown.Value)
                {
                    input.Tags.Add(KernelMemoryConstants.UseMarkdownKey, "true");
                }

                await documentService.UploadFiles(indexName, documentUpload.Tags, documentUpload.Files, cancellationToken);

                foreach (DocumentUploadRequest.UploadedFile file in documentUpload.Files)
                {
                    string fileName = file.FileName;
                    InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.Upload, new { dataSourceName = dataSource.Name, fileName, indexName, documentId = documentUpload.DocumentId, dataSourceId });
                }
                return Accepted(new UploadAccepted
                {
                    Index = indexName,
                    Message = "Document upload completed, ingestion pipeline started"
                });
            }
            catch (Exception e)
            {
                foreach (DocumentUploadRequest.UploadedFile file in documentUpload.Files)
                {
                    string fileName = file.FileName;
                    InsightsLogger.AuditFailure(logger, PerceptEvents.Documents.Upload, new { dataSourceName = dataSource.Name, fileName, indexName, documentId = documentUpload.DocumentId, dataSourceId });
                }
                return Problem(title: "Document upload failed", detail: e.Message, statusCode: 503);
            }
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentViewer)]
        [HttpGet("{dataSourceId}/status")]
        public async Task<ActionResult<PagedResponseDto<DocumentStatusResponseDto>>> Get(
            [FromRoute] Guid appId,
            [FromRoute] Guid dataSourceId,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 25,
            [FromQuery] bool includeCompleted = false,
            [FromQuery] string? filter = null,
            [FromQuery] string? sortBy = null,
            [FromQuery] string? sortDirection = null)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null)
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var kmConfiguration = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();

            var indexName = dataSource.GetIndexName();
            var entityResult = documentStatusService.GetDocuments(indexName, includeCompleted);

            if (!string.IsNullOrEmpty(filter))
            {
                entityResult = entityResult.Where(d => d.FileName.ToLower().Contains(filter.ToLower()));
            }

            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(sortDirection))
            {
                entityResult = DynamicSorting.SortByProperty(entityResult, sortBy, sortDirection);
            }
            else
            {
                entityResult = entityResult.OrderByDescending(d => d.LastUpdated);
            }

            var pagedResults = new PagedResponse<DocumentUploadStatus>(page, pageSize, entityResult);
            var result = mapper.Map<PagedResponseDto<DocumentStatusResponseDto>>(pagedResults);
            return Ok(result);
        }


        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentViewer)]
        [HttpGet("{dataSourceId}/documents")]
        public async Task<ActionResult<IEnumerable<DocumentDto>>> GetDocumentsAsync(
            [FromRoute] Guid appId,
            [FromRoute] Guid dataSourceId,
            CancellationToken cancellationToken,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? filter = null,
            [FromQuery] string? sortBy = null,
            [FromQuery] string? sortDirection = null)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var kmConfiguration = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();

            var documents = await documentService.GetDocumentsAsync(dataSource, null, cancellationToken);

            if (!string.IsNullOrEmpty(filter))
            {
                documents = documents.Where(d => d.SourceName.ToLower().Contains(filter.ToLower()));
            }

            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(sortDirection))
            {
                documents = DynamicSorting.SortByProperty(documents, sortBy, sortDirection);
            }
            else
            {
                documents = documents.OrderByDescending(d => d.LastUpdate);
            }

            var result = new PagedResponse<DocumentDto>(page, pageSize, documents);
            InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.GetStatus, new { dataSourceName = dataSource.Name, numFiles = documents.Count(), fileNames = documents.Select(d => d.SourceName), appId, dataSourceId });

            return Ok(result);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentViewer)]
        [HttpGet("{dataSourceId}/documents/{documentId}")]
        public async Task<ActionResult<IEnumerable<DocumentWithTagsDto>>> GetDocumentAsync([FromRoute] Guid appId, [FromRoute] string documentId, [FromRoute] Guid dataSourceId, CancellationToken cancellationToken)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var document = await documentService.GetDocumentAsync(dataSource, documentId, cancellationToken);

            if (document == null)
            {
                return NotFound();
            }

            InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.GetStatus, new { dataSourceName = dataSource.Name, fileName = document.SourceName, appId, dataSourceId });
            return Ok(document);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentManager)]
        [HttpDelete("{dataSourceId}/documents")]
        public async Task<ActionResult> DeleteDocumentsAsync([FromRoute] Guid appId, [FromRoute] Guid dataSourceId, [FromQuery] List<string> documentIds)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var documents = await documentService.GetDocumentsAsync(dataSource, null, CancellationToken.None);
            var documentsToDelete = documents.Where(d => documentIds.Contains(d.DocumentId)).ToList();
            if (documentsToDelete.Count == 0)
            {
                return new NotFoundResult();
            }
            await documentService.DeleteFilesAsync(dataSource, documentIds);

            InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.Delete, new { dataSourceName = dataSource.Name, fileNames = documentsToDelete.Select(d => d.SourceName), appId, dataSourceId });
            return Ok();
        }


        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentManager)]
        [HttpPatch("{dataSourceId}/documents/{documentId}")]
        public async Task<ActionResult<bool>> UpdateDocumentAsync([FromRoute] Guid appId, [FromRoute] string documentId, [FromRoute] Guid dataSourceId, [FromBody] UpdateDocumentRequestDto updateRequest)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            if (string.IsNullOrEmpty(documentId))
            {
                return BadRequest("Document ID is required.");
            }

            var tagsToRemove = updateRequest.TagsToRemove;
            var tagsToAdd = updateRequest.TagsToAdd;

            if (tagsToRemove.Count == 0 && tagsToAdd.Count == 0)
            {
                // Nothing to do
                return Ok(true);
            }

            var indexName = dataSource.GetIndexName();
            var result = await kernelMemoryDocumentService.UpdateDocumentTagsAsync(indexName, documentId, tagsToAdd, tagsToRemove);
            await cache.EvictByTagAsync($"{indexName}", default);

            var document = await documentService.GetDocumentAsync(dataSource, documentId, CancellationToken.None);
            if (document != null)
            {
                InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.Update, new { dataSourceName = dataSource.Name, fileName = document.SourceName, tagsToAdd, tagsToRemove, appId, dataSourceId });
            }
            return Ok(true);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentManager)]
        [HttpPatch("{dataSourceId}/status/{id}")]
        public async Task<ActionResult<bool>> ArchiveDocument([FromRoute] Guid appId, [FromRoute] Guid dataSourceId, [FromRoute] Guid id)
        {
            var dataSource = dataSourceService.GetById(dataSourceId);

            if (dataSource == null || dataSource.Configuration == null || !dataSource.ApplicationId.Equals(appId))
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            DocumentUploadStatus? documentStatus = await documentStatusService.GetDocument(id);
            if (documentStatus == null)
            {
                return NotFound();
            }

            await documentStatusService.ArchiveDocument(id);

            InsightsLogger.AuditSuccess(logger, PerceptEvents.Documents.Archive, new { id, dataSourceName = dataSource.Name, fileName = documentStatus.FileName, appId, dataSourceId });
            return Ok(true);
        }
    }

}