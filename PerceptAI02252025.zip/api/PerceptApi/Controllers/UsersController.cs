using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Percept.Shared.Loggers;
using PerceptApi.Constants;
using PerceptApi.DTOs;
using PerceptApi.Events;
using PerceptApi.Extensions;
using PerceptApi.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController(IUserService userService, IMapper mapper, IHttpContextAccessor contextAccessor, IDataSourceService dataSourceService,
        ILogger<UsersController> logger,
        IAuthorizationService authorizationService,
        IAppRegistrationService appService,
        IGraphService graphService,
        IUserRoleService userRoleService,
        IConfiguration configuration) : ControllerBase
    {
        [HttpGet("me")]
        public ActionResult<DirectoryEntryDto> GetMe()
        {
            var authenticatedUserId = contextAccessor.HttpContext.User.GetUserId();
            if (!authenticatedUserId.HasValue)
            {
                // Should never get here
                return new UnauthorizedResult();
            }

            var entityResult = userService.GetById(authenticatedUserId.Value);
            return Ok(mapper.Map<DirectoryEntryDto>(entityResult));
        }

        [HttpGet("derivedRoles")]
        public async Task<ActionResult<IEnumerable<string>>> GetDerivedRoles()
        {
            var authenticatedUser = contextAccessor.HttpContext.User;
            if (authenticatedUser is null)
            {
                return new UnauthorizedResult();
            }
            var authenticatedObjectId = authenticatedUser.GetObjectId();
            if (!authenticatedObjectId.HasValue)
            {
                return new UnauthorizedResult();
            }

            // reset users claims cache since this endpoint is called during frontend auth only
            userService.ClearCache(authenticatedObjectId.Value);
            var roles = await GetDerivedRolesAsync(authenticatedUser);
            return Ok(roles);
        }

        private async Task<IEnumerable<string>> GetDerivedRolesAsync(ClaimsPrincipal authenticatedUser)
        {
            var result = new List<string>();

            var userId = authenticatedUser.GetObjectId();
            if (userId is not null)
            {
                var globalAdminGroupId = configuration.GetValue(RBACProperties.GlobalAdminGroupName, Guid.Empty);
                var appCreatorGroupId = configuration.GetValue(RBACProperties.AppCreatorGroupName, Guid.Empty);

                InsightsLogger.AuditSuccess(logger, PerceptEvents.AppSettings.GetValue, new { name = "globalAdminGroupId", value = globalAdminGroupId });
                InsightsLogger.AuditSuccess(logger, PerceptEvents.AppSettings.GetValue, new { name = "appCreatorGroupId", value = appCreatorGroupId });

                var groups = (await graphService.GetGroupsAsync(userId.Value)).Select(x => x.Id);
                InsightsLogger.AuditSuccess(logger, PerceptEvents.User.GetGroupMemberships, new { user = authenticatedUser.Identity.Name, userId, groups });
                if (groups.Contains(globalAdminGroupId.ToString(), StringComparer.OrdinalIgnoreCase))
                {
                    result.AddRange(["app-admin", "app-create"]);
                }
                else if (groups.Contains(appCreatorGroupId.ToString(), StringComparer.OrdinalIgnoreCase))
                {
                    result.Add("app-create");
                }
            }

            var canManageApps = await userRoleService.HasAnyAppPermissionAsync(authenticatedUser);
            if (canManageApps) { result.Add("app-manage"); }

            return result;
        }
    }
}