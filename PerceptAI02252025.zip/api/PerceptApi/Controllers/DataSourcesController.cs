using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using Microsoft.KernelMemory;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Constants;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.ErrorHandling;
using PerceptApi.Events;
using PerceptApi.Extensions;
using Percept.Shared.Loggers;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using System.Text.RegularExpressions;

namespace PerceptApi.Controllers
{
    [Route("api/AppRegistrations/{appId:guid}/[controller]")]
    [ApiController]
    public class DataSourcesController(
        IDataSourceService dataSourceService,
        IKernelMemoryDocumentService kernelMemoryDocumentService,
        ILogger<DataSourcesController> logger,
        IMapper mapper,
        IAppRegistrationService appRegistrationService,
        IAuthorizationService authorizationService,
        IUserRoleService userRoleService,
        IUserService userService) : ApiAppControllerBase<DataSource, DataSourceRequestDto, DataSourceResponseDto>(dataSourceService, logger, mapper, authorizationService)
    {
        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Read)]
        public override async Task<ActionResult<PagedResponseDto<DataSourceResponseDto>>> Get([FromRoute] Guid appId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {
            var query = dataSourceService.GetAllByCondition(x => x.ApplicationId.Equals(appId), false).Include(x => x.AgentDataSources).ThenInclude(x => x.Agent);
            var filteredQuery = await internalGet(query, nameof(Get));

            if (!string.IsNullOrEmpty(filter))
            {
                _logger.LogInformation($"Filtering {typeof(DataSource)} by {filter}");
                filteredQuery = filteredQuery.Where(x => x.ToString().ToLower().Contains(filter.ToLower()));
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                _logger.LogInformation($"Sorting {typeof(DataSource)} by {sortBy} {sortDirection}");
                filteredQuery = sortDirection == SortingDirections.Descending ? filteredQuery.OrderByDescending(x => EF.Property<object>(x, sortBy))
                                 : filteredQuery.OrderBy(x => EF.Property<object>(x, sortBy));
            }

            var response = new PagedResponse<DataSource>(page, pageSize, filteredQuery.AsQueryable());
            return Ok(_mapper.Map<PagedResponseDto<DataSourceResponseDto>>(response));            
        }



        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.DocumentViewer)]
        [HttpGet("MyManaged")]
        public virtual async Task<ActionResult<PagedResponseDto<DataSourceResponseDto>>> GetMyManaged([FromRoute] Guid appId, [FromQuery] DataSourceType? dataSourceType = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
        {
            var query = await internalGet(appId, nameof(GetMyManaged));

            if (dataSourceType.HasValue)
            {
                query = query.Where(x => x.Type == dataSourceType);
            }

            var response = new PagedResponse<DataSource>(page, pageSize, query);
            return Ok(_mapper.Map<PagedResponseDto<DataSourceResponseDto>>(response));
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Read)]
        public override Task<ActionResult<DataSourceResponseDto>> GetById([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.GetById(appId, id);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Delete)]
        public override Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.DeleteAsync(appId, id);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Create)]
        [HttpGet("IndexExist")]
        public async Task<ActionResult<bool>> IndexExist([FromRoute] Guid appId, [FromQuery] string indexName)
        {
            //Create a temporary DataSource object to check if the user is authorized to access the data source
            var dataSource = new DataSource()
            {
                ApplicationId = appId,
                Name = indexName,
                Type = DataSourceType.Documents,
            };

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var exist = dataSourceService.IndexNameExist(appId, indexName);
            return Ok(exist);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.RbacAdmin)]
        [HttpPost("{id:guid}/DataManagers")]
        public async Task<ActionResult<DirectoryEntryDto>> AddUser([FromRoute] Guid appId, [FromRoute] Guid id, [FromBody] DirectoryEntryRequestDto user)
        {
            try
            {
                var dataSource = _service.GetById(id);

                if (dataSource is null)
                {
                    return NotFound();
                }

                var auditString = $"Add Role:DataManager for Directory Entry ObjectId: {user.ObjectId}";

                if (!await isAuthorized(dataSource))
                {
                    InsightsLogger.AuditFailure(logger, PerceptEvents.DataManagerAssignment.Add, new { appId, id, user });
                    return Unauthorized();
                }

                var entityUser = _mapper.Map<DirectoryEntry>(user);
                var userRole = await userRoleService.AddPermissionAsync(appId, dataSource.Id, EntityTypes.DataSource, entityUser.ObjectId, entityUser.IsGroup, DataSourceRoles.DataManager);
                InsightsLogger.AuditSuccess(logger, PerceptEvents.DataManagerAssignment.Add, new { appId, id, user });

                entityUser = userService.GetById(userRole.DirectoryEntryId);
                return _mapper.Map<DirectoryEntryDto>(entityUser);
            }
            catch (DataSourceException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Create)]
        [HttpPost]
        public override async Task<ActionResult<DataSourceResponseDto>> CreateAsync([FromRoute] Guid appId, [FromBody] DataSourceRequestDto item)
        {
            if (item.Configuration is KernelMemoryDataSourceConfiguration configuration)
            {
                // Same Regex in the UI
                var reg = new Regex("^[a-z0-9][a-z0-9-]{1,127}(?<![-]{2})$");
                if (!reg.IsMatch(configuration.IndexName))
                {
                    return BadRequest($"Index name {configuration.IndexName} must only include alphanumberic characters or a dash.");
                }

                if (dataSourceService.IndexNameExist(appId, configuration.IndexName))
                {
                    return Conflict($"Index with name {configuration.IndexName} already exist.");
                }
                else
                {
                    // following Kernel Memory Normalization rules
                    configuration.IndexName = dataSourceService.NormalizeIndexName(configuration.IndexName);
                }
            }

            var result = await base.CreateAsync(appId, item);
            if (result.Result is CreatedResult createdResult && createdResult.Value is DataSourceResponseDto responseDto)
            {
                await userRoleService.AddPermissionAsync(appId, responseDto.Id, EntityTypes.DataSource, User.GetObjectId().Value, false, DataSourceRoles.DataManager);
            }

            return result;
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.Update)]
        [HttpPatch("{id:guid}")]
        public async Task<ActionResult<DataSourceResponseDto>> UpdateDataSource([FromRoute] Guid id, [FromBody] DataSourceRequestDto update)
        {
            var dataSource = dataSourceService.GetById(id, true);
            if (dataSource == null)
            {
                return NotFound("DataSource not found");
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            if (dataSource.Configuration is KernelMemoryDataSourceConfiguration configuration &&
                update.Configuration is KernelMemoryDataSourceConfiguration updatedConfiguration &&
                configuration.IndexName != updatedConfiguration.IndexName && //Trying to change the index name
                dataSourceService.IndexNameExist(dataSource.ApplicationId, updatedConfiguration.IndexName))
            {
                return Conflict($"Index with name {updatedConfiguration.IndexName} already exist.");
            }

            dataSource.Name = update.Name;
            dataSource.Description = update.Description;
            dataSource.Configuration = update.Configuration;

            var result = await dataSourceService.UpdateAsync(dataSource);

            return _mapper.Map<DataSourceResponseDto>(result);
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.RbacViewer)]
        [HttpGet("{id:guid}/DataManagers")]
        public async Task<ActionResult<IEnumerable<DirectoryEntryDto>>> GetDataManagers([FromRoute] Guid id)
        {
            try
            {
                var dataSource = _service.GetById(id);

                if (dataSource is null)
                {
                    return NotFound();
                }

                if (!await isAuthorized(dataSource))
                {
                    return Unauthorized();
                }

                var users = userRoleService.GetAllByCondition(x => x.EntityId == id && x.EntityType == EntityTypes.DataSource)
                    .Include(x => x.DirectoryEntry)
                    .ToList()
                    .Where(x =>
                    {
                        var currentPermission = (DataSourceRoles)x.Permission;
                        if (currentPermission.HasFlag(DataSourceRoles.DataManager))
                        {
                            return true;
                        }
                        return false;
                    })
                    .Select(x => x.DirectoryEntry);

                return Ok(_mapper.Map<IEnumerable<DirectoryEntryDto>>(users));
            }
            catch (DataSourceException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.RbacAdmin)]
        [HttpDelete("{id:guid}/DataManagers/{userId:guid}")]
        public async Task<ActionResult<DirectoryEntryDto>> RemoveUser([FromRoute] Guid appId, [FromRoute] Guid id, [FromRoute] Guid userId)
        {
            try
            {
                var directoryEntity = userService.GetById(userId);

                if (directoryEntity is null)
                {
                    return NotFound("User or Group was not found");
                }

                var dataSource = _service.GetById(id);

                if (dataSource is null)
                {
                    return NotFound();
                }

                var auditString = $"Remove Role:DataManager for Directory Entry ObjectId: {userId}";

                if (!await isAuthorized(dataSource))
                {
                    InsightsLogger.AuditFailure(logger, PerceptEvents.DataManagerAssignment.Remove, new { appId, id, userId });
                    return Unauthorized();
                }

                var result = await userRoleService.RemovePermissionAsync(appId, id, EntityTypes.DataSource, directoryEntity, DataSourceRoles.DataManager);
                InsightsLogger.AuditSuccess(logger, PerceptEvents.DataManagerAssignment.Remove, new { appId, id, userId });
                return Ok(result);
            }
            catch (DataSourceException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [Permission<DataSourceOperationAuthorizationRequirement, DataSourcePermissions>(DataSourcePermissions.TagViewer)]
        [HttpGet("{id}/tags")]
        [OutputCache(Duration = 600, VaryByRouteValueNames = ["id"], Tags = ["{id}"])]
        public async Task<ActionResult<TagCollection>> GetTags([FromRoute] Guid id)
        {
            var dataSource = _service.GetById(id);
            if (dataSource == null || dataSource.Configuration == null)
            {
                return new NotFoundResult();
            }

            if (!await isAuthorized(dataSource))
            {
                return Unauthorized();
            }

            var kmConfiguration = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();
            var result = await kernelMemoryDocumentService.GetUniqueTagsByIndexAsync(dataSource.GetIndexName(), kmConfiguration.Categories);
            var filteredTags = Services.TagCollectionExtensions.FilterReservedTags(result);
            return Ok(filteredTags);
        }
    }
}
