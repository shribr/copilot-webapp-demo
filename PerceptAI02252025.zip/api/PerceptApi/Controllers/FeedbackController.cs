using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PerceptApi.Attributes;
using PerceptApi.Authorization;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Enums;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Controllers
{

    [ApiController]
    [Route("api/AppRegistrations/{appId:guid}/[controller]")]
    public class FeedbackController(IFeedbackService feedbackService, ILogger<FeedbackController> logger, IMapper mapper, IAuthorizationService authorizationService) :
        ApiAppControllerBase<Feedback, FeedbackRequestDto, FeedbackResponseDto>(feedbackService, logger, mapper, authorizationService)
    {
        [Permission<FeedbackOperationAuthorizationRequirement, FeedbackPermissions>(FeedbackPermissions.Viewer)]
        public override Task<ActionResult<bool>> DeleteAsync([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.DeleteAsync(appId, id);
        }

        [Permission<FeedbackOperationAuthorizationRequirement, FeedbackPermissions>(FeedbackPermissions.Viewer)]
        public override Task<ActionResult<FeedbackResponseDto>> GetById([FromRoute] Guid appId, [FromRoute] Guid id)
        {
            return base.GetById(appId, id);
        }

        [Permission<FeedbackOperationAuthorizationRequirement, FeedbackPermissions>(FeedbackPermissions.Viewer, OnlyAuthorizeFirst = true)]
        public override async Task<ActionResult<PagedResponseDto<FeedbackResponseDto>>> Get([FromRoute] Guid appId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] string? filter = null, [FromQuery] string? sortBy = null, [FromQuery] string? sortDirection = null)
        {           
            if (!await isAuthorized(GetAuthTestFeedback(appId)))
            {
                return Unauthorized();
            }

            return await base.Get(appId, page, pageSize, filter, sortBy, sortDirection);
        }

        [HttpGet("byfilter")]
        [Permission<FeedbackOperationAuthorizationRequirement, FeedbackPermissions>(FeedbackPermissions.Viewer, OnlyAuthorizeFirst = true)]
        public async Task<ActionResult<PagedResponseDto<FeedbackResponseDto>>> GetByFilter([FromRoute] Guid appId, [FromQuery] int page = 1, [FromQuery] int pageSize = 25,
            [FromQuery] Reaction reaction = Reaction.Any, [FromQuery] string? startDate = null, [FromQuery] string? endDate = null, [FromQuery] string? search = null)
        {
            if (!await isAuthorized(GetAuthTestFeedback(appId)))
            {
                return Unauthorized();
            }

            DateTime? startDateVal = !string.IsNullOrEmpty(startDate) ? DateTime.Parse(startDate).Date : null;
            DateTime? endDateVal = !string.IsNullOrEmpty(endDate) ? DateTime.Parse(endDate).AddDays(1).AddTicks(-1) : null;
            var entityResult = feedbackService.GetFiltered(appId, reaction, startDateVal, endDateVal, search);

            // Only need to check permissions on a single entity because if you have access to one you have access to all.
            var pagedResults = new PagedResponse<Feedback>(page, pageSize, entityResult.AsQueryable());

            var result = _mapper.Map<PagedResponseDto<FeedbackResponseDto>>(pagedResults);
            return Ok(result);
        }

        private Feedback GetAuthTestFeedback(Guid appId) => new Feedback
        {
            ApplicationId = appId,
            Question = "Test Question",
            Response = "Test Response",
        };
    }
}
