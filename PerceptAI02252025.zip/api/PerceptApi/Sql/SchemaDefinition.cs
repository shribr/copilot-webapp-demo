﻿namespace PerceptApi.Sql
{
    public class SchemaDefinition
    {
        public SchemaDefinition(
        string name,
        string platform,
        string? description,
        IEnumerable<SchemaTable> tables)
        {
            Name = name;
            Platform = platform;
            Description = description;
            Tables = tables ?? Array.Empty<SchemaTable>();
        }

        public string Name { get; }

        public string? Description { get; }

        public string Platform { get; }

        public IEnumerable<SchemaTable> Tables { get; }
    }
}
