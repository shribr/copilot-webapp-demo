﻿using System.Text.Json.Serialization;

namespace PerceptApi.Sql
{
    public sealed class SchemaColumn
    {
        public SchemaColumn(
            string name,
            string? description,
            string type,
            bool isPrimary,
            string? referencedTable = null,
            string? referencedColumn = null,
            bool isNullable = false)
        {
            Name = name;
            Description = description;
            Type = type;
            IsPrimary = isPrimary;
            ReferencedTable = referencedTable;
            ReferencedColumn = referencedColumn;
            IsNullable = isNullable;
        }

        public string Name { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string? Description { get; set; }

        public string Type { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public bool IsPrimary { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string? ReferencedTable { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string? ReferencedColumn { get; }

        public bool IsNullable { get; }
    }
}
