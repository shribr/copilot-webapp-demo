﻿namespace PerceptApi.Sql
{
    public interface ISchemaFormatter
    {
        Task WriteAsync(TextWriter writer, SchemaDefinition schema);
    }

    public static class SchemaDefinitionExtensions
    {
        public static async Task<string> FormatAsync(this SchemaDefinition schema, ISchemaFormatter formatter)
        {
            formatter = formatter ?? throw new ArgumentNullException(nameof(formatter));

            using var writer = new StringWriter();

            await formatter.WriteAsync(writer, schema).ConfigureAwait(false);

            return writer.ToString();
        }
    }

    public sealed class YamlSchemaFormatter : ISchemaFormatter
    {
        public static YamlSchemaFormatter Instance { get; } = new YamlSchemaFormatter();

        private YamlSchemaFormatter() { }

        async Task ISchemaFormatter.WriteAsync(TextWriter writer, SchemaDefinition schema)
        {
            if (!string.IsNullOrWhiteSpace(schema.Description))
            {
                await writer.WriteLineAsync($"description: {schema.Description}").ConfigureAwait(false);
            }

            await writer.WriteLineAsync("tables:").ConfigureAwait(false);

            foreach (var table in schema.Tables)
            {
                await writer.WriteLineAsync($"  - {table.Name}: {table.Description}").ConfigureAwait(false);
                await writer.WriteLineAsync("    columns:").ConfigureAwait(false);

                foreach (var column in table.Columns)
                {
                    await writer.WriteLineAsync($"      {column.Name}: {column.Description}").ConfigureAwait(false);
                }
            }

            await writer.WriteLineAsync("references:").ConfigureAwait(false);
            foreach (var (table, column) in schema.Tables.SelectMany(t => t.Columns.Where(c => !string.IsNullOrEmpty(c.ReferencedTable)).Select(c => (t.Name, c))))
            {
                await writer.WriteLineAsync($"  {table}.{column.Name}: {column.ReferencedTable}.{column.ReferencedColumn}").ConfigureAwait(false);
            }
        }
    }
}
