﻿using System.Text.Json.Serialization;

namespace PerceptApi.Sql
{
    public sealed class SchemaTable
    {
        public SchemaTable(
            string name,
            string? description = null,
            bool isView = false,
            IEnumerable<SchemaColumn>? columns = null)
        {
            Name = name;
            Description = description;
            Columns = columns ?? Array.Empty<SchemaColumn>();
            IsView = isView;
        }

        public string Name { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string? Description { get; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public bool IsView { get; }

        public IEnumerable<SchemaColumn> Columns { get; }
    }
}
