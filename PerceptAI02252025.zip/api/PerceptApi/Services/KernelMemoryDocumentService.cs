﻿using Microsoft.IdentityModel.Tokens;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.MemoryStorage;
using PerceptApi.DTOs;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{

    public class KernelMemoryDocumentService(IMemoryDb memoryDb, IPerceptMemoryDb perceptMemoryDb) : IKernelMemoryDocumentService
    {
        public async Task<TagCollection> GetUniqueTagsByIndexAsync(string memoryStoreName, List<string> agentCategories)
        {
            // Used to filter for files tagged with tag eq '__part_n:0'.  This should result in the first partition of each document.
            var filters = new List<MemoryFilter>
            {
                MemoryFilters.ByTag(Microsoft.KernelMemory.Constants.ReservedFilePartitionNumberTag, "0")
            };

            var records = memoryDb.GetListAsync(memoryStoreName, filters, limit: int.MaxValue);

            var uniqueTags = new TagCollection();

            await foreach (var record in records)
            {
                foreach (var tag in record.Tags)
                {
                    // If the tag key does not exist in the uniqueTags, add it
                    if (!uniqueTags.ContainsKey(tag.Key))
                    {
                        uniqueTags[tag.Key] = new List<string?>(tag.Value);
                    }
                    else
                    {
                        // Otherwise, add only unique values to the existing tag list
                        foreach (var value in tag.Value)
                        {
                            if (!uniqueTags[tag.Key].Contains(value))
                            {
                                uniqueTags[tag.Key].Add(value);
                            }
                        }
                    }
                }
            }

            // Filter out tag keys that aren't in the Categories table
            var keysToRemove = uniqueTags.Keys.Where(key => !agentCategories.Contains(key)).ToList();
            foreach (var key in keysToRemove)
            {
                uniqueTags.Remove(key);
            }

            // Sort the values
            foreach (var tag in uniqueTags.Keys.ToList())
            {
                uniqueTags[tag].Sort();
            }

            // Sort the keys
            var sortedTags = new TagCollection();
            foreach (var key in uniqueTags.Keys.OrderBy(k => k))
            {
                sortedTags.Add(key, uniqueTags[key]);
            }

            return sortedTags;
        }

        public async Task<string[]> UpdateDocumentsTagsAsync(string index, List<UpdateDocumentRequestDto> updateRequests)
        {
            List<Task<string[]>> updateTasks = updateRequests.AsParallel().Select(request =>
               UpdateDocumentTagsAsync(index, request.DocumentId, request.TagsToAdd, request.TagsToRemove)).ToList();
            var results = await Task.WhenAll(updateTasks);
            return results.SelectMany(result => result).ToArray();
        }

        public async Task<string[]> UpdateDocumentTagsAsync(string index, string documentId, TagCollection tagsToAdd, TagCollection tagsToRemove)
        {
            if (documentId.Equals(string.Empty, StringComparison.Ordinal))
            {
                throw new ArgumentNullException("documentId is required");
            }

            var filters = new List<MemoryFilter>
            {
                MemoryFilters.ByTag(Microsoft.KernelMemory.Constants.ReservedDocumentIdTag, documentId)
            };

            List<MemoryRecord> recordsToUpdate = new();
            var records = memoryDb.GetListAsync(index, filters, limit: int.MaxValue, withEmbeddings: true);
            await foreach (var record in records)
            {
                var recordIsChanged = false;
                foreach (string key in tagsToRemove.Keys)
                {
                    if (record.Tags.ContainsKey(key))
                    {
                        var valuesToRemove = record.Tags[key].Where(tagsToRemove[key].Contains).ToList();
                        if (valuesToRemove.Count > 0)
                        {
                            valuesToRemove.ForEach(v => record.Tags[key].Remove(v));
                            recordIsChanged = true;
                        }
                    }
                }
                foreach (string key in tagsToAdd.Keys)
                {
                    if (record.Tags.ContainsKey(key))
                    {
                        var newTagValues = tagsToAdd[key].Except(record.Tags[key]).ToList();
                        if (newTagValues.Count > 0)
                        {
                            record.Tags[key].AddRange(newTagValues);
                            recordIsChanged = true;
                        }
                    }
                    else
                    {
                        record.Tags.Add(key, tagsToAdd[key]);
                        recordIsChanged = true;
                    }
                }
                if (recordIsChanged)
                {
                    recordsToUpdate.Add(record);
                }
            }

            if (recordsToUpdate.Count == 0)
            {
                return new List<string>().ToArray();
            }

            return await perceptMemoryDb.UpsertBatchAsync(index, recordsToUpdate);
        }

  } 
}
