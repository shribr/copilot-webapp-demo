﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.MemoryDb.AzureAISearch;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.Enums;
using PerceptApi.Extensions;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Linq.Expressions;
using System.Text.RegularExpressions;

namespace PerceptApi.Services
{
    public class DataSourceService(IBaseRepository<DataSource> repository, IKernelMemory memory,
        IBaseRepository<UserRole> userRoleRepository) :
        AppBaseService<DataSource>(repository), IDataSourceService
    {
        public bool IndexNameExist(Guid appId, string indexName)
        {
            var normalizedIndex = NormalizeIndexName(indexName);
            var indexNameParameter = new SqlParameter("indexName", indexName);
            return repository.FromSqlRaw($"SELECT * FROM DataSources Where JSON_VALUE({nameof(DataSource.Configuration)}, '$.\"$type\"') = '{nameof(KernelMemoryDataSourceConfiguration)}' AND JSON_VALUE({nameof(DataSource.Configuration)}, '$.{nameof(KernelMemoryDataSourceConfiguration.IndexName)}') = @indexName", indexNameParameter)
                .Where(x => x.ApplicationId == appId).Any();
        }

        // copied from Kernel Memory source code AzureAiSearchMemory.cs 10/31/2024
        private static readonly Regex s_replaceIndexNameCharsRegex = new(@"[\s|\\|/|.|_|:]");
        public string NormalizeIndexName(string index)
        {
            ArgumentNullExceptionEx.ThrowIfNullOrWhiteSpace(index, nameof(index), "The index name is empty");

            if (index.Length > 128)
            {
                throw new AzureAISearchMemoryException("The index name (prefix included) is too long, it cannot exceed 128 chars.");
            }

            index = index.ToLowerInvariant();

            index = s_replaceIndexNameCharsRegex.Replace(index.Trim(), "-");

            // Name cannot start with a dash
            if (index.StartsWith('-')) { index = $"z{index}"; }

            // Name cannot end with a dash
            if (index.EndsWith('-')) { index = $"{index}z"; }

            return index;
        }

        public async Task<bool> DeleteAsync(Guid appId, Guid dataSourceId)
        {
            var dataSource = GetAllByCondition(ds => ds.Id == dataSourceId).Include(ds => ds.AgentDataSources).FirstOrDefault();
            if (dataSource == null) { return true; }
            if (dataSource.AgentDataSources.Any())
            {
                throw new Exception("Datasource in use by exisiting Agents");
            }
            if (dataSource != null)
            {
                // Remove permissions for the dataSource
                userRoleRepository.GetAllByCondition(x => x.EntityId == dataSourceId && x.EntityType == EntityTypes.DataSource, false).ToList()
                    .ForEach(userRoleRepository.Remove);

                // TODO: Identify how to process this special type of dataSource
                if (dataSource.Type == DataSourceType.Documents)
                {
                    var kmConfiguration = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();
                    await memory.DeleteIndexAsync(dataSource.GetIndexName());
                    Remove(dataSource);
                }
            }

            await repository.SaveAsync();

            return true;
        }

        public override PagedResponse<DataSource> Get(Guid appId, int page = 1, int pageSize = 25)
        {
            var query = GetByApp(appId).OrderBy(ds => ds.Name);
            return new PagedResponse<DataSource>(page, pageSize, query);
        }
    }
}