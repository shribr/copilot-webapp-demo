﻿using Azure;
using Azure.Identity;
using Azure.Search.Documents;
using Azure.Search.Documents.Models;
using Microsoft.KernelMemory;
using Microsoft.KernelMemory.Diagnostics;
using Microsoft.KernelMemory.MemoryStorage;
using PerceptApi.Services.Interfaces;
using System.Runtime.CompilerServices;
using System.Text;

namespace PerceptApi.Services
{
    public class PerceptAzureAISearchMemoryDb(AzureAISearchConfig config) : IPerceptMemoryDb
    {
        public async Task<string[]> UpsertBatchAsync(
            string indexName,
            IEnumerable<MemoryRecord> records,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var client = this.CreateSearchClient(indexName);
            var localRecords = records.Select(r => new
            {
                id = EncodeId(r.Id),
                tags = r.Tags.Pairs.Select(tag => $"{tag.Key}{Microsoft.KernelMemory.Constants.ReservedEqualsChar}{tag.Value}").ToList()
            });

            try
            {
                await client.IndexDocumentsAsync(
                    IndexDocumentsBatch.Merge(localRecords),
                    new IndexDocumentsOptions { ThrowOnAnyError = true },
                    cancellationToken: cancellationToken).ConfigureAwait(false);
            }
            catch (RequestFailedException e) when (IsIndexNotFoundException(e))
            {
                throw new IndexNotFoundException(e.Message, e);
            }
            return records.Select(r => r.Id).ToArray();
        }

        private SearchClient CreateSearchClient(string indexName)
        {
           var clientOptions = GetClientOptions(config);

           SearchClient ? result = null;
            switch (config.Auth)
            {
                case AzureAISearchConfig.AuthTypes.AzureIdentity:
                    result = new SearchClient(
                        new Uri(config.Endpoint),
                        indexName,
                        new DefaultAzureCredential(),
                        clientOptions);
                    break;

                case AzureAISearchConfig.AuthTypes.APIKey:
                    result = new SearchClient(
                        new Uri(config.Endpoint),
                          indexName,
                        new AzureKeyCredential(config.APIKey),
                        clientOptions);
                    break;
            }
            if (result is null)
            {
                throw new ConfigurationException("Unsupported Azure AI Search Authentication option");
            }
            return result;
        }

        private string EncodeId(string realId)
        {
            var bytes = Encoding.UTF8.GetBytes(realId);
            return Convert.ToBase64String(bytes).Replace('=', '_');
        }

        private bool IsIndexNotFoundException(RequestFailedException e)
        {
            return e.Status == 404
                   && e.Message.Contains("index", StringComparison.OrdinalIgnoreCase)
                   && e.Message.Contains("not found", StringComparison.OrdinalIgnoreCase);
        }

        private static SearchClientOptions GetClientOptions(AzureAISearchConfig config)
        {
            var options = new SearchClientOptions
            {
                Diagnostics =
            {
                IsTelemetryEnabled = Telemetry.IsTelemetryEnabled,
                ApplicationId = Telemetry.HttpUserAgent,
            }
            };

            // Custom audience for sovereign clouds.
            // See https://github.com/Azure/azure-sdk-for-net/blob/main/sdk/search/Azure.Search.Documents/src/SearchAudience.cs
            if (config.Auth == AzureAISearchConfig.AuthTypes.AzureIdentity && !string.IsNullOrWhiteSpace(config.AzureIdentityAudience))
            {
                options.Audience = new SearchAudience(config.AzureIdentityAudience);
            }

            return options;
        }
    }
}
