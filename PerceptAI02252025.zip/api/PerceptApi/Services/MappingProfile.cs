﻿using AutoMapper;
using Microsoft.KernelMemory;
using Percept.Shared.Data.Entities;
using PerceptApi.Data;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Models;

namespace PerceptApi.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap(typeof(PagedResponse<>), typeof(PagedResponseDto<>));
            CreateMap<Feedback, FeedbackResponseDto>()
                .ForMember(dto => dto.UserName, opt => opt.MapFrom(entity => entity.CreatedBy));
            CreateMap<FeedbackRequestDto, Feedback>(MemberList.None)
                .IgnoreIdAndAuditFields();
            CreateMap<DataSourceRequestDto, DataSource>(MemberList.None).IgnoreAuditFields();
            CreateMap<DataSource, DataSourceResponseDto>()            
            .ForMember(dataSource => dataSource.Agents, opt => opt.MapFrom(src => src.AgentDataSources.Select(x => x.Agent).ToList()));
            
            CreateMap<DirectoryEntry, DirectoryEntryDto>();
            CreateMap<DirectoryEntryDto, DirectoryEntry>();
            CreateMap<DirectoryEntryRequestDto, DirectoryEntry>(MemberList.None);
            CreateMap<ChatConversation, ChatConversationItemDto>();

            // Graph User Properties: https://learn.microsoft.com/en-us/graph/api/resources/app?view=graph-rest-1.0#properties
            CreateMap<Microsoft.Graph.Models.User, DirectoryEntry>()
                .ForMember(user => user.ObjectId, opt => opt.MapFrom(src => src.Id))
                .ForMember(user => user.Email, opt => opt.MapFrom(src => src.Mail ?? src.UserPrincipalName))
                .ForMember(user => user.Id, opt => opt.Ignore())
                .ForMember(user => user.IsGroup, opt => opt.MapFrom(src => false));
            CreateMap<Microsoft.Graph.Models.Group, DirectoryEntry>()
                .ForMember(user => user.ObjectId, opt => opt.MapFrom(src => src.Id))
                .ForMember(user => user.Email, opt => opt.MapFrom(src => src.Mail))
                .ForMember(user => user.Id, opt => opt.Ignore())
                .ForMember(user => user.IsGroup, opt => opt.MapFrom(src => true));

            CreateMap<Citation, DocumentDto>()
                .ForMember(dto => dto.LastUpdate, opt => opt.MapFrom(src => src.Partitions.First().LastUpdate))
                .ForMember(dto => dto.DataSourceId, opt => opt.Ignore());
            CreateMap<Citation, DocumentWithTagsDto>()
                .ForMember(dto => dto.LastUpdate, opt => opt.MapFrom(src => src.Partitions.First().LastUpdate))
                .ForMember(dto => dto.Tags, opt => opt.MapFrom(src => src.Partitions.First().Tags.FilterReservedTags()))
                .ForMember(dto => dto.DataSourceId, opt => opt.Ignore());
            CreateMap<AppRegistrationRequestDto, AppRegistration>(MemberList.None).IgnoreAuditFields();
            CreateMap<AppRegistration, AppRegistrationDto>();
            CreateMap<UserRole, UserRoleResponseDto>();
            CreateMap<Agent, AgentResponseDto>()                
                .ForMember(agent => agent.DataSources, opt => opt.MapFrom(src => src.DataSources.Select(x => x.DataSource).ToList()));

            CreateMap<Agent, AgentItemDto>();
                
            CreateMap<AgentRequestDto, Agent>(MemberList.None).IgnoreIdAndAuditFields();
            CreateMap<DocumentUploadStatus, DocumentStatusResponseDto>();
        }
    }

    public static class TagCollectionExtensions
    {
        public static TagCollection FilterReservedTags(this TagCollection tags)
        {
            foreach (var reservedTag in tags.Where(tag => tag.Key.StartsWith(Microsoft.KernelMemory.Constants.ReservedTagsPrefix, StringComparison.Ordinal)))
            {
                tags.Remove(reservedTag);
            };
            return tags;
        }
    }

    public static class AutoMapperExtensions
    {
        public static IMappingExpression<TSource, TDestination> IgnoreIdAndAuditFields<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping) where TDestination : IAuditableCreated
        {
            mapping.IgnoreIdField();
            mapping.IgnoreAuditFields();
            return mapping;
        }

        public static IMappingExpression<TSource, TDestination> IgnoreAuditFields<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping) where TDestination : IAuditableCreated
        {
            mapping.ForMember(entity => entity.CreatedBy, opt => opt.Ignore());
            mapping.ForMember(entity => entity.CreatedOn, opt => opt.Ignore());
            return mapping;
        }

        public static IMappingExpression<TSource, TDestination> IgnoreIdField<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping) where TDestination : IAuditableCreated
        {
            mapping.ForMember("Id", opt => opt.Ignore());
            return mapping;
        }
    }
}
