﻿using Microsoft.EntityFrameworkCore;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using OpenAI.Chat;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.ErrorHandling;
using PerceptApi.Extensions;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Text.Json;

#pragma warning disable SKEXP0001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
namespace PerceptApi.Services
{
    public class ConversationService(IBaseRepository<ChatConversation> repository,
                                     IHttpContextAccessor contextAccessor,
                                     ISystemAgentFactory systemAgentFactory,
                                     IAgentService agentService) : BaseService<ChatConversation>(repository), IConversationService
    {
        private const string ORIGINAL_INDEX_TAG = "originalIndex";
        private readonly IBaseRepository<ChatConversation> conversationRepositry = repository;

        public ChatConversation? GetByIdWithAgent(Guid id)
        {
            var query = base.GetAllByCondition(c => c.Id.Equals(id)).Include(c => c.Agent);
            return query.FirstOrDefault();
        }

        public ChatConversation GetOrCreateConversation(AgentQuery query)
        {
            var conversation = query.ConversationId.HasValue ? conversationRepositry.GetById(query.ConversationId.Value, true) : null;
            if (conversation == null)
            {
                var authenticatedUserId = contextAccessor.HttpContext.User.GetUserId();
                if (!authenticatedUserId.HasValue)
                {
                    throw new UnauthorizedAccessException("Could not determine User Id");
                }

                if (!query.AgentId.HasValue)
                {
                    throw new AgentNotFoundException("An AgentId is required to start a Conversation");
                }
                var agent = agentService.GetById(query.AgentId.Value);
                if (agent == null)
                {
                    throw new AgentNotFoundException("Requested Agent not found");
                }
                conversation = new ChatConversation { Name = query.Question, AgentId = agent.Id, DirectoryEntryId = authenticatedUserId.Value };
                conversationRepositry.Add(conversation);
            }

            return conversation;
        }

        public async Task<bool> SoftDeleteAsync(Guid id)
        {
            var entity = conversationRepositry.GetById(id, true);

            if (entity is not null)
            {
                entity.SoftDelete = true;
                await conversationRepositry.SaveAsync();
            }
            return true;
        }

        public async Task<Models.ChatMessage> AskAsync(ChatConversation conversation, AgentQuery query, CancellationToken cancellationToken)
        {
            var agent = agentService.GetById(conversation.AgentId);
            if (agent == null || agent.IsDisabled)
            {
                throw new Exception("Agent not available to continue conversation");
            }

            if (query.AgentId.HasValue)
            {
                var queryAgent = agentService.GetById((Guid)query.AgentId);
                if (queryAgent == null)
                {
                    throw new Exception($"The agent passed in your query with id {query.AgentId} was not found");
                }
                else if (agent.Id != queryAgent.Id)
                {
                    throw new Exception($"The agent passed in your query \'{queryAgent.Name}\' does not match the existing agent \'{agent.Name}\' attached to the conversation ");
                }
            }

            var systemAgent = systemAgentFactory.Create(agent, query);

            var userOrDefaultPrompt = query.ContextArguments?.Prompt ?? string.Empty;

            var chatHistory = conversation.GetOrCreateChatHistory(systemAgent.SystemMessage, userOrDefaultPrompt);

            chatHistory.AddUserMessage(query.Question);

            ChatHistory clonedChatHistory = new ChatHistory(chatHistory);
            var toolMessages = GetToolMessages(clonedChatHistory);
            foreach (var message in toolMessages.ToList())
            {
                clonedChatHistory.Remove(message);
            }

            var result = await systemAgent.InvokeAsync(clonedChatHistory);

            var newToolMessages = GetToolMessages(clonedChatHistory);
            foreach (var message in newToolMessages)
            {
                chatHistory.Add(message);
            }

            if (result is not null)
            {
                chatHistory.Add(result);
            }

            var answerId = string.Empty;
            if (result?.Metadata?.ContainsKey("Id") == true)
            {
                answerId = result.Metadata["Id"].ToString();
                conversation.Citations.Add(answerId, systemAgent.Citations);
                conversation.AgentQueryContexts.Add(answerId, query.ContextArguments);
            }

            conversation.ChatHistory = new ChatHistory(chatHistory); // This is to trigger EF that there are updates.

            await conversationRepositry.SaveAsync();

            var chatMessage = conversation.GetChatMessages(contextAccessor.HttpContext.Request).First(x => x.Id == answerId) as AIChatMessage;

            return chatMessage;
        }

        private List<SemanticFunctionResponse> GetSemanticFunctions(IEnumerable<Microsoft.SemanticKernel.ChatMessageContent> chatMessageContents)
        {
            var responses = new List<SemanticFunctionResponse>();

            foreach (var message in chatMessageContents.ToList())
            {
                if (message.Role == AuthorRole.Tool &&
                    message.Metadata is not null &&
                    message.Metadata.ContainsKey("ChatCompletionsToolCall.Id"))
                {
                    var functionContent = message.Items.OfType<FunctionResultContent>().Single();

                    var assistantMessage = chatMessageContents.Where(x => x.Items.OfType<FunctionCallContent>().Any(y => y.Id == functionContent.CallId)).Single();
                    var arguments = assistantMessage.Items.OfType<FunctionCallContent>().Single().Arguments;

                    var response = new SemanticFunctionResponse
                    {
                        PluginName = functionContent.PluginName ?? string.Empty,
                        FunctionName = functionContent.FunctionName ?? string.Empty,
                        Result = JsonSerializer.Serialize(functionContent.Result),
                        Arguments = JsonSerializer.Serialize(arguments),
                    };

                    responses.Add(response);
                }
            }

            return responses;
        }

        private IEnumerable<Microsoft.SemanticKernel.ChatMessageContent> GetToolMessages(ChatHistory chatHistory)
        {
            //Track a new list to keep the order correct.
            var messages = new List<Microsoft.SemanticKernel.ChatMessageContent>();
            var toolMessages = chatHistory.Where(x => x.Role == AuthorRole.Tool);
            foreach (var message in toolMessages.ToList())
            {
                if (message.Metadata is not null && message.Metadata.ContainsKey("ChatCompletionsToolCall.Id"))
                {
                    var toolId = string.Empty;
                    if (message.Metadata.GetValueOrDefault("ChatCompletionsToolCall.Id", new JsonElement()) is JsonElement element)
                    {
                        if (element.ValueKind != JsonValueKind.Undefined)
                        {
                            toolId = element.GetString() ?? string.Empty;
                        }
                    }
                    else if (message.Metadata.GetValueOrDefault("ChatCompletionsToolCall.Id", string.Empty) is string value)
                    {
                        toolId = value;
                    }

                    var toolItem = chatHistory.FirstOrDefault(x =>
                    {
                        if (x.Metadata?.GetValueOrDefault("ChatResponseMessage.FunctionToolCalls", new JsonElement()) is JsonElement toolElement)
                        {
                            if (toolElement.ValueKind != JsonValueKind.Undefined && toolElement.EnumerateArray().FirstOrDefault().TryGetProperty("Id", out var idProperty))
                            {
                                return idProperty.GetString() == toolId;
                            }
                        }
                        // https://learn.microsoft.com/en-us/semantic-kernel/support/migration/function-calling-migration-guide?pivots=programming-language-csharp
                        else if (x.Metadata?.GetValueOrDefault("ChatResponseMessage.FunctionToolCalls", new List<ChatToolCall>()) is List<ChatToolCall> toolList)
                        {
                            return toolList.First().Id == toolId;
                        }

                        return false;
                    });
                    if (toolItem is not null)
                    {
                        messages.Add(toolItem);
                    }
                }

                messages.Add(message);
            }

            return messages;
        }

        public IEnumerable<ChatConversation> GetAppUserChatConversations(Guid appId, Guid userId)
        {
            return GetAllByCondition(c => c.Agent.ApplicationId.Equals(appId) && c.DirectoryEntryId.Equals(userId))
                 .Include(c => c.Agent)
                 .Where(x => !x.Agent.IsDisabled)
                 .OrderByDescending(c => c.CreatedOn)
                 .ToList() ?? new List<ChatConversation>();
        }
    }
}

#pragma warning restore SKEXP0001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.