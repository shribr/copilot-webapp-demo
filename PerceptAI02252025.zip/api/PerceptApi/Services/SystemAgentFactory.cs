﻿using PerceptApi.Agents;
using PerceptApi.Agents.Interfaces;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    public class SystemAgentFactory : ISystemAgentFactory
    {
        private readonly IConfiguration _appConfiguration;

        public SystemAgentFactory(IConfiguration appConfiguration)
        {
            _appConfiguration = appConfiguration;
        }

        public ISystemAgent Create(Agent agentConfiguration, AgentQuery query)
        {
            var agent = new SystemAgent();
            agent.Initialize(_appConfiguration, agentConfiguration, query);
            return agent;
        }
    }
}
