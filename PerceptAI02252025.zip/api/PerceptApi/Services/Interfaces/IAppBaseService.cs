﻿using Percept.Shared.Data.Entities;
using PerceptApi.Models;

namespace PerceptApi.Services.Interfaces
{
    public interface IAppBaseService<T> : IBaseService<T> where T : class, IHasApplicationId
    {
        IQueryable<T> GetByApp(Guid appId);
        PagedResponse<T> Get(Guid appId, int page = 1, int pageSize = 25);
    }
}
