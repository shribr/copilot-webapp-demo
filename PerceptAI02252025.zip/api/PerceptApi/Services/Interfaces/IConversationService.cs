﻿using PerceptApi.Data.Entities;
using PerceptApi.DTOs;

namespace PerceptApi.Services.Interfaces
{
    public interface IConversationService : IBaseService<ChatConversation>
    {
        ChatConversation GetOrCreateConversation(AgentQuery query);
        Task<Models.ChatMessage> AskAsync(ChatConversation conversation, AgentQuery query, CancellationToken cancellationToken);
        Task<bool> SoftDeleteAsync(Guid id);
        IEnumerable<ChatConversation> GetAppUserChatConversations(Guid appId, Guid userId);
        ChatConversation? GetByIdWithAgent(Guid id);
    }
}
