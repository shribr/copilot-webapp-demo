﻿using PerceptApi.Data.Entities;
using PerceptApi.Enums;

namespace PerceptApi.Services.Interfaces
{
    public interface IFeedbackService : IAppBaseService<Feedback>
    {
        IEnumerable<Feedback> GetFiltered(Guid appId, Reaction reaction, DateTime? startDate, DateTime? endDate, string? search);
    }
}