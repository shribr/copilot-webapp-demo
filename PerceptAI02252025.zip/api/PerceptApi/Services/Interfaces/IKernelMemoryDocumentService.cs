﻿using Microsoft.KernelMemory;
using PerceptApi.DTOs;

namespace PerceptApi.Services.Interfaces
{
    public interface IKernelMemoryDocumentService
    {
        Task<string[]> UpdateDocumentsTagsAsync(string index, List<UpdateDocumentRequestDto> updateRequests);
        Task<string[]> UpdateDocumentTagsAsync(string index, string documentId, TagCollection tagsToAdd, TagCollection tagsToRemove);
        Task<TagCollection> GetUniqueTagsByIndexAsync(string memoryStoreName, List<string> agentCategories);
    }
}
