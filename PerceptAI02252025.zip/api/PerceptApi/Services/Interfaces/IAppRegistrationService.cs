﻿using PerceptApi.Data.Entities;

namespace PerceptApi.Services.Interfaces
{
    public interface IAppRegistrationService : IBaseService<AppRegistration>
    {
        AppRegistration GetByRouteName(string routeName);
    }
}
