﻿using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using System.Security.Principal;

namespace PerceptApi.Services.Interfaces
{
    public interface IUserRoleService : IAppBaseService<UserRole>
    {
        Task<UserRole> AddPermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, Guid objectId, bool isGroup, T permission) where T : Enum;
        Task<List<UserRole>> AddPermissionsToUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IEnumerable<DirectoryEntryRoleChange<T>> entries) where T : Enum;

        Task<bool> HasPermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IPrincipal authenticatedUser, T permission) where T : Enum;
        IEnumerable<DirectoryEntry> GetDirectoryEntriesByPermission<T>(Guid appId, Guid entityId, EntityTypes entityType, T permission) where T : Enum;
      
        Task<bool> RemovePermissionAsync<T>(UserRole userRole, T permission) where T : Enum;
        Task<bool> RemovePermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry, T permission) where T : Enum;
        Task<bool> RemovePermissionsFromUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, List<DirectoryEntry> entries, T permission, bool withSave = true) where T : Enum;
        Task<bool> RemovePermissionsFromUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IEnumerable<DirectoryEntryRoleChange<T>> entries) where T : Enum;

        UserRole? Get<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry, T permission) where T : Enum;
        Task<bool> HasAnyAppPermissionAsync(IPrincipal authenticatedUser);
        Task<IQueryable<UserRole>> GetUserRolesAsync(Guid appId, Guid entityId, EntityTypes entityType, IPrincipal authenticatedUser);
    }
}
