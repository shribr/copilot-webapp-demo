﻿using System.Data;

namespace PerceptApi.Services.Interfaces
{
    public interface IMarkdownService
    {
        IEnumerable<DataTable> ExtractDatatable(string markdown);
        MemoryStream TableToExcel(string markdown);
    }
}