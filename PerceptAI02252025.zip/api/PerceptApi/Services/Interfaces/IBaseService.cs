﻿using PerceptApi.Models;
using System.Linq.Expressions;

namespace PerceptApi.Services.Interfaces
{
    public interface IBaseService<T> where T : class
    {
        void Add(T entity);
        Task<T> CreateAsync(T entity);
        T? GetById(Guid id, bool trackChanges = false);
        PagedResponse<T> Get(int page = 1, int pageSize = 25);
        Task<bool> DeleteAsync(Guid id);
        IQueryable<T> GetAllByCondition(Expression<Func<T, bool>> expression, bool trackChanges = false);
        Task<T> UpdateAsync(T entity);
        void Remove(T entity);
        PagedResponse<T> GetPagedByCondition(Expression<Func<T, bool>> expression, bool trackChanges = false, int page = 1, int pageSize = 25);
        Task CommitTransactionAsync();
        IEnumerable<T> GetAll(bool trackChanges = false);
    }
}
