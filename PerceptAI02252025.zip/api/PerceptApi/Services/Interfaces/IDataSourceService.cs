﻿using PerceptApi.Data.Entities;

namespace PerceptApi.Services.Interfaces
{
    public interface IDataSourceService : IAppBaseService<DataSource>
    {
        Task<bool> DeleteAsync(Guid appId, Guid dataSourceId);
        bool IndexNameExist(Guid appId, string indexName);
        string NormalizeIndexName(string index);
    }
}