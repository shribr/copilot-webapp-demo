﻿using PerceptApi.Data.Entities;
using PerceptApi.DTOs;

namespace PerceptApi.Services.Interfaces
{
    public interface IAgentService : IAppBaseService<Agent>
    {
        Task<Agent> CreateAgentAsync(AgentRequestDto agentRequest);
        Task<Agent> PutAsync(Agent agentConfiguration, AgentRequestDto agentRequest);
    }
}
