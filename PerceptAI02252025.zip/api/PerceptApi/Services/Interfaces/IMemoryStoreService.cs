﻿using Microsoft.KernelMemory;
using PerceptApi.Data.Entities;

namespace PerceptApi.Services.Interfaces
{
    public interface IMemoryStoreService
    {
        Task<DataSource> CreateAsync(Guid appId, string name, string description);
        Task<bool> DeleteAsync(Guid appId, Guid dataSourceId);
        Task<TagCollection> GetTagsAsync(Guid agentId);
    }
}