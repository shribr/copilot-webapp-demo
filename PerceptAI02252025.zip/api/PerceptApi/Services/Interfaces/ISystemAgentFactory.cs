﻿using PerceptApi.Agents.Interfaces;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;

namespace PerceptApi.Services.Interfaces
{
    public interface ISystemAgentFactory
    {
        ISystemAgent Create(Agent agentConfiguration, AgentQuery query);
    }
}