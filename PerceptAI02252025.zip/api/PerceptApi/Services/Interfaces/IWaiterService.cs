﻿namespace PerceptApi.Services.Interfaces
{
    public interface IWaiterService
    {
        Task WaitFor(Func<bool> action, TimeSpan timeout, CancellationToken cancellationToken);
        Task WaitForAsync(Func<bool> action, TimeSpan timeout, TimeSpan delay, CancellationToken cancellationToken);
    }
}