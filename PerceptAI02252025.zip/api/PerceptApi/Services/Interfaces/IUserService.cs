﻿using PerceptApi.Data.Entities;
using System.Security.Claims;

namespace PerceptApi.Services.Interfaces
{
    public interface IUserService : IBaseService<DirectoryEntry>
    {
        void ClearCache(Guid objectId);
        Task<DirectoryEntry> GetOrCreateDirectoryEntryAsync(Guid objectId, bool isGroup);
        Task<DirectoryEntry> GetOrCreateUserEntryAsync(Guid objectId, ClaimsIdentity authenticatedUser);
    }
}