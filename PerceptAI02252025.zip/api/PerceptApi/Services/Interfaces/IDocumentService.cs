﻿using Azure.Storage.Blobs;
using Microsoft.KernelMemory;
using Percept.Shared.Data.Entities;
using Percept.Shared.Models;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;

namespace PerceptApi.Services.Interfaces
{
    public interface IDocumentService
    {
        Task DeleteFilesAsync(DataSource dataSource, IEnumerable<string> documentIds);
        Task DeleteDocumentAsync(DocumentUploadStatus status);
        Task<DocumentWithTagsDto?> GetDocumentAsync(DataSource dataSource, string documentId, CancellationToken cancellationToken);
        Task<IQueryable<DocumentWithTagsDto>> GetDocumentsAsync(DataSource dataSource, List<MemoryFilter>? filters, CancellationToken cancellationToken);
        Task<IEnumerable<BlobClient>> GetPendingFiles(CancellationToken cancellationToken);
        Task<DocumentPipelineStatus> ImportBlobStreamAsync(Stream stream, string blobFileName);
        Task UploadFiles(string index, TagCollection tags, List<DocumentUploadRequest.UploadedFile> Files, CancellationToken cancellationToken);
    }
}