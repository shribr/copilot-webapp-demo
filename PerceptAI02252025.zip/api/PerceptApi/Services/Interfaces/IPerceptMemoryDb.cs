﻿using Microsoft.KernelMemory.MemoryStorage;

namespace PerceptApi.Services.Interfaces
{
    public interface IPerceptMemoryDb
    {
        Task<string[]> UpsertBatchAsync(
            string indexName,
            IEnumerable<MemoryRecord> records,
            CancellationToken cancellationToken = default);
    }
}
