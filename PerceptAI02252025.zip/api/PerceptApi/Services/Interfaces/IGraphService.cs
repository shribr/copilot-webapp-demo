﻿

using PerceptApi.Data.Entities;

namespace PerceptApi.Services.Interfaces
{
    public interface IGraphService
    {
        Task<DirectoryEntry?> GetGroupAsync(Guid objectId);
        Task<IEnumerable<Microsoft.Graph.Models.DirectoryObject>> GetGroupsAsync(Guid objectId);
        Task<DirectoryEntry?> GetUserAsync(Guid objectId);
        Task<IEnumerable<DirectoryEntry>> SearchGroupsAsync(string? query);
        Task<IEnumerable<DirectoryEntry>> SearchUsersAndGroups(string? query);
        Task<IEnumerable<DirectoryEntry>> SearchUsersAsync(string? query);
    }
}