﻿using Microsoft.KernelMemory;
using Microsoft.SemanticKernel.ChatCompletion;

namespace PerceptApi.Services.Interfaces
{
    public interface IConversationHistoryService
    {
        ChatHistory AddChatInteraction(ChatHistory history, MemoryAnswer answer);
        Task<string> CreateQuestionAsync(ChatHistory history, string question);
    }
}