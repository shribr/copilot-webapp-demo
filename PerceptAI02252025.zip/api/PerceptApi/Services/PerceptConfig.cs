﻿namespace PerceptApi.Services
{
    public class PerceptConfig
    {
        public bool isDev { get; set; }
        public int ChatHistoryLimit { get; init; } = 30;
        public double CacheExpirationInHours { get; init; } = 1;
        public long? MaxUploadSizeInBytes { get; init; }
    }
}
