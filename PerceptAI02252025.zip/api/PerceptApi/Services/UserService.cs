﻿using Microsoft.Extensions.Caching.Distributed;
using PerceptApi.Data.Entities;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Security.Claims;

namespace PerceptApi.Services
{
    public class UserService(IBaseRepository<DirectoryEntry> repository, IGraphService graphService, IDistributedCache cache,
            ILogger<UserService> logger) :
         BaseService<DirectoryEntry>(repository), IUserService
    {
        private readonly IBaseRepository<DirectoryEntry> _repository = repository;

        public void ClearCache(Guid objectId)
        {
            cache.Remove(objectId.ToString());
        }

        public async Task<DirectoryEntry> GetOrCreateUserEntryAsync(Guid objectId, ClaimsIdentity authenticatedUser)
        {
            DirectoryEntry? result = null;
            try
            {
                result = await GetOrCreateDirectoryEntryAsync(objectId, false);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, null);
            }
            if (result == null)
            {
                result = await CreateAsync(new DirectoryEntry { ObjectId = objectId, DisplayName = authenticatedUser.Name, IsGroup = false });
            }
            return result;
        }

        public async Task<DirectoryEntry> GetOrCreateDirectoryEntryAsync(Guid objectId, bool isGroup)
        {
            DirectoryEntry? directoryEntry = _repository.GetAllByCondition(x => x.ObjectId.Equals(objectId) && x.IsGroup == isGroup, false).FirstOrDefault();
            if (directoryEntry is null)
            {
                if (isGroup)
                {
                    directoryEntry = await graphService.GetGroupAsync(objectId);
                }
                else
                {
                    directoryEntry = await graphService.GetUserAsync(objectId);
                }

                if (directoryEntry is null)
                {
                    throw new KeyNotFoundException("User or group was not found");
                }

                await base.CreateAsync(directoryEntry);
            }

            return directoryEntry;
        }
    }
}