﻿using Percept.Shared.Data.Entities;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    public abstract class AppBaseService<T>(IBaseRepository<T> repository)
        : BaseService<T>(repository), IAppBaseService<T> where T : class, IHasApplicationId
    {
        public virtual IQueryable<T> GetByApp(Guid appId)
        {
            var query = GetAllByCondition(a => a.ApplicationId.Equals(appId));
            return query;
        }

        public virtual PagedResponse<T> Get(Guid appId, int page = 1, int pageSize = 25)
        {
            var query = GetByApp(appId);
            return new PagedResponse<T>(page, pageSize, query);
        }
    }
}
