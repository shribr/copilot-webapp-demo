﻿using Microsoft.KernelMemory;
using Microsoft.SemanticKernel.ChatCompletion;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services;

public class ConversationHistoryService(
    IChatCompletionService chatCompletionService) : IConversationHistoryService
{
    public async Task<string> CreateQuestionAsync(ChatHistory history, string question)
    {
        var embeddingQuestion = $"""
            Reformulate the following question taking into account the context of the chat to perform embeddings search:
            ---
            {question}
            ---
            You must reformulate the question in the same language of the user's question.
            Never add "in this chat", "in the context of this chat", "in the context of our conversation", "search for" or something like that in your answer.
            """;

        history.AddUserMessage(embeddingQuestion);
        var reformulatedQuestion = await chatCompletionService.GetChatMessageContentAsync(history)!;
        history.AddAssistantMessage(reformulatedQuestion.Content!);

        return reformulatedQuestion.Content!;
    }

    public ChatHistory AddChatInteraction(ChatHistory history, MemoryAnswer answer)
    {
        if (answer.NoResult == false) // only update Chat History is there is context to add
        {
            history.AddUserMessage(answer.Question);
            history.AddAssistantMessage(answer.Result);
        }
        return history;
    }
}