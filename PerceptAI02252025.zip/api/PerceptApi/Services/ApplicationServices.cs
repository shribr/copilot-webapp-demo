﻿using Azure.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph;
using Microsoft.Identity.Web;
using Percept.Shared.Configuration;
using Percept.Shared.Services;
using Percept.Shared.Services.Interfaces;
using PerceptApi.Authorization;
using PerceptApi.Data;
using PerceptApi.Data.Entities;
using PerceptApi.Repositories;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Reflection;
using System.Security.Principal;
using DataSource = PerceptApi.Data.Entities.DataSource;


namespace PerceptApi.Services
{
    public static class ApplicationServices
    {
        public static void AddApplicationServices(this IServiceCollection services, ConfigurationManager configuration, bool isDev = false)
        {
            services.AddApiAuth(configuration, isDev);
            services.AddTransient<IPrincipal>(services =>
            {
                var context = services.GetService<IHttpContextAccessor>();
                return context?.HttpContext?.User ?? new GenericPrincipal(new GenericIdentity("unknown"), null);
            });

            services.AddScoped<IKernelMemoryDocumentService, KernelMemoryDocumentService>();

            var kernelBuilder = services.AddSemanticKernel(configuration);

            services.AddDbContextFactory<Data.PerceptDbContext>(options =>
            {
                options.UseSqlServer(configuration[ConfigurationProperties.SqlConnectionString]);
            }, ServiceLifetime.Scoped);

            services.AddDistributedSqlServerCache(options =>
            {
                options.ConnectionString = configuration[ConfigurationProperties.SqlConnectionString];
                options.SchemaName = "dbo";
                options.TableName = nameof(PerceptDbContext.MemoryStoresCache);
            });

            services.AddLogging();

            PerceptConfig perceptConfig = new();
            configuration.Bind("Percept", perceptConfig);
            perceptConfig.isDev = isDev;
            services.AddSingleton(perceptConfig);

            services.AddScoped(typeof(IBaseRepository<>), typeof(BaseRepository<>));
            services.AddScoped<IFeedbackService, FeedbackService>();
            services.AddScoped<IMemoryStoreService, MemoryStoreService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IUserRoleService, UserRoleService>();
            services.AddScoped<IConversationHistoryService, ConversationHistoryService>();
            services.AddTransient<IConversationService, ConversationService>();
            services.AddSingleton((serviceProvider) => GetGraphServiceClient(serviceProvider, configuration, isDev));
            services.AddSingleton<IGraphService, GraphService>();
            services.AddScoped<IDocumentService, DocumentService>();
            services.AddScoped<IAppRegistrationService, AppRegistrationService>();
            services.AddScoped<IAgentService, AgentService>();
            services.AddSingleton<ISystemAgentFactory, SystemAgentFactory>();
            services.AddSingleton<ITaskService, TaskService>();
            services.AddSingleton<IWaiterService, WaiterService>();
            services.AddScoped<IDocumentStatusService<PerceptDbContext>, DocumentStatusService<PerceptDbContext>>();
            services.AddSingleton<IMarkdownService, MarkdownService>();
            services.AddScoped<IDataSourceService, DataSourceService>();
            services.AddSingleton<IPerceptMemoryDb, PerceptAzureAISearchMemoryDb>();

            services.AddAutoMapper(Assembly.GetEntryAssembly());
            services.AddKernelMemory(configuration);

            // Hosting Service to support MaxUploadSize
            long? maxSize = perceptConfig.MaxUploadSizeInBytes;
            if (maxSize.HasValue)
            {

                services.Configure<IISServerOptions>(x => { x.MaxRequestBodySize = maxSize.Value; });
                services.Configure<KestrelServerOptions>(x => { x.Limits.MaxRequestBodySize = maxSize.Value; });
                services.Configure<FormOptions>(x =>
                {
                    x.MultipartBodyLengthLimit = maxSize.Value;
                    x.ValueLengthLimit = int.MaxValue;
                });
            };
        }

        public static void AddAuthorizationServices(this IServiceCollection services)
        {
            services.AddTransient<IAuthorizationHandler, PerceptAuthorizationhandler<FeedbackOperationAuthorizationRequirement, Feedback>>();
            services.AddTransient<IAuthorizationHandler, PerceptAuthorizationhandler<DataSourceOperationAuthorizationRequirement, DataSource>>();
            services.AddTransient<IAuthorizationHandler, PerceptAuthorizationhandler<AgentOperationAuthorizationRequirement, Agent>>();
            services.AddTransient<IAuthorizationHandler, PerceptAuthorizationhandler<AppOperationAuthorizationRequirement, AppRegistration>>();
            services.AddScoped<IPermissionService, PermissionService>();
        }

        private static GraphServiceClient GetGraphServiceClient(IServiceProvider serviceProvider, ConfigurationManager configuration, bool isDev)
        {
            var azureAdConfig = new AzureAdConfig();
            configuration.Bind("AzureAd", azureAdConfig);

            // TODO: Test OnBehalfOf once we have a UI to pass a valid user token.
            //if (isDev)
            //{
            var scopes = new[] { $"{azureAdConfig.GraphApiEndpoint}.default" };
            Uri? uriParseResult;
            Uri.TryCreate($"{azureAdConfig.GraphApiEndpoint}/v1.0", UriKind.Absolute, out uriParseResult);

            if (uriParseResult is null)
            {
                // TODO: Log to EventLog (requires creating an EventLogSource upon application startup) or to Azure Application Insights.
                throw new ArgumentException("Could not parse Microsoft Graph baseUrl to URI.");
            }

            return new GraphServiceClient(GetClientSecretCredential(configuration), scopes, uriParseResult.ToString());
            //}
            //else
            //{
            //    var scopes = new[] { $"{azureAdConfig.GraphApiEndpoint}User.ReadBasic.All" };
            //    return new GraphServiceClient(GetOnBehalfOfCredential(serviceProvider, configuration), scopes);
            //}
        }

        private static ClientSecretCredential GetClientSecretCredential(ConfigurationManager configuration)
        {
            var azureAdConfig = new AzureAdConfig();
            configuration.Bind("AzureAd", azureAdConfig);
            var options = new ClientSecretCredentialOptions
            {
                AuthorityHost = new Uri(azureAdConfig.Instance)
            };

            return new ClientSecretCredential(azureAdConfig.TenantId, azureAdConfig.ClientId, azureAdConfig.ClientSecret, options);

        }

        private static OnBehalfOfCredential GetOnBehalfOfCredential(IServiceProvider serviceProvider, ConfigurationManager configuration)
        {
            var azureAdConfig = new AzureAdConfig();
            configuration.Bind("AzureAd", azureAdConfig);
            var scopes = new[] { $"{azureAdConfig.GraphApiEndpoint}User.ReadBasic.All" };
            var tokenAcquisition = serviceProvider.GetService<ITokenAcquisition>();
            string accessToken = tokenAcquisition != null ?
                tokenAcquisition.GetAccessTokenForUserAsync(scopes).GetAwaiter().GetResult() :
                string.Empty;
            var options = new OnBehalfOfCredentialOptions
            {
                AuthorityHost = new Uri(azureAdConfig.Instance)
            };

            return new OnBehalfOfCredential(azureAdConfig.TenantId, azureAdConfig.ClientId, azureAdConfig.ClientSecret, accessToken, options);
        }
    }
}