﻿using Microsoft.EntityFrameworkCore;
using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using PerceptApi.Extensions;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Security.Principal;
using DirectoryEntry = PerceptApi.Data.Entities.DirectoryEntry;

namespace PerceptApi.Services
{
    public class UserRoleService : AppBaseService<UserRole>, IUserRoleService
    {
        private readonly IGraphService _graphService;
        private readonly IUserService _userService;
        private readonly IBaseRepository<UserRole> _userRoleRepository;

        public UserRoleService(IBaseRepository<UserRole> userRoleRepository, IUserService userService, IGraphService graphService) : base(userRoleRepository)
        {
            _userRoleRepository = userRoleRepository ?? throw new ArgumentNullException(nameof(userRoleRepository));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _graphService = graphService ?? throw new ArgumentNullException(nameof(graphService)); ;
        }

        public IEnumerable<DirectoryEntry> GetDirectoryEntriesByPermission<T>(Guid appId, Guid entityId, EntityTypes entityType, T permission) where T : Enum
        {
            var permissionValue = Convert.ToInt32(permission);
            return GetAllByCondition(ur =>
                ur.ApplicationId.Equals(appId) &&
                ur.EntityId.Equals(entityId) &&
                ur.EntityType.Equals(entityType) &&
                (ur.Permission & permissionValue).Equals(permissionValue) // Flag check for permission
                ).Include(ur => ur.DirectoryEntry).Select(ur => ur.DirectoryEntry).OrderBy(e => e.DisplayName);
        }

        public async Task<bool> HasPermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IPrincipal authenticatedUser, T permission) where T : Enum
        {
            var permissionValue = Convert.ToInt32(permission);
            return (await GetUserRolesAsync(appId, entityId, entityType, authenticatedUser))
                .Where(ur => (ur.Permission & permissionValue).Equals(permissionValue)).Any();
        }

        public async Task<bool> HasAnyAppPermissionAsync(IPrincipal authenticatedUser)
        {
            var userObjectId = authenticatedUser.GetObjectId().Value;
            var groupObjectIds = (await _graphService.GetGroupsAsync(userObjectId)).Select(g => new Guid(g.Id)).ToList();
            return GetAllByCondition(ur =>
                (ur.DirectoryEntry.ObjectId.Equals(userObjectId) && !ur.IsGroup) ||
                (groupObjectIds.Contains(ur.DirectoryEntry.ObjectId) && ur.IsGroup)
                ).Any();
        }

        public async Task<bool> RemovePermissionAsync<T>(UserRole userRole, T permission) where T : Enum
        {
            _RemovePermission(userRole.ApplicationId, userRole, permission);
            await _userRoleRepository.SaveAsync();
            return true;
        }

        public async Task<bool> RemovePermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry, T permission) where T : Enum
        {
            var userRole = Get(appId, entityId, entityType, directoryEntry, permission);
            if (userRole != null)
            {
                _RemovePermission(appId, userRole, permission);
                await _userRoleRepository.SaveAsync();
            }
            return true;
        }

        private void _RemovePermission<T>(Guid appId, UserRole userRole, T permission) where T : Enum
        {
            var currentPermission = (T)Enum.ToObject(typeof(T), userRole.Permission);
            if (currentPermission.HasFlag(permission))
            {
                userRole.Permission = RemovePermission(userRole.Permission, permission);

                if (userRole.Permission == 0)
                {
                    Remove(userRole);
                }
                else
                {
                    Update(userRole);
                }
            }
        }

        public async Task<bool> RemovePermissionsFromUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IEnumerable<DirectoryEntryRoleChange<T>> entries) where T : Enum
        {
            var results = new List<UserRole>();
            var entryIds = entries.Select(e => e.Id).ToList();
            var userRoles = GetAllByCondition(ur =>
                ur.EntityId.Equals(entityId) &&
                ur.EntityType.Equals(entityType) &&
                entryIds.Contains(ur.DirectoryEntryId)).ToList();

            userRoles.ForEach(userRole =>
            {
                var entry = entries.First(e=>e.Id.Equals(userRole.DirectoryEntryId));
                _RemovePermission<T>(appId, userRole, entry.RoleFlagChange);
                results.Add(userRole);
            });
            
            await _userRoleRepository.SaveAsync();
            return results.Count.Equals(entries.Count());
        }

        public async Task<bool> RemovePermissionsFromUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, List<DirectoryEntry> entries, T permission, bool withSave=true) where T : Enum
        {
            var entryIds = entries.Select(e => e.Id).ToList();
            var userRoles = GetAllByCondition(ur =>
                    ur.EntityId.Equals(entityId) &&
                    ur.EntityType.Equals(entityType) &&
                    entryIds.Contains(ur.DirectoryEntryId)
                ).ToList();

            userRoles.ForEach(userRole =>
            {
                _RemovePermission(appId, userRole, permission);
            });

            if (withSave)
            {
                await _userRoleRepository.SaveAsync();
            }
            return true;
        }

        public async Task<UserRole> AddPermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, Guid objectId, bool isGroup, T permission) where T : Enum
        {
            var result = await _AddPermissionAsync(appId, entityId, entityType, objectId, isGroup, permission);
            await _userRoleRepository.SaveAsync();
            return result;
        }

        public async Task<List<UserRole>> AddPermissionsToUsersAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, IEnumerable<DirectoryEntryRoleChange<T>> entries) where T : Enum
        {
            var results = new List<UserRole>();
            foreach (var entry in entries)
            {
                results.Add(await _AddPermissionAsync(appId, entityId, entityType, entry.ObjectId, entry.IsGroup, entry.RoleFlagChange));
            }
            await _userRoleRepository.SaveAsync();
            return results;
        }

        private async Task<UserRole> _AddPermissionAsync<T>(Guid appId, Guid entityId, EntityTypes entityType, Guid objectId, bool isGroup, T permission) where T : Enum
        {
            var directoryEntry = await _userService.GetOrCreateDirectoryEntryAsync(objectId, isGroup);

            var userRole = Get<T>(appId, entityId, entityType, directoryEntry);

            if (userRole is null)
            {
                userRole = new UserRole
                {
                    Id = Guid.NewGuid(),
                    ApplicationId = appId,
                    EntityId = entityId,
                    EntityType = entityType,
                    IsGroup = directoryEntry.IsGroup,
                    DirectoryEntryId = directoryEntry.Id,
                    Permission = AddPermission(0, permission)
                };

                Add(userRole);
            }
            else
            {
                var currentPermission = (T)Enum.ToObject(typeof(T), userRole.Permission);
                if (!currentPermission.HasFlag(permission))
                {
                    userRole.Permission = AddPermission(userRole.Permission, permission);
                    Update(userRole);
                }
            }

            return userRole;
        }

        private int AddPermission<T>(int existingPermissions, T newPermission) where T : Enum
        {
            int existing = existingPermissions;
            int newPerm = Convert.ToInt32(newPermission);
            existing |= newPerm;
            return existing;
        }

        private int RemovePermission<T>(int existingPermissions, T permissionToRemove) where T : Enum
        {
            int existing = existingPermissions;
            int permToRemove = Convert.ToInt32(permissionToRemove);
            existing &= ~permToRemove;
            return existing;
        }

        public UserRole? Get<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry) where T : Enum
        {
            var userRoles = FindByEntityAndDirectoryEntryId<T>(appId, entityId, entityType, directoryEntry);
            return userRoles.FirstOrDefault();
        }

        public UserRole? Get<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry, T permission) where T : Enum
        {
            var permissionValue = Convert.ToInt32(permission);
            var userRoles = FindByEntityAndDirectoryEntryId<T>(appId, entityId, entityType, directoryEntry)
                    .Where(x => (x.Permission & permissionValue).Equals(permissionValue));
            return userRoles.FirstOrDefault();
        }

        private IQueryable<UserRole> FindByEntityAndDirectoryEntryId<T>(Guid appId, Guid entityId, EntityTypes entityType, DirectoryEntry directoryEntry) where T : Enum
        {
            return GetAllByDirectoryEntryId(appId, directoryEntry.Id).
                Where(x => x.EntityId == entityId &&
                x.EntityType == entityType);
        }

        private IQueryable<UserRole> GetAllByDirectoryEntryId(Guid appId, Guid directoryEntryId)
        {
            return GetAllByCondition(ur =>
                   ur.ApplicationId.Equals(appId) &&
                   ur.DirectoryEntryId.Equals(directoryEntryId)
                   );
        }

        private IQueryable<UserRole> GetAllByDirectoryObjectIds(Guid appId, Guid? userObjectId, List<Guid> groupObjectIds)
        {
            return GetAllByCondition(ur =>
                ur.ApplicationId.Equals(appId) &&
                ((ur.DirectoryEntry.ObjectId.Equals(userObjectId) && !ur.IsGroup) ||
                (groupObjectIds.Contains(ur.DirectoryEntry.ObjectId) && ur.IsGroup))
                );
        }

        public async Task<IQueryable<UserRole>> GetUserRolesAsync(Guid appId, Guid entityId, EntityTypes entityType, IPrincipal authenticatedUser)
        {
            var userObjectId = authenticatedUser.GetObjectId().Value;
            var usersGroupObjectIds = (await _graphService.GetGroupsAsync(userObjectId)).Select(g => new Guid(g.Id)).ToList();

            return GetAllByDirectoryObjectIds(appId, userObjectId, usersGroupObjectIds).
               Include(ur => ur.DirectoryEntry).
               Where(ur =>
               ur.EntityId.Equals(entityId) &&
               ur.EntityType.Equals(entityType));
        }
    }
}
