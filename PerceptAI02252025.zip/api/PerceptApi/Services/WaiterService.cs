﻿using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    /// <summary>
    ///     Class WaiterService.
    ///     Implements the <see cref="IWaiterService" />
    /// </summary>
    /// <inheritdoc />
    /// <seealso cref="IWaiterService" />
    public class WaiterService : IWaiterService
    {
        /// <summary>
        ///     The time provider
        /// </summary>
        private readonly TimeProvider timeProvider;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WaiterService"/> class.
        /// </summary>
        /// <param name="timeProvider">The time provider.</param>
        /// <exception cref="ArgumentNullException">timeProvider</exception>
        public WaiterService(TimeProvider timeProvider) => this.timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));

        /// <summary>
        ///     Waits for.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="timeout">The timeout.</param>
        /// <param name="cancellationToken">The cancellation token that can be used by other objects or threads to receive notice of cancellation.</param>
        /// <returns>Waits for.</returns>
        public Task WaitFor(Func<bool> action, TimeSpan timeout, CancellationToken cancellationToken)
            => WaitForAsync(action, timeout, TimeSpan.FromSeconds(1), cancellationToken);

        /// <summary>
        ///     Wait for as an asynchronous operation.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="timeout">The timeout.</param>
        /// <param name="delay">The delay.</param>
        /// <param name="cancellationToken">The cancellation token that can be used by other objects or threads to receive notice of cancellation.</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task WaitForAsync(Func<bool> action, TimeSpan timeout, TimeSpan delay, CancellationToken cancellationToken)
        {
            var startTime = timeProvider.GetTimestamp();

            while (timeProvider.GetElapsedTime(startTime) < timeout && !cancellationToken.IsCancellationRequested && action.Invoke())
            {
                await Task.Delay(delay, cancellationToken);
            }
        }
    }
}
