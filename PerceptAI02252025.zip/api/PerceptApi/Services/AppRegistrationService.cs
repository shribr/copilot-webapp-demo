using Microsoft.EntityFrameworkCore;
using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using PerceptApi.ErrorHandling;
using PerceptApi.Extensions;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Security.Principal;

namespace PerceptApi.Services
{
    public class AppRegistrationService(IBaseRepository<AppRegistration> repository, IUserRoleService userRoleService, IPrincipal authenticatedUser) :
            BaseService<AppRegistration>(repository), IAppRegistrationService
    {
        public AppRegistration GetByRouteName(string routeName)
        {
            if (string.IsNullOrEmpty(routeName))
            {
                throw new InvalidOperationException("Route name is required");
            }

            return repository
                .GetAll()
                .Where(x => x.RouteName == routeName)
                .FirstOrDefault();
        }

        public async override Task<AppRegistration> CreateAsync(AppRegistration app)
        {
            await base.CreateAsync(app);
            var ownerObjectId = authenticatedUser.GetObjectId() ?? throw new InvalidOperationException("Authenticated user object ID is required");
            await userRoleService.AddPermissionAsync(app.Id, app.Id, EntityTypes.AppRegistration, ownerObjectId, false, AppRoles.Owner);
            return app;
        }

        public async override Task<AppRegistration> UpdateAsync(AppRegistration updateEntity)
        {
            var currentApp = GetById(updateEntity.Id, true) ?? throw new NotFoundException("App not found");

            currentApp.Name = updateEntity.Name;
            currentApp.Description = updateEntity.Description;
            currentApp.RouteName = updateEntity.RouteName;
            currentApp.Organization = updateEntity.Organization;

            return await base.UpdateAsync(currentApp);
        }
    }
}
