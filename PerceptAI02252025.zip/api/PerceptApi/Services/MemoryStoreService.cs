﻿using Microsoft.EntityFrameworkCore;
using Microsoft.KernelMemory;
using PerceptApi.Agents;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.Enums;
using PerceptApi.Extensions;
using PerceptApi.Plugins;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    public class MemoryStoreService(IBaseRepository<DataSource> repository, IKernelMemory memory, IAgentService agentService,
        IKernelMemoryDocumentService kernelMemoryDocumentService,
        IBaseRepository<UserRole> userRoleRepository,
        AzureOpenAIConfig azureOpenAIConfig) :
        AppBaseService<DataSource>(repository), IMemoryStoreService
    {
        private IBaseRepository<DataSource> _dataSourceRepository = repository;

        public async Task<DataSource> CreateAsync(Guid appId, string name, string description)
        {
            var kmDataSourceConfig = new KernelMemoryDataSourceConfiguration { IndexName = name };
            var dataSource = new DataSource
            {
                Name = name,
                ApplicationId = appId,
                Description = description,
                Type = DataSourceType.Documents,
                Configuration = kmDataSourceConfig
            };
            Add(dataSource);

            var agentConfiguration = new Agent
            {
                ApplicationId = appId,
                Name = name,
                Configuration = new AgentConfiguration()
            };

            var agentDataSourceMap = new AgentDataSource
            {
                AgentId = agentConfiguration.Id,
                DataSourceId = dataSource.Id,
                PluginId = KernelMemoryPluginConstants.PluginId
            };
            agentConfiguration.DataSources.Add(agentDataSourceMap);
            agentService.Add(agentConfiguration);

            await _dataSourceRepository.SaveAsync();
            return dataSource;
        }

        public async Task<bool> DeleteAsync(Guid appId, Guid dataSourceId)
        {
            var dataSource = _dataSourceRepository.GetAllByCondition(ds => ds.Id == dataSourceId, false).Include(ds => ds.AgentDataSources).FirstOrDefault();
            if (dataSource == null) { return true; }
            if (dataSource != null)
            {
                var kmDsConfig = dataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();
                await memory.DeleteIndexAsync(dataSource.GetIndexName());
                Remove(dataSource);

                // Remove permissions for the userstore
                userRoleRepository.GetAllByCondition(x => x.EntityId == dataSourceId && x.EntityType == EntityTypes.DataSource, false).ToList()
                    .ForEach(userRoleRepository.Remove);

                var agentDataSource = dataSource.AgentDataSources.FirstOrDefault();
                if (agentDataSource != null)
                {
                    agentService.Remove(agentService.GetById(agentDataSource.AgentId));
                }
            }

            await _dataSourceRepository.SaveAsync();
            return true;
        }

        public async Task<TagCollection> GetTagsAsync(Guid agentId)
        {
            var agent = agentService.GetAllByCondition(a => a.Id == agentId).Include(a => a.DataSources).ThenInclude(x => x.DataSource).FirstOrDefault();
            if (agent == null)
            {
                return new TagCollection();
            }

            var ds = agent.DataSources.FirstOrDefault();
            if (ds == null)
            {
                return new TagCollection();
            }

            if (ds.DataSource == null || ds.DataSource.Configuration == null)
            {
                return new TagCollection();
            }

            var kmDsConfig = ds.DataSource.Configuration.ConvertFromJsonObject<KernelMemoryDataSourceConfiguration>();

            return await kernelMemoryDocumentService.GetUniqueTagsByIndexAsync(ds.DataSource.GetIndexName(), kmDsConfig.Categories ?? new List<string>());
        }
    }
}