﻿using AutoMapper;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using Microsoft.Graph.Models.ODataErrors;
using Microsoft.Identity.Web;
using PerceptApi.Data.Entities;
using PerceptApi.Extensions;
using PerceptApi.Services.Interfaces;
using System.Security.Principal;

namespace PerceptApi.Services
{
    public class GraphService : IGraphService
    {
        private readonly IDistributedCache cache;
        private readonly GraphServiceClient graphServiceClient;
        private readonly IMapper mapper;
        private readonly PerceptConfig config;
        private readonly IPrincipal authenticatedUser;
        private readonly ILogger<GraphService> logger;
        private readonly DistributedCacheEntryOptions options;

        public GraphService(IDistributedCache cache, GraphServiceClient graphServiceClient, IMapper mapper, PerceptConfig config, IPrincipal authenticatedUser, ILogger<GraphService> logger)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            this.cache = cache ?? throw new ArgumentNullException(nameof(cache));
            this.graphServiceClient = graphServiceClient ?? throw new ArgumentNullException(nameof(graphServiceClient));
            this.mapper = mapper;
            this.config = config;
            this.authenticatedUser = authenticatedUser;
            this.logger = logger;
            options = new()
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(config.CacheExpirationInHours),
            };
        }

        public async Task<IEnumerable<DirectoryObject>> GetGroupsAsync(Guid objectId)
        {
            IEnumerable<DirectoryObject> groups = new List<DirectoryObject>();
            try
            {
                var objectIdString = objectId.ToString();
                groups = await cache.GetAsync<IEnumerable<DirectoryObject>>(objectIdString);

                if (groups is null)
                {
                    groups = (await graphServiceClient.Users[objectIdString].TransitiveMemberOf.GetAsync())?.Value ?? new();
                    cache.Set(objectIdString, groups, options);
                }
            }
            catch (Exception ex)
            {
                logger.LogError("GraphService.GetGroupsAsync objectId={0} error={1}", objectId, ex.Message);
                groups = new List<DirectoryObject>();
            }

            return groups;
        }

        public async Task<DirectoryEntry?> GetUserAsync(Guid objectId)
        {
            try
            {
                var user = await graphServiceClient.Users[objectId.ToString()].GetAsync();
                return mapper.Map<DirectoryEntry>(user);
            }
            catch (ODataError)
            {
                return null;
            }
        }

        public async Task<DirectoryEntry?> GetGroupAsync(Guid objectId)
        {
            try
            {
                var user = await graphServiceClient.Groups[objectId.ToString()].GetAsync();
                return mapper.Map<DirectoryEntry>(user);
            }
            catch (ODataError)
            {
                return null;
            }
        }

        public async Task<IEnumerable<DirectoryEntry>> SearchUsersAsync(string? query)
        {
            if (query == null || query == "")
            {
                return new List<DirectoryEntry>();
            }

            IEnumerable<DirectoryEntry> result = [];
            try
            {
                var graphUsers = await this.graphServiceClient.Users.GetAsync((requestConfiguration) =>
                {
                    requestConfiguration.Options.WithAppOnly();
                    requestConfiguration.QueryParameters.Search = $"\"givenName:{query}\" OR \"surname:{query}\" OR \"displayName:{query}\" OR \"mail:{query}\"";
                    requestConfiguration.Headers.Add("ConsistencyLevel", "eventual");
                });
                result = mapper.Map<IEnumerable<DirectoryEntry>>(graphUsers?.Value);
            }
            catch (Exception ex)
            {
                logger.LogError("GraphService.SearchUsersAsync query={0} error={1}", query, ex.Message);
                throw new Exception(ex.Message);
            }

            return result;
        }

        public async Task<IEnumerable<DirectoryEntry>> SearchGroupsAsync(string? query)
        {
            if (query == null || query == "")
            {
                return new List<DirectoryEntry>();
            }

            IEnumerable<DirectoryEntry> result = [];
            try
            {
                var graphUsers = await this.graphServiceClient.Groups.GetAsync((requestConfiguration) =>
                {
                    requestConfiguration.Options.WithAppOnly();
                    requestConfiguration.QueryParameters.Search = $"\"displayName:{query}\" OR \"description:{query}\"";
                    requestConfiguration.Headers.Add("ConsistencyLevel", "eventual");
                });
                result = mapper.Map<IEnumerable<DirectoryEntry>>(graphUsers?.Value);
            }
            catch (Exception ex)
            {
                logger.LogError("GraphService.SearchGroupsAsync query={0} error={1}", query, ex.Message);
                throw new Exception(ex.Message);
            }

            return result;
        }

        public async Task<IEnumerable<DirectoryEntry>> SearchUsersAndGroups(string? query)
        {
            var usersTask = SearchUsersAsync(query);
            var groupsTask = SearchGroupsAsync(query);

            var users = (await usersTask).ToList<DirectoryEntry>();
            var groups = (await groupsTask).ToList<DirectoryEntry>();

            return users.Concat(groups);
        }
    }
}
