﻿using Azure.Identity;

namespace PerceptApi.Services
{
    public class AzureAdConfig
    {
        public string Instance { get; set; } = AzureAuthorityHosts.AzurePublicCloud.ToString();
        public string ClientId { get; set; } = string.Empty;
        public string TenantId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        private string _graphApiEndpoint = string.Empty;
        public string GraphApiEndpoint
        {
            get => _graphApiEndpoint.EndsWith("/") ? _graphApiEndpoint : $"{_graphApiEndpoint}/";
            set => _graphApiEndpoint = value;
        }
    }
}