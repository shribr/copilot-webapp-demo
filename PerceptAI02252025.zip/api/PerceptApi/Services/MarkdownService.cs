﻿using ClosedXML.Excel;
using Markdig;
using Markdig.Extensions.Tables;
using Markdig.Syntax;
using PerceptApi.Services.Interfaces;
using System.Data;

namespace PerceptApi.Services
{
    public class MarkdownService : IMarkdownService
    {
        public IEnumerable<DataTable> ExtractDatatable(string markdown)
        {
            var dataTables = new List<DataTable>();
            var markdownPipeline = new MarkdownPipelineBuilder()
                .UsePipeTables()
                    .Build();
            var md = Markdown.Parse(markdown, markdownPipeline);
            var tables = md.Descendants().OfType<Table>();

            var tableIndex = 1;
            foreach (var table in tables)
            {
                var dataTable = new DataTable($"Sheet{tableIndex}");
                foreach (TableRow tableRow in table)
                {
                    if (tableRow.IsHeader)
                    {
                        foreach (TableCell cell in tableRow)
                        {
                            var cellValue = GetCellValue(cell);
                            dataTable.Columns.Add(new DataColumn(cellValue));
                        }
                    }
                    else
                    {
                        var row = dataTable.NewRow();
                        var i = 0;
                        foreach (TableCell cell in tableRow)
                        {
                            var cellValue = GetCellValue(cell);
                            row[i] = cellValue;
                            i++;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                dataTables.Add(dataTable);
                tableIndex++;
            }

            return dataTables;
        }

        public MemoryStream TableToExcel(string markdown)
        {
            using (var workbook = new XLWorkbook())
            {
                foreach (var table in ExtractDatatable(markdown))
                {
                    workbook.AddWorksheet(table);
                }

                var memoryStream = new MemoryStream();
                workbook.SaveAs(memoryStream);
                memoryStream.Seek(0, SeekOrigin.Begin);

                return memoryStream;
            }
        }

        private string GetCellValue(TableCell cell)
        {
            var paragraphBlock = cell.OfType<ParagraphBlock>().First();
            return paragraphBlock.Inline?.FirstChild?.ToString() ?? string.Empty;
        }
    }
}
