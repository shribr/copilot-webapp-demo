﻿using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data.Entities;
using PerceptApi.Data;
using PerceptApi.ErrorHandling;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;
using System.Linq.Expressions;

namespace PerceptApi.Services
{
    public abstract class BaseService<T>(IBaseRepository<T> repository) : IBaseService<T> where T : class
    {
        public void Add(T entity)
        {
            repository.Add(entity);
        }

        public void Update(T entity)
        {
            repository.Update(entity);
        }

        public void Remove(T entity)
        {
            repository.Remove(entity);
        }

        public virtual async Task<T> CreateAsync(T entity)
        {
            try
            {
                // CreateAsync in DB
                repository.Add(entity);
                await repository.SaveAsync();
            }
            catch (UniqueConstraintException ex)
            {
                throw new DataSourceException(ex?.InnerException?.Message);
            }
            return entity;
        }

        public virtual async Task<bool> DeleteAsync(Guid id)
        {
            var entity = repository.GetById(id);
            if (entity != null)
            {
                repository.Remove(entity);
                await repository.SaveAsync();
            }
            return true;
        }
        public virtual PagedResponse<T> Get(int page = 1, int pageSize = 25)
        {
            var query = repository.GetAll();
            return new PagedResponse<T>(page, pageSize, query);
        }

        public virtual T? GetById(Guid id, bool trackChanges = false)
        {
            return repository.GetById(id, trackChanges);
        }

        public virtual IQueryable<T> GetAllByCondition(Expression<Func<T, bool>> expression, bool trackChanges = false)
        {
            return repository.GetAllByCondition(expression, trackChanges);
        }

        public virtual IEnumerable<T> GetAll(bool trackChanges = false)
        {
            var query = repository.GetAll();

            if (!trackChanges)
            {
                query = query.AsNoTracking();
            }

            return query.ToList();
        }

        public virtual PagedResponse<T> GetPagedByCondition(Expression<Func<T, bool>> expression, bool trackChanges = false, int page = 1, int pageSize = 25)
        {
            var query = repository.GetAllByCondition(expression, trackChanges);
            return new PagedResponse<T>(page, pageSize, query);
        }

        public virtual async Task<T> UpdateAsync(T entity)
        {
            try
            {
                if (entity is IAuditableCreated && entity is IHasGuidId)
                {
                    var existingEntity = repository.GetById(((IHasGuidId)entity).Id);
                    if ((existingEntity == null))
                    {
                        throw new NotFoundException();
                    }
                    var current = (IAuditableCreated)existingEntity;
                    var entityToUpdate = (IAuditableCreated)entity;
                    entityToUpdate.CreatedBy = current.CreatedBy;
                    entityToUpdate.CreatedOn = current.CreatedOn;
                }
                repository.Update(entity);
                await repository.SaveAsync();
            }
            catch (UniqueConstraintException ex)
            {
                throw new DataSourceException(ex?.InnerException?.Message);
            }
            return entity;
        }

        public virtual async Task CommitTransactionAsync()
        {
            await repository.SaveAsync();
        }
    }
}
