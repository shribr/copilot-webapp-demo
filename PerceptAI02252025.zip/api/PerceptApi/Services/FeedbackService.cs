﻿using PerceptApi.Data.Entities;
using PerceptApi.Enums;
using PerceptApi.Models;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    public class FeedbackService(IBaseRepository<Feedback> repository) :
        AppBaseService<Feedback>(repository), IFeedbackService
    {
        private IBaseRepository<Feedback> _feedbackRepository = repository;

        public IEnumerable<Feedback> GetFiltered(Guid appId, Reaction reaction = Reaction.Any,
            DateTime? startDate = null, DateTime? endDate = null, string? search = null)
        {
            var query = base.GetByApp(appId);
            if (reaction != Reaction.Any)
            {
                query = query.Where(f => f.Reaction == reaction);
            }
            if (startDate.HasValue)
            {
                query = query.Where(f => f.CreatedOn >= startDate);
            }
            if (endDate.HasValue)
            {
                query = query.Where(f => f.CreatedOn <= endDate);
            }
            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(f =>
                (!string.IsNullOrWhiteSpace(f.Comment) && f.Comment.Contains(search)) ||
                f.Question.Contains(search) ||
                f.Response.Contains(search));
            }

            return query.ToList();
        }
    }
}