﻿using Microsoft.EntityFrameworkCore;
using PerceptApi.Agents;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.ErrorHandling;
using PerceptApi.Plugins;
using PerceptApi.Repositories.Interfaces;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Services
{
    public class AgentService(IBaseRepository<Agent> repository, IDataSourceService dataSourceService) :
        AppBaseService<Agent>(repository), IAgentService
    {

        public async Task<Agent> CreateAgentAsync(AgentRequestDto agentRequest)
        {
            var foundDataSources = agentRequest.DataSourceIds
                .Where(id => id != Guid.Empty)
                .Select(x =>
                {
                    var dataSource = dataSourceService.GetById(x) ?? throw new DataSourceNotFound($"Data source with ID {x} was not found.");
                    return dataSource;
                })
                .ToList();

            var invalidDataSources = foundDataSources
                .Where(dataSource => dataSource.ApplicationId != agentRequest.ApplicationId)
                .ToList();

            // Prevent adding data sources from other app registrations
            if (invalidDataSources.Count != 0)
            {
                throw new InvalidOperationException($"Mismatched ApplicationId found in DataSources: {string.Join(", ", invalidDataSources.Select(ds => ds.Id))}");
            }

            var newAgent = new Agent
            {
                ApplicationId = agentRequest.ApplicationId,
                Name = agentRequest.Name,
                Description = agentRequest.Description,
                Configuration = agentRequest.Configuration ?? new AgentConfiguration()
            };
            Add(newAgent);

            var agentDataSources = foundDataSources
                .Select(dataSource => new AgentDataSource
                {
                    AgentId = newAgent.Id,
                    DataSourceId = dataSource.Id,
                    PluginId = DeterminePluginId(dataSource.Type)
                })
                .ToList();

            newAgent.DataSources.AddRange(agentDataSources);

            // Save the changes again to persist the AgentDataSource records
            await repository.SaveAsync();

            return newAgent;
        }

        public async Task<Agent> PutAsync(Agent agentConfiguration, AgentRequestDto agentRequest)
        {
            var foundDataSources = agentRequest.DataSourceIds
                .Where(id => id != Guid.Empty)
                .Select(x =>
                {
                    var dataSource = dataSourceService.GetById(x) ?? throw new DataSourceNotFound($"Data source with ID {x} was not found.");
                    return dataSource;
                })
                .ToList();

            var invalidDataSources = foundDataSources
                .Where(dataSource => dataSource.ApplicationId != agentRequest.ApplicationId)
                .ToList();

            // Prevent adding data sources from other app registrations
            if (invalidDataSources.Count != 0)
            {
                throw new InvalidOperationException($"Mismatched ApplicationId found in DataSources: {string.Join(", ", invalidDataSources.Select(ds => ds.Id))}");
            }

            agentConfiguration.Configuration = agentRequest.Configuration ?? new AgentConfiguration();
            agentConfiguration.Name = agentRequest.Name;
            agentConfiguration.Description = agentRequest.Description;

            // Remove DataSources that are not present in the patch
            var dataSourcesToRemove = agentConfiguration.DataSources
                .Where(ds => !foundDataSources.Any(patchDs => patchDs.Id == ds.DataSourceId))
                .ToList();

            foreach (var dataSourceToRemove in dataSourcesToRemove)
            {
                agentConfiguration.DataSources.Remove(dataSourceToRemove);
            }

            // Add new DataSources that are not already present
            var dataSourcesToAdd = foundDataSources
                .Where(patchDs => !agentConfiguration.DataSources.Any(ds => ds.DataSourceId == patchDs.Id))
                .Select(dataSource => new AgentDataSource
                {
                    AgentId = agentConfiguration.Id,
                    DataSourceId = dataSource.Id,
                    PluginId = DeterminePluginId(dataSource.Type)
                })
                .ToList();

            agentConfiguration.DataSources.AddRange(dataSourcesToAdd);

            repository.Update(agentConfiguration);
            await repository.SaveAsync();
            return agentConfiguration;
        }

        public override Agent? GetById(Guid id, bool trackChanges = false)
        {
            return GetAllByCondition(x => x.Id.Equals(id), trackChanges)
                .Include(x => x.DataSources)
                .ThenInclude(x => x.DataSource)
                .FirstOrDefault();
        }

        public override IQueryable<Agent> GetByApp(Guid appId)
        {
            IQueryable<Agent> query = GetAllByCondition(a => a.ApplicationId.Equals(appId))
                .Include(x => x.DataSources)
                .ThenInclude(x => x.DataSource);
            return query;
        }

        private static Guid DeterminePluginId(DataSourceType type)
        {
            return type switch
            {
                DataSourceType.Documents => KernelMemoryPluginConstants.PluginId,
                DataSourceType.Database => SqlPluginConstants.PluginId,
                _ => throw new ArgumentOutOfRangeException(nameof(type), $"Unsupported DataSourceType: {type}")
            };
        }
    }
}
