﻿using PerceptApi.Data.Entities;

namespace PerceptApi.Services
{
    public class DirectoryEntryRoleChange<T>: DirectoryEntry where T : Enum
    {
        public T RoleFlagChange { get; set; }
    }
}