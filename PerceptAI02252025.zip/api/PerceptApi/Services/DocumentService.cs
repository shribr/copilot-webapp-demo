﻿using AutoMapper;
using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Azure;
using Microsoft.KernelMemory;
using Percept.Shared.Configuration;
using Percept.Shared.Constants;
using Percept.Shared.Data.Entities;
using Percept.Shared.Models;
using Percept.Shared.Services.Interfaces;
using PerceptApi.Data;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Extensions;
using PerceptApi.Services.Interfaces;
using System.Globalization;

using static Microsoft.KernelMemory.DocumentUploadRequest;

namespace PerceptApi.Services
{
    public class DocumentService : IDocumentService
    {
        private readonly ILogger<DocumentService> _logger;
        private readonly IKernelMemory _kernelMemory;
        private readonly AzureBlobsConfig _blobsConfig;
        private readonly IAzureClientFactory<BlobServiceClient> _azureFactory;
        private readonly ITaskService _taskService;
        private readonly IDocumentStatusService<PerceptDbContext> _documentStatusService;
        private readonly IMapper _mapper;

        public DocumentService(ILogger<DocumentService> logger, IKernelMemory kernelMemory, AzureBlobsConfig blobsConfig,
                                        IAzureClientFactory<BlobServiceClient> azureFactory, ITaskService taskService,
                                        IDocumentStatusService<PerceptDbContext> documentUploadStatusService,
                                        IMapper mapper)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _kernelMemory = kernelMemory ?? throw new ArgumentNullException(nameof(kernelMemory));
            _blobsConfig = blobsConfig ?? throw new ArgumentNullException(nameof(blobsConfig));
            _azureFactory = azureFactory ?? throw new ArgumentNullException(nameof(azureFactory));
            _taskService = taskService ?? throw new ArgumentNullException(nameof(taskService));
            _documentStatusService = documentUploadStatusService ?? throw new ArgumentNullException(nameof(documentUploadStatusService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<DocumentPipelineStatus?> ImportBlobStreamAsync(Stream stream, string blobFileName)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(new Uri($"https://{_blobsConfig.Account}.blob.{_blobsConfig.EndpointSuffix}"), new DefaultAzureCredential());

            // Get a reference to the container
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(ConfigurationProperties.FileStagingContainer);

            // Get a reference to the blob
            BlobClient blobClient = containerClient.GetBlobClient(blobFileName);

            var metadata = await blobClient.GetPropertiesAsync();
            var useMarkdown = metadata.Value.Metadata.ContainsKey(KernelMemoryConstants.UseMarkdownKey) && metadata.Value.Metadata[KernelMemoryConstants.UseMarkdownKey] == "true";

            var tags = new TagCollection();
            foreach (var item in metadata.Value.Metadata)
            {
                tags.Add(item.Key, [.. item.Value.Split(Tags.ValueDelimiter)]);
            }

            var fileName = Path.GetFileName(blobFileName);

            var paths = blobFileName.Split('/');
            if (paths.Count() < 2)
            {
                throw new InvalidOperationException("The file must have a root directory of the index name.");
            }
            var indexName = paths[0];

            IEnumerable<string>? steps = useMarkdown ? new List<string> {
                KernelMemoryConstants.MarkDownTextExtractionHandler,
                KernelMemoryConstants.MarkDownTextPartitioningHandler,
                Microsoft.KernelMemory.Constants.PipelineStepsGenEmbeddings,
                Microsoft.KernelMemory.Constants.PipelineStepsSaveRecords,
            } : null;

            DocumentPipelineStatus? status = null;
            var hasFailed = false;
            using (var ms = new MemoryStream())
            {
                stream.CopyTo(ms);
                var documentId = tags.ContainsKey($"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}internalDocumentId") ? tags[$"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}internalDocumentId"].First() : RandomId();
                string exception = string.Empty;
                try
                {
                    documentId = await _kernelMemory.ImportDocumentAsync(ms, fileName, documentId, tags, indexName, steps);
                }
                catch (Exception ex)
                {
                    exception = ex.Message;
                    hasFailed = true;

                    try
                    {
                        await _kernelMemory.DeleteDocumentAsync(documentId, indexName);
                    }
                    catch
                    {

                    }
                }
                finally
                {
                    status = new DocumentPipelineStatus(await _kernelMemory.GetDocumentStatusAsync(documentId, indexName));
                    status.ErrorMessage = exception;
                    status.Failed = hasFailed;
                    await _documentStatusService.UpdateStatusAsync(status, fileName);
                }
            }

            if (blobClient.Exists())
            {
                await blobClient.DeleteAsync();
            }

            return status;
        }

        public async Task UploadFiles(string index, TagCollection tags, List<UploadedFile> files, CancellationToken cancellationToken)
        {
            try
            {
                var blobClientService = _azureFactory.CreateClient(ConfigurationProperties.BlobClientServiceName);
                var blobStagingContainer = blobClientService.GetBlobContainerClient(ConfigurationProperties.FileStagingContainer);
                await blobStagingContainer.CreateIfNotExistsAsync(cancellationToken: cancellationToken);

                foreach (var file in files)
                {
                    string internalDocumentId = RandomId();
                    tags.Add($"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}file_name", file.FileName);
                    tags.Add($"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}internalDocumentId", internalDocumentId);
                    var blobClient = blobStagingContainer.GetBlobClient($"{index}/{file.FileName}");
                    await using var fileStream = file.FileContent;
                    await blobClient.UploadAsync(fileStream, new BlobUploadOptions
                    {
                        Metadata = tags.ToDictionary(x => x.Key, x => string.Join(Tags.ValueDelimiter, x.Value)),
                    });
                    var status = new DocumentPipelineStatus(internalDocumentId, index);
                    await _documentStatusService.UpdateStatusAsync(status, file.FileName);
                }
            }
            finally
            {
                // starts the import
                _taskService.StartProcess = true;
            }
        }

        public async Task<IEnumerable<BlobClient>> GetPendingFiles(CancellationToken cancellationToken)
        {
            var blobClientService = _azureFactory.CreateClient(ConfigurationProperties.BlobClientServiceName);
            var blobStagingContainer = blobClientService.GetBlobContainerClient(ConfigurationProperties.FileStagingContainer);
            if (await blobStagingContainer.ExistsAsync(cancellationToken: cancellationToken))
            {
                return blobStagingContainer.GetBlobs(cancellationToken: cancellationToken)
                    .Select(x => blobStagingContainer.GetBlobClient(x.Name));
            }
            return Array.Empty<BlobClient>();
        }

        private static string RandomId()
        {
            const string LocalDateFormat = "yyyyMMddhhmmssfffffff";
            return DateTimeOffset.Now.ToString(LocalDateFormat, CultureInfo.InvariantCulture) + Guid.NewGuid().ToString("N");
        }

        public async Task<IQueryable<DocumentWithTagsDto>> GetDocumentsAsync(DataSource dataSource, List<MemoryFilter>? filters, CancellationToken cancellationToken)
        {
            if (filters == null)
            {
                // Default filter if none specified is records tagged with tag eq '__part_n:0'
                // This should result in the first partition of each document
                filters = new List<MemoryFilter> { MemoryFilters.ByTag(Microsoft.KernelMemory.Constants.ReservedFilePartitionNumberTag, "0") };
            }

            Microsoft.KernelMemory.SearchResult answer = await _kernelMemory.SearchAsync(
                    query: "*",
                    index: dataSource.GetIndexName(),
                    filters: filters,
                    cancellationToken: cancellationToken)
            .ConfigureAwait(false);

            var documents = _mapper.Map<IEnumerable<DocumentWithTagsDto>>(answer.Results);
            foreach (var document in documents)
            {
                document.DataSourceId = dataSource.Id;
            };
            return documents.AsQueryable();
        }

        public async Task<DocumentWithTagsDto?> GetDocumentAsync(DataSource dataSource, string documentId, CancellationToken cancellationToken)
        {
            var filters = new List<MemoryFilter>
            {
                MemoryFilters.ByDocument(documentId).ByTag(Microsoft.KernelMemory.Constants.ReservedFilePartitionNumberTag, "0"),
            };
            var documents = await GetDocumentsAsync(dataSource, filters, cancellationToken);
            return documents.First();
        }

        public async Task DeleteFilesAsync(DataSource dataSource, IEnumerable<string> documentIds)
        {
            foreach (var documentId in documentIds)
            {
                var document = await GetDocumentAsync(dataSource, documentId, new CancellationToken());
                if (document == null)
                {
                    continue;
                }

                var indexName = dataSource.GetIndexName();
                await _documentStatusService.SetPendingDeleteAsync(indexName, documentId, document.SourceName);
            }

            _taskService.StartProcess = true;
        }

        public async Task DeleteDocumentAsync(DocumentUploadStatus status)
        {
            var hasFailed = false;

            string exception = string.Empty;
            try
            {
                await _kernelMemory.DeleteDocumentAsync(status.DocumentId, status.Index);
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                hasFailed = true;
            }
            finally
            {
                var pipelineStatus = new DocumentPipelineStatus(await _kernelMemory.GetDocumentStatusAsync(status.DocumentId, status.Index));
                pipelineStatus.ErrorMessage = exception;
                pipelineStatus.Failed = hasFailed;
                await _documentStatusService.UpdateStatusAsync(pipelineStatus, status.FileName);
            }
        }
    }
}
