﻿using Azure.Identity;
using ClosedXML;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Azure;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.KernelMemory;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using Microsoft.SemanticKernel;
using Percept.Shared.Configuration;
using Percept.Shared.Constants;
using PerceptApi.Attributes;
using PerceptApi.Constants;
using PerceptApi.Extensions;
using PerceptApi.Handlers;
using PerceptApi.Models;
using PerceptApi.Services.Interfaces;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PerceptApi.Services
{
    public static class IServiceCollectionExtensions
    {
        public static IServiceCollection AddApiAuth(this IServiceCollection services, IConfiguration configuration, bool isDev = false)
        {
            IdentityModelEventSource.ShowPII = isDev;
            IdentityModelEventSource.LogCompleteSecurityArtifact = true;

            // Adds Microsoft Identity platform (AAD v2.0) support to protect this Api
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
                {
                    configuration.Bind("AzureAd", options);
                    options.SaveToken = false;
                    options.RequireHttpsMetadata = false;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidIssuer = configuration["AzureAd:ValidIssuer"],
                        RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"
                    };
                    options.Events = new JwtBearerEvents
                    {
                        OnTokenValidated = async (context) =>
                        {
                            var claimsIdentity = context.Principal?.Identity as ClaimsIdentity;
                            var objectId = context.Principal?.GetObjectId();
                            var userService = context.HttpContext.RequestServices.GetService<IUserService>();
                            if (context.Principal != null && claimsIdentity != null && !string.IsNullOrEmpty(objectId) && userService != null)
                            {
                                var directoryEntry = await userService.GetOrCreateUserEntryAsync(new Guid(objectId), claimsIdentity);
                                // Add custom claims
                                claimsIdentity.AddClaim(new Claim(PerceptClaimTypes.UserId, directoryEntry.Id.ToString()));
                            }
                        },
                        OnAuthenticationFailed = async (context) =>
                        {
                            // Format the error message
                            var status = StatusCodes.Status401Unauthorized;
                            var message = Encoding.UTF8.GetBytes($"{status} ({(System.Net.HttpStatusCode)status}) -- {context.Exception.Message}");

                            // Reset the response and set it as 401 and why
                            context.NoResult();
                            context.Response.StatusCode = status;
                            context.Response.ContentType = "text/plain";
                            context.Response.ContentLength = message.Length;
                            await context.Response.Body.WriteAsync(message, 0, message.Length);
                        }
                    };
                })
                .AddPolicyScheme("JWT_or_OpenId", "JWT_or_OpenId", options =>
                {
                    options.ForwardDefaultSelector = context =>
                    {
                        string authorization = context.Request.Headers[HeaderNames.Authorization];
                        if (!string.IsNullOrEmpty(authorization) && authorization.StartsWith("Bearer "))
                        {
                            var token = authorization.Substring("Bearer ".Length).Trim();
                            var jwtHandler = new JwtSecurityTokenHandler();

                            return (jwtHandler.CanReadToken(token)) ? JwtBearerDefaults.AuthenticationScheme : OpenIdConnectDefaults.AuthenticationScheme;
                        }
                        return OpenIdConnectDefaults.AuthenticationScheme;
                    };
                })
                .AddMicrosoftIdentityWebApp(configuration, displayName: OpenIdConnectDefaults.AuthenticationScheme)
                .EnableTokenAcquisitionToCallDownstreamApi(options =>
                {
                    options.EnablePiiLogging = isDev;
                })
                .AddInMemoryTokenCaches();

            services.Configure<OpenIdConnectOptions>(
                OpenIdConnectDefaults.AuthenticationScheme, options =>
                {
                    options.ResponseType = OpenIdConnectResponseType.Code;
                    options.SaveTokens = true;
                });

            services.AddAuthorization(options =>
            {
                options.FallbackPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
            });


            return services;
        }

        public static IServiceCollection AddKernelMemory(this IServiceCollection services, IConfiguration configuration,
            Func<IKernelMemoryBuilder, IKernelMemoryBuilder>? withExtensions = null)
        {
           
            var searchClientConfig = new SearchClientConfig();
            var azureOpenAIEmbeddingConfig = new AzureOpenAIConfig();
            var azureOpenAIConfig = new AzureOpenAIConfig();
            var azureBlobs = new AzureBlobsConfig();
            var azureAISearch = new AzureAISearchConfig();
            var docIntelligenceConfig = new DocumentIntelligenceConfig();
            configuration
                .BindSection("KernelMemory:Retrieval:SearchClient", searchClientConfig)
                .BindSection("KernelMemory:Services:AzureBlobs", azureBlobs)
                .BindSection("KernelMemory:Services:AzureAISearch", azureAISearch)
                .BindSection("KernelMemory:Services:AzureOpenAIText", azureOpenAIConfig)
                .BindSection("KernelMemory:Services:AzureOpenAIEmbedding", azureOpenAIEmbeddingConfig)
                .BindSection("DocumentIntelligence", docIntelligenceConfig);

            services.AddAzureClients(clientBuilder =>
            {
                clientBuilder.AddBlobServiceClient(new Uri($"https://{azureBlobs.Account}.blob.{azureBlobs.EndpointSuffix}"))
                    .ConfigureOptions((options, provider) =>
                    {
                        if (!string.IsNullOrWhiteSpace(azureBlobs.AzureIdentityAudience))
                        {
                            options.Audience = azureBlobs.AzureIdentityAudience;
                        }
                    })
                    .WithCredential(new DefaultAzureCredential())
                    .WithName(ConfigurationProperties.BlobClientServiceName);

                clientBuilder.AddDocumentIntelligenceClient(new Uri(docIntelligenceConfig.Endpoint ?? "https://localhost"))
                // TODO: Update Doc Int Config to support explicit Audience for sovereign clouds
                //.ConfigureOptions((options, provider) =>
                                    //{
                                    //    if (!string.IsNullOrWhiteSpace(docIntelligenceConfig.AzureIdentityAudience))
                                    //    {
                                    //        options.Audience = azureBlobs.AzureIdentityAudience;
                                    //    }
                                    //})
                    .WithCredential(new DefaultAzureCredential())
                    .WithName(ConfigurationProperties.DocumentIntelligenceClientServiceName);
            });

            var memoryBuilder = new KernelMemoryBuilder(services)
                // run in a seperate hosted service
                .WithSearchClientConfig(searchClientConfig)
                .WithAzureBlobsDocumentStorage(azureBlobs)
                .WithAzureAISearchMemoryDb(azureAISearch)
                .WithAzureOpenAITextGeneration(azureOpenAIConfig)
                .WithAzureOpenAITextEmbeddingGeneration(azureOpenAIEmbeddingConfig);

            if (withExtensions != null)
            {
                withExtensions(memoryBuilder);
            }

            var memory = memoryBuilder.Build<MemoryServerless>();
            memory.Orchestrator.AddHandler<MarkDownTextExtractionHandler>(KernelMemoryConstants.MarkDownTextExtractionHandler);
            memory.Orchestrator.AddHandler<MarkDownTextPartitioningHandler>(KernelMemoryConstants.MarkDownTextPartitioningHandler);

            services.AddSingleton<IKernelMemory>(memory);
            services.AddSingleton<AzureOpenAIConfig>(azureOpenAIConfig); // using this to assign memory store plugin default model
            return services;
        }

        public static IKernelBuilder AddSemanticKernel(this IServiceCollection services, IConfiguration configuration)
        {
            var azureOpenAIConfig = new AzureOpenAIConfig();
            var azureTextEmbeddingConfig = new AzureOpenAIConfig();
            configuration.BindSection("KernelMemory:Services:AzureOpenAIText", azureOpenAIConfig);
            configuration.BindSection("KernelMemory:Services:AzureOpenAIEmbedding", azureTextEmbeddingConfig);

            var openAITextClient = AzureOpenAIClientBuilder.Build(azureOpenAIConfig);
            var openAIEmbeddingClient = AzureOpenAIClientBuilder.Build(azureTextEmbeddingConfig);

            // Add Semantic Kernel ChatCompletion capability
#pragma warning disable SKEXP0010 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
            return services.AddKernel()
                .AddAzureOpenAIChatCompletion(azureOpenAIConfig.Deployment, openAITextClient)
                .AddAzureOpenAITextEmbeddingGeneration(azureTextEmbeddingConfig.Deployment, openAIEmbeddingClient);

#pragma warning restore SKEXP0010 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
        }

        public static IServiceCollection AddSwagger(this IServiceCollection services)
        {
            return services.AddSwaggerGen(c =>
             {
                 c.UseAllOfForInheritance();
                 c.UseOneOfForPolymorphism();

                 c.SelectSubTypesUsing(baseType =>
                 {
                     if (baseType.HasAttribute<SwaggerBaseAttribute>())
                     {
                         return baseType.Assembly.GetTypes().Where(type => type.IsClass && !type.IsAbstract && type.IsSubclassOf(baseType));
                     }

                     return Enumerable.Empty<Type>();
                 }
                 );

                 c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                 {
                     In = ParameterLocation.Header,
                     Description = "Please insert JWT with Bearer into field",
                     Name = "Authorization",
                     Type = SecuritySchemeType.ApiKey
                 });
                 c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
         });
                 c.SwaggerDoc("v1", new OpenApiInfo { Title = "Percept API", Version = "v1" });
             });
        }
    }
}
