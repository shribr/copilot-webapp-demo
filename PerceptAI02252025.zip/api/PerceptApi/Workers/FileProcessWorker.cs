﻿using Percept.Shared.Services.Interfaces;
using PerceptApi.Data;
using PerceptApi.Services.Interfaces;

namespace PerceptApi.Workers
{
    public class FileProcessWorker : BackgroundService
    {
        /// <summary>
        ///     The worker interval in minutes
        /// </summary>
        private const int WORKER_INTERVAL_IN_MINUTES = 10;
        private readonly ILogger<FileProcessWorker> logger;
        private readonly IDocumentService documentService;
        private readonly IDocumentStatusService<PerceptDbContext> documentStatusService;
        private readonly ITaskService taskService;
        private readonly IWaiterService waiter;

        public FileProcessWorker(ILogger<FileProcessWorker> logger, IServiceScopeFactory serviceScopeFactory, ITaskService taskService, IWaiterService waiter)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.taskService = taskService ?? throw new ArgumentNullException(nameof(taskService));
            this.waiter = waiter ?? throw new ArgumentNullException(nameof(waiter));

            IServiceScope scope = serviceScopeFactory.CreateScope();
            documentService = scope.ServiceProvider.GetRequiredService<IDocumentService>();
            documentStatusService = scope.ServiceProvider.GetRequiredService<IDocumentStatusService<PerceptDbContext>>();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await ExecuteTaskAsync(stoppingToken);

                await waiter.WaitForAsync(() => !taskService.StartProcess,
                              TimeSpan.FromMinutes(WORKER_INTERVAL_IN_MINUTES),
                              TimeSpan.FromSeconds(5),
                              stoppingToken);
            }

        }

        public async Task ExecuteTaskAsync(CancellationToken stoppingToken)
        {
            taskService.IsBusy = true;
            try
            {
               await Import(stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error processing document tasks");
            }

            try
            {
                await Delete(stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error processing document tasks");
            }

            taskService.IsBusy = false;
            taskService.StartProcess = false;
        }

        private async Task Import(CancellationToken stoppingToken)
        {
            var pendingFiles = await documentService.GetPendingFiles(stoppingToken);

            foreach (var pendingFile in pendingFiles)
            {
                try
                {
                    await using (var stream = await pendingFile.OpenReadAsync())
                    {
                        await documentService.ImportBlobStreamAsync(stream, pendingFile.Name);
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error processing document");
                }
            }
        }

        private async Task Delete(CancellationToken stoppingToken)
        {
            var pendingFiles = documentStatusService.GetDocumentsToDelete();
            foreach (var pendingFile in pendingFiles)
            {
                try
                {
                    await documentService.DeleteDocumentAsync(pendingFile);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error processing document");
                }
            }
        }
    }
}
