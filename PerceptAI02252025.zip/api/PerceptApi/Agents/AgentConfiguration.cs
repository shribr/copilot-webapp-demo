﻿using PerceptApi.Agents.Interfaces;
namespace PerceptApi.Agents
{
    public class AgentConfiguration : IAgentConfiguration
    {
        public string Instructions { get; set; } = "You are an AI assistant to help answer user questions.";
        public int MaxConversations { get; set; } = 30;
    }
}
