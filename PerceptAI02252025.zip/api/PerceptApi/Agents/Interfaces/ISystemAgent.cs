﻿using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using PerceptApi.Data.Entities;
using PerceptApi.DTOs;
using PerceptApi.Models;

namespace PerceptApi.Agents.Interfaces
{
    public interface ISystemAgent
    {
        string SystemMessage { get; }
        Citations? Citations { get; }
        void Initialize(IConfiguration configuration, Agent agentConfiguration, AgentQuery query);
        Task<ChatMessageContent?> InvokeAsync(ChatHistory chatHistory);
    }
}