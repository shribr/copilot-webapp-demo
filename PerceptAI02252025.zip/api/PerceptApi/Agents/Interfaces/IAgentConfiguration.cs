﻿namespace PerceptApi.Agents.Interfaces
{
    public interface IAgentConfiguration
    {
        string Instructions { get; set; }
        int MaxConversations { get; set; }
    }
}