﻿using Microsoft.KernelMemory;
using Microsoft.KernelMemory.AI;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using PerceptApi.Agents.Interfaces;
using PerceptApi.Data.Entities;
using PerceptApi.DataSources;
using PerceptApi.DTOs;
using PerceptApi.Extensions;
using PerceptApi.Models;
using PerceptApi.Plugins;
using PerceptApi.Services;
using System.Reflection;
using System.Text.Json;

#pragma warning disable SKEXP0010 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
namespace PerceptApi.Agents
{
    public class SystemAgent : ISystemAgent
    {
        private const string CitationsKey = "Citations";
        private const string ChatHistoryTokensKey = "ChatHistoryTokens";
        private Kernel? kernel;
        private readonly OpenAIPromptExecutionSettings openAIPromptExecutionSettings;
        private string? _customSystemMessage;

        public string SystemMessage => (_customSystemMessage ?? "You are an AI assistant to help answer user questions.") + Environment.NewLine + PluginInstructions;

        private string PluginInstructions = string.Empty;

        public Citations? Citations { get; private set; }

        public SystemAgent()
        {
            openAIPromptExecutionSettings = new()
            {
                ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
            };
        }

        public async Task<ChatMessageContent?> InvokeAsync(ChatHistory chatHistory)
        {
            if (kernel is null)
            {
                throw new InvalidOperationException("System Agent has not been initialized.");
            }
            var chatCompletionService = kernel.GetRequiredService<IChatCompletionService>();
            var tokenizer = kernel.GetRequiredService<ITextEmbeddingGenerator>();

            var historyTokens = tokenizer.CountTokens(JsonSerializer.Serialize(chatHistory));
            kernel.Data.Add(ChatHistoryTokensKey, historyTokens);

            var result = await chatCompletionService.GetChatMessageContentAsync(
                            chatHistory,
                            executionSettings: openAIPromptExecutionSettings,
                            kernel: kernel);

            if (kernel.Data.ContainsKey(CitationsKey))
            {
                Citations = kernel.Data[CitationsKey] as Citations;
            }

            return result;
        }

        public void Initialize(IConfiguration configuration, Agent agent, AgentQuery query)
        {
            IServiceCollection serviceCollection = new ServiceCollection();

            var azureOpenAIConfig = new AzureOpenAIConfig();
            var azureTextEmbeddingConfig = new AzureOpenAIConfig();
            configuration.BindSection("KernelMemory:Services:AzureOpenAIText", azureOpenAIConfig);
            configuration.BindSection("KernelMemory:Services:AzureOpenAIEmbedding", azureTextEmbeddingConfig);

            var openAITextClient = AzureOpenAIClientBuilder.Build(azureOpenAIConfig);
            var openAIEmbeddingClient = AzureOpenAIClientBuilder.Build(azureTextEmbeddingConfig);

            // Add Semantic Kernel ChatCompletion capability
            var kernelBuilder = serviceCollection.AddKernel()
                .AddAzureOpenAIChatCompletion(azureOpenAIConfig.Deployment, openAITextClient)
                .AddAzureOpenAITextEmbeddingGeneration(azureTextEmbeddingConfig.Deployment, openAIEmbeddingClient);

            foreach (var dataSource in agent.DataSources)
            {
                var pluginConfiguration = dataSource.DataSource.Configuration;

                if (dataSource.DataSource.Type == DataSourceType.Documents)
                {
                    var kmConfig = dataSource.DataSource.Configuration as KernelMemoryDataSourceConfiguration ?? new();
                    kmConfig.IndexName = dataSource.DataSource.GetIndexName();
                    pluginConfiguration = kmConfig;
                }

                var semanticPlugin = GetSemanticPlugin(dataSource.PluginId);
                semanticPlugin.Initialize(serviceCollection, configuration, pluginConfiguration, query);
                kernelBuilder.Plugins.AddFromObject(semanticPlugin);

                PluginInstructions += semanticPlugin.SystemMessage + Environment.NewLine;
            }

            if (agent.DataSources.Count == 0)
            {
                serviceCollection.AddKernelMemory(configuration);
            }
            var serviceProvider = serviceCollection.BuildServiceProvider();
            kernel = serviceProvider.GetRequiredService<Kernel>();

            if (!string.IsNullOrEmpty(agent.Configuration.Instructions))
            {
                _customSystemMessage = agent.Configuration.Instructions;
            }
        }

        private static ISemanticKernelPlugin GetSemanticPlugin(Guid id)
        {
            return Assembly.GetExecutingAssembly().GetTypes().Where(type => typeof(ISemanticKernelPlugin).IsAssignableFrom(type) && !type.IsInterface && !type.IsAbstract)
                .Select(Activator.CreateInstance)
                .Cast<ISemanticKernelPlugin>()
                .FirstOrDefault(plugin => plugin.Id == id)
                ?? throw new InvalidOperationException($"No plugin found with id {id}.");
        }

    }
}
#pragma warning restore SKEXP0010 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
