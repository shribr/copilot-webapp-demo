﻿using System;
using System.Globalization;
using Microsoft.Net.Http.Headers;
using System.Text;

namespace Percept.Shared.Utils
{
    public static class HttpFileHelpers
    {
        public static EntityTagHeaderValue GenerateETag(DateTimeOffset lastWriteTime)
        {
            EntityTagHeaderValue etag = new EntityTagHeaderValue("\"" + Convert.ToBase64String(Encoding.UTF8.GetBytes(lastWriteTime.Ticks.ToString(CultureInfo.InvariantCulture))) + "\"");
            return etag;
        }
    }
}
