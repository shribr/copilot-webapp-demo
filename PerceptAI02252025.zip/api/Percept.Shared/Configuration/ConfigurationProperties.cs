﻿namespace Percept.Shared.Configuration
{
    public static class ConfigurationProperties
    {
        public const string SqlConnectionString = "SqlConnectionString";
        public const string BlobClientServiceName = "PerceptAI_BlobClient";
        public const string FileStagingContainer = "fileupload-staging";
        public const string CacheExpirationInHours = "CacheExpirationInHours";
        public const string DocumentIntelligenceClientServiceName = "DocumentIntelligenceClient";
    }
}
