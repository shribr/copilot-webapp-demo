﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;

namespace Percept.Shared.Configuration
{
    public static class WebApplicationExtensions
    {
        public static void UseApiAuth(this WebApplication app)
        {
            app.UseAuthentication();
            app.UseAuthorization();
        }

        public static void UseCors(this WebApplication app, IConfiguration configuration)
        {
            CorsOptions options = new();
            configuration.Bind("CORS", options);
            app.UseCors(x => x
                .WithOrigins(options.AllowedOrigins.Split(","))
                .AllowCredentials()
                .WithExposedHeaders("Content-Disposition")
                .WithHeaders(options.AllowedHeaders.Split(","))
                .WithMethods(options.AllowedMethods.Split(",")));
        }
    }
}
