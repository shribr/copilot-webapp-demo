﻿namespace Percept.Shared.Events
{
    public class PerceptEvent(int eventIdBase, string eventName)
    {
        private int _eventId;
        public required int EventId
        {
            get { return eventIdBase + _eventId; }
            set { _eventId = value; }
        }
        public string EventName { get { return eventName; } }
        public required string Description { get; set; }
    }
}