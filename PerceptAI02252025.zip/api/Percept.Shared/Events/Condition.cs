﻿namespace Percept.Shared.Events
{
    public enum Condition
    {
        Success,
        Failure
    }
}