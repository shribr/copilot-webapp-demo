﻿using System;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace Percept.Shared.Converter
{
    public class EnumNameConverter<T> : JsonConverter<T> where T : Enum
    {
        public override T Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            var enumString = reader.GetString();
            if (Enum.TryParse(typeof(T), enumString, out var result))
            {
                return (T)result;
            }
            throw new JsonException($"Unable to convert \"{enumString}\" to Enum \"{typeof(T)}\"");
        }

        public override void Write(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString());
        }
    }
}
