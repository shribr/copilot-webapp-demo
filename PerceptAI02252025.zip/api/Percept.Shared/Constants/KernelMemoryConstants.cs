﻿namespace Percept.Shared.Constants
{
    public class KernelMemoryConstants
    {
        public const string MarkDownTextExtractionHandler = "MarkDownTextExtractionHandler";
        public const string MarkDownTextPartitioningHandler = "MarkDownTextPartitioningHandler";
        public const string UseMarkdownKey = $"{Microsoft.KernelMemory.Constants.ReservedTagsPrefix}UseMarkdown";
    }
}
