﻿namespace Percept.Shared.Constants
{
    public static class Tags
    {
        public static readonly string ValueDelimiter = "|";
    }
}
