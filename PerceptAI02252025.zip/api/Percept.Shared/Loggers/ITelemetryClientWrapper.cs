using Microsoft.ApplicationInsights;
using System.Collections.Generic;

namespace Percept.Shared.Loggers
{
    public interface ITelemetryClientWrapper
    {
        public TelemetryClient telemetryClient { get; set; }
        void Initialize(TelemetryClient telemetryClient);
        void CustomEvent(string eventName, Dictionary<string, string>? parameters);
    }
}
