using Microsoft.ApplicationInsights;
using System.Collections.Generic;

namespace Percept.Shared.Loggers
{
    public class TelemetryClientWrapper : ITelemetryClientWrapper
    {
        public TelemetryClient telemetryClient { get; set; }

        public void Initialize(TelemetryClient tc)
        {
            telemetryClient = tc;
        }

        public void CustomEvent(string eventName, Dictionary<string, string>? parameters)
        {
            telemetryClient.TrackEvent(eventName, parameters);
        }
    }
}
