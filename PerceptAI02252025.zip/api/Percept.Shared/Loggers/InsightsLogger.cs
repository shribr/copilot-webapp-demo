﻿using Microsoft.Extensions.Logging;
using Percept.Shared.Events;
using System.Text.Json;
using Microsoft.ApplicationInsights;
using System.Collections.Generic;
using System;

namespace Percept.Shared.Loggers
{
    public static class InsightsLogger
    {
        private static ITelemetryClientWrapper _telemetryClientWrapper = new TelemetryClientWrapper();

        public static void AddTelemetryClient(TelemetryClient telemetryClient)
        {
            if (telemetryClient == null)
            {
                throw new ArgumentNullException(nameof(telemetryClient), "TelemetryClient cannot be null");
            }
            _telemetryClientWrapper.Initialize(telemetryClient);
            _telemetryClientWrapper.CustomEvent("Initialize telemetry client", null);
        }

        private static void Audit<T>(ILogger logger, PerceptEvent perceptEvent, Condition condition, T? args)
        {
            var logLevel = condition == Condition.Success ? LogLevel.Information : LogLevel.Error;
            var eventId = new EventId(perceptEvent.EventId, perceptEvent.EventName);
            var message = $"Audit {condition}: {perceptEvent.Description}";

            if (_telemetryClientWrapper.telemetryClient == null)
            {
                logger.Log(logLevel, eventId, $"{message} {JsonSerializer.Serialize(args)}");
            }
            else
            {
                _telemetryClientWrapper.CustomEvent(perceptEvent.EventName, new Dictionary<string, string>
                {
                    { "LogLevel", logLevel.ToString() },
                    { "EventId", eventId.Id.ToString() },
                    { "Message", message },
                    { "Args", JsonSerializer.Serialize(args) }
                });
            }
        }

        public static void AuditSuccess<T>(ILogger logger, PerceptEvent perceptEvent, T? args)
        {
            Audit(logger, perceptEvent, Condition.Success, args);
        }

        public static void AuditFailure<T>(ILogger logger, PerceptEvent perceptEvent, T? args)
        {
            Audit(logger, perceptEvent, Condition.Failure, args);
        }
    }
}