﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Percept.Shared.Developer
{
    public class DeveloperAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        public DeveloperAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder)
            : base(options, logger, encoder)
        {
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var claims = new[] {
                new Claim(ClaimTypes.Name, "DeveloperUser"),
                new Claim("oid", "C97F1F5B-D8C8-4CC7-AE49-C2EF7FFFB5B1"), // Mimic AzureAd Object ID Claim
                new Claim("scp", "User.All Admin.All")
            };
            var identity = new ClaimsIdentity(claims, "Developer");
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, "Developer");

            return await Task.FromResult(AuthenticateResult.Success(ticket));
        }
    }
}
