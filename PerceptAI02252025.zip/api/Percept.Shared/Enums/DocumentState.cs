﻿namespace Percept.Shared.Enums
{
    public enum DocumentState
    {
        Received = 0,
        Processing = 1,
        Completed = 2,
        Error = 3,
        PendingDelete = 4,
        Deleted = 5
    }
}
