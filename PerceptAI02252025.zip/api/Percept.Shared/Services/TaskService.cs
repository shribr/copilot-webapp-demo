﻿using Percept.Shared.Services.Interfaces;

namespace Percept.Shared.Services
{
    /// <summary>
    ///     Class TaskService.
    ///     Implements the <see cref="ITaskService" />
    /// </summary>
    /// <inheritdoc />
    /// <seealso cref="ITaskService" />
    public class TaskService : ITaskService
    {
        /// <summary>
        ///     Gets or sets a value indicating whether this instance is busy.
        /// </summary>
        /// <value><c>true</c> if this instance is busy; otherwise, <c>false</c>.</value>
        public bool IsBusy { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [start process].
        /// </summary>
        /// <value><c>true</c> if [start process]; otherwise, <c>false</c>.</value>
        public bool StartProcess { get; set; }
    }
}
