﻿namespace Percept.Shared.Services.Interfaces
{
    public interface ITaskService
    {
        bool IsBusy { get; set; }
        bool StartProcess { get; set; }
    }
}