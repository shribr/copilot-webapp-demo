﻿using Percept.Shared.Data;
using Percept.Shared.Data.Entities;
using Percept.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Percept.Shared.Services.Interfaces
{
    public interface IDocumentStatusService<T> where T: IDocumentUploadStatusDbContext
    {
        Task ArchiveDocument(Guid id);
        Task<DocumentUploadStatus?> GetDocument(Guid id);
        Task DeleteDocumentUploadStatusAsync(string indexName, string documentId);
        Task SetPendingDeleteAsync(string indexName, string documentId, string fileName);
        IQueryable<DocumentUploadStatus> GetDocuments(string indexName, bool includeCompleted = false);
        IEnumerable<DocumentUploadStatus> GetDocumentsToDelete();
        Task UpdateStatusAsync(DocumentPipelineStatus? status, string fileName);
    }
}