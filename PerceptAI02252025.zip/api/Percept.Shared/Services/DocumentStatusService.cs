using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data;
using Percept.Shared.Data.Entities;
using Percept.Shared.Enums;
using Percept.Shared.Models;
using Percept.Shared.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Percept.Shared.Services
{
    // Note: This service is primarilly used by the File Worker and will have threading and
    // Open DB Connection issues if you attempt to use BaseService and Repository pattern
    public class DocumentStatusService<T>(IDbContextFactory<T> dbContextFactory) : IDocumentStatusService<T> where T : DbContext, IDocumentUploadStatusDbContext
    {
        public IEnumerable<DocumentUploadStatus> GetDocumentsToDelete()
        {
            IEnumerable<DocumentUploadStatus> result;
            using (var dbContext = dbContextFactory.CreateDbContext())
            {
                result = dbContext.DocumentUploadStatus.Where(
                    x => x.RemainingSteps.Contains(Microsoft.KernelMemory.Constants.PipelineStepsDeleteDocument)
                    ).ToList();
            }
            return result;
        }

        public Task<DocumentUploadStatus?> GetDocument(Guid id)
        {
            DocumentUploadStatus? result;
            using (var dbContext = dbContextFactory.CreateDbContext())
            {
                result = dbContext.DocumentUploadStatus.Where(x => x.Id == id).FirstOrDefault();
            }
            return Task.FromResult(result);
        }

        public IQueryable<DocumentUploadStatus> GetDocuments(string indexName, bool includeCompleted = false)
        {
            IQueryable<DocumentUploadStatus> result;
            var dbContext = dbContextFactory.CreateDbContext();

            result = dbContext.DocumentUploadStatus.Where(x =>
            x.Index == indexName &&
            (includeCompleted ? true :
            x.State != DocumentState.Completed && x.State != DocumentState.Deleted && x.isArchived != true
            )).OrderByDescending(s => s.LastUpdated);

            return result;
        }

        public async Task UpdateStatusAsync(DocumentPipelineStatus? status, string fileName)
        {
            if (status is null)
            {
                return;
            }

            using (var dbContext = dbContextFactory.CreateDbContext())
            {
                var documentUploadStatus = dbContext.DocumentUploadStatus.Where(x => x.DocumentId == status.DocumentId).FirstOrDefault();

                if (documentUploadStatus is null)
                {
                    documentUploadStatus = new DocumentUploadStatus()
                    {
                        Id = Guid.NewGuid(),
                        DocumentId = status.DocumentId,
                        FileName = fileName,
                        Index = status.Index,
                        State = DocumentStatusService<T>.GetStatus(status),
                        CompletedSteps = status.CompletedSteps,
                        RemainingSteps = status.RemainingSteps,
                        LastUpdated = status.LastUpdate,
                        ErrorMessage = status.ErrorMessage,
                        isArchived = false
                    };

                    dbContext.DocumentUploadStatus.Add(documentUploadStatus);
                }
                else
                {
                    documentUploadStatus.ErrorMessage = status.ErrorMessage;
                    documentUploadStatus.State = DocumentStatusService<T>.GetStatus(status);
                    documentUploadStatus.CompletedSteps = status.CompletedSteps;
                    documentUploadStatus.RemainingSteps = status.RemainingSteps;
                    documentUploadStatus.LastUpdated = status.LastUpdate;

                    dbContext.DocumentUploadStatus.Update(documentUploadStatus);
                }
                await dbContext.SaveChangesAsync();
            }
        }

        public async Task ArchiveDocument(Guid id)
        {
            using (var dbContext = dbContextFactory.CreateDbContext())
            {
                var documentUploadStatus = dbContext.DocumentUploadStatus.Where(x => x.Id == id).FirstOrDefault();

                if (documentUploadStatus is not null)
                {
                    documentUploadStatus.isArchived = true;
                    dbContext.DocumentUploadStatus.Update(documentUploadStatus);
                    await dbContext.SaveChangesAsync();
                }
            }
        }

        private static DocumentState GetStatus(DocumentPipelineStatus status)
        {
            if (status.Failed)
            {
                return DocumentState.Error;
            }

            // PendingDelete Status
            if (status.RemainingSteps.Contains(Microsoft.KernelMemory.Constants.PipelineStepsDeleteDocument))
            {
                return DocumentState.PendingDelete;
            }

            if (status.CompletedSteps.Contains(Microsoft.KernelMemory.Constants.PipelineStepsDeleteDocument))
            {
                return DocumentState.Deleted;
            }

            // Upload Status
            if (status.Completed)
            {
                return DocumentState.Completed;
            }

            if (status.RemainingSteps.Count != 0 && status.CompletedSteps.Count !=0)
            {
                return DocumentState.Processing;
            }

            return DocumentState.Received;
        }

        public async Task SetPendingDeleteAsync(string indexName, string documentId, string fileName)
        {
            var status = new DocumentPipelineStatus(documentId, indexName);
            status.RemainingSteps.Add(Microsoft.KernelMemory.Constants.PipelineStepsDeleteDocument);
            await UpdateStatusAsync(status, fileName);
            return;
        }

        public async Task DeleteDocumentUploadStatusAsync(string indexName, string documentId)
        {
            using (var dbContext = dbContextFactory.CreateDbContext())
            {
                var entity = dbContext.DocumentUploadStatus.Where(x => x.Index == indexName && x.DocumentId == documentId).FirstOrDefault();

                if (entity is not null)
                {
                    dbContext.DocumentUploadStatus.Remove(entity);
                    await dbContext.SaveChangesAsync();
                }
            }

            return;
        }
    }
}