﻿using Microsoft.EntityFrameworkCore;
using Percept.Shared.Data.Entities;

namespace Percept.Shared.Data
{
    public interface IDocumentUploadStatusDbContext
    {
        DbSet<DocumentUploadStatus> DocumentUploadStatus { get; set; }
    }
}
