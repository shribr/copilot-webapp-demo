﻿using System;
using System.Collections.Generic;
using Percept.Shared.Enums;

namespace Percept.Shared.Data.Entities
{
    public class DocumentUploadStatus : IHasGuidId
    {
        public required Guid Id { get; set; }
        public required string DocumentId { get; set; }
        public required string FileName { get; set; }
        public required string Index { get; set; }
        public required DocumentState State { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
        public DateTimeOffset LastUpdated { get; set; }
        public List<string> CompletedSteps { get; set; } = new();
        public List<string> RemainingSteps { get; set; } = new();
        public bool isArchived { get; set; } = false;
    }
}
