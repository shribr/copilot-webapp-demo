﻿using System;

namespace Percept.Shared.Data.Entities
{
    public interface IHasGuidId
    {
        Guid Id { get; }
    }
}
