﻿using Microsoft.KernelMemory;
using System;

namespace Percept.Shared.Models
{
    public class DocumentPipelineStatus : DataPipelineStatus
    {
        public string ErrorMessage { get; set; } = string.Empty;
        public bool Failed { get; set; }

        public DocumentPipelineStatus(DataPipelineStatus status)
        {
            CompletedSteps = status.CompletedSteps;
            Empty = status.Empty;
            Index = status.Index;
            DocumentId = status.DocumentId;
            Tags = status.Tags;
            Creation = status.Creation;
            LastUpdate = status.LastUpdate;
            Steps = status.Steps;
            RemainingSteps = status.RemainingSteps;
            CompletedSteps = status.CompletedSteps;
            Completed = status.Completed;
        }

        public DocumentPipelineStatus(string documentId, string index)
        {
            CompletedSteps = new();
            Empty = new();
            Index = index;
            DocumentId = documentId;
            Tags = new();
            Creation = DateTimeOffset.UtcNow;
            LastUpdate = DateTimeOffset.UtcNow;
            Steps = new();
            RemainingSteps = new();
            CompletedSteps = new();
            Completed = false;
        }
    }
}
