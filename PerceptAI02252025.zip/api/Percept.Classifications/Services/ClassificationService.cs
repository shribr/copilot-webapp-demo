﻿using Percept.Classifications.Data;

namespace Percept.Classifications.Services
{
    public class ClassificationService(IClassificationDbContext context) : IClassificationService
    {
        public IEnumerable<ClassificationControlConfiguration> GetConfigurations()
        {
            var controls = context.ClassificationControls
                .OrderBy(w => w.Label)
                .AsEnumerable();
            return controls;
        }

        public IEnumerable<ClassificationControlValueOption> GetValueOptions()
        {
            var options = context.ClassificationValueOptions
                 .OrderBy(w => w.ControlId)
                 .ThenBy(w => w.GroupName)
                 .ThenBy(w => w.Label)
                 .AsEnumerable();
            return options;
        }
    }
}
