﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Percept.Classifications.Data;

namespace Percept.Classifications.Services
{
    public static class ConfigureServices
    {
        public static void AddClassifications(this IServiceCollection services, IConfiguration configuration, Type hostDbContext)
        {
            services.AddScoped<IClassificationService, ClassificationService>();
            services.AddScoped(typeof(IClassificationDbContext), hostDbContext);

            // Ensure controllers from Percept.Workspaces are added
            services.AddControllers(options =>
            {
                options.ModelMetadataDetailsProviders.Add(new SystemTextJsonValidationMetadataProvider());
            }).AddApplicationPart(assembly: typeof(Controllers.ClassificationsController).Assembly);
        }
    }
}
