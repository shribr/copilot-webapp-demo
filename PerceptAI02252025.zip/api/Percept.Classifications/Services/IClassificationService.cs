﻿using Percept.Classifications.Data;

namespace Percept.Classifications.Services
{
    public interface IClassificationService
    {
        IEnumerable<ClassificationControlConfiguration> GetConfigurations();
        IEnumerable<ClassificationControlValueOption> GetValueOptions();
    }
}