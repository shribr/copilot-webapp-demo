Implment the Interface on your host Db Context

    public class PerceptDbContext(DbContextOptions<PerceptDbContext> options, IHttpContextAccessor httpContext) : 
        DbContext(options), IClassificationDbContext
                  
        public DbSet<ClassificationControlConfiguration> ClassificationControls { get;set; }
        public DbSet<ClassificationControlValueOption> ClassificationValueOptions { get; set; }
        public DbContext Context => this;

Add Classifications Serialization Support in your DbContext to store the classification values on Entities as JSON
        
    modelBuilder.EnableSerializationOfClassifications();

Register the Services in Program or Startup passing the configuration and the type of your DbContext

    Services.AddClassifications(configuration, typeof(PerceptDbContext));

Add an EF Migration to create the tables
    
    PM> add-migration Classifications -Context PerceptDbContext

Update the database

    PM> update-database -Context PerceptDbContext