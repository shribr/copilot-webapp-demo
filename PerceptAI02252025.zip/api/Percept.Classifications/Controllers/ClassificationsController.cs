﻿using Microsoft.AspNetCore.Mvc;
using Percept.Classifications.Data;
using Percept.Classifications.Services;

namespace Percept.Classifications.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClassificationsController(IClassificationService service) : ControllerBase
    {
        [HttpGet("Controls")]
        public ActionResult<IEnumerable<ClassificationControlConfiguration>> GetConfigurations()
        {
            var configurations = service.GetConfigurations();
            return Ok(configurations);
        }

        [HttpGet("ValueOptions")]
        public ActionResult<IEnumerable<ClassificationControlValueOption>> ValueOptions()
        {
            var valueOptions = service.GetValueOptions();
            return Ok(valueOptions);
        }
    }
}
