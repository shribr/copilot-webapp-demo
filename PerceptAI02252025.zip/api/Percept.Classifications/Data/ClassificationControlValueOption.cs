﻿using System.ComponentModel.DataAnnotations;

namespace Percept.Classifications.Data
{
    public class ClassificationControlValueOption
    {
        public int Id { get; set; } // DB Primary key
        public string? GroupName { get; set; } 
        [Required(ErrorMessage = "ControlId is required")]
        public required string ControlId { get; set; }
        [Required(ErrorMessage = "OptionValue is required")]
        public required string Value { get; set; }
        [Required(ErrorMessage = "OptionLabel is required")]
        public required string Label { get; set; }
        public string? HelperText { get; set; }
        [Required(ErrorMessage = "MarkingColor is required")]
        public required string MarkingColor { get; set; }
    }
}
