﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Text.Json;

namespace Percept.Classifications.Data
{
    public static class EntityFrameworkExtensions
    {
        public static void EnableSerializationOfClassifications(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClassificationControlConfiguration>()
                .Property(e => e.ParentValues)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, (JsonSerializerOptions)null),
                    v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions)null),
                    new ValueComparer<ICollection<string>>(
                        (c1, c2) => c1.SequenceEqual(c2),
                        c => c.Aggregate(0, (a, v) => HashCode.Combine(a, v.GetHashCode())),
                        c => (ICollection<string>)c.ToList())
                    );
        }
    }
}
