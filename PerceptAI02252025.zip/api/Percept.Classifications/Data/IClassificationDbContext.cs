﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace Percept.Classifications.Data
{
    public interface IClassificationDbContext: ICurrentDbContext
    {
        public DbSet<ClassificationControlConfiguration> ClassificationControls { get; set; }
        public DbSet<ClassificationControlValueOption> ClassificationValueOptions { get; set; }
    }
}
