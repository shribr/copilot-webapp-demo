﻿

INSERT INTO ClassificationControls (Id, ParentControl, ParentValues, [Label], HelperText, AllowMultiple, [Required]) VALUES
('classification', '/', NULL, 'Classification', 'The classification attribute (String) is used to identify the highest classification of information included within a document (Banner Line - Resource Level) or within a given portion of a document (Portion Marking - Portion Level). This attribute is always used in conjunction with the ownerProducer attribute. Taken together, these two attributes specify the classification category and type of classification (US, non-US, or Joint).', 0, 1),
('sciControls', NULL, NULL, 'SCI Controls', 'The sciControls attribute (Array[String]) identifies one or more sensitive compartmented information control systems.', 1, 0),
('sarIdentifiers', NULL, NULL, 'SAR Identifiers', 'The sarIdentifiers attribute (Array[String]) identifies one or more defense or intelligence programs for which special access is required.', 1, 0),
('cui-dissemination', 'classification', '["CUI"]', 'Limited Dissemination Control', 'The disseminationControls attribute (Array[String]) identifies one or more non-IC dissemination controls.', 1, 0),
('releasableTo', NULL, NULL, 'Releasable To', 'The releasableTo attribute (Array[String]) identifies one or more foreign governments or international organizations to which the information is releasable.', 1, 0),
('nonICMarkings', NULL, NULL, 'Non-IC Markings', 'The nonICMarkings attribute (Array[String]) identifies one or more non-IC markings.', 1, 0),
('cui-categories', 'classification', '["CUI"]', 'CUI Categories', 'ADD A DESCRIPTION FOR CUI CATEGORIES', 1, 0)