﻿using System.ComponentModel.DataAnnotations;

namespace Percept.Classifications.Data
{
    public class ClassificationControlConfiguration
    {
        public string? ParentControl { get; set; }
        public ICollection<string>? ParentValues { get; set; }
        [Required(ErrorMessage = "Id is required")]
        public required string Id { get; set; }
        [Required(ErrorMessage = "Label is required")]
        public required string Label { get; set; }
        public string? HelperText { get; set; }
        public bool AllowMultiple { get; set; }
        public bool Required { get; set; }
    }
}
