# Release Notes

All notable changes to this project will be documented in this file.

## 1.0.1

### Removed

- Rolled back multi-datasource chat support.

## 1.0.0

### Added

#### UI Features

- Added support for customizing the help link name.

  **Example configuration:**

  ```plaintext
   NEXT_HELP_URL_NAME="How to Use AI Assistant"
  ```

#### API Features

- Enabled multi-datasource chat support by introducing a Semantic Kernel Agent Framework, allowing for multiple agent scenarios. UI support for this feature is coming soon.
- Introduced idempotent SQL scripts for database migrations, available in the `Migrations` folder within the `Percept_Api` artifact.  These scripts are the recommended method for applying Percept schema changes and keeping the database up to date.

### Fixed

#### UI Fixes

- Improved the formatting of ordered and unordered lists in chat responses.

#### API Fixes

- Resolved an issue with handling large text partitions in the Markdown Embeddings Handler by splitting them into smaller, overlapping chunks.
- Updated the Kernel Memory Plugin to use the `MaxMatchesCount` app setting, limiting the maximum number of results returned by `SearchAsync`.

## January 31, 2025

### Added

#### UI Features

- Added an optional help documentation link in the **User Profile Menu**.
- To enable this link, set the front-end App Setting value for `NEXT_HELP_URL` to the URL of the help documentation, ensuring the link is accessible from users client browser.

  **Example configuration:**

  ```plaintext
  NEXT_HELP_URL=https://dev.azure.com/myCollection/_git/myrepo?path=/Documentation/SolutionOverview.md&_a=preview
  ```

- Knowledge Sources now display a list of associated Agents.

### Fixed

- Prevented deletion of Knowledge Sources that are associated with an Agent.
